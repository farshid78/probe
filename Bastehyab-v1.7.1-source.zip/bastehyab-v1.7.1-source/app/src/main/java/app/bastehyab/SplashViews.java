package app.bastehyab;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapShader;
import android.graphics.Matrix;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.view.View;

/** Custom drawing for the opening / creator screen. Purely visual; no touch handling. */
final class SplashViews {
    private SplashViews() { }

    static float dp(View v, float value) {
        return value * v.getResources().getDisplayMetrics().density;
    }

    /** Deep cyber-network backdrop: fine grid, connected nodes and restrained data glows. */
    static final class Backdrop extends View {
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint grid = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint links = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint nodes = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint rings = new Paint(Paint.ANTI_ALIAS_FLAG);

        private final float[][] points = {
                {0.06f,0.19f},{0.18f,0.10f},{0.31f,0.20f},{0.46f,0.08f},{0.61f,0.18f},
                {0.78f,0.09f},{0.93f,0.22f},{0.10f,0.43f},{0.25f,0.37f},{0.42f,0.49f},
                {0.62f,0.39f},{0.83f,0.48f},{0.96f,0.40f},{0.06f,0.69f},{0.23f,0.79f},
                {0.39f,0.67f},{0.58f,0.82f},{0.75f,0.69f},{0.93f,0.82f},{0.48f,0.94f}
        };
        private final int[][] edges = {
                {0,1},{1,2},{2,3},{3,4},{4,5},{5,6},{0,7},{7,8},{8,2},{8,9},
                {9,10},{10,4},{10,11},{11,12},{7,13},{13,14},{14,15},{15,9},{15,16},
                {16,17},{17,11},{17,18},{16,19}
        };

        Backdrop(Context c) {
            super(c);
            grid.setStyle(Paint.Style.STROKE);
            grid.setStrokeWidth(dp(this, 0.7f));
            grid.setColor(UI.light ? 0x18748AB8 : 0x172F73A8);
            links.setStyle(Paint.Style.STROKE);
            links.setStrokeWidth(dp(this, 1.0f));
            links.setColor(UI.light ? 0x286B82B8 : 0x3C6C58B8);
            nodes.setColor(UI.light ? 0x88315CFF : 0xAA55DDF5);
            rings.setStyle(Paint.Style.STROKE);
            rings.setStrokeWidth(dp(this, 1.1f));
            rings.setColor(0x224E98D8);
        }

        @Override protected void onDraw(Canvas cv) {
            float w = getWidth(), h = getHeight();
            if (w <= 0 || h <= 0) return;
            fill.setShader(new LinearGradient(0, 0, w, h,
                    UI.light ? new int[]{0xFFF5F7FC, 0xFFEAF0FA, 0xFFF8FAFF} : new int[]{0xFF101A2E, 0xFF172640, 0xFF0D1424}, null, Shader.TileMode.CLAMP));
            cv.drawRect(0, 0, w, h, fill);
            fill.setShader(new RadialGradient(w * 0.82f, h * 0.18f, dp(this, 330),
                    UI.light ? new int[]{0x337B8DFF, 0x007B8DFF} : new int[]{0x554B2B9A, 0x004B2B9A}, null, Shader.TileMode.CLAMP));
            cv.drawRect(0, 0, w, h, fill);
            fill.setShader(new RadialGradient(w * 0.12f, h * 0.78f, dp(this, 300),
                    UI.light ? new int[]{0x3320BFA9, 0x0020BFA9} : new int[]{0x3A087D9C, 0x00087D9C}, null, Shader.TileMode.CLAMP));
            cv.drawRect(0, 0, w, h, fill);

            float step = dp(this, 44);
            for (float x = 0; x < w; x += step) cv.drawLine(x, 0, x, h, grid);
            for (float y = 0; y < h; y += step) cv.drawLine(0, y, w, y, grid);

            for (int[] edge : edges) {
                float x1 = points[edge[0]][0] * w, y1 = points[edge[0]][1] * h;
                float x2 = points[edge[1]][0] * w, y2 = points[edge[1]][1] * h;
                cv.drawLine(x1, y1, x2, y2, links);
            }
            for (int i = 0; i < points.length; i++) {
                float x = points[i][0] * w, y = points[i][1] * h;
                cv.drawCircle(x, y, dp(this, i % 4 == 0 ? 2.4f : 1.5f), nodes);
            }

            float cx = w * 0.5f, cy = h * 0.35f;
            cv.drawCircle(cx, cy, dp(this, 112), rings);
            cv.drawCircle(cx, cy, dp(this, 126), rings);
            cv.drawCircle(cx, cy, dp(this, 140), rings);
            rings.setColor(0x164AD8D0);
            cv.drawArc(cx - dp(this, 158), cy - dp(this, 158), cx + dp(this, 158), cy + dp(this, 158),
                    208, 112, false, rings);
        }
    }

    /** Neon package + Wi-Fi mark inspired by the supplied cyber-network reference. */
    /** Fingerprint/network + data-cube brand mark. Persian wordmark is rendered natively by Android. */
    static final class PackageWifiLogo extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        PackageWifiLogo(Context c) { super(c); setLayerType(View.LAYER_TYPE_SOFTWARE, null); }

        @Override protected void onDraw(Canvas c) {
            float w = getWidth(), h = getHeight();
            if (w <= 0 || h <= 0) return;
            float cx = w * .5f, top = h * .22f;
            float bw = w * .58f, bh = h * .52f;
            float x = cx - bw / 2f, y = top + h * .13f;
            float ridge = bh * .24f;
            Path topFace = new Path();
            topFace.moveTo(x, y + ridge); topFace.lineTo(cx, y); topFace.lineTo(x + bw, y + ridge);
            topFace.lineTo(cx, y + ridge * 2.05f); topFace.close();
            Path leftFace = new Path();
            leftFace.moveTo(x, y + ridge); leftFace.lineTo(cx, y + ridge * 2.05f);
            leftFace.lineTo(cx, y + bh); leftFace.lineTo(x, y + bh - ridge * .38f); leftFace.close();
            Path rightFace = new Path();
            rightFace.moveTo(cx, y + ridge * 2.05f); rightFace.lineTo(x + bw, y + ridge);
            rightFace.lineTo(x + bw, y + bh - ridge * .38f); rightFace.lineTo(cx, y + bh); rightFace.close();

            p.setStyle(Paint.Style.FILL);
            p.setShader(new LinearGradient(x, y, x + bw, y + bh,
                    new int[]{0xFF5277FF, 0xFF315CFF, 0xFF20BFA9}, null, Shader.TileMode.CLAMP));
            c.drawPath(topFace, p); c.drawPath(leftFace, p); c.drawPath(rightFace, p); p.setShader(null);

            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(this, 2.2f));
            p.setStrokeJoin(Paint.Join.ROUND); p.setStrokeCap(Paint.Cap.ROUND);
            p.setColor(UI.light ? 0xFF315CFF : 0xFF9CB2FF); c.drawPath(topFace, p);
            c.drawPath(leftFace, p); c.drawPath(rightFace, p);

            // Check mark: the visual shorthand for a verified package match.
            p.setStrokeWidth(dp(this, 4.2f)); p.setColor(0xFFFFFFFF);
            Path check = new Path();
            check.moveTo(cx - bw * .19f, y + bh * .55f);
            check.lineTo(cx - bw * .04f, y + bh * .68f);
            check.lineTo(cx + bw * .23f, y + bh * .40f);
            c.drawPath(check, p);

            // Two restrained signal arcs above the package.
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(this, 2.6f));
            p.setColor(UI.light ? 0xFF20A995 : 0xFF20BFA9);
            c.drawArc(cx - dp(this, 25), top - dp(this, 2), cx + dp(this, 25), top + dp(this, 48), 220, 100, false, p);
            c.drawArc(cx - dp(this, 16), top + dp(this, 7), cx + dp(this, 16), top + dp(this, 39), 220, 100, false, p);
        }
    }

    /** Hexagon ring with a gradient stroke, used behind the app logo. */
    static final class HexBadge extends View {
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);

        HexBadge(Context c) {
            super(c);
            stroke.setStyle(Paint.Style.STROKE);
            stroke.setStrokeWidth(dp(this, 2));
        }

        @Override protected void onDraw(Canvas cv) {
            float w = getWidth(), h = getHeight();
            float r = Math.min(w, h) / 2f - dp(this, 4);
            Path p = hex(w / 2f, h / 2f, r);
            fill.setShader(new LinearGradient(0, 0, w, h,
                    UI.light ? new int[]{0x22315CFF, 0x1120BFA9} : new int[]{0x334AD8D0, 0x203D65C5}, null, Shader.TileMode.CLAMP));
            cv.drawPath(p, fill);
            stroke.setShader(new LinearGradient(0, 0, w, h,
                    new int[]{0xFF315CFF, 0xFF20BFA9}, null, Shader.TileMode.CLAMP));
            cv.drawPath(p, stroke);
        }

        static Path hex(float cx, float cy, float r) {
            Path p = new Path();
            for (int i = 0; i < 6; i++) {
                double a = Math.PI / 3 * i - Math.PI / 6;
                float x = (float) (cx + r * Math.cos(a));
                float y = (float) (cy + r * Math.sin(a));
                if (i == 0) p.moveTo(x, y); else p.lineTo(x, y);
            }
            p.close();
            return p;
        }
    }

    /** Accent circle with a paper-plane glyph (Telegram-style). */
    static final class PlaneIcon extends View {
        private final Paint circle = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint glyph = new Paint(Paint.ANTI_ALIAS_FLAG);

        PlaneIcon(Context c) {
            super(c);
            glyph.setColor(0xFF06241C);
        }

        @Override protected void onDraw(Canvas cv) {
            float w = getWidth(), h = getHeight();
            circle.setShader(new LinearGradient(0, 0, w, h,
                    new int[]{0xFF315CFF, 0xFF20BFA9}, null, Shader.TileMode.CLAMP));
            cv.drawCircle(w / 2f, h / 2f, Math.min(w, h) / 2f, circle);
            Path p = new Path();
            p.moveTo(w * 0.24f, h * 0.48f);
            p.lineTo(w * 0.78f, h * 0.26f);
            p.lineTo(w * 0.62f, h * 0.76f);
            p.lineTo(w * 0.47f, h * 0.60f);
            p.close();
            cv.drawPath(p, glyph);
            Path fold = new Path();
            fold.moveTo(w * 0.47f, h * 0.60f);
            fold.lineTo(w * 0.78f, h * 0.26f);
            fold.lineTo(w * 0.50f, h * 0.66f);
            fold.close();
            cv.drawPath(fold, glyph);
        }
    }

    /** Creator portrait cropped into a consistent circular frame for compact profile cards. */
    static final class PersonAvatar extends View {
        private final Paint fallback = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint photo = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        private final Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint innerRing = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Matrix shaderMatrix = new Matrix();
        private final Bitmap portrait;
        private final BitmapShader shader;

        PersonAvatar(Context c) {
            super(c);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
            Bitmap loaded;
            try {
                loaded = BitmapFactory.decodeResource(c.getResources(), R.drawable.creator_avatar);
            } catch (RuntimeException ex) {
                loaded = null;
            }
            portrait = loaded;
            shader = portrait == null ? null : new BitmapShader(portrait,
                    Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
            photo.setDither(true);
            if (shader != null) photo.setShader(shader);

            fallback.setColor(UI.light ? 0xFF315CFF : 0xFF243B62);
            glow.setColor(UI.light ? 0x22315CFF : 0x22315CFF);
            glow.setStyle(Paint.Style.FILL);
            glow.setShadowLayer(dp(this, 5), 0, 0, UI.light ? 0x44315CFF : 0x55315CFF);
            ring.setStyle(Paint.Style.STROKE);
            ring.setStrokeWidth(dp(this, 2.2f));
            ring.setShader(new LinearGradient(0, 0, dp(this, 66), dp(this, 66),
                    new int[]{0xFF315CFF, 0xFF9B7BFF, 0xFF20BFA9}, null, Shader.TileMode.CLAMP));
            innerRing.setStyle(Paint.Style.STROKE);
            innerRing.setStrokeWidth(dp(this, 0.8f));
            innerRing.setColor(UI.light ? 0x66536FD0 : 0x8869DDF4);
        }

        @Override protected void onDraw(Canvas cv) {
            super.onDraw(cv);
            float w = getWidth(), h = getHeight();
            if (w <= 0 || h <= 0) return;
            float cx = w * .5f, cy = h * .5f;
            float radius = Math.min(w, h) * .5f - dp(this, 4);
            if (radius <= 0) return;

            cv.drawCircle(cx, cy, radius + dp(this, 1), glow);
            if (shader != null && portrait != null) {
                float diameter = (radius - dp(this, 2)) * 2f;
                float scale = diameter / Math.min(portrait.getWidth(), portrait.getHeight());
                float left = cx - portrait.getWidth() * scale * .5f;
                float top = cy - portrait.getHeight() * scale * .5f;
                shaderMatrix.setScale(scale, scale);
                shaderMatrix.postTranslate(left, top);
                shader.setLocalMatrix(shaderMatrix);
                cv.drawCircle(cx, cy, radius - dp(this, 2), photo);
            } else {
                cv.drawCircle(cx, cy, radius - dp(this, 2), fallback);
                Paint figure = new Paint(Paint.ANTI_ALIAS_FLAG);
                figure.setColor(0xFFF0F6FF);
                cv.drawCircle(cx, cy - radius * .20f, radius * .22f, figure);
                cv.drawOval(cx - radius * .48f, cy + radius * .05f,
                        cx + radius * .48f, cy + radius * .83f, figure);
            }
            cv.drawCircle(cx, cy, radius - dp(this, 1), ring);
            cv.drawCircle(cx, cy, radius - dp(this, 4), innerRing);
            Paint status = new Paint(Paint.ANTI_ALIAS_FLAG);
            status.setColor(0xFF20BFA9);
            cv.drawCircle(cx + radius * .68f, cy + radius * .68f, dp(this, 5.5f), status);
            status.setColor(UI.light ? 0xFFFFFFFF : 0xFF172238);
            cv.drawCircle(cx + radius * .68f, cy + radius * .68f, dp(this, 2.2f), status);
        }
    }
}
