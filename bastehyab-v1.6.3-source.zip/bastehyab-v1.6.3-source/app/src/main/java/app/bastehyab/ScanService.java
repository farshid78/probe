package app.bastehyab;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.graphics.Rect;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;
import android.widget.Toast;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.RejectedExecutionException;

public class ScanService extends AccessibilityService {
    static volatile ScanService inst;
    static volatile String lastScanStatus = "هنوز اسکن انجام نشده است";
    static volatile int lastScannedPackages, lastValidPackages, lastSuspiciousPackages, lastDuplicatePackages;
    static volatile long lastCompletedScanAt;
    static volatile long lastScanDurationMs;
    static volatile String lastOpId = "";
    static volatile String lastEmptyReason = "";
    static volatile String lastPackageStatus = "";

    // ---- user-started full extraction: the app scrolls the operator list ONLY after an explicit user request
    static volatile boolean fullMode;
    static volatile boolean fullStartedScanning;
    static volatile boolean fullTargetObservedOnce;
    static volatile String fullTargetOpId = "";
    static volatile String fullTargetPackage = "";
    static volatile long fullStartedAt;
    static volatile long fullLastStepAt;
    /** Earliest time the next scan may run; scroll events must not shorten this delay. */
    static volatile long fullNextScanAt;
    static volatile int fullSteps, fullNoNew;
    static volatile int fullNoMove, fullScrollStrategy;
    /** Best observed scroll offset from the operator's Accessibility scroll events. */
    static volatile int fullObservedScrollPercent = -1;
    static volatile String lastScrollMethod = "هنوز اسکرولی انجام نشده";
    static volatile String lastPopupError = "";
    static volatile boolean fullFinished;
    /** The user must confirm (floating dialog) that the operator's internet-package page is open. */
    static volatile boolean fullConfirmed;
    /** Temporary pause preserves all collected packages and the current operator page. */
    static volatile boolean fullPaused;
    static volatile long fullPausedAt;
    /** The user chose "later": the dialog stays hidden until the next screen change in the operator app. */
    static volatile boolean promptDismissed;
    /** Pause between the user's confirmation and the first automatic scroll. */
    static final long FULL_CONFIRM_DELAY_MS = 1800L;
    /** Pause between the operator app appearing and the confirmation dialog showing. */
    static final long FULL_PROMPT_DELAY_MS = 900L;
    static final long FULL_PROMPT_RETRY_MS = 900L;
    // Keep retrying while the target operator is foregrounded; transitions can take longer
    // than a fixed seven-second retry window on slower devices.
    static final int FULL_PROMPT_MAX_ATTEMPTS = 240;
    static final long FULL_SCROLL_SETTLE_MS = 1900L;
    static final long FULL_RESUME_DELAY_MS = 350L;
    static final java.util.Set<String> fullSeen = new HashSet<>();
    static final int FULL_MAX_STEPS = 120;
    static final long FULL_WAIT_MS = 240000L;
    static final long FULL_MAX_MS = 300000L;

    /** Start only for the exact package opened by the operator button; wait for a real offer page. */
    static synchronized void startFull(String operatorId, String targetPackage) {
        fullSeen.clear();
        fullSteps = 0;
        fullNoNew = 0;
        fullNoMove = 0;
        fullScrollStrategy = 0;
        fullObservedScrollPercent = -1;
        lastScrollMethod = "هنوز اسکرولی انجام نشده";
        lastPopupError = "";
        fullLastFingerprint = "";
        fullFinished = false;
        fullConfirmed = false;
        fullPaused = false;
        fullPausedAt = 0L;
        promptDismissed = false;
        fullStartedScanning = false;
        fullTargetObservedOnce = false;
        fullTargetOpId = operatorId == null ? "" : operatorId.trim();
        fullTargetPackage = targetPackage == null ? "" : targetPackage.trim();
        // Navigation time is not part of the five-minute extraction window.
        fullStartedAt = 0L;
        fullLastStepAt = 0L;
        fullNextScanAt = 0L;
        lastPackageStatus = "";
        if (fullTargetOpId.isEmpty() || fullTargetPackage.isEmpty()) {
            fullMode = false;
            lastScanStatus = "استخراج خودکار شروع نشد؛ شناسه‌ی اپراتور یا برنامه معتبر نیست";
            return;
        }
        fullMode = true;
        lastScanStatus = "استخراج خودکار آماده است؛ وارد بخش بسته‌های اینترنت شوید و در پنجره‌ی شناور تایید کنید";
        if (inst != null) {
            inst.h.removeCallbacks(inst.promptRunnable);
            inst.h.removeCallbacks(inst.controlsRetry);
            inst.promptPending = false;
            inst.promptAttempts = 0;
            if (inst.popup != null) inst.popup.hideConfirm();
            // The floating comparison window is touchable. Keeping it visible over an app
            // can swallow the very swipe used to scroll that app, especially in Irancell/MCI.
            if (inst.popup != null) inst.popup.hide();
            inst.h.removeCallbacks(inst.fullTimeout);
            inst.h.postDelayed(inst.fullTimeout, FULL_WAIT_MS);
        }
    }

    static boolean isFullTarget(String packageName) {
        return !fullTargetPackage.isEmpty() && fullTargetPackage.equals(packageName);
    }

    /** Ignore window changes until the target operator app was actually reached. */
    static boolean shouldStopFullForWindowChange(String packageName) {
        return fullMode && !fullPaused && fullTargetObservedOnce && !ignorable(packageName == null ? "" : packageName)
                && !isFullTarget(packageName == null ? "" : packageName);
    }

    static synchronized void stopFull(String reason) {
        if (!fullMode) return;
        fullMode = false;
        // A stationary viewport does not prove that the end of the list was reached.
        fullFinished = reason != null
                && (reason.contains("پایان قطعی فهرست") || reason.contains("فهرست تمام شد"));
        fullConfirmed = false;
        fullPaused = false;
        fullPausedAt = 0L;
        fullNextScanAt = 0L;
        promptDismissed = false;
        if (inst != null) {
            inst.h.removeCallbacks(inst.fullTimeout);
            inst.h.removeCallbacks(inst.promptRunnable);
            inst.h.removeCallbacks(inst.controlsRetry);
            inst.h.removeCallbacks(inst.job);
            inst.promptPending = false;
            inst.scanAgain = false;
            if (inst.popup != null) inst.popup.hideConfirm();
        }
        lastScanStatus = (reason == null ? "استخراج خودکار متوقف شد" : reason)
                + " • " + fullSeen.size() + " بسته‌ی یکتا";
    }

    /** Called from the floating panel after the user confirms the internet-package page. */
    static synchronized void confirmFull() {
        if (!fullMode || fullConfirmed || fullPaused) return;
        fullConfirmed = true;
        lastScanStatus = "تایید شد؛ اسکن خودکار تا چند لحظه‌ی دیگر شروع می‌شود";
        ScanService s = inst;
        if (s != null) {
            s.ensureFloatingControls();
            // Events emitted by the overlay must not shorten the confirmation settling delay.
            fullNextScanAt = System.currentTimeMillis() + FULL_CONFIRM_DELAY_MS;
            s.h.removeCallbacks(s.job);
            s.h.postDelayed(s.job, FULL_CONFIRM_DELAY_MS);
            s.h.removeCallbacks(s.fullTimeout);
            s.h.postDelayed(s.fullTimeout, FULL_WAIT_MS);
        }
    }

    /** Pause without clearing the seen set, counters, target app, or current viewport. */
    static synchronized void pauseFull() {
        if (!fullMode || !fullConfirmed || fullPaused) return;
        fullPaused = true;
        fullPausedAt = System.currentTimeMillis();
        lastScanStatus = "اسکن موقتاً متوقف شد؛ صفحه و بسته‌های شناسایی‌شده حفظ شدند";
        ScanService s = inst;
        if (s != null) {
            s.h.removeCallbacks(s.job);
            s.h.removeCallbacks(s.fullTimeout);
            s.scanAgain = false;
            s.ensureFloatingControls();
        }
    }

    /** Resume from the visible page; paused time does not consume the scan time limit. */
    static synchronized void resumeFull() {
        if (!fullMode || !fullConfirmed || !fullPaused) return;
        ScanService s = inst;
        if (s != null && !isFullTarget(s.fg)) {
            lastScanStatus = "برای ادامه، ابتدا به برنامه‌ی اپراتور برگردید؛ اطلاعات اسکن حفظ شده است";
            s.ensureFloatingControls();
            return;
        }
        long now = System.currentTimeMillis();
        long pausedFor = fullPausedAt > 0L ? Math.max(0L, now - fullPausedAt) : 0L;
        if (fullStartedAt > 0L) fullStartedAt += pausedFor;
        fullPaused = false;
        fullPausedAt = 0L;
        lastScanStatus = "ادامه‌ی اسکن از صفحه‌ی فعلی";
        if (s != null) {
            s.ensureFloatingControls();
            fullNextScanAt = now + FULL_RESUME_DELAY_MS;
            s.h.removeCallbacks(s.fullTimeout);
            long remaining = fullStartedAt > 0L
                    ? Math.max(1000L, FULL_MAX_MS - Math.max(0L, now - fullStartedAt))
                    : FULL_WAIT_MS;
            s.h.postDelayed(s.fullTimeout, remaining);
            s.h.removeCallbacks(s.job);
            s.h.postDelayed(s.job, FULL_RESUME_DELAY_MS);
        }
    }

    static void togglePauseFull() {
        if (fullPaused) resumeFull(); else pauseFull();
    }

    /** "Later" hides the pre-start panel without cancelling; it returns on a screen change. */
    static void postponePrompt() {
        if (!fullMode || fullConfirmed) return;
        promptDismissed = true;
        lastScanStatus = "پنجره‌ی تایید پنهان شد؛ با تغییر صفحه‌ی اپراتور دوباره نمایش داده می‌شود";
        ScanService s = inst;
        if (s != null && s.popup != null) s.popup.hideConfirm();
    }

    static boolean shouldPrompt(boolean dismissed, boolean windowStateChanged) {
        return !dismissed || windowStateChanged;
    }

    /** Computes event debounce without allowing view-scroll noise to bypass the next-step lock. */
    static long eventScanDelay(long now, long lastScan, boolean full, boolean scrollEvent,
                               long nextFullScanAt) {
        long floor = full ? 550L : (scrollEvent ? 220L : 450L);
        long minimum = full ? 260L : (scrollEvent ? 120L : 180L);
        long eligibleAt = lastScan + floor;
        if (full) eligibleAt = Math.max(eligibleAt, nextFullScanAt);
        return Math.max(minimum, eligibleAt - now);
    }

    static void cancelFull() {
        ScanService service = inst;
        stopFull("استخراج خودکار با انتخاب شما خارج شد");
        if (service != null) service.returnToMainActivity();
    }

    /** The Exit control must return to Bastehyab, not merely hide the floating panel. */
    private void returnToMainActivity() {
        h.post(() -> {
            try {
                Intent intent = new Intent();
                intent.setClassName(getPackageName(), getPackageName() + ".MainActivity");
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                        | Intent.FLAG_ACTIVITY_CLEAR_TOP
                        | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity(intent);
            } catch (RuntimeException error) {
                android.util.Log.w("BastehyabScan", "Could not return to main activity: "
                        + error.getClass().getSimpleName());
            }
        });
    }

    private final Handler h = new Handler(Looper.getMainLooper());
    private boolean promptPending;
    private int promptAttempts;
    // Keep fields used by field-initialized callbacks declared before those callbacks.
    private final Map<String, List<String>> dumps = new HashMap<>();
    private Popup popup;
    private long lastScanAt;
    private static volatile String fullLastFingerprint = "";
    private final Runnable writeDiag = this::writeDiagnosticFile;
    private int emptyStreak;
    private boolean scanning, scanAgain;
    private String fg = "", dismissed = "";
    /** Heavy accessibility-tree parsing runs away from the service/UI thread. */
    private volatile ExecutorService scanExecutor;

    private static final class DiagnosticSnapshot {
        final String packageName, dump;
        DiagnosticSnapshot(String packageName, String dump) {
            this.packageName = packageName;
            this.dump = dump;
        }
    }

    private static final class ScanOutcome {
        boolean fullModeAtStart;
        String targetPackage = "";
        int scanned, valid, suspicious, duplicates, emptyStreak;
        boolean incomplete, fullTargetObserved, packagePageFound, hideComparison;
        String fullFingerprint = "", lastEmptyReason = "", operatorLabel = "", packageStatus = "";
        String error = "";
        final List<String> fullSignatures = new ArrayList<>();
        final List<DiagnosticSnapshot> diagnostics = new ArrayList<>();
        Compare.Result comparison;
        Set<String> comparisonKeys;
        long durationMs;
    }

    private final Runnable promptRunnable = () -> {
        promptPending = false;
        if (!fullMode || fullConfirmed || fullPaused || promptDismissed) return;
        if (refreshFloatingControls()) {
            promptAttempts = 0;
            lastPopupError = "";
            return;
        }
        promptAttempts++;
        String error = popup == null ? "سرویس پنجره شناور آماده نیست" : popup.confirmError();
        lastPopupError = error == null ? "خطای نامشخص" : error;
        lastScanStatus = "نمایش پنجره‌ی کنترل ناموفق بود؛ تلاش مجدد "
                + Fmt.fa(String.valueOf(promptAttempts)) + " از "
                + Fmt.fa(String.valueOf(FULL_PROMPT_MAX_ATTEMPTS));
        if (promptAttempts < FULL_PROMPT_MAX_ATTEMPTS) {
            schedulePromptRetry();
        } else {
            lastScanStatus = "پنجره‌ی شناور نمایش داده نشد؛ سرویس دسترسی بسته‌یاب را بررسی کنید ("
                    + lastPopupError + ")";
        }
    };
    private final Runnable fullTimeout = () -> {
        if (fullMode && !fullPaused) stopFull(fullStartedScanning
                ? "توقف: مهلت پنج‌دقیقه‌ای استخراج به پایان رسید"
                : "توقف: مهلت ورود به صفحه‌ی بسته‌های اینترنت به پایان رسید");
    };
    private final Runnable job = this::scan;

    private void schedulePromptRetry() {
        promptPending = true;
        h.postDelayed(promptRunnable, FULL_PROMPT_RETRY_MS);
    }

    /** Rebuilds the one floating control panel for the current extraction state. */
    private boolean refreshFloatingControls() {
        if (!fullMode || popup == null) return false;
        Op target = Cfg.opById(this, fullTargetOpId);
        int mode = !fullConfirmed ? 0 : (fullPaused ? 2 : 1);
        int percent = fullProgressPercent();
        boolean shown = popup.showConfirm(target == null ? "اپراتور" : target.name, mode,
                percent, fullSteps, fullSeen.size(), lastScanStatus,
                mode == 0 ? ScanService::confirmFull : ScanService::togglePauseFull,
                ScanService::cancelFull,
                mode == 0 ? ScanService::postponePrompt : null);
        lastPopupError = shown ? "" : popup.confirmError();
        return shown;
    }


    /** Best-effort progress: real scroll offsets when available, otherwise completed scan steps. */
    static int fullProgressPercent() {
        if (fullFinished) return 100;
        int stepPercent = fullSteps <= 0 ? 0
                : Math.min(95, Math.max(1, fullSteps * 100 / FULL_MAX_STEPS));
        return Math.max(stepPercent, Math.max(0, Math.min(100, fullObservedScrollPercent)));
    }

    private final Runnable controlsRetry = this::retryFloatingControls;

    private void ensureFloatingControls() {
        h.removeCallbacks(controlsRetry);
        if (!refreshFloatingControls() && fullMode) h.postDelayed(controlsRetry, FULL_PROMPT_RETRY_MS);
    }

    private void retryFloatingControls() {
        if (!fullMode) return;
        if (!refreshFloatingControls()) h.postDelayed(controlsRetry, FULL_PROMPT_RETRY_MS);
    }

    @Override public void onInterrupt() {
        h.removeCallbacks(job);
        pendingReset();
        stopFull("سرویس دسترسی‌پذیری متوقف شد");
        if (popup != null) { popup.hide(); popup.hideConfirm(); }
    }

    private void pendingReset() {
        scanAgain = false;
        scanning = false;
    }

    @Override protected void onServiceConnected() {
        inst = this;
        // Remove a possible raw diagnostic file left by versions before the privacy fix.
        File legacyDiagnostic = new File(getFilesDir(), "diag.txt");
        if (legacyDiagnostic.exists()) legacyDiagnostic.delete();
        dumps.clear();
        ExecutorService previous = scanExecutor;
        if (previous != null) previous.shutdownNow();
        scanExecutor = Executors.newSingleThreadExecutor(r -> {
            Thread t = new Thread(r, "Bastehyab-ScanWorker");
            t.setDaemon(true);
            return t;
        });
        popup = new Popup(this);
        popup.onClose(() -> dismissed = fg);
    }

    @Override public boolean onUnbind(Intent i) {
        h.removeCallbacksAndMessages(null);
        pendingReset();
        stopFull("سرویس دسترسی‌پذیری غیرفعال شد");
        ExecutorService worker = scanExecutor;
        scanExecutor = null;
        if (worker != null) worker.shutdownNow();
        inst = null;
        dumps.clear();
        if (popup != null) { popup.hide(); popup.hideConfirm(); }
        return super.onUnbind(i);
    }

    private static boolean ignorable(String p) {
        String s = p.toLowerCase();
        return s.equals("com.android.systemui") || s.contains("inputmethod") || s.contains("keyboard") || s.contains("honeyboard");
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent e) {
        CharSequence cs = e.getPackageName();
        if (cs == null || popup == null) return;
        String p = cs.toString();
        if (fullMode && isFullTarget(p)) {
            fullTargetObservedOnce = true;
            if (e.getEventType() == AccessibilityEvent.TYPE_VIEW_SCROLLED) {
                int maxY = e.getMaxScrollY();
                if (maxY > 0) {
                    int observed = Math.max(0, Math.min(100, (int) ((long) e.getScrollY() * 100L / maxY)));
                    fullObservedScrollPercent = Math.max(fullObservedScrollPercent, observed);
                }
            }
        }
        boolean screenChange = e.getEventType() == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED;
        // Leaving the operator normally ends extraction, but a deliberate pause preserves it.
        if (screenChange && shouldStopFullForWindowChange(p)
                && !(p.equals(getPackageName()) && Popup.recentOverlayChange())) {
            stopFull("استخراج خودکار متوقف شد؛ از برنامه‌ی اپراتور خارج شدید");
        }
        if (screenChange && !ignorable(p)
                && !(p.equals(getPackageName()) && Popup.recentOverlayChange())) {
            fg = p;
            if (!p.equals(dismissed)) dismissed = "";
            if (!p.equals(getPackageName())) popup.hide();
        }
        if (fullMode && fullConfirmed && isFullTarget(p)) ensureFloatingControls();
        if (fullMode && !fullConfirmed && isFullTarget(p) && !promptPending
                && shouldPrompt(promptDismissed, screenChange)) {
            if (screenChange && promptAttempts >= FULL_PROMPT_MAX_ATTEMPTS) promptAttempts = 0;
            promptDismissed = false;
            promptPending = true;
            h.postDelayed(promptRunnable, FULL_PROMPT_DELAY_MS);
        }
        if (p.equals(getPackageName())) return;
        if (fullMode && fullPaused) return;
        Op op = Cfg.opFor(this, p);
        if (op == null || !op.enabled) return;
        long now = System.currentTimeMillis();
        // Accessibility scroll events can arrive repeatedly while an operator page is still
        // rendering. They may reschedule a scan, but never before fullNextScanAt.
        boolean scrollEvent = e.getEventType() == AccessibilityEvent.TYPE_VIEW_SCROLLED;
        long delay = eventScanDelay(now, lastScanAt, fullMode, scrollEvent, fullNextScanAt);
        h.removeCallbacks(job);
        h.postDelayed(job, delay);
    }

    /**
     * Debounced entry point on the service thread. Only window handles are traversed by the
     * worker; parsing, fingerprinting, persistence and comparison no longer block Android UI.
     */
    private void scan() {
        if (fullMode && fullPaused) return;
        if (fullMode && !fullConfirmed) {
            lastScanStatus = "در انتظار تایید شما در پنجره‌ی شناور؛ وارد بخش بسته‌های اینترنت شوید";
            return;
        }
        if (scanning) {
            scanAgain = true;
            return;
        }
        ExecutorService worker = scanExecutor;
        if (worker == null || worker.isShutdown()) {
            lastScanStatus = "پردازشگر اسکن آماده نیست؛ سرویس دسترسی را یک‌بار خاموش و روشن کنید";
            return;
        }

        scanning = true;
        if (fullMode && popup != null) popup.hide();
        final boolean fullAtStart = fullMode;
        final String targetAtStart = fullTargetPackage;
        final String dismissedAtStart = dismissed;
        final int emptyStreakAtStart = emptyStreak;
        final long startedAt = android.os.SystemClock.elapsedRealtime();
        try {
            worker.execute(() -> {
                ScanOutcome outcome = performScanWork(fullAtStart, targetAtStart,
                        dismissedAtStart, emptyStreakAtStart, startedAt);
                h.post(() -> finishScan(outcome));
            });
        } catch (RejectedExecutionException rejected) {
            scanning = false;
            lastScanStatus = "پردازش اسکن پذیرفته نشد؛ دوباره تلاش کنید";
        }
    }

    /** CPU- and I/O-heavy part; deliberately contains no Popup/WindowManager operations. */
    private ScanOutcome performScanWork(boolean fullAtStart, String targetAtStart,
                                        String dismissedAtStart, int initialEmptyStreak,
                                        long startedAt) {
        ScanOutcome out = new ScanOutcome();
        out.fullModeAtStart = fullAtStart;
        out.targetPackage = targetAtStart == null ? "" : targetAtStart;
        out.emptyStreak = initialEmptyStreak;
        Set<String> scanKeys = new HashSet<>();
        try {
            List<AccessibilityNodeInfo> roots = new ArrayList<>();
            List<AccessibilityWindowInfo> windows = getWindows();
            if (windows != null) {
                for (AccessibilityWindowInfo window : windows) {
                    if (window == null) continue;
                    try {
                        if (window.getType() == AccessibilityWindowInfo.TYPE_APPLICATION) {
                            AccessibilityNodeInfo root = window.getRoot();
                            if (root != null) roots.add(root);
                        }
                    } finally {
                        window.recycle();
                    }
                }
            }
            if (roots.isEmpty()) {
                AccessibilityNodeInfo root = getRootInActiveWindow();
                if (root != null) roots.add(root);
            }

            DisplayMetrics metrics = getResources().getDisplayMetrics();
            for (AccessibilityNodeInfo root : roots) {
                try {
                    String packageName = String.valueOf(root.getPackageName());
                    if (fullAtStart && !isFullTarget(packageName)) continue;
                    Op op = Cfg.opFor(this, packageName);
                    if (op == null || !op.enabled) continue;
                    if (fullAtStart) {
                        out.fullTargetObserved = true;
                    }

                    Extractor.Result result = Extractor.extract(root, op, metrics.heightPixels);
                    out.operatorLabel = op.name;
                    out.diagnostics.add(new DiagnosticSnapshot(packageName, result.dump));
                    out.incomplete |= result.incomplete;
                    out.duplicates += result.duplicates;

                    for (Pkg item : result.items) {
                        if (!scanKeys.add(item.key)) {
                            out.duplicates++;
                            continue;
                        }
                        out.scanned++;
                        if (item.currencyKnown && !item.ambig) out.valid++;
                        else out.suspicious++;
                    }

                    boolean offerPage = fullAtStart && looksLikeOfferPage(root);
                    if (offerPage) {
                        out.packagePageFound = true;
                        out.fullFingerprint = pageFingerprint(root);
                    }
                    if (result.items.isEmpty()) {
                        out.lastEmptyReason = "گره‌ها: " + result.nodes + "، متن‌های قابل‌مشاهده: " + result.leaves
                                + (result.fullTraversal ? "، پیمایش کامل" : "");
                        out.emptyStreak++;
                        if (out.emptyStreak >= 3) out.hideComparison = true;
                        continue;
                    }

                    out.packagePageFound = true;
                    if (fullAtStart && out.fullFingerprint.isEmpty())
                        out.fullFingerprint = pageFingerprint(root);
                    out.emptyStreak = 0;
                    Store.upsert(this, result.items);

                    boolean hasDefinitivePrice = false;
                    for (int i = result.items.size() - 1; i >= 0; i--) {
                        Pkg latest = result.items.get(i);
                        if (latest.currencyKnown && !latest.ambig && latest.toman >= 100) {
                            out.packageStatus = latest.title + " • "
                                    + Cfg.priceLabel(this, latest.toman) + " ثبت شد";
                            hasDefinitivePrice = true;
                            break;
                        }
                    }
                    if (!hasDefinitivePrice) {
                        Pkg uncertain = result.items.get(result.items.size() - 1);
                        out.packageStatus = uncertain.title + " • استخراج شد و برای بررسی دستی نگهداری شد";
                    }
                    if (fullAtStart) {
                        // Merge into the cross-page set on the main thread after this batch completes.
                        for (Pkg item : result.items) out.fullSignatures.add(item.sig());
                    }

                    Compare.Result comparison = Compare.run(this, result.keys);
                    if (!fullAtStart && Cfg.popup(this) && !packageName.equals(dismissedAtStart)
                            && !comparison.ranked.isEmpty()
                            && comparison.ops >= Cfg.minOps(this)) {
                        out.comparison = comparison;
                        out.comparisonKeys = new HashSet<>(result.keys);
                    }
                } finally {
                    root.recycle();
                }
            }
        } catch (RuntimeException error) {
            out.error = error.getClass().getSimpleName();
        } finally {
            out.durationMs = Math.max(0L, android.os.SystemClock.elapsedRealtime() - startedAt);
        }
        return out;
    }

    /** Applies the worker result and performs all visible-window and gesture operations. */
    private void finishScan(ScanOutcome out) {
        if (out == null) {
            scanning = false;
            return;
        }
        lastScanDurationMs = out.durationMs;
        if (inst != this) {
            scanning = false;
            return;
        }

        lastScannedPackages = out.scanned;
        lastValidPackages = out.valid;
        lastSuspiciousPackages = out.suspicious;
        lastDuplicatePackages = out.duplicates;
        lastCompletedScanAt = System.currentTimeMillis();
        emptyStreak = out.emptyStreak;
        if (!out.lastEmptyReason.isEmpty()) lastEmptyReason = out.lastEmptyReason;
        if (!out.packageStatus.isEmpty()) lastPackageStatus = out.packageStatus;
        for (DiagnosticSnapshot snapshot : out.diagnostics) diag(snapshot.packageName, snapshot.dump);

        boolean sameFullSession = out.fullModeAtStart && fullMode
                && out.targetPackage.equals(fullTargetPackage);
        boolean staleSession = (out.fullModeAtStart && !sameFullSession)
                || (!out.fullModeAtStart && fullMode);
        int fullNew = 0;
        if (sameFullSession && out.fullTargetObserved) {
            fullTargetObservedOnce = true;
            for (String signature : out.fullSignatures) if (fullSeen.add(signature)) fullNew++;
        }

        if (!staleSession && !(sameFullSession && fullPaused)) {
            if (!out.error.isEmpty()) {
                lastScanStatus = "خطا در اسکن: " + out.error;
                android.util.Log.w("BastehyabScan", "Accessibility scan failed: " + out.error);
            } else if (sameFullSession) {
                if (out.fullTargetObserved && !fullStartedScanning && out.packagePageFound) {
                    fullStartedScanning = true;
                    fullNoNew = 0;
                    fullStartedAt = System.currentTimeMillis();
                    h.removeCallbacks(fullTimeout);
                    h.postDelayed(fullTimeout, FULL_MAX_MS);
                    lastScanStatus = "صفحه‌ی بسته‌ها شناسایی شد؛ استخراج خودکار آغاز شد";
                } else if (out.fullTargetObserved && !fullStartedScanning) {
                    lastScanStatus = "استخراج خودکار آماده است؛ به صفحه‌ی خرید بسته‌های اینترنت بروید";
                } else {
                    lastScanStatus = (out.incomplete ? "استخراج ناقص؛ بخشی از درخت صفحه در دسترس نبود"
                            : out.scanned == 0 ? "در صفحه‌ی فعلی بسته‌ای شناسایی نشد (" + lastEmptyReason + ")"
                            : "اسکن کامل شد")
                            + (out.operatorLabel.isEmpty() ? "" : " • " + out.operatorLabel);
                }
            } else {
                lastScanStatus = (out.incomplete ? "استخراج ناقص؛ بخشی از درخت صفحه در دسترس نبود"
                        : out.scanned == 0 ? "در صفحه‌ی فعلی بسته‌ای شناسایی نشد (" + lastEmptyReason + ")"
                        : "اسکن کامل شد")
                        + (out.operatorLabel.isEmpty() ? "" : " • " + out.operatorLabel);
            }
        }

        if (out.hideComparison && !fullMode && popup != null) popup.hide();
        if (!fullMode && !out.fullModeAtStart && out.comparison != null
                && out.comparisonKeys != null && popup != null) {
            popup.show(out.comparison, out.comparisonKeys);
        }
        if (fullMode) ensureFloatingControls();
        if (sameFullSession && out.error.isEmpty() && fullStartedScanning && fullConfirmed && !fullPaused
                && out.fullTargetObserved && out.packagePageFound) {
            advanceFull(fullNew, out.fullFingerprint);
        }

        scanning = false;
        if (scanAgain) {
            scanAgain = false;
            if (!fullPaused) {
                h.removeCallbacks(job);
                long rerunDelay = fullMode
                        ? Math.max(550L, fullNextScanAt - System.currentTimeMillis()) : 450L;
                h.postDelayed(job, rerunDelay);
            }
        }
    }

    /**
     * Recognize an operator offer page even when an individual card is temporarily unreadable.
     * This lets full extraction continue across sparse/partially-rendered pages instead of
     * waiting forever for the parser to produce at least one package.
     */
    private boolean looksLikeOfferPage(AccessibilityNodeInfo root) {
        if (root == null) return false;
        boolean hasInternet = false, hasBundle = false, hasOfferData = false;
        java.util.ArrayDeque<AccessibilityNodeInfo> q = new java.util.ArrayDeque<>();
        java.util.List<AccessibilityNodeInfo> owned = new java.util.ArrayList<>();
        q.add(root);
        int visited = 0;
        try {
            while (!q.isEmpty() && visited++ < 700) {
                AccessibilityNodeInfo n = q.removeFirst();
                CharSequence t = n.getText();
                CharSequence d = n.getContentDescription();
                String v = ((t == null ? "" : t.toString()) + " " + (d == null ? "" : d.toString())).toLowerCase(java.util.Locale.ROOT);
                if (v.contains("اینترنت") || v.contains("internet")) hasInternet = true;
                if (v.contains("بسته") || v.contains("package")) hasBundle = true;
                if (v.contains("گیگ") || v.contains("مگ") || v.contains("قیمت") || v.contains("تومان")
                        || v.contains("ریال") || v.contains("خرید")) hasOfferData = true;
                if (hasInternet && hasBundle && hasOfferData) return true;
                for (int i = 0; i < n.getChildCount(); i++) {
                    AccessibilityNodeInfo child = n.getChild(i);
                    if (child != null) { owned.add(child); q.addLast(child); }
                }
            }
        } catch (RuntimeException ignored) {
            return false;
        } finally {
            for (AccessibilityNodeInfo n : owned) try { n.recycle(); } catch (RuntimeException ignored) {}
        }
        return hasBundle && hasOfferData;
    }

    /** One step of the user-started extraction. The scroll method adapts when the app ignores it. */
    private void advanceFull(int newThisScan, String fingerprint) {
        if (!fullMode || fullPaused) return;
        long now = System.currentTimeMillis();
        if (now - fullLastStepAt < 850L) return;
        fullLastStepAt = now;
        fullSteps++;
        fullNoNew = newThisScan == 0 ? fullNoNew + 1 : 0;

        String fp = fingerprint == null ? "" : fingerprint;
        if (!fp.isEmpty() && fp.equals(fullLastFingerprint)) {
            fullNoMove++;
            // ACTION_SCROLL_FORWARD is best when supported. If the visible page did not change,
            // try a real vertical gesture inside the list, then a broader app-window swipe.
            if (fullNoMove == 1) fullScrollStrategy = Math.max(fullScrollStrategy, 1);
            else if (fullNoMove >= 2) fullScrollStrategy = 2;
        } else if (!fp.isEmpty()) {
            fullLastFingerprint = fp;
            fullNoMove = 0;
        }

        lastScanStatus = "استخراج کامل: مرحله " + fullSteps + "، " + fullSeen.size()
                + " بسته‌ی یکتا؛ " + newThisScan + " بسته‌ی تازه";
        if (fullSteps >= FULL_MAX_STEPS || now - fullStartedAt > FULL_MAX_MS) {
            stopFull("توقف ایمن: به سقف زمان یا تعداد حرکت رسید");
            return;
        }
        if (fullNoMove >= 4) {
            stopFull("اسکرول متوقف شد؛ پایان فهرست یا محدودیت اپ قابل تأیید نیست");
            return;
        }

        final String targetAtStart = fullTargetPackage;
        ExecutorService worker = scanExecutor;
        if (worker == null || worker.isShutdown()) {
            stopFull("پردازشگر اسکرول آماده نیست؛ اسکن به‌صورت ایمن متوقف شد");
            return;
        }
        try {
            worker.execute(() -> {
                // Finding the scrollable node can require many remote accessibility queries.
                // Keep that work off the main thread too, then update the overlay on main.
                boolean requested = fullMode && !fullPaused
                        && targetAtStart.equals(fullTargetPackage) && performAdaptiveScroll();
                String method = lastScrollMethod;
                h.post(() -> finishFullScroll(targetAtStart, requested, method));
            });
        } catch (RejectedExecutionException rejected) {
            stopFull("پردازشگر اسکرول در دسترس نبود؛ اسکن به‌صورت ایمن متوقف شد");
        }
    }

    /** Completes the scroll cycle on the service/UI thread after worker-side node traversal. */
    private void finishFullScroll(String target, boolean requested, String method) {
        if (!fullMode || fullPaused || !target.equals(fullTargetPackage)) return;
        if (!requested) {
            stopFull("اسکرول خودکار در این صفحه پشتیبانی نشد؛ فهرست را دستی کمی پایین ببرید");
            return;
        }
        lastScanStatus += " • " + method;
        ensureFloatingControls();
        fullNextScanAt = System.currentTimeMillis() + FULL_SCROLL_SETTLE_MS;
        h.removeCallbacks(job);
        h.postDelayed(job, FULL_SCROLL_SETTLE_MS);
    }

    /**
     * Scroll strategy: accessible list action first, then a vertical swipe inside the detected
     * list, finally a swipe in the app content viewport. This is only called after the user has
     * explicitly started a scan and the selected operator's offers page has been recognized.
     */
    private AccessibilityNodeInfo getFullTargetRoot() {
        AccessibilityNodeInfo active = getRootInActiveWindow();
        if (active != null && isFullTarget(String.valueOf(active.getPackageName()))) return active;
        if (active != null) active.recycle();

        // Some operator apps place an accessibility/consent window above the actual content.
        // Search application windows for the exact selected package before giving up.
        List<AccessibilityWindowInfo> windows = getWindows();
        if (windows != null) {
            for (AccessibilityWindowInfo window : windows) {
                if (window == null) continue;
                AccessibilityNodeInfo candidate = null;
                try {
                    if (window.getType() == AccessibilityWindowInfo.TYPE_APPLICATION) {
                        candidate = window.getRoot();
                        if (candidate != null && isFullTarget(String.valueOf(candidate.getPackageName()))) {
                            return candidate; // Caller owns and recycles this root.
                        }
                    }
                } finally {
                    if (candidate != null && !isFullTarget(String.valueOf(candidate.getPackageName()))) {
                        candidate.recycle();
                    }
                    window.recycle();
                }
            }
        }
        return null;
    }

    /** Scroll strategy: list action, several list swipe positions, then app viewport positions. */
    private boolean performAdaptiveScroll() {
        if (!fullMode || fullPaused) return false;
        AccessibilityNodeInfo root = getFullTargetRoot();
        if (root == null) return false;

        Rect appBounds = new Rect();
        root.getBoundsInScreen(appBounds);
        DisplayMetrics metrics = getResources().getDisplayMetrics();
        if (appBounds.width() < 180 || appBounds.height() < 260) {
            int topInset = Math.round(48f * metrics.density);
            int bottomInset = Math.round(72f * metrics.density);
            appBounds.left = 0;
            appBounds.top = topInset;
            appBounds.right = metrics.widthPixels;
            appBounds.bottom = Math.max(Math.round(300f * metrics.density),
                    metrics.heightPixels - bottomInset);
        }
        AccessibilityNodeInfo list = findScrollable(root);
        Rect listBounds = new Rect(appBounds);
        boolean actionAccepted = false;
        if (list != null) {
            list.getBoundsInScreen(listBounds);
            if (listBounds.width() < 180 || listBounds.height() < 260) {
                listBounds.left = appBounds.left;
                listBounds.top = appBounds.top;
                listBounds.right = appBounds.right;
                listBounds.bottom = appBounds.bottom;
            }
            if (fullScrollStrategy == 0) {
                try { actionAccepted = list.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD); }
                catch (RuntimeException ignored) { actionAccepted = false; }
            }
            if (list != root) list.recycle();
        }
        root.recycle();

        if (actionAccepted) {
            lastScrollMethod = "فرمان پیمایش فهرست";
            return true;
        }

        int variant = Math.abs(fullNoMove) % 3;
        if (fullScrollStrategy == 0) fullScrollStrategy = 1;
        if (fullScrollStrategy <= 1) {
            if (dispatchVerticalSwipe(listBounds, variant)) {
                fullScrollStrategy = 1;
                lastScrollMethod = "حرکت لمسی داخل فهرست (مسیر " + (variant + 1) + ")";
                return true;
            }
            fullScrollStrategy = 2;
        }

        if (dispatchVerticalSwipe(appBounds, (variant + 1) % 3)) {
            fullScrollStrategy = 2;
            lastScrollMethod = "حرکت لمسی در ناحیه‌ی اصلی برنامه";
            return true;
        }
        return false;
    }

    /**
     * Dispatches a real vertical gesture. Different horizontal lanes are tried on repeated
     * no-movement pages because operator apps sometimes place buttons/cards over the center.
     */
    private boolean dispatchVerticalSwipe(Rect bounds, int variant) {
        if (!fullMode || fullPaused || bounds == null) return false;
        int width = bounds.width(), height = bounds.height();
        if (width < 180 || height < 260) return false;
        float[] lanes = {0.50f, 0.72f, 0.28f};
        int x = bounds.left + Math.round(width * lanes[Math.floorMod(variant, lanes.length)]);
        int y1 = bounds.top + Math.round(height * 0.84f);
        int y2 = bounds.top + Math.round(height * 0.27f);
        if (y1 <= y2) return false;
        Path path = new Path();
        path.moveTo(x, y1);
        path.lineTo(x, y2);
        try {
            GestureDescription gesture = new GestureDescription.Builder()
                    .addStroke(new GestureDescription.StrokeDescription(path, 0L, 520L))
                    .build();
            return dispatchGesture(gesture, null, null);
        } catch (RuntimeException e) {
            android.util.Log.w("BastehyabScan", "Scroll gesture unavailable: " + e.getClass().getSimpleName());
            return false;
        }
    }

    /** A short-lived hash of visible text and geometry; raw page text is never written to disk. */
    private String pageFingerprint(AccessibilityNodeInfo root) {
        if (root == null) return "";
        java.util.ArrayDeque<AccessibilityNodeInfo> queue = new java.util.ArrayDeque<>();
        java.util.List<AccessibilityNodeInfo> owned = new java.util.ArrayList<>();
        queue.add(root);
        int hash = 1, count = 0, visited = 0;
        try {
            while (!queue.isEmpty() && visited++ < 1800) {
                AccessibilityNodeInfo n = queue.removeFirst();
                if (!n.isEditable() && !n.isPassword() && n.isVisibleToUser()) {
                    CharSequence text = n.getText();
                    if (text == null || text.length() == 0) text = n.getContentDescription();
                    if (text != null && text.length() > 0) {
                        String value = Fmt.norm(text.toString());
                        if (!value.isEmpty()) {
                            Rect b = new Rect();
                            n.getBoundsInScreen(b);
                            hash = 31 * hash + value.hashCode();
                            hash = 31 * hash + b.top / 8;
                            hash = 31 * hash + b.left / 8;
                            count++;
                        }
                    }
                }
                for (int i = 0; i < n.getChildCount(); i++) {
                    AccessibilityNodeInfo child = n.getChild(i);
                    if (child != null) { owned.add(child); queue.addLast(child); }
                }
            }
        } catch (RuntimeException ignored) {
            // A partial fingerprint is still useful for retry selection; parser marks truncation separately.
        } finally {
            for (AccessibilityNodeInfo n : owned) try { n.recycle(); } catch (RuntimeException ignored) {}
        }
        return count + ":" + Integer.toHexString(hash);
    }

    /**
     * Pick the largest visible scroll container, preferring tall content over small horizontal
     * carousels. The returned node remains owned by the caller; every other child is recycled.
     */
    static AccessibilityNodeInfo findScrollable(AccessibilityNodeInfo root) {
        if (root == null) return null;
        java.util.ArrayDeque<AccessibilityNodeInfo> queue = new java.util.ArrayDeque<>();
        java.util.List<AccessibilityNodeInfo> owned = new ArrayList<>();
        queue.add(root);
        AccessibilityNodeInfo best = null;
        long bestScore = -1L;
        int visited = 0;
        while (!queue.isEmpty() && visited++ < 1200) {
            AccessibilityNodeInfo n = queue.poll();
            if (n.isScrollable() && n.isVisibleToUser()) {
                Rect bounds = new Rect();
                n.getBoundsInScreen(bounds);
                long width = Math.max(0L, (long) bounds.width());
                long height = Math.max(0L, (long) bounds.height());
                // Reject horizontal carousels and tiny nested controls. A package list is
                // normally a tall viewport; the fallback below handles unusual tablet layouts.
                boolean verticalCandidate = height >= width * 0.55 && height >= 240L;
                if (verticalCandidate) {
                    long score = width * height + 3L * height * height;
                    if (score > bestScore) {
                        bestScore = score;
                        best = n;
                    }
                }
            }
            for (int i = 0; i < n.getChildCount(); i++) {
                AccessibilityNodeInfo c = n.getChild(i);
                if (c != null) { owned.add(c); queue.add(c); }
            }
        }
        // If no tall vertical viewport exists, do not guess: horizontal carousels are not
        // a safe substitute for the main package list.
        for (AccessibilityNodeInfo c : owned) if (c != best) c.recycle();
        return best;
    }

    void showTest() {
        // The comparison overlay is touchable and spans most of the screen. Never
        // allow the settings preview to appear while automatic extraction is active.
        if (fullMode) {
            hideComparisonPopup();
            Toast.makeText(this, "هنگام استخراج خودکار، پنجره‌ی مقایسه غیرفعال است.", Toast.LENGTH_SHORT).show();
            return;
        }
        Compare.Result cr = Compare.run(this, new HashSet<String>());
        if (cr.ranked.isEmpty()) {
            Toast.makeText(this, "هنوز داده‌ای برای نمایش نیست", Toast.LENGTH_SHORT).show();
            return;
        }
        popup.show(cr, new HashSet<String>());
    }

    void hideComparisonPopup() {
        if (popup != null) popup.hide();
    }

    private void diag(String p, String dump) {
        List<String> history = dumps.get(p);
        if (history == null) {
            history = new ArrayList<>();
            dumps.put(p, history);
        }
        // Avoid logging the same viewport repeatedly; retain up to the latest 30 distinct
        // snapshots so the exported report shows what happened before and after each scroll.
        if (history.isEmpty() || !history.get(history.size() - 1).equals(dump)) {
            history.add("time=" + new java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US)
                    .format(new java.util.Date()) + " step=" + fullSteps + " unique=" + fullSeen.size()
                    + " scroll=" + lastScrollMethod + "\n" + dump);
            while (history.size() > 30) history.remove(0);
        }
        // Debounce file I/O but always write the newest snapshot.
        h.removeCallbacks(writeDiag);
        h.postDelayed(writeDiag, 450L);
    }

    /** Force a final report write before sharing the diagnostic file. */
    static void flushDiagnostics() {
        ScanService service = inst;
        if (service == null) return;
        service.h.removeCallbacks(service.writeDiag);
        service.writeDiagnosticFile();
    }

    private void writeDiagnosticFile() {
        StringBuilder sb = new StringBuilder();
        sb.append("Bastehyab diagnostic • version 1.6.3\n");
        sb.append("capturedAt=").append(new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.US)
                .format(new java.util.Date())).append('\n');
        sb.append("status=").append(lastScanStatus).append('\n');
        sb.append("fullMode=").append(fullMode).append(" paused=").append(fullPaused)
                .append(" promptError=").append(lastPopupError).append(" nextScanAt=").append(fullNextScanAt)
                .append(" target=").append(fullTargetPackage)
                .append(" steps=").append(fullSteps).append(" unique=").append(fullSeen.size())
                .append(" observedScrollPercent=").append(fullObservedScrollPercent)
                .append(" noMove=").append(fullNoMove).append(" scrollStrategy=").append(fullScrollStrategy)
                .append(" scrollMethod=").append(lastScrollMethod).append('\n');
        sb.append("lastScanDurationMs=").append(lastScanDurationMs)
                .append(" scanned=").append(lastScannedPackages).append(" valid=").append(lastValidPackages)
                .append(" suspicious=").append(lastSuspiciousPackages).append(" duplicates=")
                .append(lastDuplicatePackages).append('\n');
        List<String> keys = new ArrayList<>(dumps.keySet());
        java.util.Collections.sort(keys);
        for (String key : keys) {
            sb.append("=== package=").append(key).append(" snapshots=")
                    .append(dumps.get(key).size()).append('\n');
            int page = 0;
            for (String snapshot : dumps.get(key)) {
                sb.append("--- snapshot ").append(++page).append(" ---\n")
                        .append(snapshot).append('\n');
            }
        }
        try (Writer w = new OutputStreamWriter(new FileOutputStream(
                new File(getFilesDir(), "diag.txt")), StandardCharsets.UTF_8)) {
            w.write(sb.toString());
        } catch (Exception ignored) {}
    }

}
