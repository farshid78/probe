package app.bastehyab;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapShader;
import android.graphics.Matrix;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.view.View;

/** Custom drawing for the opening / creator screen. Purely visual; no touch handling. */
final class SplashViews {
    private SplashViews() { }

    static float dp(View v, float value) {
        return value * v.getResources().getDisplayMetrics().density;
    }

    /** Backward-compatible splash background; shares the live ice/fire scene. */
    static final class Backdrop extends AppBackdrop {
        Backdrop(Context c) { super(c); }
    }

    /**
     * Lightweight animated wallpaper. Ice and ember orbs drift toward one another,
     * collide in staggered cycles, then shed small sparks/shards that fall behind UI.
     * It draws only on this background view, so cards, labels and touch targets remain
     * on top and fully interactive. The motion is time-based and loops without a seam.
     */
    static class AppBackdrop extends View {
        private static final long LOOP_MS = 9000L;
        private static final long FRAME_MS = 16L; // ~60fps; low-cost Canvas drawing while Activity is foregrounded.
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint orb = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint highlight = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint trail = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint spark = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path wave = new Path();
        private Shader backgroundShader, iceGlowShader, fireGlowShader;
        private boolean animationRunning;
        private long animationOrigin;

        AppBackdrop(Context c) {
            super(c);
            setWillNotDraw(false);
            setLayerType(View.LAYER_TYPE_HARDWARE, null);
            trail.setStyle(Paint.Style.STROKE);
            trail.setStrokeCap(Paint.Cap.ROUND);
            spark.setStrokeCap(Paint.Cap.ROUND);
        }

        @Override protected void onSizeChanged(int width, int height, int oldWidth, int oldHeight) {
            super.onSizeChanged(width, height, oldWidth, oldHeight);
            rebuildShaders(width, height);
        }

        void refreshTheme() {
            rebuildShaders(getWidth(), getHeight());
            invalidate();
        }

        private void rebuildShaders(int width, int height) {
            if (width <= 0 || height <= 0) return;
            backgroundShader = new LinearGradient(0, 0, width, height,
                    UI.light ? new int[]{0xFFF1F6F9, 0xFFE6EEF3, 0xFFDDE7ED}
                            : UI.mono ? new int[]{0xFF090A0C, 0xFF17191D, 0xFF25282E}
                            : new int[]{0xFF071521, 0xFF0D1D2A, 0xFF1B1C20},
                    null, Shader.TileMode.CLAMP);
            iceGlowShader = new RadialGradient(width * .08f, height * .16f, dp(this, 350),
                    UI.mono ? new int[]{0x2A9CA8B5, 0x009CA8B5}
                            : new int[]{0x3C55B9E7, 0x0055B9E7}, null, Shader.TileMode.CLAMP);
            fireGlowShader = new RadialGradient(width * .94f, height * .84f, dp(this, 390),
                    UI.mono ? new int[]{0x22858B95, 0x00858B95}
                            : new int[]{0x35F07B45, 0x00F07B45}, null, Shader.TileMode.CLAMP);
        }

        void startAnimation() {
            if (animationRunning) return;
            animationRunning = true;
            animationOrigin = android.os.SystemClock.uptimeMillis();
            postInvalidateOnAnimation();
        }

        void stopAnimation() {
            animationRunning = false;
            removeCallbacks(frameTick);
        }

        @Override protected void onDetachedFromWindow() {
            stopAnimation();
            super.onDetachedFromWindow();
        }

        private final Runnable frameTick = new Runnable() {
            @Override public void run() {
                if (animationRunning && isShown() && getWindowVisibility() == View.VISIBLE) invalidate();
            }
        };

        @Override protected void onDraw(Canvas cv) {
            super.onDraw(cv);
            float w = getWidth(), h = getHeight();
            if (w <= 0 || h <= 0) return;
            p.setShader(backgroundShader);
            cv.drawRect(0, 0, w, h, p);
            p.setShader(iceGlowShader);
            cv.drawRect(0, 0, w, h, p);
            p.setShader(fireGlowShader);
            cv.drawRect(0, 0, w, h, p);
            p.setShader(null);

            // Sparse glass-like geometry and very quiet flowing streaks.
            p.setStyle(Paint.Style.FILL);
            p.setColor(UI.mono ? 0x0DDEE2E8 : 0x0DD9F3FF);
            cv.drawRoundRect(-w*.12f, h*.08f, w*.12f, h*.20f, dp(this, 18), dp(this, 18), p);
            cv.drawRoundRect(w*.88f, h*.08f, w*1.10f, h*.22f, dp(this, 20), dp(this, 20), p);
            cv.drawRoundRect(w*.06f, h*.78f, w*.28f, h*.94f, dp(this, 20), dp(this, 20), p);
            cv.drawRoundRect(w*.88f, h*.81f, w*1.09f, h*.96f, dp(this, 20), dp(this, 20), p);
            trail.setStrokeWidth(dp(this, 1.15f));
            trail.setColor(UI.mono ? 0x204B525C : 0x2477BBD7);
            wave.reset(); wave.moveTo(-w*.10f, h*.88f);
            wave.cubicTo(w*.28f, h*.74f, w*.62f, h*.99f, w*1.10f, h*.82f);
            cv.drawPath(wave, trail);
            trail.setColor(UI.mono ? 0x183F454E : 0x20F18455);
            wave.reset(); wave.moveTo(-w*.08f, h*.93f);
            wave.cubicTo(w*.33f, h*.79f, w*.67f, h*1.01f, w*1.09f, h*.88f);
            cv.drawPath(wave, trail);

            long elapsed = animationRunning
                    ? Math.max(0L, android.os.SystemClock.uptimeMillis() - animationOrigin) : 0L;
            float base = (elapsed % LOOP_MS) / (float) LOOP_MS;
            for (int i = 0; i < 3; i++) {
                float phase = (base + i / 3f) % 1f;
                drawCollisionPair(cv, w, h, phase, i);
            }
            if (animationRunning && isShown() && getWindowVisibility() == View.VISIBLE) {
                removeCallbacks(frameTick);
                postDelayed(frameTick, FRAME_MS);
            }
        }

        private void drawCollisionPair(Canvas cv, float w, float h, float phase, int lane) {
            final float impactAt = .46f;
            float separation;
            if (phase < impactAt) {
                float t = smooth(phase / impactAt);
                separation = 0.42f * (1f - t);
            } else {
                float t = smooth((phase - impactAt) / (1f - impactAt));
                separation = 0.42f * t;
            }
            float centerX = w * .5f;
            float centerY = h * (.20f + lane * .30f)
                    + (float)Math.sin(phase * Math.PI * 2f + lane * 1.7f) * h * .025f;
            float dx = w * separation;
            float radius = dp(this, 7.5f + lane * 1.4f);
            int ice = UI.mono ? 0xFFCAD0D8 : UI.light ? 0xFF78BBD6 : 0xFF75D9F5;
            int fire = UI.mono ? 0xFF9EA5AF : UI.light ? 0xFFE09A70 : 0xFFFF965F;

            drawOrb(cv, centerX - dx, centerY, radius, ice, true);
            drawOrb(cv, centerX + dx, centerY, radius, fire, false);

            if (phase >= impactAt) {
                float age = (phase - impactAt) / (1f - impactAt);
                float fade = 1f - age;
                float ringRadius = dp(this, 9f + 32f * age);
                spark.setStyle(Paint.Style.STROKE);
                spark.setStrokeWidth(dp(this, 1.25f));
                spark.setColor(withAlpha(ice, Math.round(100 * fade)));
                cv.drawCircle(centerX, centerY, ringRadius, spark);
                spark.setStyle(Paint.Style.FILL);
                spark.setColor(withAlpha(fire, Math.round(34 * fade)));
                cv.drawCircle(centerX, centerY, dp(this, 5f + 17f * age), spark);

                // Alternating ice splinters and ember sparks arc out then fall toward the bottom.
                for (int k = 0; k < 10; k++) {
                    float delay = k * .035f;
                    float t = Math.max(0f, age - delay) / Math.max(.001f, 1f - delay);
                    if (t <= 0f || t >= 1f) continue;
                    float angle = k * 2.3999632f + lane * .83f;
                    float drift = (float)Math.sin(angle) * w * (.055f + .065f * t) * t;
                    float x = centerX + drift;
                    float fallDistance = Math.max(0f, h - centerY);
                    float y = centerY + fallDistance * (.88f * t + .12f * t * t)
                            + (float)Math.sin(t * 8f + k) * dp(this, 2f);
                    if (y > h * .985f) continue;
                    float groundFade = Math.min(1f, (h - y) / Math.max(1f, h * .10f));
                    int color = (k & 1) == 0 ? ice : fire;
                    int alpha = Math.max(0, Math.min(150, Math.round((125f * (1f - t * .45f)) * fade * groundFade)));
                    spark.setColor(withAlpha(color, alpha));
                    if ((k & 1) == 0) {
                        spark.setStrokeWidth(dp(this, 1.5f));
                        float shard = dp(this, 3f + (k % 3));
                        cv.drawLine(x - shard, y - shard * .65f, x + shard, y + shard * .65f, spark);
                        cv.drawLine(x - shard * .45f, y + shard, x + shard * .45f, y - shard, spark);
                    } else {
                        cv.drawCircle(x, y, dp(this, 1.5f + (k % 2)), spark);
                    }
                }
            }
        }

        private void drawOrb(Canvas cv, float x, float y, float r, int color, boolean icy) {
            glow.setStyle(Paint.Style.FILL);
            glow.setColor(withAlpha(color, 16)); cv.drawCircle(x, y, r * 3.0f, glow);
            glow.setColor(withAlpha(color, 25)); cv.drawCircle(x, y, r * 2.0f, glow);
            glow.setColor(withAlpha(color, 45)); cv.drawCircle(x, y, r * 1.35f, glow);
            orb.setColor(color); cv.drawCircle(x, y, r, orb);
            orb.setStyle(Paint.Style.STROKE); orb.setStrokeWidth(dp(this, .9f));
            orb.setColor(withAlpha(0xFFFFFFFF, 145)); cv.drawCircle(x - r*.1f, y - r*.1f, r*.92f, orb);
            orb.setStyle(Paint.Style.FILL);
            highlight.setColor(withAlpha(0xFFFFFFFF, icy ? 185 : 125));
            cv.drawCircle(x - r*.28f, y - r*.32f, r*.24f, highlight);
        }

        private static int withAlpha(int color, int alpha) {
            return (Math.max(0, Math.min(255, alpha)) << 24) | (color & 0x00FFFFFF);
        }
        private static float smooth(float x) {
            x = Math.max(0f, Math.min(1f, x));
            return x * x * (3f - 2f * x);
        }
    }

    /** Original Bastehyab brand mark, shared with the launcher icon. */
    static final class BrandMark extends View {
        private final Paint imagePaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        private final Paint shadowPaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        private final Bitmap mark;
        BrandMark(Context c) {
            super(c);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
            shadowPaint.setColor(0xFFFFFFFF);
            shadowPaint.setShadowLayer(dp(this, 10), 0, dp(this, 5), UI.mono ? 0xAA000000 : 0xAA050B18);
            Bitmap decoded = BitmapFactory.decodeResource(c.getResources(), R.drawable.brand_mark);
            mark = decoded;
        }
        @Override protected void onDraw(Canvas c) {
            if (mark == null || getWidth() <= 0 || getHeight() <= 0) return;
            float side = Math.min(getWidth(), getHeight()) * .94f;
            android.graphics.RectF dst = new android.graphics.RectF(
                    (getWidth() - side) * .5f, (getHeight() - side) * .5f,
                    (getWidth() + side) * .5f, (getHeight() + side) * .5f);
            android.graphics.RectF shadow = new android.graphics.RectF(dst);
            shadow.offset(0, dp(this, 2.5f));
            c.drawBitmap(mark, null, shadow, shadowPaint);
            c.drawBitmap(mark, null, dst, imagePaint);
        }
    }

    /** Soft rounded logo halo with a ice-blue and ember edge light. */
    static final class LogoHalo extends View {
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);

        LogoHalo(Context c) {
            super(c);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
            stroke.setStyle(Paint.Style.STROKE);
            stroke.setStrokeWidth(dp(this, 2));
        }

        @Override protected void onDraw(Canvas cv) {
            float w = getWidth(), h = getHeight();
            float inset = dp(this, 2);
            android.graphics.RectF bounds = new android.graphics.RectF(inset, inset, w-inset, h-inset);
            fill.setColor(UI.mono ? 0x553A3E46 : 0x554CB6D9);
            android.graphics.RectF shadowBounds = new android.graphics.RectF(bounds);
            shadowBounds.offset(0, dp(this, 4));
            cv.drawRoundRect(shadowBounds, dp(this, 34), dp(this, 34), fill);
            fill.setShader(new LinearGradient(0, 0, w, h,
                    UI.light ? new int[]{0xAAFFFFFF, 0x556BADC7, 0x33D58B69}
                            : UI.mono ? new int[]{0x88666D78, 0x44252A31}
                            : new int[]{0x8879D9F4, 0x553C769A, 0x66FF895B},
                    null, Shader.TileMode.CLAMP));
            fill.setShadowLayer(dp(this, 12), 0, dp(this, 5), UI.mono ? 0x99000000 : 0xAA55BFEA);
            cv.drawRoundRect(bounds, dp(this, 34), dp(this, 34), fill);
            fill.clearShadowLayer();
            stroke.setStrokeWidth(dp(this, 2.1f));
            stroke.setShader(new LinearGradient(0, 0, w, h,
                    UI.mono ? new int[]{0xFFF5F6F8, 0xFF858D99, 0xFFFFFFFF}
                            : new int[]{0xFFE3FBFF, UI.ICE, UI.FIRE, 0xFFFFD2B5},
                    null, Shader.TileMode.CLAMP));
            cv.drawRoundRect(bounds, dp(this, 34), dp(this, 34), stroke);
            stroke.setStrokeWidth(dp(this, .8f));
            stroke.setColor(UI.mono ? 0x66868D98 : 0x667FE0F5);
            android.graphics.RectF inner = new android.graphics.RectF(bounds);
            inner.inset(dp(this, 4), dp(this, 4));
            cv.drawRoundRect(inner, dp(this, 30), dp(this, 30), stroke);
        }

        static Path hex(float cx, float cy, float r) {
            Path p = new Path();
            for (int i = 0; i < 6; i++) {
                double a = Math.PI / 3 * i - Math.PI / 6;
                float x = (float) (cx + r * Math.cos(a));
                float y = (float) (cy + r * Math.sin(a));
                if (i == 0) p.moveTo(x, y); else p.lineTo(x, y);
            }
            p.close();
            return p;
        }
    }

    /** Accent circle with a paper-plane glyph (Telegram-style). */
    static final class PlaneIcon extends View {
        private final Paint circle = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint glyph = new Paint(Paint.ANTI_ALIAS_FLAG);

        PlaneIcon(Context c) {
            super(c);
            glyph.setColor(0xFFFFFFFF);
        }

        @Override protected void onDraw(Canvas cv) {
            float w = getWidth(), h = getHeight();
            if (w <= 0 || h <= 0) return;
            circle.setShader(new LinearGradient(0, 0, w, h,
                    new int[]{UI.PRIMARY, UI.BLUE}, null, Shader.TileMode.CLAMP));
            cv.drawCircle(w / 2f, h / 2f, Math.min(w, h) / 2f, circle);
            Path p = new Path();
            p.moveTo(w * 0.24f, h * 0.48f);
            p.lineTo(w * 0.78f, h * 0.26f);
            p.lineTo(w * 0.62f, h * 0.76f);
            p.lineTo(w * 0.47f, h * 0.60f);
            p.close();
            cv.drawPath(p, glyph);
            Path fold = new Path();
            fold.moveTo(w * 0.47f, h * 0.60f);
            fold.lineTo(w * 0.78f, h * 0.26f);
            fold.lineTo(w * 0.50f, h * 0.66f);
            fold.close();
            cv.drawPath(fold, glyph);
        }
    }

    /** Creator portrait cropped into a consistent circular frame for compact profile cards. */
    static final class PersonAvatar extends View {
        private final Paint fallback = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint photo = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        private final Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint innerRing = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Matrix shaderMatrix = new Matrix();
        private final Bitmap portrait;
        private final BitmapShader shader;

        PersonAvatar(Context c) {
            super(c);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
            Bitmap loaded;
            try {
                loaded = BitmapFactory.decodeResource(c.getResources(), R.drawable.creator_avatar);
            } catch (RuntimeException ex) {
                loaded = null;
            }
            portrait = loaded;
            shader = portrait == null ? null : new BitmapShader(portrait,
                    Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
            photo.setDither(true);
            if (shader != null) photo.setShader(shader);

            fallback.setColor(UI.light ? 0xFF397F9D : UI.mono ? 0xFF34383F : 0xFF18354A);
            glow.setColor(UI.light ? 0x225AAACB : UI.mono ? 0x224D535D : 0x2279D9F4);
            glow.setStyle(Paint.Style.FILL);
            glow.setShadowLayer(dp(this, 4), 0, 0,
                    UI.light ? 0x335AAACB : UI.mono ? 0x334D535D : 0x4479D9F4);
            ring.setStyle(Paint.Style.STROKE);
            ring.setStrokeWidth(dp(this, 2.2f));
            ring.setShader(new LinearGradient(0, 0, dp(this, 66), dp(this, 66),
                    UI.mono ? new int[]{0xFFE8EBF0, 0xFF9299A3, 0xFFF4F5F7}
                            : new int[]{UI.ICE, UI.BLUE, UI.FIRE}, null, Shader.TileMode.CLAMP));
            innerRing.setStyle(Paint.Style.STROKE);
            innerRing.setStrokeWidth(dp(this, 0.8f));
            innerRing.setColor(UI.mono ? 0x667A828E : 0x6679BBD2);
        }

        @Override protected void onDraw(Canvas cv) {
            super.onDraw(cv);
            float w = getWidth(), h = getHeight();
            if (w <= 0 || h <= 0) return;
            float cx = w * .5f, cy = h * .5f;
            float radius = Math.min(w, h) * .5f - dp(this, 4);
            if (radius <= 0) return;

            cv.drawCircle(cx, cy, radius + dp(this, 1), glow);
            if (shader != null && portrait != null) {
                float diameter = (radius - dp(this, 2)) * 2f;
                float scale = diameter / Math.min(portrait.getWidth(), portrait.getHeight());
                float left = cx - portrait.getWidth() * scale * .5f;
                float top = cy - portrait.getHeight() * scale * .5f;
                shaderMatrix.setScale(scale, scale);
                shaderMatrix.postTranslate(left, top);
                shader.setLocalMatrix(shaderMatrix);
                cv.drawCircle(cx, cy, radius - dp(this, 2), photo);
            } else {
                cv.drawCircle(cx, cy, radius - dp(this, 2), fallback);
                Paint figure = new Paint(Paint.ANTI_ALIAS_FLAG);
                figure.setColor(0xFFF0F6FF);
                cv.drawCircle(cx, cy - radius * .20f, radius * .22f, figure);
                cv.drawOval(cx - radius * .48f, cy + radius * .05f,
                        cx + radius * .48f, cy + radius * .83f, figure);
            }
            cv.drawCircle(cx, cy, radius - dp(this, 1), ring);
            cv.drawCircle(cx, cy, radius - dp(this, 4), innerRing);
            Paint status = new Paint(Paint.ANTI_ALIAS_FLAG);
            status.setColor(0xFF63DDAA);
            cv.drawCircle(cx + radius * .68f, cy + radius * .68f, dp(this, 5.5f), status);
            status.setColor(UI.mono ? 0xFF101114 : UI.light ? 0xFFFFFFFF : 0xFF0A121C);
            cv.drawCircle(cx + radius * .68f, cy + radius * .68f, dp(this, 2.2f), status);
        }
    }
}
