package app.bastehyab;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.RippleDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Shared visual system for Bastehyab. All screens consume the same dark, light and monochrome tokens. */
final class UI {
    private UI() { }

    static boolean light, mono;
    static int BG, CARD, CARD2, STROKE, PRIMARY, ACCENT, TEXT, MUTED, DANGER, BLUE, ICE, FIRE;
    static final int SUCCESS = 0xFF45C995;
    static Typeface BODY, MEDIUM, BOLD;

    static void applyTheme(Context c) {
        String appearance = Cfg.sp(c).getString("appearance", "dark");
        light = "light".equals(appearance);
        mono = "mono".equals(appearance);
        if (light) {
            BG = 0xFFF0F5F8; CARD = 0xFFFAFCFD; CARD2 = 0xFFE8F0F4; STROKE = 0xFFD5E1E8;
            PRIMARY = 0xFF397F9D; ACCENT = 0xFF668EAA; TEXT = 0xFF192630;
            MUTED = 0xFF647987; DANGER = 0xFFB76549; BLUE = 0xFF438EAF;
            ICE = 0xFF5AAACB; FIRE = 0xFFC87351;
        } else if (mono) {
            BG = 0xFF101114; CARD = 0xFF1A1C20; CARD2 = 0xFF25282E; STROKE = 0xFF3A3E46;
            PRIMARY = 0xFFE8EBF0; ACCENT = 0xFFB7BEC8; TEXT = 0xFFF3F4F6;
            MUTED = 0xFFA6ADB7; DANGER = 0xFFD0D3D9; BLUE = 0xFFCDD3DC;
            ICE = 0xFFE5E9EF; FIRE = 0xFFB8BEC7;
        } else {
            // Dark ice-and-fire: cool blue/cyan is the primary action colour;
            // ember orange is reserved for warnings, highlights and small accents.
            BG = 0xFF0A121C; CARD = 0xFF151F2B; CARD2 = 0xFF1D2A39; STROKE = 0xFF304154;
            PRIMARY = 0xFF73CBE9; ACCENT = 0xFF9CB9D8; TEXT = 0xFFF0F5F8;
            MUTED = 0xFF9BAFBE; DANGER = 0xFFFF956C; BLUE = 0xFF69B6D7;
            ICE = 0xFF79D9F4; FIRE = 0xFFFF895B;
        }
        if (BODY == null || MEDIUM == null || BOLD == null) {
            try {
                BODY = Typeface.createFromAsset(c.getAssets(), "fonts/NotoSansArabic-Regular.ttf");
                MEDIUM = Typeface.createFromAsset(c.getAssets(), "fonts/NotoSansArabic-Medium.ttf");
                BOLD = Typeface.createFromAsset(c.getAssets(), "fonts/NotoSansArabic-Bold.ttf");
            } catch (RuntimeException fontError) {
                BODY = Typeface.create("sans-serif", Typeface.NORMAL);
                MEDIUM = Typeface.create("sans-serif-medium", Typeface.NORMAL);
                BOLD = Typeface.create("sans-serif", Typeface.BOLD);
            }
        }
    }

    static int themeColor(int color) {
        int alpha = color >>> 24;
        int rgb = color & 0x00FFFFFF;
        int mapped = rgb;
        if (mono) {
            // Keep current semantic tokens intact; legacy decorative colours collapse
            // to a restrained grayscale ramp for the classic black-and-white theme.
            if (rgb == (BG & 0x00FFFFFF) || rgb == (CARD & 0x00FFFFFF)
                    || rgb == (CARD2 & 0x00FFFFFF) || rgb == (STROKE & 0x00FFFFFF)
                    || rgb == (PRIMARY & 0x00FFFFFF) || rgb == (ACCENT & 0x00FFFFFF)
                    || rgb == (TEXT & 0x00FFFFFF) || rgb == (MUTED & 0x00FFFFFF)
                    || rgb == (DANGER & 0x00FFFFFF) || rgb == (BLUE & 0x00FFFFFF)) {
                mapped = rgb;
            } else {
                int r = (rgb >> 16) & 255, g = (rgb >> 8) & 255, b = rgb & 255;
                int luminance = (r * 212 + g * 715 + b * 73) / 1000;
                if (luminance < 28) mapped = BG;
                else if (luminance < 82) mapped = CARD;
                else if (luminance < 150) mapped = CARD2;
                else if (luminance < 218) mapped = MUTED;
                else mapped = TEXT;
            }
        } else if (light) {
            switch (rgb) {
                case 0x07101F: case 0x050B15: case 0x0C1B31: case 0x091426: case 0x0B172A:
                case 0x101828: case 0x10182D: case 0x07152F: case 0x0B2348: mapped = BG; break;
                case 0x11213A: case 0x101F37: case 0x0E1A30: case 0x0E1A2D: case 0x0E1A32:
                case 0x1B2942: case 0x182D4A: case 0x172238: mapped = CARD; break;
                case 0x1B3150: case 0x28415F: case 0x182B47: case 0x263B5A: case 0x16283A:
                case 0x152D42: case 0x0C1931: case 0x1A2D4A: case 0x142642: mapped = CARD2; break;
                case 0xF7FAFF: case 0xFFFFFF: mapped = TEXT; break;
                case 0xB3C1D7: case 0xB9D5E9: case 0x8393B0: mapped = MUTED; break;
                case 0x4AD9EA: case 0x55E8FF: case 0x54E8F7: case 0x41DDF4: case 0x35D9F5:
                case 0x37DFF4: case 0x38DDF2: mapped = PRIMARY; break;
                case 0xB39BFF: case 0x9D78FF: case 0x9D7BFF: mapped = ACCENT; break;
                case 0xFF829A: case 0xFF718F: mapped = DANGER; break;
                case 0x3A557A: case 0x516C91: case 0x587396: case 0x74518D: mapped = STROKE; break;
                case 0x373449: case 0x29283A: case 0x49315F: case 0x29273F: mapped = CARD; break;
                case 0x353349: case 0x48445F: mapped = CARD2; break;
                case 0xB65AF2: case 0xB65FE4: case 0xCE55EA: case 0x8F53C8: case 0x6245D0: mapped = PRIMARY; break;
                case 0x5B4DB2: case 0x8F4DD4: case 0x7646E8: case 0xCB58B9: mapped = ACCENT; break;
                case 0xF08ADF: case 0xFF7F9C: mapped = FIRE; break;
                case 0xFFF3E7FB: case 0xFFEFE7FA: mapped = CARD2; break;
                default: break;
            }
        } else {
            switch (rgb) {
                case 0x07101F: case 0x050B15: case 0x0C1B31: case 0x091426: case 0x0B172A:
                case 0x101828: case 0x10182D: case 0x07152F: case 0x0B2348: mapped = BG; break;
                case 0x11213A: case 0x101F37: case 0x0E1A30: case 0x0E1A2D: case 0x0E1A32:
                case 0x1B2942: case 0x182D4A: case 0x172238: mapped = CARD; break;
                case 0x1B3150: case 0x28415F: case 0x182B47: case 0x263B5A: case 0x16283A:
                case 0x152D42: case 0x0C1931: case 0x1A2D4A: case 0x142642: mapped = CARD2; break;
                case 0xF7FAFF: case 0xFFFFFF: mapped = TEXT; break;
                case 0xB3C1D7: case 0xB9D5E9: case 0x8393B0: mapped = MUTED; break;
                case 0x4AD9EA: case 0x55E8FF: case 0x54E8F7: case 0x41DDF4: case 0x35D9F5:
                case 0x37DFF4: case 0x38DDF2: mapped = PRIMARY; break;
                case 0xB39BFF: case 0x9D78FF: case 0x9D7BFF: mapped = ACCENT; break;
                case 0xFF829A: case 0xFF718F: mapped = DANGER; break;
                case 0x3A557A: case 0x516C91: case 0x587396: case 0x74518D: mapped = STROKE; break;
                case 0x373449: case 0x29283A: case 0x49315F: case 0x29273F: mapped = CARD; break;
                case 0x353349: case 0x48445F: mapped = CARD2; break;
                case 0xB65AF2: case 0xB65FE4: case 0xCE55EA: case 0x8F53C8: case 0x6245D0: mapped = PRIMARY; break;
                case 0x5B4DB2: case 0x8F4DD4: case 0x7646E8: case 0xCB58B9: mapped = ACCENT; break;
                case 0xF08ADF: case 0xFF7F9C: mapped = FIRE; break;
                case 0xFFF3E7FB: case 0xFFEFE7FA: mapped = CARD2; break;
                default: break;
            }
        }
        return (alpha << 24) | (mapped & 0x00FFFFFF);
    }

    static void applyTypefaceTree(View view) {
        if (view instanceof TextView) {
            TextView text = (TextView) view;
            if (text instanceof Button || text instanceof android.widget.Switch) text.setTypeface(MEDIUM);
            else if (text.getTypeface() != null && text.getTypeface().isBold()) text.setTypeface(BOLD);
            else text.setTypeface(BODY);
            text.setIncludeFontPadding(false);
        }
        if (view instanceof android.view.ViewGroup) {
            android.view.ViewGroup group = (android.view.ViewGroup) view;
            for (int i = 0; i < group.getChildCount(); i++) applyTypefaceTree(group.getChildAt(i));
        }
    }

    static int dp(Context c, float v) { return Math.round(v * c.getResources().getDisplayMetrics().density); }
    static int sz(Context c, int v) { return v > 0 ? dp(c, v) : v; }

    static int surfaceColor(int color) {
        if ((color & 0x00FFFFFF) == 0x00FFFFFF || (color >>> 24) == 0) return color;
        return themeColor(color);
    }
    private static int shade(int color, float factor) {
        int a = color & 0xFF000000;
        int red = Math.max(0, Math.min(255, Math.round(((color >> 16) & 255) * factor)));
        int green = Math.max(0, Math.min(255, Math.round(((color >> 8) & 255) * factor)));
        int blue = Math.max(0, Math.min(255, Math.round((color & 255) * factor)));
        return a | (red << 16) | (green << 8) | blue;
    }
    static GradientDrawable rr(Context c, int fill, float r) {
        int resolved = surfaceColor(fill);
        GradientDrawable g;
        if ((resolved >>> 24) == 0xFF) {
            float up = light ? 1.012f : mono ? 1.035f : 1.055f;
            float down = light ? 0.988f : mono ? 0.965f : 0.972f;
            g = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                    new int[]{shade(resolved, up), shade(resolved, down)});
        } else {
            g = new GradientDrawable();
            g.setColor(resolved);
        }
        g.setCornerRadius(dp(c, r));
        return g;
    }
    static GradientDrawable rr(Context c, int fill, float r, int stroke) {
        GradientDrawable g = rr(c, fill, r); g.setStroke(dp(c, 1), surfaceColor(stroke)); return g;
    }
    static GradientDrawable grad(Context c, int a, int b, float r) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{surfaceColor(a), surfaceColor(b)}); g.setCornerRadius(dp(c, r)); return g;
    }
    static Drawable appBackground(Context c) {
        if (light) return new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{0xFFF6FAFC, 0xFFEAF1F5, 0xFFE4EBF0});
        if (mono) return new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{0xFF090A0C, 0xFF14161A, 0xFF202329});
        // A low-saturation diagonal wash suggests ice meeting ember without
        // turning the background into a bright fire effect.
        return new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{0xFF091827, 0xFF101B2A, 0xFF1C2029, 0xFF251A18});
    }
    static int tint(int color) { return (themeColor(color) & 0x00FFFFFF) | 0x22000000; }
    static int contrastText(int background) {
        double r = ((background >> 16) & 255) / 255.0;
        double g = ((background >> 8) & 255) / 255.0;
        double b = (background & 255) / 255.0;
        r = r <= 0.04045 ? r / 12.92 : Math.pow((r + 0.055) / 1.055, 2.4);
        g = g <= 0.04045 ? g / 12.92 : Math.pow((g + 0.055) / 1.055, 2.4);
        b = b <= 0.04045 ? b / 12.92 : Math.pow((b + 0.055) / 1.055, 2.4);
        double luminance = 0.2126 * r + 0.7152 * g + 0.0722 * b;
        return luminance > 0.42 ? 0xFF182338 : 0xFFFFFFFF;
    }

    static TextView tv(Context c, String s, float sp, int color, boolean bold) {
        TextView t = new TextView(c); t.setText(s); t.setTextSize(Math.max(10.5f, sp)); t.setTextColor(themeColor(color));
        t.setTypeface(bold ? BOLD : BODY);
        t.setTextDirection(View.TEXT_DIRECTION_RTL); t.setGravity(Gravity.TOP | Gravity.START);
        t.setTextAlignment(View.TEXT_ALIGNMENT_GRAVITY); t.setIncludeFontPadding(false);
        t.setLineSpacing(dp(c, 2f), 1.08f);
        return t;
    }
    static LinearLayout vbox(Context c) {
        LinearLayout l = new LinearLayout(c); l.setOrientation(LinearLayout.VERTICAL);
        l.setLayoutDirection(View.LAYOUT_DIRECTION_RTL); return l;
    }
    static LinearLayout hbox(Context c) {
        LinearLayout l = new LinearLayout(c); l.setOrientation(LinearLayout.HORIZONTAL);
        l.setLayoutDirection(View.LAYOUT_DIRECTION_RTL); l.setGravity(Gravity.CENTER_VERTICAL); return l;
    }
    static LinearLayout.LayoutParams lp(Context c, int w, int h, float s, float t, float e, float b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(sz(c, w), sz(c, h));
        p.setMargins(0, dp(c, t), 0, dp(c, b)); p.setMarginStart(dp(c, s)); p.setMarginEnd(dp(c, e)); return p;
    }
    static LinearLayout.LayoutParams lp2(Context c, float start) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        p.setMarginStart(dp(c, start)); return p;
    }
    static LinearLayout.LayoutParams lpw(float weight) { return new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, weight); }
    static LinearLayout card(Context c) {
        LinearLayout l = vbox(c);
        int p = dp(c, 16);
        l.setPadding(p, p, p, p);
        int top = light ? 0xFFFEFFFF : mono ? 0xFF24272D : 0xFF1B2938;
        GradientDrawable panel = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{top, CARD});
        panel.setCornerRadius(dp(c, 20));
        panel.setStroke(dp(c, 1), STROKE);
        l.setBackground(panel);
        l.setClipToOutline(true);
        // A visible but restrained lift: soft ambient shadow + a bright top edge.
        l.setElevation(dp(c, 6));
        return l;
    }
    static TextView chip(Context c, String s, int bg, int fg) {
        TextView t = tv(c, s, 11, fg, true);
        t.setPadding(dp(c, 11), dp(c, 8), dp(c, 11), dp(c, 8));
        boolean selected = (themeColor(bg) & 0x00FFFFFF) == (PRIMARY & 0x00FFFFFF);
        if (selected) {
            t.setTextColor(contrastText(PRIMARY));
            t.setBackground(grad(c, PRIMARY, ACCENT, 13));
        } else t.setBackground(rr(c, bg, 13, STROKE));
        t.setGravity(Gravity.CENTER);
        return t;
    }
    static Button btn(Context c, String s, int bg, int fg, View.OnClickListener l) {
        Button b = new Button(c);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextSize(13);
        b.setTypeface(MEDIUM);
        boolean primary = (themeColor(bg) & 0x00FFFFFF) == (PRIMARY & 0x00FFFFFF);
        GradientDrawable shape = primary
                ? new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                    mono ? new int[]{0xFFE8EBF0, 0xFFB7BEC8}
                         : light ? new int[]{0xFF65B4D2, 0xFF397F9D}
                         : new int[]{0xFF3988A8, 0xFF2B6685})
                : new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                    new int[]{surfaceColor(bg), surfaceColor(bg)});
        shape.setCornerRadius(dp(c, 16));
        shape.setStroke(dp(c, 1), primary ? (mono ? 0xFF9EA6B1 : light ? 0xFF76AFC5 : 0xFF4A839B) : STROKE);
        b.setTextColor(primary ? contrastText(mono ? 0xFFE8EBF0 : light ? 0xFF65B4D2 : 0xFF73CBE9)
                : themeColor(fg));
        b.setBackground(new RippleDrawable(ColorStateList.valueOf(0x33FFFFFF), shape,
                rr(c, 0xFFFFFFFF, 16)));
        b.setStateListAnimator(null);
        b.setElevation(dp(c, 4));
        b.setMinHeight(dp(c, 48));
        b.setMinimumHeight(dp(c, 48));
        b.setGravity(Gravity.CENTER);
        b.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        b.setTextDirection(View.TEXT_DIRECTION_RTL);
        b.setPadding(dp(c, 16), dp(c, 10), dp(c, 16), dp(c, 10));
        b.setOnClickListener(l);
        return b;
    }
}
