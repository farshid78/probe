# گزارش اجرای پرامپت‌ها — Bastehyab

**آرشیو ورودی:** `Bastehyab_1.9.5.zip`  
**نسخهٔ canonical داخل سورس:** `VERSION_NAME=1.9.1` و `VERSION_CODE=1900000001` در `version.properties`  
**تاریخ ممیزی:** 2026-11-13

> نام ZIP با نسخهٔ واقعی canonical داخل پروژه یکسان نیست. برای جلوگیری از rollback یا تغییر ناخواستهٔ انتشار، نام فایل ZIP مبنای versionName قرار نگرفت و `version.properties` بدون تغییر باقی ماند.

## خلاصهٔ تصمیم‌ها بر اساس پرامپت‌ها

| پرامپت | وضعیت قبل از ویرایش | اقدام در این دور | وضعیت نهایی |
|---|---|---|---|
| چرخهٔ عمر scan worker | generation/session guard و finally برای adaptive scroll وجود داشت؛ scan worker هنوز catch/finally محلی و مسیر rejection جداگانه داشت | `ScanWorkerTask` برای تکمیل دقیقاً یک‌باره در owner thread اضافه شد؛ exception و rejection به نتیجهٔ خطا تبدیل می‌شوند؛ retry خطا در full session حداکثر دو تلاش مجدد دارد | اصلاح محدود انجام شد؛ تست JUnit و smoke worker اضافه شد؛ fault injection کامل روی adaptive scroll و race دستگاهی باقی است |
| تشخیص انتهای فهرست | freshness، package/session/container signature، vertical container و `ListEndDetector` از قبل وجود داشتند | تولید الگوریتم جدید لازم نبود؛ سناریوهای موجود smoke بازبینی شدند | عمدتاً از قبل پیاده‌سازی شده؛ تست چند-container واقعی و fixture اپراتور باقی است |
| رضایت و Accessibility | disclosure، affirmative action، consent نشست، allowlist پنج اپراتور، توقف در disable و نبود INTERNET/`isAccessibilityTool` از قبل وجود داشت | مسیر ذخیرهٔ dump/diagnostic خام حذف شد؛ `diag.txt` فقط شمارنده و state code محدود را می‌نویسد؛ sanitizer با متن/description اعلان اجباری redaction می‌کند | اصلاح حریم خصوصی انجام شد؛ بازبینی دستی disclosure و Play Console checklist همچنان لازم است |
| قیمت، ارز و VAT | `PriceModel` و مسیر canonical و پرهیز از fallback اپراتوری موجود بود | تبدیل ریال با مبلغ غیرقابل‌تقسیم بر ۱۰ رد می‌شود تا اعشار تومان truncate نشود؛ تست‌های JVM جدول‌محور اضافه شد | اصلاح و تست‌نویسی انجام شد؛ JUnit تحت Gradle اجرا نشده |
| Store | snapshot عمیق، schema version، quarantine، backup، atomic write و executor ذخیره از قبل وجود داشت | منطق production دست نخورده نگه داشته شد؛ تست Robolectric parser و migration اضافه شد؛ smoke recovery/concurrency اجرا شد | از قبل عمدتاً پیاده‌سازی شده؛ تست Robolectric اجرا نشده |
| identity و dedup | `PkgIdentity` نسخه ۳، product ID مشاهده‌شده و fingerprint پایدار از قبل وجود داشت | منطق production تغییر نکرد؛ تست‌های identity قیمت‌مستقل/مدت/حجم/متن مجاور/ID اضافه شد | از قبل پیاده‌سازی شده؛ تست JUnit افزوده ولی اجرا نشده |
| Home live refresh | ticker از `updateHomeScanUi()` استفاده می‌کرد و render کامل هر tick نبود | تغییری ندادم | موجود؛ شبیه‌سازی ساختاری ۵ دقیقه‌ای smoke PASS شد؛ تست Activity واقعی باقی است |
| UI/UX و Accessibility | ساختار RTL، palette، labels، touch target و dialog adaptiveness تا حد زیادی موجود بود | تغییر گستردهٔ بصری انجام نشد تا قابلیت سالم و زبان بصری بی‌دلیل تغییر نکند | smoke ساختاری PASS؛ TalkBack، فونت ۲۰۰٪، عرض 320dp و screenshot واقعی هنوز دستی‌اند |
| پس‌زمینه | `AppBackdropInstrumentationTest` واقعی در `androidTest` وجود داشت؛ stub ناقص smoke مبنای گزارش نبود | تست instrumentation موجود حفظ شد؛ static guard اجرا شد | تست واقعی در سورس هست، اما در این محیط به علت نبود adb اجرا نشد |
| ساخت و انتشار | نسخه canonical، tag/manual approval و bootstrap Wrapper موجود؛ منطق قبلی اجازهٔ publish روی main را داشت؛ AVD path مشکل‌پذیر بود | push به main فقط build/test می‌کند؛ release فقط tag هم‌نام یا dispatch از main؛ AVD path/user-home/libpulse/library path صریح شد؛ گزارش‌ها و coverage taskها در CI اضافه شدند | پیکربندی و static validation PASS؛ اجرای CI و build واقعی هنوز اثبات نشده |
| fixture catalog | fixture زندهٔ پنج اپراتور در ZIP وجود نداشت | کاتالوگ نسخه‌دار پنج اپراتور با metadata `null` و `certified=false` اضافه شد؛ sanitizer اعلان را redacted می‌کند | catalog آماده؛ fixture واقعی عمداً NOT_CAPTURED باقی مانده |
| مرتب‌سازی مخزن | فایل‌های preview و تصاویر مرجع داخل `branding/` بودند؛ PNG icon و logo تکراری بودند؛ لینک‌های README به اسناد غایب اشاره داشتند | previewها به `design/references/` منتقل شدند؛ README و branding README اصلاح شدند؛ اسناد جاری/گزارش‌ها اضافه شد؛ لینک‌های مرده حذف شدند | مرتب‌سازی انجام شد؛ duplicate PNG و `bg_app.xml` به علت نبود build/resource proof حذف نشدند |

## تغییرات فایل‌ها

### فایل‌های production تغییرکرده

- `app/src/main/java/app/bastehyab/ScanService.java`: completion یکتا برای scan worker، retry محدود و حذف مسیر diagnostic حاوی dump خام.
- `app/src/main/java/app/bastehyab/ScanWorkerTask.java`: abstraction کوچک برای exactly-once completion به callback مالک state.
- `app/src/main/java/app/bastehyab/PriceModel.java`: رد تبدیل ریال به تومان در صورت عدم تقسیم‌پذیری دقیق بر ۱۰.

### تست‌ها و ابزارها

- تست JVM جدید: `CfgMigrationTest`, `CompareTest`, `ExtractorJvmTest`, `HistoryTest`, `PkgIdentityTest`, `PriceModelTest`, `ScanWorkerTaskTest`, `StoreParserTest`.
- smoke harness جدید: `tools/android-core-smoke-tests/ScanWorkerTaskSmokeTest.java` و اضافه‌شدن آن به core/popup harness.
- sanitizer: `tools/fixture-sanitizer/sanitize_accessibility.py` و `test.sh` برای redaction اجباری notification/status-bar/heads-up rows.

### CI، اسناد و دارایی‌ها

- `.github/workflows/android-build.yml`: منع release از push عادی به main، coverage taskها، upload reportها، AVD directory صریح، libpulse و SDK emulator library path.
- `tools/release/validate-release-metadata.py`: بررسی triggerهای release و canonical version از root.
- `README.md`, `CHANGELOG.md`, `branding/README_FA.md` و اسناد جدید در `docs/`.
- `test-fixtures/operators/catalog.json`.
- انتقال previewها و referenceها از `branding/` به `design/references/`.

## موجودی قبل و بعد

| مورد | قبل (ZIP ورودی) | بعد از ممیزی |
|---|---:|---:|
| فایل کل مخزن | 178 | 196 |
| فایل Markdown در root | 1 (`README.md`) | 2 (`README.md`, `CHANGELOG.md`) |
| فایل Markdown در `docs/` و `docs/archive/` | 0 | 6 |
| تست JVM در `app/src/test` | 3 | 11 |
| تست instrumentation در `app/src/androidTest` | 1 | 1 |
| capture/fixture واقعی پنج اپراتور | 0 | 0 (کاتالوگ placeholder اضافه شد) |
| preview/reference داخل `branding/` | 6 | 0؛ به `design/references/` منتقل شدند |

تعداد کل فایل‌های فعلی ۱۹۶ است؛ ۶ فایل تصویری صرفاً جابه‌جا شده‌اند و حذف نشده‌اند. دو PNG همسان باقی مانده‌اند و در گزارش دارایی به‌عنوان گزینهٔ حذفِ نیازمند تأیید owner معرفی شده‌اند. `bg_app.xml` نیز حفظ شده تا build resource واقعی انجام شود.

## تست‌های واقعاً اجراشده در این محیط

همهٔ موارد زیر با exit code صفر اجرا شدند:

- `tools/fixture-sanitizer/test.sh`
- `tools/parser-smoke-tests/run.sh`
- `tools/android-core-smoke-tests/run.sh` — شامل worker exception/rejection/یک‌بار completion، انتخاب container عمودی، stale timestamp، source/metric ناقص، session/consent و فیلترها.
- `tools/popup-overlay-smoke-tests/run.sh`
- `tools/ui-layout-smoke-tests/run.sh`
- `tools/android-core-smoke-tests/check-accessibility-api.sh`
- `tools/privacy-consent-tests/test.sh`
- `tools/store-smoke-tests/run.sh` — شامل رکورد معیوب، backup recovery، migration، concurrency، clear pending write، interrupt قبل/بعد rename و benchmark snapshot/identity.
- `tools/home-live-refresh-smoke-tests/test.py` — شبیه‌سازی ۲۰۰ tick / پنج دقیقه.
- `tools/backdrop-instrumentation-tests/static-review.py`
- `tools/release/validate-release-metadata.py`
- کنترل linkهای داخلی Markdown.
- parse فایل YAML workflow و `bash -n` برای ۲۲ بلوک فرمان `run`.

این تست‌ها smoke/static harness هستند؛ آنها جایگزین اجرای JUnit/Gradle، Android instrumentation یا آزمون دستگاه واقعی نیستند.

## تست‌های اجرا نشده و محدودیت‌ها

در این محیط `gradle`, `adb`, `gradlew` و `gradle-wrapper.jar` وجود نداشتند. شبکه نیز برای دریافت distribution/JAR رسمی Gradle در دسترس نبود. بنابراین موارد زیر اجرا نشده‌اند:

- `:app:testDebugUnitTest`؛ در نتیجه تمام تست‌های JUnit و Robolectric فقط اضافه و source-reviewed شده‌اند.
- `:app:lintDebug`, `:app:assembleDebug`, `:app:assembleRelease` و build resource report.
- `:app:connectedDebugAndroidTest` و `AppBackdropInstrumentationTest`.
- تولید واقعی Unit/Android coverage و artifactهای گزارش CI؛ فقط workflow برای تولید/انتشار آنها آماده شده است.
- install/upgrade با signing certificate واقعی، Release واقعی و GitHub Actions run.
- screenshot واقعی Activity، TalkBack، D-pad، Switch Access، 200% font scale، perf/FPS روی دستگاه.
- تست زندهٔ برنامه‌های اپراتور و metadata نسخهٔ صفحه/برنامه. هیچ‌یک از پنج اپراتور certified نیستند.

اجرای `tools/backdrop-instrumentation-tests/run.sh` در این محیط به‌درستی با کد ۲ متوقف شد چون `adb` نصب نیست؛ این نتیجه bug اپلیکیشن نیست.

## باقی‌مانده‌های مهم

1. در CI واقعی، JUnit/Robolectric و instrumentation را اجرا و HTML/XML/coverage artifact را بازبینی کنید.
2. تست واقعی race در stop/restart session و خطای adaptive-scroll را به instrumentation اضافه کنید.
3. برای هر پنج اپراتور fixture زندهٔ ناشناس‌شده با app version، screen build/date، expected package count و ambiguity تهیه کنید.
4. UI snapshot و TalkBack/manual verification را در ابعاد و fontScale ذکرشده تکمیل کنید.
5. `branding/bastehyab-logo.png` را فقط پس از تأیید مالک حذف کنید؛ محتوای آن با `bastehyab-app-icon.png` یکسان است و لوگوتایپ واقعی SVG است.
6. `bg_app.xml` را فقط پس از build resource واقعی و تأیید عدم ارجاع حذف کنید.
7. Wrapper رسمی تولیدشده در CI را بعد از دریافت artifact و تطبیق checksum commit کنید؛ JAR ساختگی نسازید.
