# ماتریس تست بسته‌یاب

## طبقه‌بندی

| لایه | موضوع | خودکار و موجود/اضافه‌شده | وضعیت اجرا در این محیط |
|---|---|---|---|
| JVM خالص | قیمت و تبدیل ارز | `PriceModelTest`، `ExtractorJvmTest`، `PkgIdentityTest`، `HistoryTest`، `ListEndDetectorTest` | سورس تست افزوده شد؛ Gradle در محیط موجود نیست |
| JVM با Android شبیه‌سازی‌شدهٔ معتبر | `Compare.run`، مهاجرت `Cfg`، parser ذخیره‌سازی `Store` | `CompareTest`، `CfgMigrationTest`، `StoreParserTest` با Robolectric 4.17؛ `ScanWorkerTaskTest` | سورس تست افزوده شد؛ اجرا نشده، نیازمند Gradle و دریافت dependency |
| Smoke harness | Store recovery/concurrency، popup، consent، parser، UI layout | اسکریپت‌های `tools/*/run.sh` و `tools/privacy-consent-tests/test.sh` | در صورت اجرای گزارش‌شده، فقط نتیجه همان اسکریپت است؛ جایگزین Gradle یا device test نیست |
| Android instrumentation | `AppBackdrop` و lifecycle واقعی View/Activity | `AppBackdropInstrumentationTest` | در این محیط اجرا نشده؛ CI باید آن را روی emulator اجرا کند |
| Device / operator app | استخراج صفحهٔ زنده | تست کنترل‌شده برای پنج اپراتور | دستی/دستگاه واقعی؛ هیچ اپراتوری certified نیست |

## سناریوهای scan

| سناریو | هدف | نوع آزمون | وضعیت فعلی |
|---|---|---|---|
| صفحه خالی | عدم اعلام موفقیت بدون بسته | JVM/fixture replay | نیازمند fixture واقعی |
| tree ناقص یا stale node | نتیجه UNKNOWN و retry محدود | core smoke/static guard | بخشی پوشش دارد؛ آزمون device باقی است |
| load more / pagination | جلوگیری از END تأییدشده | `ListEndDetectorTest` و core smoke | بخشی خودکار |
| carousel افقی | metrics افقی نباید evidence انتها شوند | core smoke با geometry stubs | در تست‌های موجود بخشی پوشش دارد؛ آزمون زنده باقی است |
| nested و چند scroll container | انتخاب container عمودی مرتبط | static/core test + device | پوشش مستقیم ناکافی |
| stale event و تغییر package/session | invalidate شواهد نشست قبلی | core smoke | باید روی device تکمیل شود |
| app switch / permission revoke | توقف task و عدم خواندن tree | privacy/core smoke | مسیر اصلی رضایت و disable پوشش خودکار دارد؛ fault race واقعی روی device باقی است |
| low memory / timeout / executor rejection | آزادسازی state و امکان restart | `ScanWorkerTaskTest` / core smoke برای exception، executor rejection و exactly-once؛ fault injection مستقیم adaptive-scroll و تعویض session در worker واقعی هنوز باقی است |

## سناریوهای ranking

| سناریو | آزمون |
|---|---|
| ریال/تومان و overflow | `PriceModelTest` و parser smoke |
| مالیات پایه و مبلغ شامل مالیات | `CompareTest` |
| فیلتر دسته، بین‌الملل، مدت و حجم | `CompareTest`؛ موارد ترکیبی نیازمند گسترش بیشتر |
| قیمت هر گیگ و مدت | `Compare.value` و smoke parser؛ تست مقایسهٔ گسترده‌تر لازم است |
| review/rejection | `CompareTest` بخشی؛ Store smoke شامل هم‌زمانی review/reprice |
| stale data | نیازمند تست Robolectric تکمیلی با clock کنترل‌شده |

## آزمون زندهٔ اپراتورها (manual / controlled device)

برای هر run موارد زیر باید ثبت شوند: نسخهٔ دقیق app اپراتور، Android build/API، مدل دستگاه، density DPI، locale، زمان UTC، تعداد بستهٔ مورد انتظار مستقل از parser، تعداد استخراج‌شده، فیلدهای تطبیق‌داده‌شده، موارد ambiguous/rejected، نتیجهٔ اسکرول و شناسهٔ fixture ناشناس‌شده. fixture خام هرگز commit نمی‌شود.

| اپراتور | Android package | وضعیت fixture | تست زنده | certification |
|---|---|---|---|---|
| ایرانسل | `com.myirancell` | ثبت نشده | لازم است | خیر |
| همراه اول | `ir.mci.ecareapp` | ثبت نشده | لازم است | خیر |
| رایتل | `ir.rightel.myrightel` | ثبت نشده | لازم است | خیر |
| سامانتل | `com.mysamantel` | ثبت نشده | لازم است | خیر |
| شاتل | `com.shmapp` | ثبت نشده | لازم است | خیر |

## گزارش پوشش و محدودیت اجرا

CI برای `testDebugUnitTest` و `connectedDebugAndroidTest`، coverage reportهای unit و instrumentation، lint و artifactهای XML/HTML report پیکربندی شده است. تا اجرای CI، عدد coverage معتبر وجود ندارد و نباید درصد پوشش اعلام شود.

## فهرست تست‌های دستی الزامی

- اجرای TalkBack فارسی در Home/Compare/Settings و کنترل Popup با D-pad/Switch Access.
- فونت 200٪ و عرض 320dp، portrait و landscape.
- سه palette، حالت Auto و System night mode، Reduce Motion و Battery Saver.
- نصب/ارتقا با signing certificate معتبر و versionCode منتشرشدهٔ قبلی.
- اجرای واقعی اسکن روی پنج برنامه با ثبت metadata بالا؛ هیچ نسخه‌ای از اپراتور از پیش certified نیست.
- سنجش FPS/CPU در انیمیشن روشن و خاموش، و حفظ scroll/focus طی اسکن ۵ دقیقه‌ای.
