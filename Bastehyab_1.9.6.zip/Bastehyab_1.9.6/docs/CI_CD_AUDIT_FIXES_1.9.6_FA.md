# گزارش ممیزی و یکپارچه‌سازی CI/CD بسته‌یاب 1.9.6

## نتیجه اجرایی

- تنها workflow پروژه: `.github/workflows/android-build.yml`.
- Build از ریشه سورس checkoutشده انجام می‌شود؛ workflow نهایی به ZIP داخلی وابسته نیست.
- Push معمولی به `main`، شاخه‌های دیگر و حتی push شدن Tag فقط CI را اجرا می‌کنند؛ هیچ‌کدام به‌تنهایی Release منتشر نمی‌کنند.
- انتشار فقط با `workflow_dispatch` روی Tag دقیق `v<VERSION_NAME>`، واردکردن همان `VERSION_NAME` و روشن‌کردن ورودی تأیید صریح `confirm_release` ممکن است. Tag باید به همان commit اجرا اشاره کند و commit باید از قبل در `main` ادغام شده باشد.
- job انتشار در GitHub Environment به نام `release` اجرا می‌شود. برای تأیید انسانی دومرحله‌ای باید Required reviewers در تنظیمات آن Environment فعال شود.

## مقایسه نسخه‌ها

### `.github/workflows/android-build.yml` داخل سورس 1.9.6

این workflow مبنای مناسب‌تری بود: نسخه را از `version.properties` می‌خواند، Debug و Release را جدا می‌ساخت، Gradle 8.13 و checksum رسمی Wrapper را کنترل می‌کرد، Release را با `apksigner` بررسی می‌کرد، آزمون ارتقای APK قبلی را داشت و فایل‌های موقت امضا را در `if: always()` پاک می‌کرد. ضعف باقیمانده این بود که Tag معتبر به‌تنهایی می‌توانست Release را منتشر کند و تأیید دستی داخل گردش انتشار صریح نبود.

### `android-build (3).yml` ارائه‌شده جداگانه

این نسخه علاوه بر build مستقیم، ZIP سورس را از Git می‌خواست و در jobهای مختلف همان ZIP را استخراج می‌کرد. منطق plan آن انتشار را برای Tag، اجرای دستی و در برخی شرایط push به `main` مجاز می‌کرد. وابستگی ZIP و امکان انتشار با push عادی main برای سیاست این پروژه حذف شد.

### `bastehyab-android-build-release.yml` و نسخه `(1)`

دو فایل ارائه‌شده از نظر محتوا یکسان‌اند. این workflow قدیمی روی push به `main` ساخت Release و انتشار خودکار را اجرا می‌کرد؛ نسخه canonical را به شکل فعلی از `version.properties` کنترل نمی‌کرد، از Gradle مستقیم به‌جای Wrapper معتبر استفاده می‌کرد و آزمون کامل ارتقای نسخه/مقایسه versionCode با APK انتشار قبلی را نداشت. این دو فایل نباید در `.github/workflows` مخزن باقی بمانند.

## تغییرات اعمال‌شده

1. Triggerهای push برای CI-only نگه داشته شدند؛ Release فقط از `workflow_dispatch` دستی روی Tag دقیق اجرا می‌شود.
2. ورودی Boolean به نام `confirm_release` اضافه شد و مقدار پیش‌فرض آن `false` است.
3. اجرای دستی روی branch به‌جای Tag معتبر رد می‌شود؛ نسخه ورودی باید عیناً با `VERSION_NAME` برابر باشد.
4. commit مربوط به Tag با `GITHUB_SHA` تطبیق داده می‌شود و باید ancestor شاخه `main` باشد.
5. قبل از دسترسی به Secretهای امضا، `VERSION_CODE` باید از `PUBLISHED_VERSION_CODE_BASELINE` و versionCode آخرین GitHub Release بزرگ‌تر باشد.
6. runner به `ubuntu-24.04` و JDK به Temurin `17.0.21+9` pin شد؛ Gradle 8.13 و نسخه Actionها نیز ثابت‌اند.
7. آزمون امضای APK، بررسی certificate fingerprint، `zipalign` و نصب/ارتقای in-place روی Emulator API 36 حفظ شد.
8. فایل‌های موقت `keystore.properties` و JKS در مرحله `if: always()` حذف می‌شوند. مقادیر Secret چاپ نمی‌شوند و پیش از ادامه به‌عنوان Mask ثبت می‌شوند.
9. Debug و Release artifactهای مستقل دارند. گزارش‌های Lint، JUnit، Instrumentation، coverage و screenshot در artifact گزارش ذخیره می‌شوند.
10. validator اکنون تعداد workflowها را کنترل می‌کند و در صورت وجود فایل YAML دوم در `.github/workflows` شکست می‌خورد.
11. README با مسیر انتشار دستی و مراحل لازم تنظیمات GitHub به‌روزرسانی شد.

## بررسی ZIP سورس

در ساختار پروژه استخراج‌شده از `Bastehyab_1.9.6_Store_History_Refined_Source.zip` هیچ فایل ZIP داخلی وجود ندارد (تعداد: صفر). بنابراین نسخه `android-build (3).yml` در این ساختار با شرط «دقیقاً یک ZIP ثبت‌شده در Git» اجرا نمی‌شد. workflow یکپارچه‌شده مستقیماً از ریشه پروژه build می‌کند و این وابستگی را حذف می‌کند. آرشیو نهایی تحویلی، خود یک ZIP کامل است و آزمون سلامت `unzip -t` روی آن اجرا می‌شود.

## الزامات تنظیم مخزن GitHub

پیش از هر Release باید موارد زیر تنظیم شوند:

- Repository Variable `PUBLISHED_VERSION_CODE_BASELINE`: بزرگ‌ترین versionCode منتشرشده در Google Play و تمام فروشگاه‌های بیرونی.
- در صورت نیاز به baseline APK خارجی: متغیر `PUBLISHED_BASELINE_RELEASE_TAG` و APK با نام دقیق `Bastehyab-Published-Baseline.apk` در Release مرجع؛ امضا و versionCode آن کنترل می‌شوند.
- Secrets: `ANDROID_KEYSTORE_BASE64`، `KEYSTORE_PASSWORD`، `KEY_ALIAS` و `KEY_PASSWORD`.
- Environment با نام `release` و Required reviewers فعال؛ این بخش در GitHub Settings پیکربندی می‌شود و داخل YAML قابل تحمیل نیست.
- فایل‌های Workflow قدیمی/تکراری از `.github/workflows` حذف شوند؛ validator تنها یک workflow مجاز می‌داند.

## نتیجه آزمون‌های قابل اجرای این محیط

- YAML parse: PASS
- `bash -n` برای همه بلوک‌های `run`: PASS
- `tools/release/validate-release-metadata.py v1.9.6`: PASS
- fixture sanitizer، parser، Store، Android core، popup overlay، UI layout، accessibility و static reviewهای responsive/backdrop: PASS
- `unzip -t` آرشیو ورودی/خروجی: PASS

**محدودیت اجرا:** در محیط فعلی Android SDK، Gradle نصب‌شده و Emulator موجود نبود؛ بنابراین APK واقعی ساخته نشد، امضای APK واقعی اجرا نشد و آزمون نصب/ارتقای Emulator روی GitHub Runner یا دستگاه انجام نشد. این مراحل در workflow نهایی تعریف شده‌اند و باید پس از push به مخزن در GitHub Actions اجرا و نتیجه‌شان بررسی شود. هیچ Release یا انتشار واقعی ایجاد نشده است.
