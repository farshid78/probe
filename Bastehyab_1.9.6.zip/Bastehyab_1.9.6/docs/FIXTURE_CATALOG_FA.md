# کاتالوگ fixtureهای اپراتور

کاتالوگ ماشین‌خوان در [`../test-fixtures/operators/catalog.json`](../test-fixtures/operators/catalog.json) است.

در آرشیو فعلی هیچ capture زنده و ناشناس‌شده‌ای برای پنج اپراتور وجود ندارد. به همین دلیل برای `app_version`، `screen_version_or_build`، `captured_at_utc`، `expected_package_count` و `expected_fields` مقدار ساختگی ثبت نشده و وضعیت همهٔ ورودی‌ها `NOT_CAPTURED` است.

پیش از commit هر fixture: یک کپی جداگانه از dump بگیرید، sanitizer را اجرا کنید، خروجی را دستی بازبینی کنید، متن اعلان‌ها/شماره/ایمیل/شناسه/حساب/رمز/OTP را حذف یا redacted کنید، سپس metadata نسخهٔ صفحه و تاریخ واقعی را ثبت کنید. دادهٔ خام هرگز وارد مخزن نشود.
