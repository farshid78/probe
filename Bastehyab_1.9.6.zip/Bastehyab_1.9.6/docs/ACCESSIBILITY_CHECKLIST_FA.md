# چک‌لیست انتشار Accessibility Service

این سند جایگزین تصمیم مالک انتشار یا تأیید Google Play نیست.

- [ ] فرم Accessibility declaration در Play Console با کاربرد واقعی و بدون `isAccessibilityTool=true` تکمیل شود.
- [ ] ویدئوی نمایشی ضبط شود که disclosure داخل برنامه، انتخاب اپراتور، رضایت صریح هر نشست، تأیید شروع، مکث/توقف و scope محدودشده به همان اپراتور را نشان دهد.
- [ ] ثابت شود بدون opt-in و بدون confirmation همان نشست، tree خوانده نمی‌شود و gesture ارسال نمی‌شود.
- [ ] لغو رضایت و disable کردن سرویس در حین worker آزمایش شود.
- [ ] متن disclosure، service description، README و Privacy Policy قبل از هر انتشار تطبیق داده شوند.
- [ ] export diagnostic بررسی شود تا هیچ متن درخت، notification، شماره، شناسه یا محتوای حساب در آن نباشد.
- [ ] بررسی سیاست نهایی توسط مالک انتشار انجام شود؛ پذیرش فروشگاه تضمین نمی‌شود.
