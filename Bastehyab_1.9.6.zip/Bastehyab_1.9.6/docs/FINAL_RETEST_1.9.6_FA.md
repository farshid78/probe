# گزارش نهایی آزمون مجدد بسته‌یاب — نسخهٔ ۱.۹.۶

**تاریخ ممیزی:** ۲۰۲۶-۱۱-۱۳  
**نسخهٔ canonical:** `VERSION_NAME=1.9.6`  
**شمارهٔ ساخت:** `VERSION_CODE=1900000006`  
**وضعیت تصمیم انتشار:** **تأیید نهایی انتشار صادر نمی‌شود**؛ آزمون‌های محلی و ایستا موفق‌اند، اما آزمون‌های Gradle/Android واقعی، ماتریس API 24 تا 36، اسکن زندهٔ اپراتورها و امضای APK در این محیط اجرا نشده‌اند.

## ۱. خلاصهٔ اجرایی

سورس نسخهٔ ۱.۹.۶ پس از اصلاحات قبلی Store/History، Popup، Parser، اسکن و CI/CD دوباره بررسی شد. مجموعهٔ smoke، static و JVM مستقل اجرا شد. همچنین سه نقص در ابزارهای آزمون/CI پیدا و اصلاح شد: assertion قدیمی تست حریم خصوصی، انتظار زودهنگام آزمون مهاجرت Store و classpath ناقص پیش‌نمایش UI. آزمون مستقیم برای کلاس production یعنی `HistoryLog` نیز اضافه شد.

**هیچ خطای قطعی جدید در منطق production از آزمون‌های قابل اجرای محلی اثبات نشد.** این نتیجه فقط به دامنهٔ آزمون‌های جدول زیر محدود است و جایگزین اجرای برنامه روی دستگاه واقعی نیست.

## ۲. محیط و محدودیت اجرا

- محیط محلی: OpenJDK 21.
- پروژه: `minSdk=24` (Android 7.0)، `compileSdk=36` و `targetSdk=36`.
- در محیط اجرا `gradle`، `gradlew`، `gradle-wrapper.jar`، `adb`، `emulator` و `sdkmanager` موجود نبودند.
- پروژه checksum رسمی Gradle 8.13 و Wrapper را نگه می‌دارد؛ CI با Gradle نصب‌شده و نسخهٔ pin‌شده Wrapper رسمی را ایجاد و checksum آن را کنترل می‌کند.
- بنابراین تست‌های unit/Robolectric، Android Lint، build واقعی، instrumentation، نصب/ارتقای APK و تست دستگاهی اجرا نشده‌اند.

## ۳. نتایج آزمون‌های اجراشده

| آزمون | نتیجه | دامنهٔ واقعی |
|---|---|---|
| Fixture Sanitizer | PASS | پوشاندن شماره، ایمیل، UUID، شناسه‌های طولانی و فیلدهای قابل‌ویرایش/رمز |
| Privacy / Consent | PASS | guardهای ایستا و رفتار رضایت/محدودسازی هدف؛ همراه با Android Core smoke |
| Parser Regression | PASS | نرمال‌سازی، ارز، بازه‌های مرزی، ارقام فارسی/لاتین، متن خصمانه، کارت نامعتبر و جداسازی رکوردها |
| Store Recovery | PASS | ۲۱ سناریوی بازیابی، مهاجرت، فایل خراب، هم‌زمانی، atomic write، clear حین عملیات، identity و محاسبات مالی |
| Android Core Smoke | PASS | worker، exception/rejection، سیاست اسکن پنج شناسهٔ اپراتور، انتخاب container عمودی، state و تاریخچه |
| HistoryLog واقعی | PASS | هویت اپراتور/بسته، حذف یادداشت آزاد، حفظ JSON خراب، ردیف نامعتبر، سقف ۳۰۰ رویداد و clear/commit |
| Popup Tests | PASS | کنترل پنجره، ساختار View، حداکثر ۸ ردیف، 320×480، landscape، فونت ۲۰۰٪، drag، ذخیره موقعیت، rebuild و shutdown |
| Popup Static Review | PASS | ۱۶ کنترل ساختاری |
| UI Layout / Accessibility Static | PASS | RTL، حداقل 48dp هدف لمس، برچسب‌ها، live region، focus و scroll دیالوگ |
| Accessibility API Compatibility | PASS | بررسی سازگاری APIهای Accessibility در سورس |
| Backdrop Static Review | PASS | تخصیص حافظه در draw، throttle، lifecycle و wiring تست |
| Responsive Static Review | PASS | ۱۴ کنترل layout، scroll restore، orientation/font-scale و insets |
| Home Live Refresh | PASS | شبیه‌سازی ساختاری ۲۰۰ tick در ۵ دقیقه؛ بدون بازسازی کامل صفحه در هر tick |
| Release Metadata Validation | PASS | تنها workflow، نسخهٔ canonical، تگ `v1.9.6`، سیاست دستی انتشار، versionCode و checksumها |
| UI Desktop Preview | PASS | تولید پیش‌نمایش Java2D برای حالت تاریک، روشن و تک‌رنگ؛ این تصاویر screenshot دستگاه اندروید نیستند |
| Shell/Python/XML/YAML Syntax | PASS | syntax اسکریپت‌ها، Python tools، منابع XML و parse فایل workflow |

گزارش خروجی آزمون‌ها در `test-results/logs/` قرار دارد.

## ۴. آزمون‌هایی که اجرا نشدند

| آزمون درخواستی | وضعیت | علت |
|---|---|---|
| Android Lint | NOT RUN | نبود Gradle و Android SDK |
| JUnit (`app/src/test`) | NOT RUN | ۱۱ فایل تست JUnit وجود دارد؛ اجرای Gradle ممکن نبود |
| Robolectric | NOT RUN | dependency و runtime تحت Gradle در دسترس نبود؛ Robolectric 4.17 در build تعریف شده است |
| Android Instrumentation | NOT RUN | نبود adb/emulator؛ ۳ فایل instrumentation در سورس موجود است |
| Android 7 تا Android 16 (API 24 تا 36) | NOT RUN | هیچ دستگاه یا شبیه‌ساز متصل نبود؛ runner دستگاهی نیز به `adb` نیاز دارد |
| 320dp تا تبلت، 100٪ تا 200٪ | PARTIAL / NOT DEVICE-VERIFIED | Popup fake viewport در 320×480 و landscape با fontScale=2.0 پاس شد؛ ماتریس واقعی اندازه/تبلت و screenshot دستگاه اجرا نشد |
| TalkBack واقعی | NOT RUN | فقط semantics و live region به‌صورت ایستا بررسی شد |
| حالت روشن/تاریک واقعی | PARTIAL | کنتراست paletteهای light/dark/mono ایستا بررسی شد؛ اجرای runtime و System night mode انجام نشد |
| اسکن زندهٔ پنج اپراتور | NOT RUN | اپ‌های رسمی/حساب‌ها و screen fixture واقعی در دسترس نبودند |
| مقدار مورد انتظار بسته‌ها بر اساس دادهٔ واقعی | NOT RUN | برای هر پنج اپراتور `expected_package_count` برابر null و fixture برابر `NOT_CAPTURED` است |
| CPU/RAM/FPS روی دستگاه | NOT RUN | ابزار و دستگاه Android در دسترس نبود |
| اجرای طولانی واقعی | NOT RUN | فقط شبیه‌سازی ساختاری refresh پنج‌دقیقه‌ای انجام شد |
| امضای APK و upgrade واقعی | NOT RUN | APK امضاشده و کلید انتشار/شبیه‌ساز موجود نبود |

### پوشش اسکن اپراتورها

Core smoke برای پنج شناسهٔ هدف زیر، آغاز نشست محدودشده، سیاست اسکرول مشترک و کنترل session را آزمود؛ اما هیچ‌کدام به معنی تأیید استخراج زنده یا صحت شمارش بسته‌ها نیست:

| اپراتور | package | fixture / شمار مورد انتظار |
|---|---|---|
| ایرانسل | `com.myirancell` | NOT_CAPTURED / نامشخص |
| همراه اول | `ir.mci.ecareapp` | NOT_CAPTURED / نامشخص |
| رایتل | `ir.rightel.myrightel` | NOT_CAPTURED / نامشخص |
| سامانتل | `com.mysamantel` | NOT_CAPTURED / نامشخص |
| شاتل | `com.shmapp` | NOT_CAPTURED / نامشخص |

در نتیجه، قیمت، حجم و مدت اعتبار هیچ بسته‌ای در این دور با صفحهٔ زندهٔ اپراتور تطبیق داده نشده است.

## ۵. باگ‌های کشف‌شده و اصلاح‌شده

### الف) assertion قدیمی در Privacy test

تست قدیمی انتظار شرط `if (e == null || !fullMode) return` را داشت. کد production رویداد null را رد می‌کند و مسیر `!fullMode` را جداگانه اجرا می‌کند تا در اسکرول اپراتور پنجرهٔ مقایسه بسته شود. assertion به ساختار فعلی کد اصلاح شد؛ منطق production در این بخش تغییر نکرد.

### ب) race در تست مهاجرت Store

helper تست `persisted()` می‌توانست پیش از اتمام ذخیرهٔ مهاجرت، مقدار اولیهٔ versionها را برابر تشخیص دهد و فایل Schema 3 را زودتر بخواند. تست اکنون تا مشاهدهٔ واقعی `schemaVersion=4` در فایل خروجی منتظر می‌ماند. پس از اصلاح، سناریوی مهاجرت در اجرای مجدد PASS شد.

### ج) پوشش ناکافی HistoryLog واقعی

تست Store از stub برای HistoryLog استفاده می‌کرد و همهٔ رفتار `HistoryLog.java` واقعی را نمی‌آزمود. `HistoryLogSmokeTest.java` اضافه شد و موارد حساسیت داده و حفظ اطلاعات را مستقیماً روی کلاس production بررسی می‌کند.

### د) پیش‌نمایش UI خطای کامپایل را پنهان می‌کرد

`tools/neu-preview/run.sh` با `javac ... || true` خطای کامپایل را نادیده می‌گرفت و چند وابستگی تست (BuildConfig، R، منابع و JSON/Os stub) را نداشت. classpath کامل شد و fail-fast جایگزین نادیده‌گرفتن خطا شد؛ پیش‌نمایش سه palette با موفقیت تولید شد.

### هـ) کامل نبودن فهرست smokeهای CI

Privacy/Consent و Home Live Refresh در مرحلهٔ smoke workflow اجرا نمی‌شدند. هر دو دستور به `.github/workflows/android-build.yml` اضافه شدند.

## ۶. باگ‌های باقی‌مانده / ریسک‌های تأییدنشده

- هیچ نقص production جدیدی از smokeهای محلی اثبات نشد؛ ولی رفتار واقعی Accessibility، lifecycle بین برنامه‌ها، چرخش، OEM WindowManager و مصرف منابع هنوز روی دستگاه تأیید نشده است.
- اسکن زنده و شمارش بسته‌ها برای پنج اپراتور تأیید نشده؛ کاتالوگ fixture عمداً مقادیر مورد انتظار را حدس نمی‌زند.
- آزمون‌های `HistoryLog` با SharedPreferences/JSON test doubles اجرا شده‌اند؛ رفتار framework واقعی Android هنوز به Robolectric/device نیاز دارد.
- workflow فعلی Instrumentation را روی Android 16 اجرا می‌کند؛ ماتریس ۱۳ سطح API از 24 تا 36 در CI اجرا نشده است. اسکریپت `responsive-device-matrix/run.sh` برای دستگاه‌های API 24..36 وجود دارد، اما به دستگاه‌های متصل و adb نیاز دارد.
- TalkBack واقعی، device screenshots، مصرف RAM/CPU و طول عمر چندساعته هنوز تأیید نشده‌اند.

## ۷. گزارش عملکرد و Crash

### عملکرد محلی Store

آخرین Store benchmark روی JVM میزبان، برای مجموعهٔ ۲۵۰۰ رکورد:

- snapshot: median = 1,248 µs؛ p95 = 2,768 µs.
- identity benchmark: median = 127,598 µs؛ p95 = 149,663 µs.
- Home: شبیه‌سازی ساختاری ۲۰۰ refresh / پنج دقیقه؛ تعداد بازسازی کامل صفحه در هر tick برابر صفر طبق قرارداد سورس.

این اعداد benchmark میزبان و test doubles هستند، نه اندازه‌گیری CPU/RAM یا زمان پاسخ روی گوشی. مقدار مصرف حافظه، درصد CPU، FPS و مصرف باتری اندازه‌گیری نشده است.

### Crash report

هیچ crash report واقعی از برنامه تولید نشد؛ APK نصب‌شده و `adb logcat` در دسترس نبود. در تست‌های JVM موفق crash مشاهده نشد. این به معنی تضمین نبود crash روی Android نیست. یک failure اولیه در تست مهاجرت Store، race در helper آزمون بود که اصلاح شد؛ پس از اصلاح سناریو PASS شد.

## ۸. فایل‌های تغییرکرده در این دور

- `.github/workflows/android-build.yml` — افزودن Privacy/Consent و Home Live Refresh به smoke stage.
- `tools/privacy-consent-tests/test.sh` — اصلاح assertion مطابق مسیر واقعی event handler.
- `tools/store-smoke-tests/StoreSmokeTest.java` — انتظار برای persist واقعی schema v4 به‌جای بررسی زودهنگام version counter.
- `tools/android-core-smoke-tests/HistoryLogSmokeTest.java` — آزمون مستقیم HistoryLog production.
- `tools/android-core-smoke-tests/run.sh` — کامپایل و اجرای HistoryLogSmokeTest.
- `tools/neu-preview/run.sh` — تکمیل classpath و فعال‌سازی fail-fast کامپایل.
- `docs/FINAL_RETEST_1.9.6_FA.md` — همین گزارش.
- `test-results/logs/*` — خروجی آزمون‌ها و ثبت محدودیت‌های محیط.

در این دور فایل‌های production اپ (کلاس‌های اجرایی اندروید) تغییر داده نشدند؛ تغییرها به harness آزمون، گام‌های smoke در CI و مستندات محدودند.

## ۹. نسخهٔ نهایی و تصمیم انتشار

- نسخهٔ سورس: **1.9.6**
- `versionCode`: **1900000006**
- اعتبارسنجی metadata و تگ `v1.9.6`: PASS.
- ساخت APK، امضای واقعی، تطبیق گواهی با نسخهٔ منتشرشدهٔ قبلی و نصب/ارتقای واقعی: NOT RUN.

**تصمیم: نسخهٔ ۱.۹.۶ در این مرحله «نامزد آزموده‌شدهٔ محلی» است، نه نسخهٔ تأییدشده برای انتشار عمومی.** برای تأیید Release باید CI روی GitHub با Android SDK/Emulator اجرا شود، baseline واقعی `versionCode` و APK امضاشدهٔ قبلی فراهم باشد، آزمون‌های JUnit/Robolectric/Instrumentation موفق شوند و اسکن زندهٔ پنج اپراتور با fixture ناشناس‌شده و تعداد بستهٔ مورد انتظار ثبت شود.
