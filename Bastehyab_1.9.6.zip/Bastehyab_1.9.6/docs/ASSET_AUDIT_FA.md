# ممیزی دارایی‌ها

- در ZIP ورودی فقط `README.md` در root وجود داشت؛ پس از مرتب‌سازی، `CHANGELOG.md` نیز به‌عنوان سند جاری افزوده شد (جمع فعلی root: ۲ فایل Markdown)، نه حدود ۵۵ مورد گزارش اولیه.
- `branding/bastehyab-app-icon.png` و `branding/bastehyab-logo.png` دقیقاً hash یکسان دارند: `54233bc9d2fea342d51b94dbfdb07b0a5e28da1b9eb4b42049532271279e5f11`.
- لوگوتایپ واقعی فارسی در `branding/bastehyab-logo.svg` است؛ README از SVG به‌عنوان لوگوی اصلی استفاده می‌کند. PNG canonical آیکون `branding/bastehyab-app-icon.png` باقی می‌ماند.
- previewهای `neu_dark/light/mono` و سه تصویر مرجع از `branding/` به `design/references/` منتقل شدند؛ این دارایی‌ها خارج از `app/src/main/res` هستند.
- `creator-avatar-original.png` حفظ شد؛ فایل runtime `creator_avatar.jpg` و `brand_mark.png` دست‌نخورده باقی ماندند.
- `bg_app.xml` پس از scan متنی reference مستقیم نداشت؛ حذف نشد چون build resource واقعی در این محیط ممکن نیست.
- فایل تکراری `branding/bastehyab-logo.png` فعلاً حذف نشد. پیشنهاد حذف پس از تأیید owner: این فایل duplicate با hash بالا است؛ README و مسیرهای داخل مخزن به SVG تغییر داده شده‌اند، اما مرجع خارجی خارج از مخزن قابل ارزیابی نیست.
- فایل‌های حذف پیشنهادی دیگر: هیچ‌کدام؛ launcher/nav/runtime assets حذف نشده‌اند.
