package app.bastehyab;

import android.content.Context;
import android.view.FakeWindowManager;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.TextView;

/**
 * Regression test for the R5 bug: View.isAttachedToWindow() is false right after addView(), which
 * used to leave orphaned (un-removable, un-movable) scan panels. The fake WindowManager here is as
 * strict as the real one, and isAttachedToWindow() always returns false (the worst case).
 */
public class PopupOverlayTest {
    static void check(boolean ok, String msg) { if (!ok) throw new AssertionError(msg); }

    static TextView find(View v, String contains) {
        if (v instanceof TextView && String.valueOf(((TextView) v).text).contains(contains)) return (TextView) v;
        if (v instanceof ViewGroup) for (View k : ((ViewGroup) v).kids) { TextView t = find(k, contains); if (t != null) return t; }
        return null;
    }

    static void drag(TextView handle, float fx, float fy, float tx, float ty) {
        check(handle.touchL != null, "drag handle has no touch listener");
        check(handle.touchL.onTouch(handle, new MotionEvent(MotionEvent.ACTION_DOWN, fx, fy)), "DOWN not consumed");
        check(handle.touchL.onTouch(handle, new MotionEvent(MotionEvent.ACTION_MOVE, tx, ty)), "MOVE not consumed");
        handle.touchL.onTouch(handle, new MotionEvent(MotionEvent.ACTION_UP, tx, ty));
    }


    static int countPackageCards(View v) {
        int count = 0;
        if (v instanceof TextView && String.valueOf(((TextView) v).text).contains("گیگ")) count++;
        if (v instanceof ViewGroup) for (View child : ((ViewGroup) v).kids) count += countPackageCards(child);
        return count;
    }

    static void comparisonOverlayRegression(FakeWindowManager wm) {
        Context comparisonContext = new Context();
        Cfg.sp(comparisonContext).edit().putInt("rows", 8).apply();
        Popup comparison = new Popup(comparisonContext);
        Compare.Result result = new Compare.Result();
        result.metric = Cfg.PER_GB;
        result.unit = "تومان";
        result.label = "قیمت هر بسته";
        result.ops = 2;
        for (int i = 0; i < 12; i++) {
            Pkg p = new Pkg();
            p.op = "test"; p.key = "test-" + i; p.gb = 5 + i; p.days = 30; p.toman = 10000 + i * 1000;
            result.ranked.add(p); result.rank.put(p.key, i + 1); result.val.put(p.key, (double) i + 1);
            if (i < 4) result.screen.add(p);
        }
        // The same packages in the current screen and global ranking must not be duplicated;
        // the total number of rendered package cards is capped at eight.
        check(comparison != null, "comparison popup construction failed");
        comparison.show(result, new java.util.HashSet<String>());
        check(wm.windows.size() == 1, "comparison popup was not attached");
        View root = wm.windows.get(0);
        check(root instanceof ViewGroup && ((ViewGroup) root).kids.size() == 1,
                "popup root must contain exactly one scroll container");
        View scroll = ((ViewGroup) root).kids.get(0);
        check(scroll instanceof ViewGroup && ((ViewGroup) scroll).kids.size() == 1,
                "scroll container must own the content view (no parent cycle)");
        View content = ((ViewGroup) scroll).kids.get(0);
        check(content != root && content != scroll, "invalid cyclic popup view hierarchy");
        check(countPackageCards(root) == 8, "comparison popup should render exactly eight cards when eight are available: " + countPackageCards(root));

        // Dragging must update the actual window and keep a reusable position for rebuild.
        View header = ((ViewGroup) content).kids.get(0);
        check(header.touchL != null, "comparison header has no drag handler");
        WindowManager.LayoutParams params = (WindowManager.LayoutParams) wm.params.get(root);
        check((params.flags & WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL) != 0,
                "touches outside comparison overlay must pass through to operator app");
        int oldX = params.x, oldY = params.y;
        header.touchL.onTouch(header, new MotionEvent(MotionEvent.ACTION_DOWN, 300, 300));
        header.touchL.onTouch(header, new MotionEvent(MotionEvent.ACTION_MOVE, 340, 360));
        header.touchL.onTouch(header, new MotionEvent(MotionEvent.ACTION_UP, 340, 360));
        check(params.x != oldX && params.y != oldY, "comparison drag did not move in both axes");
        comparison.hide();
        check(wm.windows.isEmpty(), "comparison hide did not remove the window");
        comparison = new Popup(new Context()); // simulate service recreation; position comes from preferences
        comparison.show(result, new java.util.HashSet<String>());
        check(wm.windows.size() == 1, "comparison popup did not rebuild after service recreation");
        WindowManager.LayoutParams rebuilt = (WindowManager.LayoutParams) wm.params.get(wm.windows.get(0));
        check(rebuilt.x == params.x && rebuilt.y == params.y, "comparison popup position was not persisted");
        comparison.shutdown();
        check(wm.windows.isEmpty(), "comparison shutdown leaked a WindowManager view");
    }


    static final class ViewportContext extends Context {
        private final android.content.res.Resources resources;
        ViewportContext(final int width, final int height, final float fontScale) {
            resources = new android.content.res.Resources() {
                @Override public android.util.DisplayMetrics getDisplayMetrics() {
                    android.util.DisplayMetrics dm = new android.util.DisplayMetrics();
                    dm.widthPixels = width; dm.heightPixels = height; dm.density = 1f;
                    return dm;
                }
                @Override public android.content.res.Configuration getConfiguration() {
                    android.content.res.Configuration cfg = new android.content.res.Configuration();
                    cfg.fontScale = fontScale;
                    return cfg;
                }
            };
        }
        @Override public android.content.res.Resources getResources() { return resources; }
    }

    static void viewportRegression(FakeWindowManager wm, Compare.Result result) {
        for (int[] size : new int[][]{{320, 480}, {480, 320}}) {
            Popup popup = new Popup(new ViewportContext(size[0], size[1], 2.0f));
            popup.show(result, new java.util.HashSet<String>());
            check(wm.windows.size() == 1, "small/landscape popup was not attached");
            WindowManager.LayoutParams params = (WindowManager.LayoutParams) wm.params.get(wm.windows.get(0));
            check(params.width <= size[0] - 24 && params.width > 0,
                    "popup width exceeded the available viewport: " + params.width);
            check(params.x >= -(size[0] - params.width) / 2
                            && params.x <= (size[0] - params.width) / 2,
                    "popup horizontal offset escaped viewport");
            popup.shutdown();
            check(wm.windows.isEmpty(), "small/landscape popup leaked after shutdown");
        }
    }

    public static void main(String[] args) {
        FakeWindowManager wm = Context.WM;
        Popup popup = new Popup(new Context());
        Runnable noop = () -> {};

        // 1) Repeated refreshes with the same state must reuse the single window.
        for (int i = 0; i < 6; i++) check(popup.showConfirm("ایرانسل", 0, 0, 0, 0, "x", noop, noop, noop), "show failed");
        check(wm.windows.size() == 1 && wm.adds == 1, "same-state refresh created extra windows: " + wm.windows.size());
        check(popup.isConfirmShown(), "panel should be reported as shown");

        // 2) A mode change replaces the panel; never two at once.
        check(popup.showConfirm("ایرانسل", 1, 10, 2, 5, "y", noop, noop, null), "mode change failed");
        check(wm.windows.size() == 1 && wm.adds == 2 && wm.removes == 1, "mode change left orphans: " + wm.windows.size());

        // 3) Dragging moves the window that is actually on screen.
        View panel = wm.windows.get(0);
        WindowManager.LayoutParams lp = (WindowManager.LayoutParams) wm.params.get(panel);
        int x0 = lp.x, y0 = lp.y;
        drag(find(panel, "جابه‌جایی"), 500, 500, 560, 640);
        check(lp.x == x0 + 60 && lp.y == y0 + 140, "panel did not follow the finger: " + lp.x + "," + lp.y);
        check(wm.updates > 0, "updateViewLayout never called");
        // Injected swipes temporarily disable hit-testing of the panel, then restore it.
        popup.setConfirmTouchBlocked(true);
        check((lp.flags & WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE) != 0,
                "scan panel should not intercept its own injected swipe");
        popup.setConfirmTouchBlocked(false);
        check((lp.flags & WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE) == 0,
                "scan panel touchability should be restored after the swipe");
        // the title is a drag area as well
        int ux = lp.x;
        drag(find(panel, "استخراج خودکار"), 100, 100, 90, 100);
        check(lp.x == ux - 10, "title drag failed");

        // 4) A rebuilt panel (pause) keeps the position chosen by the user.
        int movedX = lp.x, movedY = lp.y;
        check(popup.showConfirm("ایرانسل", 2, 10, 2, 5, "z", noop, noop, null), "pause panel failed");
        check(wm.windows.size() == 1, "orphan after pause");
        WindowManager.LayoutParams lp2 = (WindowManager.LayoutParams) wm.params.get(wm.windows.get(0));
        check(lp2.x == movedX && lp2.y == movedY, "position not preserved");

        // 5) A stopped scan can leave a readable final report with a close-only action.
        String report = "اسکرول خودکار در این صفحه پشتیبانی نشد\nآخرین روش: حرکت لمسی";
        check(popup.showConfirm("ایرانسل", 3, 42, 7, 11, report, null,
                () -> popup.hideConfirm(), null), "final report panel failed");
        check(wm.windows.size() == 1, "final report left duplicate windows");
        View reportPanel = wm.windows.get(0);
        check(find(reportPanel, "گزارش نهایی") != null, "final report title is missing");
        TextView reportText = find(reportPanel, "آخرین روش");
        check(reportText != null && String.valueOf(reportText.text).contains("اسکرول خودکار"),
                "final report details were not retained in the visible status text");
        TextView closeReport = find(reportPanel, "بستن گزارش");
        check(closeReport != null && closeReport.clickL != null, "final report close action is missing");
        closeReport.clickL.onClick(closeReport);
        check(wm.windows.isEmpty() && !popup.isConfirmShown(), "close report did not remove the panel");

        // 6) Exit: the panel is really removed, repeatedly and safely.
        popup.hideConfirm();
        check(wm.windows.isEmpty() && !popup.isConfirmShown(), "hideConfirm left a window behind");
        popup.hideConfirm();
        check(wm.windows.isEmpty(), "second hideConfirm misbehaved");

        // 7) Can be shown again afterwards.
        check(popup.showConfirm("ایرانسل", 0, 0, 0, 0, "", noop, noop, noop), "re-show failed");
        check(wm.windows.size() == 1, "re-show count wrong");
        popup.hideConfirm();
        Popup restoredControls = new Popup(new Context());
        check(restoredControls.showConfirm("ایرانسل", 0, 0, 0, 0, "", noop, noop, noop),
                "scan controls did not re-show after manager recreation");
        WindowManager.LayoutParams restoredControlParams = (WindowManager.LayoutParams) wm.params.get(wm.windows.get(0));
        check(restoredControlParams.x == movedX && restoredControlParams.y == movedY,
                "scan-control position was not persisted across manager recreation");
        restoredControls.shutdown();

        // 8) If Android/OEM detaches the view without our hide path, the next health check
        // detects that WindowManager no longer owns it and a refresh rebuilds it.
        check(popup.showConfirm("ایرانسل", 0, 0, 0, 0, "", noop, noop, noop), "show for detach test failed");
        View detached = wm.windows.get(0);
        wm.windows.remove(detached);
        wm.params.remove(detached);
        try { Thread.sleep(1250L); } catch (InterruptedException e) { Thread.currentThread().interrupt(); throw new AssertionError(e); }
        check(!popup.isConfirmShown(), "detached panel was incorrectly reported as visible");
        check(popup.showConfirm("ایرانسل", 0, 0, 0, 0, "", noop, noop, noop), "detached panel was not rebuilt");
        check(wm.windows.size() == 1 && wm.adds >= 6, "rebuild did not attach a fresh panel");
        popup.hideConfirm();

        // 9) Stale drag listener of a removed panel must be inert (no moving of other windows).
        check(popup.showConfirm("ایرانسل", 0, 0, 0, 0, "", noop, noop, noop), "show failed");
        View old = wm.windows.get(0);
        TextView oldHandle = find(old, "جابه‌جایی");
        popup.hideConfirm();
        check(!oldHandle.touchL.onTouch(oldHandle, new MotionEvent(MotionEvent.ACTION_DOWN, 1, 1)), "stale listener still active");
        check(wm.windows.isEmpty(), "window count wrong at end");
        comparisonOverlayRegression(wm);
        Compare.Result viewportResult = new Compare.Result();
        viewportResult.label = "responsive"; viewportResult.unit = "تومان";
        viewportRegression(wm, viewportResult);
        System.out.println("PASS: scan controls + comparison overlay hierarchy, max-eight rows, narrow/landscape 200% font, drag, persistent position, remove/rebuild and shutdown");
    }
}
