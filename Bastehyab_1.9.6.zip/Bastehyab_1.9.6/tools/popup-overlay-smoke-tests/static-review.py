#!/usr/bin/env python3
from pathlib import Path
root = Path(__file__).resolve().parents[2]
popup = (root / 'app/src/main/java/app/bastehyab/Popup.java').read_text()
service = (root / 'app/src/main/java/app/bastehyab/ScanService.java').read_text()
instrumentation = (root / 'app/src/androidTest/java/app/bastehyab/PopupOverlayInstrumentationTest.java').read_text()
checks = {
    'comparison view hierarchy is root -> scroll -> content': 'popupScroll.addView(popupContent' in popup and 'root.addView(popupScroll' in popup and 'popupContent.addView(popupScroll' not in popup,
    'comparison width is clamped to current viewport': 'private int popupWidth(DisplayMetrics dm)' in popup and 'dm.widthPixels - margin * 2' in popup,
    'comparison height is bounded by current viewport': 'UI.boundedScroll(c, maxOverlayHeight(windowMetrics))' in popup and 'dm.heightPixels * 0.58f' in popup,
    'touches outside comparison overlay pass through to operator app': 'FLAG_NOT_TOUCH_MODAL' in popup,
    'accessibility overlays do not steal active-window focus': popup.count('FLAG_NOT_FOCUSABLE') >= 2,
    'transient missing operator roots retry without closing scan controls': 'scheduleScanReplacing(650L)' in service and 'selected-app-not-active' in service,
    'comparison and scan control content remain RTL': 'popupContent.setLayoutDirection(View.LAYOUT_DIRECTION_RTL)' in popup and 'confirmScroll.setLayoutDirection(View.LAYOUT_DIRECTION_RTL)' in popup,
    'total visible package cards capped at eight': 'Math.min(8, Cfg.rows(c))' in popup and 'displayedRows >= maxRows' in popup,
    'current-screen ranking is shown separately from global ranking': 'بهترین‌های همین صفحه' in popup and 'برترین‌ها در همه‌ی اپراتورهای تیک‌خورده' in popup,
    'drag clamps both axes and persists comparison and scan-control coordinates': 'maxPopupX(dm, width)' in popup and 'popup_position_x' in popup and 'popup_position_y' in popup and 'confirm_position_x' in popup and 'confirm_position_y' in popup,
    'comparison and scan controls are mutually exclusive': 'hide();' in popup and 'hideConfirm();' in popup,
    'injected scroll can temporarily pass through scan controls': 'FLAG_NOT_TOUCHABLE' in popup and 'setConfirmTouchBlocked' in popup,
    'window cleanup has immediate-removal fallback': 'wm.removeViewImmediate(view)' in popup,
    'rank worker is stopped during service teardown': 'rankWorker.shutdownNow();' in popup and 'void shutdown()' in popup,
    'service interruption removes both overlays': 'if (popup != null) { popup.hide(); popup.hideConfirm(); }' in service,
    'configuration changes rebuild comparison and scan overlays': 'void onConfigurationChanged()' in popup and 'onConfigurationChanged(android.content.res.Configuration newConfig)' in service and 'ensureFloatingControls();' in service,
    'operator scroll automatically dismisses the comparison overlay': 'e.getEventType() == AccessibilityEvent.TYPE_VIEW_SCROLLED' in service and 'popup.isComparisonShown()' in service and 'isConfiguredOperatorPackage(p)' in service and 'popup.hide()' in service,
    'real-device instrumentation covers show screenshot hide rebuild': 'takeScreenshot()' in instrumentation and 'popup::hide' in instrumentation and 'popup.show(result' in instrumentation and 'popup.showConfirm(' in instrumentation,
}
failed = [name for name, ok in checks.items() if not ok]
for name, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ': ' + name)
if failed:
    raise SystemExit(1)
print(f'PASS: {len(checks)} Popup source guardrails')
