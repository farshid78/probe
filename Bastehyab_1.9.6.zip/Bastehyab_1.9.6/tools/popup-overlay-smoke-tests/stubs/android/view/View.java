package android.view;
import android.content.Context;
public class View {
  public static class MeasureSpec { public static final int AT_MOST=-2147483648, UNSPECIFIED=0; public static int makeMeasureSpec(int size,int mode){return size | mode;} public static int getMode(int spec){return spec & 0xC0000000;} public static int getSize(int spec){return spec & 0x3FFFFFFF;} }
  public static final int LAYOUT_DIRECTION_RTL=1, TEXT_DIRECTION_RTL=2, TEXT_DIRECTION_LTR=3, TEXT_ALIGNMENT_GRAVITY=1,TEXT_ALIGNMENT_CENTER=4;
  public static final int IMPORTANT_FOR_ACCESSIBILITY_NO=2, ACCESSIBILITY_LIVE_REGION_POLITE=1;
  public static class AccessibilityDelegate { public void onInitializeAccessibilityNodeInfo(View host, android.view.accessibility.AccessibilityNodeInfo info) {} }
  public interface OnTouchListener { boolean onTouch(View v, MotionEvent e); }
  public interface OnClickListener { void onClick(View v); }
  public interface OnAttachStateChangeListener { void onViewAttachedToWindow(View v); void onViewDetachedFromWindow(View v); }
  public OnTouchListener touchL; public OnClickListener clickL;
  public View(Context c){}
  public boolean isAttachedToWindow(){return false;}
  protected void onMeasure(int w,int h){} public void setElevation(float e){} public void setLayoutDirection(int d){} public void setPadding(int a,int b,int c,int d){}
  public void setBackground(android.graphics.drawable.Drawable d){}
  public void setOnTouchListener(OnTouchListener l){touchL=l;} public void setOnClickListener(OnClickListener l){clickL=l;}
  public void addOnAttachStateChangeListener(OnAttachStateChangeListener l){}
  public void setClickable(boolean b){} public void setFocusable(boolean b){} public void setContentDescription(String s){} public void setStateDescription(String s){} public void setAccessibilityDelegate(AccessibilityDelegate d){} public void setImportantForAccessibility(int v){} public void setAccessibilityLiveRegion(int v){} public void setMinimumWidth(int w){} public Context getContext(){return null;} public void setSelected(boolean b){} public boolean isSelected(){return false;} public void setLongClickable(boolean b){}
  public int getWidth(){return 0;} public int getHeight(){return 0;}
  public void setTextDirection(int d){} public void setTextAlignment(int d){}
  public void setStateListAnimator(Object o){} public void setMinimumHeight(int h){}
  public void setClipToOutline(boolean b){}
}
