package android.graphics.drawable; import android.graphics.*;
public class InsetDrawable extends Drawable { public InsetDrawable(Drawable d,int i){}
 public void draw(Canvas c){} public void setAlpha(int a){} public void setColorFilter(ColorFilter f){} public int getOpacity(){return 0;} }
