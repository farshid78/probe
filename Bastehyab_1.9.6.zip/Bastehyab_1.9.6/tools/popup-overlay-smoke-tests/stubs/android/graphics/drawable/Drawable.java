package android.graphics.drawable; import android.graphics.*;
public abstract class Drawable { Rect b=new Rect(); public Rect getBounds(){return b;} public void setBounds(int l,int t,int r,int bt){b.left=l;b.top=t;b.right=r;b.bottom=bt;onBoundsChange(b);} protected void onBoundsChange(Rect r){}
 public abstract void draw(Canvas c); public abstract void setAlpha(int a); public abstract void setColorFilter(ColorFilter f); public abstract int getOpacity();
 public void invalidateSelf(){} public int getIntrinsicWidth(){return -1;} public int getIntrinsicHeight(){return -1;} }
