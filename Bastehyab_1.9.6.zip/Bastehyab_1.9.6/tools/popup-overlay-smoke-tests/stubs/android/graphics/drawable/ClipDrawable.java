package android.graphics.drawable; import android.graphics.*;
public class ClipDrawable extends Drawable { public static final int HORIZONTAL=1; public ClipDrawable(Drawable d,int g,int o){}
 public void draw(Canvas c){} public void setAlpha(int a){} public void setColorFilter(ColorFilter f){} public int getOpacity(){return 0;} }
