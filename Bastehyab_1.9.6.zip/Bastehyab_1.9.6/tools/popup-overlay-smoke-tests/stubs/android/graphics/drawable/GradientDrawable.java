package android.graphics.drawable; import android.graphics.*;
public class GradientDrawable extends Drawable { public static final int OVAL=1; public enum Orientation {TL_BR,LEFT_RIGHT,TOP_BOTTOM} public GradientDrawable(){} public GradientDrawable(Orientation o,int[] c){} public void setColor(int c){} public void setCornerRadius(float r){} public void setStroke(int w,int c){} public void setShape(int s){} public void setSize(int w,int h){}
 public void draw(Canvas c){} public void setAlpha(int a){} public void setColorFilter(ColorFilter f){} public int getOpacity(){return 0;} }
