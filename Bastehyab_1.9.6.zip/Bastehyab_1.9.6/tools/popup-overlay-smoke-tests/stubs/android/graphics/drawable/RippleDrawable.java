package android.graphics.drawable; import android.graphics.*;
public class RippleDrawable extends Drawable { public RippleDrawable(android.content.res.ColorStateList c, Drawable d, Drawable m){}
 public void draw(Canvas c){} public void setAlpha(int a){} public void setColorFilter(ColorFilter f){} public int getOpacity(){return 0;} }
