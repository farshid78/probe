package android.graphics.drawable; import android.graphics.*;
public class ColorDrawable extends Drawable { public ColorDrawable(int c){}
 public void draw(Canvas c){} public void setAlpha(int a){} public void setColorFilter(ColorFilter f){} public int getOpacity(){return 0;} }
