package android.graphics.drawable; import android.graphics.*;
public class StateListDrawable extends Drawable { public void addState(int[] s, Drawable d){}
 public void draw(Canvas c){} public void setAlpha(int a){} public void setColorFilter(ColorFilter f){} public int getOpacity(){return 0;} }
