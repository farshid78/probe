package android.graphics.drawable; import android.graphics.*;
public class LayerDrawable extends Drawable { public LayerDrawable(Drawable[] d){} public void setId(int i,int id){}
 public void draw(Canvas c){} public void setAlpha(int a){} public void setColorFilter(ColorFilter f){} public int getOpacity(){return 0;} }
