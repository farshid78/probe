package android.app; import android.content.Context; import android.view.*;
public class Dialog { public Dialog(Context c){} public boolean requestWindowFeature(int f){return true;} public void setContentView(View v){} public Window getWindow(){return new Window();} public void show(){} public void dismiss(){} }
