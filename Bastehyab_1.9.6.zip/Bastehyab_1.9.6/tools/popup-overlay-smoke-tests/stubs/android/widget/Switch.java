package android.widget; import android.content.Context;
public class Switch extends TextView { public Switch(Context c){super(c);} public void setTrackDrawable(android.graphics.drawable.Drawable d){} public void setThumbDrawable(android.graphics.drawable.Drawable d){} }
