package android.widget; import android.content.Context;
public class EditText extends TextView { public EditText(Context c){super(c);} public void setHintTextColor(int c){} }
