package android.widget; import android.content.Context;
public class FrameLayout extends android.view.ViewGroup { public FrameLayout(Context c){super(c);} public static class LayoutParams extends MarginLayoutParams { public LayoutParams(int w,int h){super(w,h);} } }
