#!/usr/bin/env python3
from pathlib import Path
root = Path(__file__).resolve().parents[2]
ui = (root/'app/src/main/java/app/bastehyab/UI.java').read_text()
popup = (root/'app/src/main/java/app/bastehyab/Popup.java').read_text()
main = (root/'app/src/main/java/app/bastehyab/MainActivity.java').read_text()
strings = (root/'app/src/main/res/values/strings.xml').read_text()
checks = {
    'choice controls have minimum 48dp target': 't.setMinWidth(dp(c, 48))' in ui and 't.setMinHeight(dp(c, 48))' in ui,
    'icon actions expose labels and button semantics': 'static TextView iconButton' in ui and 'v.setContentDescription(label)' in ui and 'info.setClassName(android.widget.Button.class.getName())' in ui,
    'small caption font floor is 12sp': 'Math.max(12f, sp)' in ui,
    'dialog actions stack for narrow or large-font layouts': 'fontScale >= 1.15f' in ui and 'boolean verticalActions' in ui,
    'dialog body remains scrollable': 'BoundedScrollView' in ui and 'sv.addView(body' in ui,
    'popup controls have Persian action labels': 'a11y_expand_compare' in popup and 'a11y_close_compare' in popup,
    'popup controls support keyboard focus': 'FLAG_NOT_TOUCH_MODAL | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN' in popup,
    'popup scan status uses polite live region': 'setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE)' in popup,
    'popup status avoids repeated announcements': '!safeStatus.contentEquals(confirmStatus.getText())' in popup,
    'progress ticks are not individually announced': 'IMPORTANT_FOR_ACCESSIBILITY_NO' in popup,
    'home scan status is a polite live region': 'h.scanStatus.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE)' in main,
    'decorative bottom-nav icons and labels are hidden from tree': 'im.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO)' in main and 'label.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO)' in main,
    'strings include accessible scan and popup controls': 'name="scan_stop"' in strings and 'name="a11y_close_compare"' in strings,
}
for name, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ': ' + name)
if not all(checks.values()): raise SystemExit(1)
