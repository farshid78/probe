package android.graphics;
/** Java2D-backed stub used only by tools/neu-preview to render the real NeuDrawable on a desktop JVM. */
public class Paint {
  public static final int ANTI_ALIAS_FLAG=1; public enum Style {FILL,STROKE}
  public int color=0xFF000000; public Style style=Style.FILL; public float stroke=1f; public Shader shader;
  public Paint(int f){}
  public void setShader(Shader s){shader=s;} public void setStyle(Style s){style=s;}
  public void setColor(int c){color=c;} public void setAlpha(int a){color=(a<<24)|(color&0xFFFFFF);}
  public int getAlpha(){return color>>>24;}
  public void setStrokeWidth(float w){stroke=w;} public void setColorFilter(ColorFilter f){}
}
