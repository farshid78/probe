package android.graphics;
import java.awt.*; import java.awt.geom.*; import java.util.ArrayDeque;
public class Canvas {
  public final Graphics2D g; private final ArrayDeque<java.awt.Shape> clips=new ArrayDeque<>();
  public Canvas(Graphics2D g){this.g=g; g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON); g.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL,RenderingHints.VALUE_STROKE_PURE);}
  private static Color col(int c){return new Color((c>>16)&255,(c>>8)&255,c&255,c>>>24);}
  public void drawRoundRect(float l,float t,float r,float b,float rx,float ry,Paint p){
    RoundRectangle2D.Float s=new RoundRectangle2D.Float(l,t,r-l,b-t,rx*2,ry*2);
    if(p.style==Paint.Style.FILL){ paint(p); g.fill(s);} else { paint(p); g.setStroke(new BasicStroke(p.stroke)); g.draw(s);} }
  private void paint(Paint p){
    if(p.shader instanceof LinearGradient){ LinearGradient lg=(LinearGradient)p.shader; float k=p.getAlpha()/255f;
      int a0=Math.round((lg.c0>>>24)*k), a1=Math.round((lg.c1>>>24)*k);
      g.setPaint(new GradientPaint(lg.x0,lg.y0,col((a0<<24)|(lg.c0&0xFFFFFF)),lg.x1,lg.y1,col((a1<<24)|(lg.c1&0xFFFFFF)))); }
    else g.setPaint(col(p.color)); }
  public void drawRoundRect(RectF r,float a,float b,Paint p){drawRoundRect(r.left,r.top,r.right,r.bottom,a,b,p);}
  public int save(){clips.push(g.getClip()==null?new Rectangle(-100000,-100000,200000,200000):g.getClip()); return clips.size();}
  public void restore(){ g.setClip(clips.pop()); }
  public void clipPath(Path p){ if(p.shape!=null) g.clip(p.shape); }
}
