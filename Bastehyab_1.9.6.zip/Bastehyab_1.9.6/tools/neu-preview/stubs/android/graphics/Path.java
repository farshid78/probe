package android.graphics;
public class Path { public enum Direction {CW,CCW} public java.awt.Shape shape;
  public void moveTo(float x,float y){} public void lineTo(float x,float y){} public void reset(){shape=null;}
  public void addRoundRect(RectF r,float a,float b,Direction d){shape=new java.awt.geom.RoundRectangle2D.Float(r.left,r.top,r.width(),r.height(),a*2,b*2);} }
