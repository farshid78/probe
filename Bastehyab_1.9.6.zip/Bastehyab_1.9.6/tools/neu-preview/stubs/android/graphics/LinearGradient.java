package android.graphics;
public class LinearGradient extends Shader {
  public final float x0,y0,x1,y1; public final int c0,c1;
  public LinearGradient(float a,float b,float c,float d,int e,int f,Shader.TileMode t){x0=a;y0=b;x1=c;y1=d;c0=e;c1=f;}
  public LinearGradient(float a,float b,float c,float d,int[] e,float[] f,Shader.TileMode t){x0=a;y0=b;x1=c;y1=d;c0=e[0];c1=e[e.length-1];}
}
