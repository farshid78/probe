package android.content.res; import android.util.DisplayMetrics;
public class Resources { public static final DisplayMetrics DM=new DisplayMetrics(); static { DM.density=3f; } public DisplayMetrics getDisplayMetrics(){return DM;} }
