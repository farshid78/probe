#!/usr/bin/env bash
# Renders the real NeuDrawable/UI code through Java2D stubs -> PNG previews. Usage: run.sh <out-dir>
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
OUTIMG="${1:-.}"
OUT="$(mktemp -d)"
trap 'rm -rf "$OUT"' EXIT
cp -r "$ROOT/tools/android-core-smoke-tests/stubs" "$OUT/stubs"
rm -rf "$OUT/stubs/appstub"
cp -r "$ROOT/tools/popup-overlay-smoke-tests/stubs/android/." "$OUT/stubs/android/"
cp -r "$ROOT/tools/neu-preview/stubs/android/." "$OUT/stubs/android/"
# Keep the richer core Resources test double (fontScale/uiMode included).
cp "$ROOT/tools/android-core-smoke-tests/stubs/android/content/res/Resources.java" "$OUT/stubs/android/content/res/Resources.java"
python3 - "$OUT/stubs/android" <<'PY'
import sys
b=sys.argv[1]
def sub(p,old,new):
    s=open(b+p).read(); assert old in s,(p,old); open(b+p,'w').write(s.replace(old,new,1))
sub('/content/Context.java','public Context getApplicationContext()','public static final String WINDOW_SERVICE="window"; public static final android.view.FakeWindowManager WM=new android.view.FakeWindowManager(); public Object getSystemService(String n){return WM;}\n    public Context getApplicationContext()')
sub('/util/Log.java','public static int w','public static int d(String t,String m){return 0;} public static int w')
PY
find "$OUT/stubs" -name '*.java' > "$OUT/sources.txt"
P="$ROOT/tools/parser-smoke-tests/stubs"
S="$ROOT/tools/store-smoke-tests/stubs"
for f in "$P/android/graphics/Rect.java" "$P/android/view/accessibility/AccessibilityNodeInfo.java" \
         "$S/android/system/Os.java" "$S/org/json/JSONArray.java" "$S/org/json/JSONObject.java" \
         "$ROOT/tools/popup-overlay-smoke-tests/stubs/app/bastehyab/R.java" \
         "$ROOT/tools/android-core-smoke-tests/stubs/appstub/BuildConfig.java"; do echo "$f" >> "$OUT/sources.txt"; done
for f in Pkg PkgIdentity History HistoryLog Op OpSnapshot ListEndDetector ScanStrategyPolicy Cfg Fmt PriceModel Extractor Compare ScanWorkerTask ScanService Store Popup UI NeuDrawable; do echo "$ROOT/app/src/main/java/app/bastehyab/$f.java" >> "$OUT/sources.txt"; done
echo "$ROOT/tools/neu-preview/NeuPreview.java" >> "$OUT/sources.txt"
mkdir -p "$OUT/classes" "$OUTIMG"
javac -d "$OUT/classes" @"$OUT/sources.txt"
java -Djava.awt.headless=true -cp "$OUT/classes" app.bastehyab.NeuPreview "$OUTIMG"
