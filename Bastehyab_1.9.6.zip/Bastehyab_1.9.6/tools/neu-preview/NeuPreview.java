package app.bastehyab;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;

/** Renders the REAL NeuDrawable/UI tokens on a desktop JVM so the soft-UI look can be reviewed as PNG. */
public class NeuPreview {
    static Graphics2D g;
    static Canvas cv;
    static Context ctx = new Context();

    static Color col(int c) { return new Color((c >> 16) & 255, (c >> 8) & 255, c & 255, c >>> 24); }
    static void box(Drawable d, int x, int y, int w, int h) {
        d.setBounds(x, y, x + w, y + h);
        d.draw(cv);
    }
    static void text(String s, int x, int y, int size, int color, boolean bold, boolean center, int boxW) {
        g.setFont(new Font(Font.SANS_SERIF, bold ? Font.BOLD : Font.PLAIN, size));
        g.setColor(col(color));
        FontMetrics m = g.getFontMetrics();
        int px = center ? x + (boxW - m.stringWidth(s)) / 2 : x;
        g.drawString(s, px, y);
    }

    static BufferedImage screen(String theme) {
        ctx.getSharedPreferences("cfg", 0).edit().putString("appearance", theme).apply();
        UI.applyTheme(ctx);
        int W = 1080, H = 2560;
        BufferedImage img = new BufferedImage(W, H, BufferedImage.TYPE_INT_ARGB);
        g = img.createGraphics();
        cv = new Canvas(g);
        g.setPaint(new GradientPaint(0, 0, col(0xFF000000 | (UI.BG & 0xFFFFFF)), W, H, col(UI.light ? 0xFFDFE2F5 : UI.mono ? 0xFF0F1114 : 0xFF0E1222)));
        g.fillRect(0, 0, W, H);

        int x = 70, w = W - 140, y = 90;
        // hero
        box(UI.raised(ctx, 26, 9, true), x, y, w, 270);
        box(UI.inset(ctx, 22, UI.ACCENT), x + 40, y + 45, 150, 150);
        text("// SECURE • LOCAL • OFFLINE", x + 220, y + 80, 28, UI.ACCENT, true, false, 0);
        text("Bastehyab", x + 220, y + 150, 56, UI.TEXT, true, false, 0);
        box(UI.inset(ctx, 12, 0), x + 220, y + 185, 240, 52);
        text("● shield on", x + 235, y + 220, 26, UI.SUCCESS, true, false, 0);

        // section header
        y += 360;
        text("// OVERVIEW", x + 28, y, 26, UI.ACCENT, true, false, 0);
        text("Overview", x + 28, y + 56, 44, UI.TEXT, true, false, 0);

        // stats
        y += 100;
        int sw = (w - 40) / 2;
        box(UI.raised(ctx, 20, 7, true), x, y, sw, 190);
        text("12", x, y + 100, 64, UI.ACCENT, true, true, sw);
        text("valid packages", x, y + 150, 26, UI.MUTED, false, true, sw);
        box(UI.raised(ctx, 20, 7, true), x + sw + 40, y, sw, 190);
        text("4", x + sw + 40, y + 100, 64, UI.ACCENT, true, true, sw);
        text("operators", x + sw + 40, y + 150, 26, UI.MUTED, false, true, sw);

        // scan card + progress
        y += 260;
        box(UI.raised(ctx, 22, 7, true), x, y, w, 270);
        text("Last scan status", x + 40, y + 70, 34, UI.TEXT, true, false, 0);
        text("identified 24 | valid 18 | suspicious 2", x + 40, y + 125, 26, UI.MUTED, false, false, 0);
        box(UI.inset(ctx, 12, 0), x + 40, y + 175, w - 80, 26);
        // fill
        d(x + 40, y + 175, (int) ((w - 80) * .62), 26, 12);

        // buttons
        y += 340;
        int bw = (w - 40) / 2;
        box(primary(false), x, y, bw, 130);
        text("Start scan", x, y + 80, 34, 0xFFFFFFFF, true, true, bw);
        box(primary(true), x + bw + 40, y, bw, 130);
        text("pressed", x + bw + 40, y + 80, 34, 0xFFFFFFFF, true, true, bw);
        y += 190;
        box(UI.raisedSmall(ctx, 16), x, y, bw, 130);
        text("Secondary", x, y + 80, 34, UI.PRIMARY, true, true, bw);
        box(UI.inset(ctx, 16, 0), x + bw + 40, y, bw, 130);
        text("Secondary (pressed)", x + bw + 40, y + 80, 30, UI.PRIMARY, true, true, bw);

        // choices
        y += 200;
        int cw = (w - 80) / 3;
        for (int i = 0; i < 3; i++) {
            boolean on = i == 1;
            box(on ? UI.inset(ctx, 14, UI.PRIMARY) : UI.raisedSmall(ctx, 14), x + i * (cw + 40), y, cw, 110);
            text(i == 0 ? "Cheapest" : i == 1 ? "Longest" : "My usage", x + i * (cw + 40), y + 68, 30, on ? UI.PRIMARY : UI.TEXT, on, true, cw);
        }

        // input
        y += 190;
        box(UI.inset(ctx, 14, 0), x, y, w, 120);
        text("operator package name", x + 40, y + 72, 30, UI.MUTED, false, false, 0);

        // rank-1 card
        y += 200;
        box(new NeuDrawable(NeuDrawable.RAISED, 66, 27, UI.CARD2, UI.CARD, UI.LSH, UI.DSH,
                (UI.PRIMARY & 0xFFFFFF) | 0xAA000000, 4, (UI.G2 & 0xFFFFFF) | 0xFF000000), x, y, w, 250);
        box(UI.inset(ctx, 12, UI.ACCENT), x + 36, y + 36, 100, 100);
        text("1", x + 36, y + 100, 44, UI.ACCENT, true, true, 100);
        text("20 GB / 30 days", x + 170, y + 100, 44, UI.TEXT, true, false, 0);
        text("Final price", x + 36, y + 200, 24, UI.MUTED, false, false, 0);
        text("98,000 T", x + 36 + 200, y + 200, 30, UI.TEXT, true, false, 0);

        // switch rows
        y += 330;
        box(UI.inset(ctx, 14, UI.ACCENT), x + w - 150, y, 150, 84);
        d2(x + w - 150 + 150 - 84 + 6, y + 6, 72, UI.ACCENT);
        box(UI.inset(ctx, 14, 0), x + w - 150 - 220, y, 150, 84);
        d2(x + w - 150 - 220 + 6, y + 6, 72, UI.CARD2);
        text("Switches (on / off)", x, y + 54, 30, UI.TEXT, false, false, 0);

        // nav
        y = H - 270;
        box(UI.raised(ctx, 26, 9, true), x, y, w, 190);
        int nw = (w - 80) / 3;
        box(UI.inset(ctx, 20, UI.PRIMARY), x + 20 + 0 * (nw + 20), y + 20, nw, 150);
        text("Home", x + 20, y + 110, 28, UI.TEXT, true, true, nw);
        text("Compare", x + 20 + (nw + 20), y + 110, 28, UI.MUTED, false, true, nw);
        text("Settings", x + 20 + 2 * (nw + 20), y + 110, 28, UI.MUTED, false, true, nw);
        g.dispose();
        return img;
    }

    static Drawable primary(boolean pressed) {
        // identical to UI.btn(...) primary states
        android.graphics.drawable.StateListDrawable s = null;
        try {
            java.lang.reflect.Method m = UI.class.getDeclaredMethod("primaryShape", Context.class, float.class, boolean.class);
            m.setAccessible(true);
            return (Drawable) m.invoke(null, ctx, 16f, pressed);
        } catch (Exception e) { throw new RuntimeException(e); }
    }
    static void d(int x, int y, int w, int h, int r) {
        g.setPaint(new GradientPaint(x, y, col(UI.G2), x + w, y, col(UI.ACCENT)));
        g.fill(new java.awt.geom.RoundRectangle2D.Float(x, y, w, h, r * 2, r * 2));
    }
    static void d2(int x, int y, int s, int c) {
        g.setPaint(new GradientPaint(x, y, col(UI.ACCENT == c ? UI.ACCENT : c), x + s, y + s, col(UI.ACCENT == c ? UI.BLUE : c)));
        g.fillOval(x, y, s, s);
    }

    public static void main(String[] args) throws Exception {
        String out = args.length > 0 ? args[0] : ".";
        BufferedImage[] shots = {screen("dark"), screen("light"), screen("mono")};
        String[] names = {"dark", "light", "mono"};
        for (int i = 0; i < 3; i++) javax.imageio.ImageIO.write(shots[i], "png", new File(out, "neu_" + names[i] + ".png"));
        System.out.println("rendered");
    }
}
