package app.bastehyab;
import android.content.Context;
final class HistoryLog {
 static volatile int records;
 static volatile int reviews;
 static void record(Context c,Pkg old,Pkg cur){records++;}
 static void recordReview(Context c,Pkg p,boolean approved){reviews++;}
}
