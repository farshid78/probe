package app.bastehyab;
import android.content.Context;
import java.util.Collections;
import java.util.List;
final class Cfg {
 static final int DURATION=1,PER_GB_MONTH=2,MY_USAGE=3;
 static Op opById(Context c,String id){return null;}
 static int metric(Context c){return 0;}
 static float usage(Context c){return 30f;}
 static int bucket(Context c){return 0;}
 static List<Op> ops(Context c){Op o=new Op();return Collections.singletonList(o);}
 static int fresh(Context c){return 30;}
 static float minGb(Context c){return 0f;}
 static int maxDays(Context c){return 0;}
 static boolean restricted(Context c){return true;}
 static boolean intl(Context c){return false;}
 static int vat(Context c){return 0;}
}
