package app.bastehyab;
import java.util.regex.Pattern;
final class Extractor {
 static final Pattern INTL=Pattern.compile("a^",Pattern.CASE_INSENSITIVE);
 static final String INTL_WHY="بین‌الملل";
 static String whyOf(String s,double days,int volume){return "";}
 static String mergeWhy(String a,String b){if(a==null||a.isEmpty())return b==null?"":b;if(b==null||b.isEmpty())return a;return a;}
 static int volCount(String s){return 0;}
 static String keyOf(String op,String title,String code,String why){return op+"|"+title+"|"+code+"|"+why;}
}
