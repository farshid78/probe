package app.bastehyab;
final class Op { String cur="AUTO"; String id="operator"; boolean cmp=true; }
