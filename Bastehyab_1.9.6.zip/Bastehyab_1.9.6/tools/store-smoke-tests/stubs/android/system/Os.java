package android.system;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
public final class Os {
 public static volatile CountDownLatch entered;
 public static volatile CountDownLatch release;
 public static volatile boolean failBefore;
 public static volatile boolean failAfter;
 public static volatile String faultSuffix;
 public static void rename(String oldPath,String newPath) throws Exception {
   boolean fault = faultSuffix != null && oldPath.endsWith(faultSuffix);
   if (fault && failBefore) { failBefore=false; faultSuffix=null; throw new Exception("injected-before-rename"); }
   CountDownLatch e=entered, r=release;
   if(e!=null && oldPath.endsWith("data.json.tmp")) { e.countDown(); if(r!=null) r.await(5,TimeUnit.SECONDS); entered=null; release=null; }
   Files.move(new File(oldPath).toPath(),new File(newPath).toPath(),StandardCopyOption.REPLACE_EXISTING,StandardCopyOption.ATOMIC_MOVE);
   if (fault && failAfter) { failAfter=false; faultSuffix=null; throw new Exception("injected-after-rename"); }
 }
}
