JVM-only filesystem shim used by Store smoke tests. Production code uses android.system.Os.rename.
