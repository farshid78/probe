package org.json;
import java.util.Map;
import java.util.HashMap;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;
public class JSONObject {
 private static final AtomicLong IDS=new AtomicLong();
 private static final Map<String,Map<String,Object>> REGISTRY=new ConcurrentHashMap<>();
 private final Map<String,Object> values=new HashMap<>();
 public JSONObject(){}
 public JSONObject(String token){Map<String,Object> m=REGISTRY.get(token);if(m==null)throw new IllegalArgumentException("bad-json-object");values.putAll(m);}
 public JSONObject put(String k,Object v){values.put(k,v);return this;}
 public boolean has(String k){return values.containsKey(k);}
 public Object get(String k){if(!values.containsKey(k))throw new IllegalArgumentException(k);return values.get(k);}
 public String getString(String k){Object v=get(k);return String.valueOf(v);}
 public int getInt(String k){Object v=get(k);return v instanceof Number?((Number)v).intValue():Integer.parseInt(String.valueOf(v));}
 public double getDouble(String k){Object v=get(k);return v instanceof Number?((Number)v).doubleValue():Double.parseDouble(String.valueOf(v));}
 public long getLong(String k){Object v=get(k);return v instanceof Number?((Number)v).longValue():Long.parseLong(String.valueOf(v));}
 public JSONArray getJSONArray(String k){Object v=get(k);if(v instanceof JSONArray)return (JSONArray)v;throw new IllegalArgumentException(k);}
 public String optString(String k,String d){Object v=values.get(k);return v==null?d:String.valueOf(v);}
 public double optDouble(String k,double d){Object v=values.get(k);try{return v==null?d:v instanceof Number?((Number)v).doubleValue():Double.parseDouble(String.valueOf(v));}catch(RuntimeException e){return d;}}
 public long optLong(String k,long d){Object v=values.get(k);try{return v==null?d:v instanceof Number?((Number)v).longValue():Long.parseLong(String.valueOf(v));}catch(RuntimeException e){return d;}}
 public boolean optBoolean(String k,boolean d){Object v=values.get(k);return v==null?d:v instanceof Boolean?(Boolean)v:Boolean.parseBoolean(String.valueOf(v));}
 public int optInt(String k,int d){Object v=values.get(k);try{return v==null?d:v instanceof Number?((Number)v).intValue():Integer.parseInt(String.valueOf(v));}catch(RuntimeException e){return d;}}
 public JSONArray optJSONArray(String k){Object v=values.get(k);return v instanceof JSONArray?(JSONArray)v:null;}
 @Override public String toString(){String token="{OBJ:"+IDS.incrementAndGet()+"}";REGISTRY.put(token,new HashMap<>(values));return token;}
}
