package org.json;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;
public class JSONArray {
 private static final AtomicLong IDS=new AtomicLong();
 private static final Map<String,List<Object>> REGISTRY=new ConcurrentHashMap<>();
 private final List<Object> values=new ArrayList<>();
 public JSONArray(){}
 public JSONArray(java.util.Collection<?> source){values.addAll(source);}
 public JSONArray(String token){if("[]".equals(token.trim()))return;List<Object> v=REGISTRY.get(token);if(v==null)throw new IllegalArgumentException("bad-json-array");values.addAll(v);}
 public JSONArray put(Object o){values.add(o);return this;}
 public int length(){return values.size();}
 public Object get(int i){return values.get(i);}
 public JSONObject getJSONObject(int i){Object v=get(i);if(v instanceof JSONObject)return (JSONObject)v;throw new IllegalArgumentException("not-object");}
 public long getLong(int i){Object v=get(i);return v instanceof Number?((Number)v).longValue():Long.parseLong(String.valueOf(v));}
 public String getString(int i){return String.valueOf(get(i));}
 @Override public String toString(){String token="[ARR:"+IDS.incrementAndGet()+"]";REGISTRY.put(token,new ArrayList<>(values));return token;}
}
