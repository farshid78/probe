#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
HERE="$(cd "$(dirname "$0")" && pwd)"
OUT="$(mktemp -d)"
trap 'rm -rf "$OUT"' EXIT
javac -Xlint:all -d "$OUT" \
  $(find "$HERE/stubs" -name '*.java' | sort) \
  "$ROOT/app/src/main/java/app/bastehyab/Fmt.java" \
  "$ROOT/app/src/main/java/app/bastehyab/PriceModel.java" \
  "$ROOT/app/src/main/java/app/bastehyab/Pkg.java" \
  "$ROOT/app/src/main/java/app/bastehyab/PkgIdentity.java" \
  "$ROOT/app/src/main/java/app/bastehyab/Store.java" \
  "$ROOT/app/src/main/java/app/bastehyab/History.java" \
  "$ROOT/app/src/main/java/app/bastehyab/Compare.java" \
  "$HERE/StoreSmokeTest.java"
for scenario in bad backup legacy empty corrupt future copy concurrent clear atomic bench identity id-conflict identity-migration prompt6-migration identity-bench compare-financial history; do
  java -cp "$OUT" app.bastehyab.StoreSmokeTest "$scenario"
done
