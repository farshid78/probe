package app.bastehyab;

import android.content.Context;
import android.system.Os;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

public final class StoreSmokeTest {
    private static void check(boolean ok, String message) {
        if (!ok) throw new AssertionError(message);
    }
    private static Context context(String name) throws Exception {
        File dir=Files.createTempDirectory("bastehyab-store-"+name).toFile();
        return new Context(dir);
    }
    private static Pkg pkg(String suffix) {
        Pkg p=new Pkg();
        p.op="operator"; p.title="Offer "+suffix; p.code="code-"+suffix;
        p.gb=10; p.days=30; p.toman=10000; p.ts=System.currentTimeMillis();
        p.identityTitle=p.title; p.identityKind=PkgIdentity.inferKind(p.title);
        p.productIdObserved=true;
        PkgIdentity.normalize(p);
        p.currencyKnown=true; p.taxKnown=true; p.normalizedToman=p.toman;
        p.alts=new long[]{9000,10000};
        return p;
    }
    private static Pkg identityPkg(String title, double gb, double days, long price,
                                   String why, long observedAt, String code, boolean observedId) {
        Pkg p=new Pkg();
        p.op="operator"; p.title=title; p.identityTitle=title; p.identityKind="DATA";
        p.gb=gb; p.days=days; p.toman=price; p.normalizedToman=price;
        p.currencyKnown=true; p.taxKnown=true; p.why=why; p.restricted=why!=null&&!why.isEmpty();
        p.code=code==null?"":code; p.productIdObserved=observedId; p.observedAt=observedAt;
        p.ts=observedAt; p.priceSource="fixture"; PkgIdentity.normalize(p);
        return p;
    }

    private static JSONObject legacyV2(String title, double gb, double days, long price,
                                        String why, long ts) throws Exception {
        return new JSONObject().put("op","operator").put("key","legacy:"+title+":"+days)
                .put("title",title).put("code","").put("why",why).put("gb",gb).put("days",days)
                .put("toman",price).put("ts",ts).put("r",why!=null&&!why.isEmpty())
                .put("am",false).put("ck",true).put("note","");
    }

    private static void writeDatabase(File file, List<JSONObject> objects) throws Exception {
        JSONObject root=new JSONObject(); root.put("schemaVersion",2); root.put("recordCount",objects.size());
        JSONArray rows=new JSONArray(); for(JSONObject o:objects)rows.put(o);
        root.put("records",rows);
        Files.write(file.toPath(),root.toString().getBytes(StandardCharsets.UTF_8));
    }
    private static void writePrompt6Schema3(File file, List<JSONObject> objects) throws Exception {
        JSONObject root=new JSONObject().put("schemaVersion",3).put("recordCount",objects.size());
        JSONArray rows=new JSONArray(); for(JSONObject o:objects)rows.put(o);
        root.put("records",rows);
        Files.write(file.toPath(),root.toString().getBytes(StandardCharsets.UTF_8));
    }
    private static void loaded(Context c) throws Exception {
        CountDownLatch latch=new CountDownLatch(1);
        Store.whenLoaded(c,latch::countDown);
        check(latch.await(5,TimeUnit.SECONDS),"load timeout");
    }
    private static boolean persisted(long timeoutMs) throws Exception {
        long until=System.currentTimeMillis()+timeoutMs;
        while(System.currentTimeMillis()<until){
            String d=Store.diagnostics();
            int a=d.indexOf("persistedVersion=")+17;
            int b=d.indexOf(',',a);
            int c=d.indexOf("mutationVersion=")+16;
            int e=d.indexOf('}',c); if(e<0)e=d.length();
            long pv=Long.parseLong(d.substring(a,b));
            long mv=Long.parseLong(d.substring(c,e));
            if(pv>=mv)return true;
            Thread.sleep(20);
        }
        return false;
    }
    private static List<Pkg> snapshot(Context c) { return Store.snapshot(c); }

    private static void badRecord() throws Exception {
        Context c=context("bad-record");
        List<JSONObject> rows=new ArrayList<>();
        for(int i=0;i<10;i++)rows.add(pkg(""+i).json());
        rows.add(new JSONObject().put("op","broken"));
        writeDatabase(new File(c.getFilesDir(),"data.json"),rows);
        loaded(c);
        check(snapshot(c).size()==10,"healthy records not preserved");
        check(Store.diagnostics().contains("quarantined=1"),"bad record not counted in quarantine");
        System.out.println("PASS bad-record-isolated");
    }

    private static void backupAndMigrations() throws Exception {
        Context c=context("backup");
        File primary=new File(c.getFilesDir(),"data.json");
        File backup=new File(c.getFilesDir(),"data.json.bak");
        Files.write(primary.toPath(),"not-json".getBytes(StandardCharsets.UTF_8));
        writeDatabase(backup,Collections.singletonList(pkg("backup").json()));
        loaded(c);
        check(snapshot(c).size()==1,"backup recovery failed");
        check(Store.diagnostics().contains("STORE_BACKUP_RECOVERED"),"backup recovery diagnostic missing");
        check(persisted(4000),"recovered database was not rewritten");
        System.out.println("PASS backup-recovery");
    }

    private static void legacyMigration() throws Exception {
        Context old=context("legacy");
        Pkg legacy=pkg("legacy");
        JSONArray oldArray=new JSONArray().put(legacy.json());
        Files.write(new File(old.getFilesDir(),"data.json").toPath(),oldArray.toString().getBytes(StandardCharsets.UTF_8));
        loaded(old);
        check(snapshot(old).size()==1,"legacy version-one array not loaded");
        check(persisted(4000),"legacy database not migrated to schema v2");
        System.out.println("PASS legacy-migration");
    }

    private static void emptyFile() throws Exception {
        Context empty=context("empty");
        Files.write(new File(empty.getFilesDir(),"data.json").toPath(),new byte[0]);
        loaded(empty);
        check(snapshot(empty).isEmpty(),"empty file should fail safely to empty state");
        check(Store.diagnostics().contains("STORE_EMPTY_FILE"),"empty-file code missing");
        System.out.println("PASS empty-file");
    }


    private static void corruptDocumentAndFutureSchema() throws Exception {
        Context corrupt=context("corrupt-document");
        Files.write(new File(corrupt.getFilesDir(),"data.json").toPath(),"{truncated".getBytes(StandardCharsets.UTF_8));
        loaded(corrupt);
        check(snapshot(corrupt).isEmpty(),"corrupt root should not crash or create partial records");
        check(Store.diagnostics().contains("STORE_DOCUMENT_INVALID"),"corrupt-root diagnostic missing");
        System.out.println("PASS corrupt-document");
    }

    private static void futureSchema() throws Exception {
        Context future=context("future-schema");
        JSONObject root=new JSONObject().put("schemaVersion",99).put("records",new JSONArray());
        Files.write(new File(future.getFilesDir(),"data.json").toPath(),root.toString().getBytes(StandardCharsets.UTF_8));
        loaded(future);
        check(snapshot(future).isEmpty(),"unsupported schema must not be parsed as current");
        check(Store.diagnostics().contains("STORE_SCHEMA_NEWER"),"future schema code missing");
        System.out.println("PASS unsupported-schema");
    }

    private static void detachedSnapshots() throws Exception {
        Context c=context("copy"); loaded(c);
        Pkg input=pkg("copy");
        Store.upsert(c,Collections.singletonList(input));
        input.title="caller-mutated"; input.alts[0]=123;
        List<Pkg> one=snapshot(c);
        check(one.size()==1,"insert missing");
        one.get(0).title="snapshot-mutated"; one.get(0).alts[0]=456;
        check("Offer copy".equals(snapshot(c).get(0).title),"Pkg reference escaped map");
        check(snapshot(c).get(0).alts[0]==9000,"array reference escaped map");
        Store.reprice(c,"operator",2);
        check(snapshot(c).get(0).normalizedToman==9000,"reprice did not synchronize canonical price");
        check(persisted(4000),"snapshot changes did not flush");
        System.out.println("PASS deep-copy-boundary");
    }

    private static void concurrentMutations() throws Exception {
        Context c=context("concurrency");
        Pkg seed=pkg("race"); seed.ambig=true; seed.currencyKnown=false; seed.reviewStatus="pending";
        Store.upsert(c,Collections.singletonList(seed));
        check(persisted(4000),"seed did not persist");
        loaded(c);
        List<Thread> threads=new ArrayList<>();
        for(int t=0;t<6;t++){
            final int id=t;
            Thread worker=new Thread(() -> {
                for(int i=0;i<150;i++){
                    Pkg p=pkg("race"); p.note="thread-"+id;
                    Store.upsert(c,Collections.singletonList(p));
                    Store.snapshot(c);
                    Compare.run(c, null); // compare reads a detached point-in-time snapshot
                    Store.reprice(c,"operator",(i%2)+1);
                    Store.saveReview(c,seed.key,true,10,30,12000,"review");
                }
            });
            threads.add(worker);worker.start();
        }
        for(Thread t:threads)t.join(10000);
        for(Thread t:threads)check(!t.isAlive(),"concurrency worker stuck");
        Store.flush(c);
        check(persisted(7000),"concurrent writes not persisted");
        check(snapshot(c).size()==1,"concurrent update duplicated or lost record");
        System.out.println("PASS concurrent-compare-review-reprice-upsert");
    }

    private static void clearDuringPendingLoad() throws Exception {
        Context c=context("clear-pending");
        writeDatabase(new File(c.getFilesDir(),"data.json"),Collections.singletonList(pkg("stale").json()));
        // Both operations race the queued load; the clear must win whichever order executes.
        Store.clearAll(c);
        loaded(c);
        Store.flush(c);
        check(snapshot(c).isEmpty(),"pending load resurrected records after clearAll");
        check(persisted(5000),"clearAll not persisted");
        System.out.println("PASS clear-during-pending-load");
    }

    private static void nonBlockingAndAtomicFailures() throws Exception {
        Context c=context("async-atomic"); loaded(c);
        // Initial successful write.
        Store.upsert(c,Collections.singletonList(pkg("one")));
        check(persisted(4000),"initial write failed");
        Pkg two=pkg("two");
        CountDownLatch entered=new CountDownLatch(1),release=new CountDownLatch(1);
        Os.entered=entered;Os.release=release;
        Store.upsert(c,Collections.singletonList(two));
        check(entered.await(3,TimeUnit.SECONDS),"writer did not reach atomic rename");
        long start=System.nanoTime(); Store.flush(c); long millis=TimeUnit.NANOSECONDS.toMillis(System.nanoTime()-start);
        check(millis<100,"flush blocked caller for "+millis+"ms");
        release.countDown();
        check(persisted(5000),"second queued write failed");
        check(new File(c.getFilesDir(),"data.json.bak").exists(),"last known-good backup missing after second save");
        System.out.println("PASS main-thread-nonblocking-and-successive-writes");

        // Simulate failure immediately before replacing primary; retry must preserve then commit.
        Os.faultSuffix="data.json.tmp";Os.failBefore=true;
        Pkg three=pkg("three");Store.upsert(c,Collections.singletonList(three));
        check(persisted(8000),"pre-rename failure did not retry");
        check(Store.snapshot(c).size()==3,"record lost after pre-rename failure");
        System.out.println("PASS interruption-before-rename");

        // Simulate a reported failure after rename has taken place; recovery/retry remains idempotent.
        Os.faultSuffix="data.json.tmp";Os.failAfter=true;
        Pkg four=pkg("four");Store.upsert(c,Collections.singletonList(four));
        check(persisted(8000),"post-rename failure did not retry");
        check(Store.snapshot(c).size()==4,"record lost after post-rename failure");
        check(new File(c.getFilesDir(),"data.json.bak").exists(),"backup deleted after successful save");
        System.out.println("PASS interruption-after-rename");

        CountDownLatch enteredClear=new CountDownLatch(1),releaseClear=new CountDownLatch(1);
        Os.entered=enteredClear;Os.release=releaseClear;
        Store.upsert(c,Collections.singletonList(pkg("five")));
        check(enteredClear.await(3,TimeUnit.SECONDS),"pending writer was not blocked for clear test");
        Store.clearAll(c);
        releaseClear.countDown();
        check(persisted(6000),"clear did not supersede pending write");
        check(snapshot(c).isEmpty(),"clear did not clear in-memory records");
        JSONObject disk=new JSONObject(new String(Files.readAllBytes(new File(c.getFilesDir(),"data.json").toPath()),StandardCharsets.UTF_8));
        check(disk.getJSONArray("records").length()==0,"pending write resurrected records after clearAll");
        System.out.println("PASS clear-during-pending-write");
    }

    private static void benchmarkSnapshot() throws Exception {
        Context c=context("benchmark");
        List<JSONObject> rows=new ArrayList<>();
        for(int i=0;i<2500;i++)rows.add(pkg("bench-"+i).json());
        writeDatabase(new File(c.getFilesDir(),"data.json"),rows);
        loaded(c);
        check(snapshot(c).size()==2500,"benchmark data size mismatch");
        long[] times=new long[50];
        for(int i=0;i<times.length;i++){
            long start=System.nanoTime(); Store.snapshot(c);
            times[i]=TimeUnit.NANOSECONDS.toMicros(System.nanoTime()-start);
        }
        java.util.Arrays.sort(times);
        System.out.println("BENCH snapshot-2500 median-us="+times[times.length/2]+" p95-us="+times[(int)(times.length*.95)-1]);
        System.out.println("PASS snapshot-benchmark");
    }

    private static void identityDedupAndConflicts() throws Exception {
        Context c=context("identity-dedup"); loaded(c);
        long t=System.currentTimeMillis();
        Pkg first=identityPkg("بسته اینترنت ۵ گیگابایت",5,7,50000,"",t,null,false);
        Pkg repriced=identityPkg("بسته اینترنت ۵ گیگابایت",5,7,65000,"",t+1000,null,false);
        check(first.key.equals(repriced.key),"price change must not alter identity key");
        Store.upsert(c,Collections.singletonList(first));
        Store.upsert(c,Collections.singletonList(repriced));
        check(snapshot(c).size()==1,"overlapping scans/reprice must not duplicate one identity");
        check(snapshot(c).get(0).toman==65000,"newer observed price must be selected");

        Pkg classification=identityPkg("بسته اینترنت ۵ گیگابایت",5,7,65000,"بسته‌ی شبانه",t+2000,null,false);
        check(classification.key.equals(first.key),"classification change must not mint another key");
        Store.upsert(c,Collections.singletonList(classification));
        Pkg conflict=snapshot(c).get(0);
        check(snapshot(c).size()==1,"classification-only conflict must remain one identity");
        check(conflict.classificationConflict,"classification mismatch must be explicitly flagged");
        check(conflict.classificationVariants.contains("بسته‌ی شبانه")
                && conflict.classificationVariants.contains("GENERAL"),"both classification variants must be preserved");
        check(conflict.why.isEmpty(),"the earlier observed GENERAL classification must remain canonical");
        check("pending".equals(conflict.reviewStatus),"classification conflict must enter manual review");
        check(!Store.reviewQueue(c).isEmpty(),"classification conflict must appear in review queue");
        Store.flush(c); check(persisted(5000),"identity dedup state did not persist");
        System.out.println("PASS identity-price-overlap-and-classification-conflict");
    }

    private static void explicitIdCollisionRetainsBoth() throws Exception {
        Context c=context("identity-id-conflict"); loaded(c);
        long t=System.currentTimeMillis();
        Pkg seven=identityPkg("بسته اینترنت ۵ گیگابایت",5,7,50000,"",t,"PKG-007",true);
        Pkg thirty=identityPkg("بسته اینترنت ۵ گیگابایت",5,30,50000,"",t+1000,"PKG-007",true);
        check(seven.key.equals(thirty.key),"explicit package ID must have primary identity priority");
        Store.upsert(c,Collections.singletonList(seven));
        Store.upsert(c,Collections.singletonList(thirty));
        List<Pkg> all=snapshot(c);
        check(all.size()==2,"conflicting attributes under one explicit ID must preserve both records");
        int flagged=0; java.util.Set<String> keys=new java.util.HashSet<>();
        for(Pkg p:all){ if(p.identityConflict && "pending".equals(p.reviewStatus)) flagged++; keys.add(p.key); }
        check(flagged==2 && keys.size()==2,"both ID variants must be explicitly marked and deterministically keyed");
        Pkg primary=null, variantKey=null;
        for(Pkg p:all){ if(p.days==7) primary=p; if(p.days==30) variantKey=p; }
        check(primary!=null && variantKey!=null && !primary.key.contains(":variant:")
                && variantKey.key.contains(":variant:"),
                "the already stored 7-day ID record remains canonical; contradictory 30-day evidence gets a variant key");
        check(Store.reviewQueue(c).size()==2,"both ID conflict variants must require review");
        Pkg variant=null; for(Pkg p:all) if(p.days==30) variant=p;
        check(variant!=null && Store.saveReview(c,variant.key,true,5,30,52000,"مشخصات با صفحهٔ رسمی تطبیق داده شد"),
                "manual review must be able to resolve a deterministic ID conflict variant");
        Pkg reviewed=null; for(Pkg p:snapshot(c)) if(p.days==30) reviewed=p;
        check(reviewed!=null && reviewed.identityConflict && reviewed.comparisonVersion().identityConflict==false,
                "manual approval resolves conflict only in the comparison copy, preserving stored evidence");
        Store.flush(c); check(persisted(5000),"ID conflict variants not persisted");
        System.out.println("PASS explicit-id-conflict-preserves-both-variants");
    }

    private static void identityBenchmark() {
        final int count=2500, rounds=7;
        List<Pkg> values=new ArrayList<>(count);
        for(int i=0;i<count;i++) values.add(identityPkg("Offer "+i+" 5GB",5+(i%4),7+(i%3)*7,
                50000+i,"",System.currentTimeMillis(),null,false));
        for(int i=0;i<1000;i++) PkgIdentity.keyOf(values.get(i%count));
        long[] samples=new long[rounds];
        for(int r=0;r<rounds;r++){
            long start=System.nanoTime();
            for(Pkg p:values) PkgIdentity.keyOf(p);
            samples[r]=(System.nanoTime()-start)/1000L;
        }
        java.util.Arrays.sort(samples);
        System.out.println("BENCH identity-2500 total-us median="+samples[rounds/2]+" p95="+samples[rounds-1]);
        check(samples[rounds/2] < 2_000_000L,"identity benchmark exceeded 2 seconds for 2500 keys");
        System.out.println("PASS versioned-identity-benchmark");
    }

    private static void v2IdentityMigrationPreservesDistinctValidRecords() throws Exception {
        Context c=context("identity-v2-migration");
        List<JSONObject> rows=new ArrayList<>();
        rows.add(legacyV2("بسته اینترنت ۵ گیگابایت",5,7,50000,"",10));
        rows.add(legacyV2("بسته اینترنت ۵ گیگابایت",5,30,90000,"",20));
        // Same 30-day legacy identity with an alternate classification: it is consolidated into
        // one reviewable identity while both classification values survive in metadata.
        rows.add(legacyV2("بسته اینترنت ۵ گیگابایت",5,30,95000,"بسته‌ی شبانه",30));
        writeDatabase(new File(c.getFilesDir(),"data.json"),rows);
        loaded(c);
        List<Pkg> all=snapshot(c);
        check(all.size()==2,"v2 migration must retain 7-day and 30-day valid packages");
        Pkg thirty=null;
        for(Pkg p:all) if(Math.abs(p.days-30)<0.01) thirty=p;
        check(thirty!=null && thirty.classificationConflict,"legacy duplicate classification must be marked for review");
        check("LIMITS_UNKNOWN".equals(thirty.identityLimits),
                "v2 data without a persisted card-level limits field must migrate as unknown, not known-unrestricted");
        check(thirty.classificationVariants.contains("بسته‌ی شبانه"),"legacy classification variant lost during migration");
        check("".equals(thirty.why) && thirty.toman==95000,
                "migration must retain earliest canonical classification but newest observed price");
        check(HistoryLog.records>0,"migration merge must create a price-history entry rather than silently overwrite");
        check(Store.diagnostics().contains("identityMerged="),"identity merge count missing from diagnostics");
        check(persisted(5000),"v2 identity migration was not rewritten to current schema");
        System.out.println("PASS v2-identity-migration-preserves-valid-duration-records");
    }

    private static void prompt6Schema3Migration() throws Exception {
        Context c=context("prompt6-schema3-migration");
        JSONObject oldRecord = new JSONObject().put("op","operator").put("key","old-key")
                .put("title","بسته اینترنت ۵ گیگابایت").put("code","legacy-view-id-007")
                .put("why","").put("gb",5).put("days",30).put("toman",90000)
                .put("ts",30).put("r",false).put("am",false).put("ck",true).put("note","");
        writePrompt6Schema3(new File(c.getFilesDir(),"data.json"),Collections.singletonList(oldRecord));
        loaded(c);
        List<Pkg> migrated=snapshot(c);
        check(migrated.size()==1,"Prompt6 schema-3 record must survive migration");
        Pkg p=migrated.get(0);
        check(p.identityVersion==PkgIdentity.VERSION && !p.productIdObserved
                && p.key.startsWith("pkg:v3:fp:"),
                "legacy code without observed-ID provenance must not be promoted to a product ID");
        check("LIMITS_UNKNOWN".equals(p.identityLimits),
                "Prompt6 data must retain unknown card-level limits, not assume unrestricted");
        File migratedFile = new File(c.getFilesDir(),"data.json");
        JSONObject rewritten = null;
        long migrationDeadline = System.currentTimeMillis() + 5000L;
        while (System.currentTimeMillis() < migrationDeadline) {
            try {
                rewritten = new JSONObject(new String(Files.readAllBytes(
                        migratedFile.toPath()), StandardCharsets.UTF_8));
                if (rewritten.optInt("schemaVersion",0) == 4) break;
            } catch (RuntimeException ignored) { }
            Thread.sleep(20L);
        }
        check(rewritten != null && rewritten.optInt("schemaVersion",0)==4,
                "schema-3 Prompt6 source must be persisted as storage schema 4 before the migration test completes");
        System.out.println("PASS prompt6-schema3-to-schema4-identity-migration");
    }


    private static void compareFinancialGuardrails() throws Exception {
        Context c=context("compare-financial");
        Pkg a=pkg("a"); a.key="a"; a.gb=2; a.days=30; a.normalizedToman=100000; a.taxIncluded=true;
        Pkg b=pkg("b"); b.key="b"; b.gb=2; b.days=30; b.normalizedToman=100000; b.taxIncluded=false;
        Pkg invalid=pkg("invalid"); invalid.key="invalid"; invalid.gb=Double.NaN;
        Pkg overflow=pkg("overflow"); overflow.key="overflow"; overflow.normalizedToman=Long.MAX_VALUE;
        Compare.Result result=Compare.run(c,java.util.Arrays.asList(a,b,invalid,overflow),Collections.<String>emptySet());
        check(result.ranked.size()==2,"only two tax-known, finite and bounded prices should rank");
        check(result.val.get("a") < result.val.get("b"),"VAT-inclusive price must not receive VAT again");
        check(result.ambig.size()==2,"invalid dimensions and out-of-range money must be quarantined");
        check(PriceModel.monthlyCost(100000L,6d,60d,30d)==500000L,"monthly usage cost formula incorrect");
        PriceModel.Parsed parsed=PriceModel.parse("بسته ۲ گیگ، ۱۰۰٬۰۰۰ تومان، اعتبار ۳۰ روز",PriceModel.Currency.UNKNOWN);
        check(parsed!=null && parsed.normalizedToman==100000L,"price parser consumed duration as price");
        check(PriceModel.parse("۱۰۰۰۰ تومان یا ۹۰۰۰ تومان",PriceModel.Currency.UNKNOWN)==null,
                "multiple candidate prices must be treated as ambiguous");
        System.out.println("PASS financial-overflow-tax-once-usage-and-parser-guardrails");
    }


    private static void historyIdentityAndNumericGuards() {
        Pkg old = pkg("history");
        old.key = "same-key"; old.op = "operator-a"; old.currencyKnown = true; old.ambig = false;
        Pkg current = old.copy(); current.toman = old.toman + 1000; current.ts++;
        check(History.diff(old, current).size() == 1, "same operator/package price change should be logged");
        Pkg otherOperator = current.copy(); otherOperator.op = "operator-b";
        check(History.diff(old, otherOperator).isEmpty(), "cross-operator identity collision must not be logged as same package");
        Pkg invalid = current.copy(); invalid.toman = Long.MAX_VALUE;
        check(History.diff(old, invalid).isEmpty() == false, "valid positive finite price transition remains eligible");
        current.gb = Double.NaN;
        check(History.diff(old, current).stream().noneMatch(ch -> "gb".equals(ch.field)),
                "NaN dimensions must not enter history");
        current = old.copy(); current.days = Double.POSITIVE_INFINITY;
        check(History.diff(old, current).stream().noneMatch(ch -> "days".equals(ch.field)),
                "infinite duration must not enter history");
        System.out.println("PASS history-operator-identity-and-finite-value-guards");
    }

    public static void main(String[] args) throws Exception {
        switch(args[0]) {
            case "bad": badRecord(); break;
            case "backup": backupAndMigrations(); break;
            case "legacy": legacyMigration(); break;
            case "empty": emptyFile(); break;
            case "corrupt": corruptDocumentAndFutureSchema(); break;
            case "future": futureSchema(); break;
            case "copy": detachedSnapshots(); break;
            case "concurrent": concurrentMutations(); break;
            case "clear": clearDuringPendingLoad(); break;
            case "atomic": nonBlockingAndAtomicFailures(); break;
            case "bench": benchmarkSnapshot(); break;
            case "identity": identityDedupAndConflicts(); break;
            case "id-conflict": explicitIdCollisionRetainsBoth(); break;
            case "identity-migration": v2IdentityMigrationPreservesDistinctValidRecords(); break;
            case "prompt6-migration": prompt6Schema3Migration(); break;
            case "identity-bench": identityBenchmark(); break;
            case "compare-financial": compareFinancialGuardrails(); break;
            case "history": historyIdentityAndNumericGuards(); break;
            default: throw new IllegalArgumentException(args[0]);
        }
    }
}
