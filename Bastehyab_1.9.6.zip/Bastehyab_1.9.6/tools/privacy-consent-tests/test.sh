#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
XML="$ROOT/app/src/main/res/xml/service_config.xml"
MANIFEST="$ROOT/app/src/main/AndroidManifest.xml"
SERVICE="$ROOT/app/src/main/java/app/bastehyab/ScanService.java"
STORE="$ROOT/app/src/main/java/app/bastehyab/Store.java"
STRINGS="$ROOT/app/src/main/res/values/strings.xml"
README="$ROOT/README.md"
# Idle package visibility is limited to the five built-in operator apps.
grep -q 'android:packageNames="com.myirancell,ir.mci.ecareapp,ir.rightel.myrightel,com.mysamantel,com.shmapp"' "$XML"
! grep -q 'flagReportViewIds\|flagRetrieveInteractiveWindows' "$XML"
grep -q 'android:canPerformGestures="true"' "$XML"
grep -q 'swipe' "$STRINGS"
# No accessibility-tool claim and no app INTERNET permission.
! grep -q 'isAccessibilityTool' "$MANIFEST"
! grep -q 'android.permission.INTERNET' "$MANIFEST"
# Passive operator scan path removed; active scan has exact consent and selected-package gates.
! grep -q 'Cfg.opFor(this, packageName)' "$SERVICE"
grep -q 'if (e == null) return' "$SERVICE"
grep -q 'if (!fullMode) {' "$SERVICE"
grep -q 'extractionAuthorized(fullMode, fullConfirmed, fullPaused, p, fullTargetPackage)' "$SERVICE"
grep -q 'info.packageNames = packages' "$SERVICE"
grep -q 'selected-app-not-active' "$SERVICE"
! grep -q 'getWindows()\|window.getRoot()' "$SERVICE"
grep -q 'revokeDisclosureConsent' "$SERVICE"
# Persisted JSON excludes raw accessibility text; parser input is cleared before insertion.
! grep -q 'o.put("raw"' "$ROOT/app/src/main/java/app/bastehyab/Pkg.java"
grep -q 'p.raw = "";' "$STORE"
# The privacy text and service description explicitly state local processing and gesture use.
grep -q 'روی دستگاه انجام می‌شود' "$STRINGS"
grep -q 'swipe عمودی' "$README"
# No logs directly emit node text/content-description values.
! grep -R -E 'Log\.[a-z]+\([^;]*(getText\(|getContentDescription\(|\.text\b|\.raw\b)' "$ROOT/app/src/main/java/app/bastehyab" >/dev/null
# Run behavior tests for consent, target isolation, revocation, and service shutdown.
bash "$ROOT/tools/android-core-smoke-tests/run.sh"
echo 'PASS: privacy/consent static guards and behavior smoke tests.'
