#!/usr/bin/env bash
set -euo pipefail

# This script is intentionally run only after gradle/actions/setup-gradle has
# installed the pinned official Gradle distribution. The wrapper task creates
# the official scripts/JAR; no hand-written or fabricated wrapper JAR is used.
readonly GRADLE_VERSION="8.13"
readonly DISTRIBUTION_SHA256="20f1b1176237254a6fc204d8434196fa11a4cfb387567519c61556e8710aed78"
readonly WRAPPER_JAR_SHA256="81a82aaea5abcc8ff68b3dfcb58b3c3c429378efd98e7433460610fecd7ae45f"

command -v gradle >/dev/null 2>&1 || {
  echo "Gradle is not installed. Run gradle/actions/setup-gradle first." >&2
  exit 2
}

gradle --no-daemon wrapper \
  --gradle-version "$GRADLE_VERSION" \
  --distribution-type bin \
  --gradle-distribution-sha256-sum "$DISTRIBUTION_SHA256"

JAR="gradle/wrapper/gradle-wrapper.jar"
test -s "$JAR"
printf '%s  %s\n' "$WRAPPER_JAR_SHA256" "$JAR" | sha256sum --check --status || {
  echo "Generated Gradle Wrapper JAR does not match Gradle's published checksum." >&2
  exit 3
}

cat > gradle/wrapper/gradle-wrapper.jar.sha256 <<CHECKSUM
$WRAPPER_JAR_SHA256
CHECKSUM

grep -Fq "distributionSha256Sum=$DISTRIBUTION_SHA256" gradle/wrapper/gradle-wrapper.properties
chmod +x gradlew
./gradlew --version
