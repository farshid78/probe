#!/usr/bin/env python3
"""Validate the single canonical version source against app/docs/CI metadata."""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[2]
props = {}
for line in (ROOT / "version.properties").read_text(encoding="utf-8").splitlines():
    line = line.strip()
    if not line or line.startswith("#"):
        continue
    key, value = line.split("=", 1)
    props[key.strip()] = value.strip()

name = props.get("VERSION_NAME", "")
code_text = props.get("VERSION_CODE", "")
if not re.fullmatch(r"\d+\.\d+\.\d+", name):
    raise SystemExit("VERSION_NAME must be strict MAJOR.MINOR.PATCH")
if not code_text.isdigit():
    raise SystemExit("VERSION_CODE must be a positive integer")
code = int(code_text)
if not 1 <= code <= 2_100_000_000:
    raise SystemExit("VERSION_CODE is outside Android's supported positive range")

app = (ROOT / "app/build.gradle").read_text(encoding="utf-8")
root_build = (ROOT / "build.gradle").read_text(encoding="utf-8")
readme = (ROOT / "README.md").read_text(encoding="utf-8")
changelog = (ROOT / "CHANGELOG.md").read_text(encoding="utf-8")
workflow = (ROOT / ".github/workflows/android-build.yml").read_text(encoding="utf-8")
wrapper_props = (ROOT / "gradle/wrapper/gradle-wrapper.properties").read_text(encoding="utf-8")
wrapper_jar_sha = (ROOT / "gradle/wrapper/gradle-wrapper.jar.sha256").read_text(encoding="utf-8").strip()
scan_service = (ROOT / "app/src/main/java/app/bastehyab/ScanService.java").read_text(encoding="utf-8")

checks = {
    "app consumes canonical version.properties": "version.properties" in app and "versionName appVersionName" in app and "versionCode appVersionCode" in app,
    "diagnostic uses generated canonical BuildConfig value": "BuildConfig.APP_VERSION_NAME" in scan_service and "version 1.6.8" not in scan_service,
    "AGP is pinned to 8.13.2": "version '8.13.2'" in root_build,
    "compileSdk and targetSdk are 36": "compileSdk 36" in app and "targetSdk 36" in app,
    "README source badge matches canonical version": f"Source-{name}-" in readme and f"Source version {name}" in readme,
    "README Gradle badge matches wrapper": "Gradle-8.13-" in readme,
    "matching changelog section exists": re.search(rf"^## {re.escape(name)}(?:\s|$)", changelog, re.M) is not None,
    "workflow has no run-number-derived versionCode": "GITHUB_RUN_NUMBER * 100" not in workflow and "BH_VERSION_CODE" not in workflow,
    "workflow bootstraps and validates official wrapper": "tools/release/bootstrap-wrapper.sh" in workflow,
    "Gradle distribution checksum is pinned": "gradle-8.13-bin.zip" in wrapper_props and "20f1b1176237254a6fc204d8434196fa11a4cfb387567519c61556e8710aed78" in wrapper_props,
    "official Gradle 8.13 wrapper JAR checksum is pinned": wrapper_jar_sha == "81a82aaea5abcc8ff68b3dfcb58b3c3c429378efd98e7433460610fecd7ae45f",
    "R8 remains disabled pending dedicated tests": "minifyEnabled false" in app,
    "release is limited to version-matching tags or manual main dispatch": "refs/tags/v*" in workflow and "workflow_dispatch" in workflow and "RELEASE_VERSION_INPUT" in workflow and "needs.plan.outputs.publish" in workflow,
    "ordinary main pushes cannot trigger releases": not re.search(r'GITHUB_EVENT_NAME\s*==\s*"push"[^\n]*refs/heads/main', workflow),
    "plan reads canonical version.properties at repository root": "Read canonical version from repository root" in workflow and "sed -n 's/^VERSION_NAME=//p' version.properties" in workflow,
}
failed = [label for label, ok in checks.items() if not ok]
for label, ok in checks.items():
    print(("PASS" if ok else "FAIL") + "  " + label)
if failed:
    raise SystemExit(1)
print(f"Canonical release: versionName={name}, versionCode={code}")

if len(sys.argv) > 1:
    tag = sys.argv[1]
    if tag != f"v{name}":
        raise SystemExit(f"Tag {tag!r} does not match canonical version v{name}")
    print(f"PASS  tag {tag} matches canonical version")
