#!/usr/bin/env python3
"""Validate canonical app version, the single CI workflow, and release guardrails."""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[2]

# Parse a strict, single-source properties file. Duplicate keys are rejected.
props = {}
for number, raw in enumerate((ROOT / "version.properties").read_text(encoding="utf-8").splitlines(), 1):
    line = raw.strip()
    if not line or line.startswith("#"):
        continue
    if "=" not in line:
        raise SystemExit(f"Invalid version.properties line {number}: expected KEY=VALUE")
    key, value = line.split("=", 1)
    key, value = key.strip(), value.strip()
    if key in props:
        raise SystemExit(f"Duplicate key in version.properties: {key}")
    props[key] = value

name = props.get("VERSION_NAME", "")
code_text = props.get("VERSION_CODE", "")
if not re.fullmatch(r"\d+\.\d+\.\d+", name):
    raise SystemExit("VERSION_NAME must be strict MAJOR.MINOR.PATCH")
if not code_text.isdigit():
    raise SystemExit("VERSION_CODE must be a positive integer")
code = int(code_text)
if not 1 <= code <= 2_100_000_000:
    raise SystemExit("VERSION_CODE is outside Android's supported positive range")

app = (ROOT / "app/build.gradle").read_text(encoding="utf-8")
root_build = (ROOT / "build.gradle").read_text(encoding="utf-8")
readme = (ROOT / "README.md").read_text(encoding="utf-8")
changelog = (ROOT / "CHANGELOG.md").read_text(encoding="utf-8")
workflow_dir = ROOT / ".github/workflows"
workflow_files = sorted(p for p in workflow_dir.iterdir() if p.is_file() and p.suffix.lower() in {".yml", ".yaml"})
workflow_path = workflow_dir / "android-build.yml"
workflow = workflow_path.read_text(encoding="utf-8") if workflow_path.is_file() else ""
wrapper_props = (ROOT / "gradle/wrapper/gradle-wrapper.properties").read_text(encoding="utf-8")
wrapper_jar_sha = (ROOT / "gradle/wrapper/gradle-wrapper.jar.sha256").read_text(encoding="utf-8").strip()
scan_service = (ROOT / "app/src/main/java/app/bastehyab/ScanService.java").read_text(encoding="utf-8")

checks = {
    "exactly one workflow file exists and it is android-build.yml": len(workflow_files) == 1 and workflow_files[0].name == "android-build.yml",
    "app consumes canonical version.properties": "version.properties" in app and "versionName appVersionName" in app and "versionCode appVersionCode" in app,
    "diagnostic uses generated canonical BuildConfig value": "BuildConfig.APP_VERSION_NAME" in scan_service and "version 1.6.8" not in scan_service,
    "AGP is pinned to 8.13.2": "version '8.13.2'" in root_build,
    "compileSdk and targetSdk are 36": "compileSdk 36" in app and "targetSdk 36" in app,
    "README source badge matches canonical version": f"Source-{name}-" in readme and f"Source version {name}" in readme,
    "README Gradle badge matches wrapper": "Gradle-8.13-" in readme,
    "matching changelog section exists": re.search(rf"^## {re.escape(name)}(?:\s|$)", changelog, re.M) is not None,
    "CI does not synthesize versionCode from run number": "GITHUB_RUN_NUMBER * 100" not in workflow and "BH_VERSION_CODE" not in workflow,
    "runner OS is pinned for repeatable CI": workflow.count("runs-on: ubuntu-24.04") == 3,
    "all GitHub Actions references are pinned to commit SHAs": all(re.search(r"@[0-9a-f]{40}(?:\s|$)", line) for line in workflow.splitlines() if re.search(r"\buses:\s*", line)),
    "Temurin patch release is pinned": "java-version: '17.0.21+9'" in workflow,
    "Gradle bootstrap version is pinned": "gradle-version: '8.13'" in workflow,
    "version source is read from root version.properties": "sed -n 's/^VERSION_NAME=//p' version.properties" in workflow and "sed -n 's/^VERSION_CODE=//p' version.properties" in workflow,
    "all pushes are CI-only; release publish is manual dispatch only": "All pushes (including main and version tags) are CI-only. Publishing is manual-only." in workflow and "publish=true" in workflow,
    "manual publishing requires explicit confirmation": "confirm_release" in workflow and "Release confirmation checkbox must be enabled." in workflow,
    "manual publishing requires exact matching version tag": '"$GITHUB_REF" != "refs/tags/v$VERSION_NAME"' in workflow and '"$GITHUB_REF_NAME" != "v$VERSION_NAME"' in workflow,
    "release tag must point to main's tested commit": "git merge-base --is-ancestor \"$GITHUB_SHA\" origin/main" in workflow and "TAG_COMMIT" in workflow,
    "release is gated by approval environment": "environment:" in workflow and "name: release" in workflow,
    "versionCode exceeds external published baseline": "VERSION_CODE <= PUBLISHED_VERSION_CODE_BASELINE" in workflow,
    "versionCode exceeds previous GitHub release": "VERSION_CODE <= PREVIOUS_VERSION_CODE" in workflow,
    "release APK signature and alignment are verified": "apksigner" in workflow and "zipalign" in workflow,
    "upgrade install uses the previously signed APK": "adb -s emulator-5554 install -r" in workflow and "Previous release" in workflow,
    "secrets are explicitly masked": "::add-mask::$value" in workflow,
    "temporary signing material is cleaned on every job outcome": "if: always()" in workflow and 'rm -f "$GITHUB_WORKSPACE/keystore.properties"' in workflow and 'rm -f "$RUNNER_TEMP/bastehyab-release.jks"' in workflow,
    "Debug and Release APK paths are separate": "Bastehyab-Debug.apk" in workflow and "Bastehyab-Release.apk" in workflow,
    "test and lint reports are retained as artifacts": "app/build/reports/**" in workflow and "app/build/test-results/**" in workflow,
    "workflow builds checked-out source directly, not a nested ZIP": "git ls-files '*.zip'" not in workflow and "unzip -q" not in workflow,
    "official wrapper bootstrap and checksum verification are used": "tools/release/bootstrap-wrapper.sh" in workflow and "gradle-wrapper.jar.sha256" in workflow,
    "Gradle 8.13 distribution checksum is pinned": "gradle-8.13-bin.zip" in wrapper_props and "20f1b1176237254a6fc204d8434196fa11a4cfb387567519c61556e8710aed78" in wrapper_props,
    "official Gradle 8.13 wrapper JAR checksum is pinned": wrapper_jar_sha == "81a82aaea5abcc8ff68b3dfcb58b3c3c429378efd98e7433460610fecd7ae45f",
    "Wrapper bootstrap validates the downloaded JAR checksum": "sha256sum --check --status" in (ROOT / "tools/release/bootstrap-wrapper.sh").read_text(encoding="utf-8"),
}
failed = [label for label, ok in checks.items() if not ok]
for label, ok in checks.items():
    print(("PASS" if ok else "FAIL") + "  " + label)
if failed:
    raise SystemExit(1)
print(f"Canonical release: versionName={name}, versionCode={code}")

if len(sys.argv) > 1:
    tag = sys.argv[1]
    if tag != f"v{name}":
        raise SystemExit(f"Tag {tag!r} does not match canonical version v{name}")
    print(f"PASS  tag {tag} matches canonical version")
