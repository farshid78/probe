#!/usr/bin/env python3
"""Extract exactly one version section from CHANGELOG.md."""
from pathlib import Path
import re
import sys

if len(sys.argv) != 3:
    raise SystemExit("usage: generate-release-notes.py VERSION OUTPUT_FILE")
version, output = sys.argv[1], Path(sys.argv[2])
if not re.fullmatch(r"\d+\.\d+\.\d+", version):
    raise SystemExit("invalid semantic version")
text = Path("CHANGELOG.md").read_text(encoding="utf-8")
match = re.search(
    rf"^## {re.escape(version)}(?:[ \t][^\n]*)?\n(.*?)(?=^## \d+\.\d+\.\d+|\Z)",
    text, re.M | re.S,
)
if not match:
    raise SystemExit(f"CHANGELOG.md has no section for {version}")
body = match.group(1).strip()
if not body:
    raise SystemExit(f"CHANGELOG section {version} is empty")
output.write_text(f"# Bastehyab {version}\n\n{body}\n", encoding="utf-8")
print(f"Generated release notes for {version}: {output}")
