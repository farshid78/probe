#!/usr/bin/env python3
"""Structural regression checks for incremental Home refresh and async compare."""
from pathlib import Path

root = Path(__file__).resolve().parents[2]
main_path = root / "app/src/main/java/app/bastehyab/MainActivity.java"
store_path = root / "app/src/main/java/app/bastehyab/Store.java"
compare_path = root / "app/src/main/java/app/bastehyab/Compare.java"
popup_path = root / "app/src/main/java/app/bastehyab/Popup.java"
service_path = root / "app/src/main/java/app/bastehyab/ScanService.java"
main = main_path.read_text(encoding="utf-8")
store = store_path.read_text(encoding="utf-8")
compare = compare_path.read_text(encoding="utf-8")
popup = popup_path.read_text(encoding="utf-8")
service = service_path.read_text(encoding="utf-8")


def body(src: str, marker: str) -> str:
    start = src.index(marker)
    brace = src.index("{", start)
    depth = 0
    for i in range(brace, len(src)):
        if src[i] == "{":
            depth += 1
        elif src[i] == "}":
            depth -= 1
            if depth == 0:
                return src[brace + 1:i]
    raise AssertionError(f"unclosed method: {marker}")

live = body(main, "private final Runnable liveRefresh")
scan_update = body(main, "private void updateHomeScanUi()")
best_update = body(main, "private void updateHomeBest(")
home_request = body(main, "private void requestHomeData(boolean force)")
compare_request = body(main, "private void requestCompareData(boolean force)")
compare_apply = body(main, "private void applyCompareData(")
on_resume = body(main, "@Override protected void onResume()")
popup_ticks = body(popup, "private View ticks()")
popup_recalc = body(popup, "private void recalculateAsync()")
show_test = body(service, "void showTest()")
on_destroy_service = body(service, "@Override public void onDestroy()")
on_unbind_service = body(service, "@Override public boolean onUnbind(Intent i)")

assert "body.getChildCount() == 0" in on_resume and "requestCompareData(true)" in on_resume
assert "tab == 2" not in on_resume, "resume should not rebind Settings or discard in-progress inputs/dialogs"
assert "render(" not in live, "live ticker must not rebuild any page"
assert "removeAllViews" not in live and "removeAllViews" not in scan_update
assert "addView(" not in scan_update and "removeView" not in scan_update
assert "addView(" not in best_update and "removeView" not in best_update
assert "setTextIfChanged(" in scan_update and "setProgress(" in scan_update
assert "uiDataExecutor.execute" in home_request and "Store.snapshotState" in home_request
assert "Compare.run(app, snapshot.records" in home_request
assert "uiDataExecutor.execute" in compare_request and "Store.snapshotState" in compare_request
assert "Compare.run(app, snapshot.records" in compare_request
assert "compareRowViews" in compare_apply and "indexOfChild" in compare_apply
assert "static Snapshot snapshotState" in store
assert "run(Context c, List<Pkg> storeSnapshot" in compare
assert "@Override protected void onStop()" in main and "stopHomeTicker();" in body(main, "@Override protected void onPause()")
assert "uiDataExecutor.shutdown()" in body(main, "@Override protected void onDestroy()")
assert 'Trace.beginSection("BY.Home.LiveRefresh")' in scan_update
assert "Store.all(this)" not in main, "MainActivity must not use sync Store.all()"
# Other UI-triggered ranking entry points must not calculate on the main thread either.
assert "recalculateAsync()" in popup_ticks and "Compare.run(" not in popup_ticks
assert "rankWorker.execute" in popup_recalc and "Store.snapshotState" in popup_recalc
assert "Compare.run(c, snapshot.records" in popup_recalc
assert "worker.execute" in show_test and "Compare.run(this, snapshot.records" in show_test
assert "shutdown()" in on_destroy_service and "shutdown()" in on_unbind_service

# Five minutes / 1.5s interval is 200 updates. Source contract guarantees these are
# field-level updates and zero root rebuilds; this is structural, not a device timing claim.
ticks = (5 * 60 * 1000) // 1500
root_rebuilds_per_tick = 0
assert ticks == 200 and root_rebuilds_per_tick == 0
print("PASS: 200-tick/5-minute structural simulation; no live render/removeAllViews; stable Home fields; async Home/Compare/Popup ranking; keyed comparison-list diff; lifecycle worker/ticker cleanup.")
