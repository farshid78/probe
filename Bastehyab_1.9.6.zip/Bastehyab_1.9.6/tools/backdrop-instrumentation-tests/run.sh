#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
cd "$ROOT"
if ! command -v adb >/dev/null 2>&1; then
  echo "ERROR: adb is required; connect an Android device or start an emulator." >&2
  exit 2
fi
if ! command -v gradle >/dev/null 2>&1 && [ ! -x ./gradlew ]; then
  echo "ERROR: Gradle or the project Gradle wrapper is required." >&2
  exit 2
fi
if [ -x ./gradlew ]; then
  ./gradlew --no-daemon :app:connectedDebugAndroidTest
else
  gradle --no-daemon :app:connectedDebugAndroidTest
fi
