#!/usr/bin/env python3
"""Fast source guardrails; does not replace AppBackdropInstrumentationTest on Android."""
from pathlib import Path
import re

root = Path(__file__).resolve().parents[2]
splash = (root / "app/src/main/java/app/bastehyab/SplashViews.java").read_text(encoding="utf-8")
ui = (root / "app/src/main/java/app/bastehyab/UI.java").read_text(encoding="utf-8")
activity = (root / "app/src/main/java/app/bastehyab/MainActivity.java").read_text(encoding="utf-8")
manifest = (root / "app/src/main/AndroidManifest.xml").read_text(encoding="utf-8")

start = splash.index("@Override protected void onDraw(Canvas canvas)")
brace = splash.index("{", start)
depth = 0
end = None
for i in range(brace, len(splash)):
    if splash[i] == "{":
        depth += 1
    elif splash[i] == "}":
        depth -= 1
        if depth == 0:
            end = i + 1
            break
assert end is not None, "Could not find AppBackdrop.onDraw body"
on_draw = splash[start:end]
for bad in (r"\bnew\s+", r"Typeface\.create", r"BitmapFactory\.decode", r"new\s+(LinearGradient|RadialGradient|BitmapShader)"):
    assert not re.search(bad, on_draw), f"Allocation-heavy construct found inside onDraw: {bad}"

assert "FRAME_INVALIDATE_INTERVAL_MS = 33L" in splash, "Backdrop invalidation must be frame-throttled"
assert "reduceMotion" in splash and "batterySaverMode" in splash
assert "hostResumed" in splash and "onDetachedFromWindow" in splash and "onWindowVisibilityChanged" in splash
assert "removeAllUpdateListeners" in splash, "Destroy must release ValueAnimator callbacks"
assert 'getString("appearance", "auto")' in ui, "Auto must be the migration/default appearance"
assert "Configuration.UI_MODE_NIGHT_MASK" in ui, "Auto palette must inspect Android uiMode"
assert 'android:configChanges="uiMode"' in manifest
assert "onConfigurationChanged" in activity and "applySystemBars()" in activity
assert "connectedDebugAndroidTest" in (root / "tools/backdrop-instrumentation-tests/run.sh").read_text(encoding="utf-8")
print("PASS: source guardrails (no heavy onDraw allocations, throttled invalidation, system Auto, lifecycle and real instrumentation wiring)")
