# Backdrop instrumentation tests (real Android runtime)

The former local-JVM stub harness has been removed. The backdrop now has AndroidX instrumentation tests at:

`app/src/androidTest/java/app/bastehyab/AppBackdropInstrumentationTest.java`

Run against a physical Android device or emulator with the project's Android SDK installed:

```bash
bash tools/backdrop-instrumentation-tests/run.sh
```

The AndroidX `AndroidJUnitRunner` suite exercises a real `Activity`, attached/detached `View`, Android `ValueAnimator`, Android global animator duration scale, configuration-derived Auto theme, Reduce Motion, and Battery Saver policy. It also logs measured draw FPS and main-thread CPU percentage for animated and static modes under `BastehyabBackdropPerf`.

The tests are intentionally not replaced by hand-written `android.*` stubs. This repository snapshot does not include a device/emulator; execution must occur on a connected device or emulator. Results are emitted in Gradle's connectedAndroidTest report and Logcat.
