package app.bastehyab;

/** Regression coverage for conservative three-state end-of-list detection. */
public final class ListEndDetectorTest {
    private static void check(boolean ok, String message) {
        if (!ok) throw new AssertionError(message);
    }

    public static void main(String[] args) {
        ListEndDetector detector = new ListEndDetector();
        check(detector.state() == ListEndDetector.State.UNKNOWN, "initial state must be unknown");

        check(detector.observe(100, 1000, false, false, 1) == ListEndDetector.State.MORE_AVAILABLE,
                "not-at-bottom means more content may exist");
        check(detector.observe(1000, 1000, true, false, 2) == ListEndDetector.State.MORE_AVAILABLE,
                "load-more indicator prevents end confirmation");
        check(detector.observe(1000, 1000, false, true, 3) == ListEndDetector.State.UNKNOWN,
                "a first bottom observation is only a candidate");
        check(detector.observe(1000, 1000, false, false, 3) == ListEndDetector.State.UNKNOWN,
                "duplicate cycle cannot satisfy independent-observation requirement");
        check(detector.observe(1000, 1000, false, false, 4) == ListEndDetector.State.END_CONFIRMED,
                "two independent bottom observations confirm end");

        check(detector.observe(500, 1000, false, false, 6) == ListEndDetector.State.MORE_AVAILABLE,
                "moving away from bottom resets end proof");
        check(detector.observe(0, 0, false, false, 7) == ListEndDetector.State.UNKNOWN,
                "missing scroll range must remain unknown");
        detector.reset();
        check(detector.state() == ListEndDetector.State.UNKNOWN, "reset returns to unknown");
        check(detector.observe(-1, 0, -1, -1, false, true, 8) == ListEndDetector.State.UNKNOWN,
                "events without source-backed metrics must remain unknown");
        check(detector.observe(-1, 0, -1, -1, false, false, 9) == ListEndDetector.State.UNKNOWN,
                "a second metric-less cycle must not confirm end");

        check(detector.observe(900, 1000, 12, 9, false, false, 10)
                == ListEndDetector.State.MORE_AVAILABLE,
                "a visible item index before the last item means more content remains");
        check(detector.observe(1000, 1000, 12, 11, false, false, 11)
                == ListEndDetector.State.UNKNOWN,
                "first independent bottom observation is not enough");
        check(detector.observe(1000, 1000, 12, 11, false, false, 12)
                == ListEndDetector.State.END_CONFIRMED,
                "scroll offsets and last visible item together confirm the end after two cycles");

        detector.reset();
        check(detector.observeStableViewport("cards-A", false, true, 20) == ListEndDetector.State.UNKNOWN,
                "first stable viewport is a candidate only");
        check(detector.observeStableViewport("cards-A", false, true, 20) == ListEndDetector.State.UNKNOWN,
                "duplicate viewport cycle cannot confirm end");
        check(detector.observeStableViewport("cards-A", false, true, 21) == ListEndDetector.State.END_CONFIRMED,
                "two complete stable viewports after gesture escalation confirm end for providers without offsets");

        detector.reset();
        check(detector.observeStableViewport("cards-A", false, false, 30) == ListEndDetector.State.UNKNOWN,
                "an incomplete accessibility tree cannot prove the end");
        check(detector.observeStableViewport("cards-B", true, true, 31) == ListEndDetector.State.MORE_AVAILABLE,
                "visible pagination control prevents end confirmation");

        detector.reset();
        check(detector.observe(1000, 1000, 12, 11, false, false, 40,
                "container-A", 7L, true, 10000L, 10500L) == ListEndDetector.State.UNKNOWN,
                "first fresh vertical bottom observation is only a candidate");
        check(detector.observe(1000, 1000, 12, 11, false, false, 40,
                "container-A", 7L, true, 10000L, 10500L) == ListEndDetector.State.UNKNOWN,
                "duplicate scan cycle cannot confirm end");
        check(detector.observe(1000, 1000, 12, 11, false, false, 41,
                "container-B", 7L, true, 10010L, 10510L) == ListEndDetector.State.UNKNOWN,
                "changing scroll container resets bottom proof");
        check(detector.observe(1000, 1000, 12, 11, false, false, 42,
                "container-B", 8L, true, 10020L, 10520L) == ListEndDetector.State.UNKNOWN,
                "changing scan session resets bottom proof");
        check(detector.observe(1000, 1000, 12, 11, false, false, 43,
                "container-B", 8L, false, 10030L, 10530L) == ListEndDetector.State.UNKNOWN,
                "horizontal/non-vertical evidence cannot prove list end");
        check(detector.observe(1000, 1000, 12, 11, false, false, 44,
                "container-B", 8L, true, 10000L, 13000L) == ListEndDetector.State.UNKNOWN,
                "stale scroll event cannot prove list end");
        check(detector.observe(1000, 1000, 12, 11, false, false, 45,
                "container-B", 8L, true, 10040L, 10540L) == ListEndDetector.State.UNKNOWN,
                "fresh evidence after invalidation is only a candidate");
        check(detector.observe(1000, 1000, 12, 11, false, false, 46,
                "container-B", 8L, true, 10050L, 10550L) == ListEndDetector.State.END_CONFIRMED,
                "two fresh vertical observations in the same session/container confirm end");

        detector.reset();
        check(detector.observeStableViewport("same", false, true, 50,
                "container-A", 1L, true) == ListEndDetector.State.UNKNOWN,
                "stable viewport starts with one scoped observation");
        check(detector.observeStableViewport("same", false, true, 51,
                "container-A", 2L, true) == ListEndDetector.State.UNKNOWN,
                "session change resets stable viewport proof");
        check(detector.observeStableViewport("same", false, true, 52,
                "container-A", 2L, true) == ListEndDetector.State.END_CONFIRMED,
                "two stable viewports in same scope and session confirm end");

        // There is deliberately no operator-specific stable-offer shortcut anymore.
        // Every provider must complete through the same bottom/viewport proof above.
        System.out.println("ListEndDetectorTest: PASS");
    }
}
