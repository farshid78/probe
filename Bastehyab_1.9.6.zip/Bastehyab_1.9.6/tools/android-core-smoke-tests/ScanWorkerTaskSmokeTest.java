package app.bastehyab;

import java.util.ArrayDeque;
import java.util.Queue;
import java.util.concurrent.RejectedExecutionException;

/** Standalone javac smoke test for one-shot worker completion and rejection. */
public final class ScanWorkerTaskSmokeTest {
    private static final class Poster implements ScanWorkerTask.Poster {
        final Queue<Runnable> pending = new ArrayDeque<>();
        public void post(Runnable r) { pending.add(r); }
        void drain() { while (!pending.isEmpty()) pending.remove().run(); }
    }
    public static void main(String[] args) {
        Poster poster = new Poster();
        final int[] calls = {0};
        final Throwable[] failure = {null};
        ScanWorkerTask<String> failed = new ScanWorkerTask<>(() -> { throw new IllegalStateException("private text not logged"); },
                poster, (value, error) -> { calls[0]++; failure[0] = error; });
        failed.run();
        failed.reject(new RejectedExecutionException("late reject"));
        poster.drain();
        if (calls[0] != 1 || !(failure[0] instanceof IllegalStateException)) throw new AssertionError("exception completion not exactly once");

        calls[0] = 0; failure[0] = null;
        ScanWorkerTask<String> rejected = new ScanWorkerTask<>(() -> "must-not-run", poster,
                (value, error) -> { calls[0]++; failure[0] = error; });
        rejected.reject(new RejectedExecutionException("executor closed"));
        rejected.run();
        poster.drain();
        if (calls[0] != 1 || !(failure[0] instanceof RejectedExecutionException)) throw new AssertionError("rejection completion not exactly once");

        final String[] value = {null};
        ScanWorkerTask<String> successful = new ScanWorkerTask<>(() -> "ok", poster,
                (result, error) -> { if (error != null) throw new AssertionError(error); value[0] = result; });
        successful.run(); successful.run(); poster.drain();
        if (!"ok".equals(value[0])) throw new AssertionError("success result lost");
        System.out.println("PASS: worker success, exception, executor rejection and exactly-once completion.");
    }
}
