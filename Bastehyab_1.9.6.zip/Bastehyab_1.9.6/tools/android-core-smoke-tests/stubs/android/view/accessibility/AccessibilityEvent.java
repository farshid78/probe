package android.view.accessibility;
public class AccessibilityEvent {
 private AccessibilityNodeInfo source; private long eventTime=System.currentTimeMillis(); private String packageName="test.operator"; private int eventType;
 public AccessibilityEvent source(AccessibilityNodeInfo n){source=n;return this;} public AccessibilityEvent eventTime(long t){eventTime=t;return this;} public AccessibilityEvent packageName(String p){packageName=p;return this;} public AccessibilityEvent eventType(int t){eventType=t;return this;}
 public AccessibilityNodeInfo getSource(){return source;} public long getEventTime(){return eventTime;}
 public static final int TYPE_WINDOW_STATE_CHANGED=32, TYPE_VIEW_SCROLLED=4096; public CharSequence getPackageName(){return packageName;} public int getEventType(){return eventType;} public int getScrollY(){return 0;} public int getMaxScrollY(){return 0;} public int getItemCount(){return 0;} public int getToIndex(){return -1;}
}
