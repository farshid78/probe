package android.content;
public interface SharedPreferences {
    String getString(String key, String fallback);
    int getInt(String key, int fallback);
    float getFloat(String key, float fallback);
    boolean getBoolean(String key, boolean fallback);
    Editor edit();
    interface Editor {
        Editor putString(String key, String value);
        Editor putInt(String key, int value);
        Editor putFloat(String key, float value);
        Editor putBoolean(String key, boolean value);
        Editor remove(String key);
        void apply();
        boolean commit();
    }
}
