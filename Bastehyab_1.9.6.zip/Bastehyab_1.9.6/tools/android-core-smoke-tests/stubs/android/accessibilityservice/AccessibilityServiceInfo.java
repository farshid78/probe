package android.accessibilityservice;
public class AccessibilityServiceInfo { public String[] packageNames; public int eventTypes; public int feedbackType; public int flags; public long notificationTimeout; }
