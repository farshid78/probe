package app.bastehyab;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.List;

/** Exercises the production HistoryLog against the same in-memory Android preference doubles. */
public final class HistoryLogSmokeTest {
    private static void ok(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }

    private static Pkg pkg(String op, String key, String title) {
        Pkg p = new Pkg();
        p.op = op; p.key = key; p.title = title;
        p.gb = 5; p.days = 30; p.toman = 100000;
        p.currencyKnown = true; p.ts = 1234L;
        return p;
    }

    public static void main(String[] args) throws Exception {
        Context context = new Context();
        SharedPreferences preferences = Cfg.sp(context);
        HistoryLog.clear(context);
        HistoryLog.clearError(context);

        // Price history keeps the operator/package identity and sanitizes labels.
        Pkg oldPrice = pkg("irancell", "pkg-001", "بسته\u202E اینترنت ۵ گیگ");
        Pkg newPrice = oldPrice.copy();
        newPrice.toman = 110000L;
        newPrice.ts = 1235L;
        HistoryLog.record(context, oldPrice, newPrice);
        List<HistoryLog.Entry> changes = HistoryLog.recent(context, 10);
        ok(changes.size() == 1, "price change should create exactly one history row");
        HistoryLog.Entry price = changes.get(0);
        ok("irancell".equals(price.operatorId) && "pkg-001".equals(price.packageKey),
                "price history must retain operator and package identity");
        ok(!price.title.contains("\u202E"), "history title must strip bidi override controls");
        ok("price".equals(price.field) && price.before == 100000d && price.after == 110000d,
                "price change values were not retained");

        // Review notes can contain arbitrary user-entered text and must never be persisted.
        Pkg reviewed = pkg("samantel", "sam-36gb-180d", "بسته ۳۶ گیگ");
        reviewed.reviewedToman = 360275L;
        reviewed.reviewedAt = 2000L;
        reviewed.reviewNote = "PRIVATE_REVIEW_NOTE_DO_NOT_STORE";
        HistoryLog.recordReview(context, reviewed, true);
        List<HistoryLog.Entry> afterReview = HistoryLog.recent(context, 10);
        ok(afterReview.size() == 2, "review event should be appended");
        ok(afterReview.get(0).note.isEmpty(), "review note must not be exposed in history entries");
        ok("samantel".equals(afterReview.get(0).operatorId)
                        && "sam-36gb-180d".equals(afterReview.get(0).packageKey),
                "review history must retain operator and package identity");
        JSONArray saved = new JSONArray(preferences.getString("history", "[]"));
        JSONObject last = saved.getJSONObject(saved.length() - 1);
        ok(!last.has("reviewNote") && !last.has("note"),
                "free-form review note must not exist in persisted history JSON");

        // Invalid rows are isolated while the valid row remains readable.
        JSONArray mixed = new JSONArray();
        mixed.put(new JSONObject().put("field", "price").put("before", 1)
                .put("after", 2).put("ts", 1).put("title", "valid"));
        mixed.put(new JSONObject().put("field", "").put("before", 1)
                .put("after", 2).put("ts", 2).put("title", "invalid"));
        preferences.edit().putString("history", mixed.toString()).commit();
        List<HistoryLog.Entry> mixedRows = HistoryLog.recent(context, 10);
        ok(mixedRows.size() == 1 && "valid".equals(mixedRows.get(0).title),
                "invalid history row should not hide a healthy history row");

        // A corrupt document must be preserved byte-for-byte; record must fail closed.
        String corrupt = "{not-a-valid-history-document";
        preferences.edit().putString("history", corrupt).commit();
        HistoryLog.recordReview(context, reviewed, false);
        ok(corrupt.equals(preferences.getString("history", "")),
                "corrupt history must not be overwritten by a new event");
        ok(HistoryLog.hasError(context)
                        && HistoryLog.errorSummary(context).contains("JSON_CORRUPT_PRESERVED"),
                "corrupt history must set a privacy-safe diagnostic code");

        // The bounded log keeps only the newest 300 rows.
        HistoryLog.clear(context);
        HistoryLog.clearError(context);
        for (int i = 1; i <= 305; i++) {
            Pkg event = pkg("rightel", "r-" + i, "بسته " + i);
            event.reviewedToman = 100000L + i;
            event.reviewedAt = i;
            HistoryLog.recordReview(context, event, true);
        }
        List<HistoryLog.Entry> bounded = HistoryLog.recent(context, 400);
        ok(bounded.size() == 300, "history must retain no more than 300 events");
        ok(bounded.get(0).ts == 305L && bounded.get(299).ts == 6L,
                "history retention must preserve the newest events in newest-first order");

        HistoryLog.clear(context);
        ok(HistoryLog.recent(context, 400).isEmpty(), "clear must synchronously remove history");
        HistoryLog.clearError(context);
        ok(!HistoryLog.hasError(context), "clearError must clear the error indicator");
        System.out.println("PASS: production HistoryLog identity, sanitization, review-note privacy, corrupt preservation, invalid-row isolation, 300-row bound and clear/commit");
    }
}
