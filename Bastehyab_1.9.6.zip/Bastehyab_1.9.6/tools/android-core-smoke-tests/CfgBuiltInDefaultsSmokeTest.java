package app.bastehyab;

/** Verifies that built-in operators share canonical parser settings while custom profiles stay intact. */
public final class CfgBuiltInDefaultsSmokeTest {
    public static void main(String[] args) {
        Op irancell = new Op("irancell", "ایرانسل", 1, "IRR", true, "old.irancell");
        irancell.policy = 1;
        Op irancellDefaults = new Op("irancell", "ایرانسل", 1, "AUTO", true, "com.myirancell");
        Cfg.applyBuiltInDefaults(irancell, irancellDefaults);

        Op mci = new Op("mci", "همراه اول", 2, "IRT", true, "old.mci");
        mci.policy = 2;
        Op mciDefaults = new Op("mci", "همراه اول", 2, "AUTO", true, "ir.mci.ecareapp");
        Cfg.applyBuiltInDefaults(mci, mciDefaults);

        check("AUTO".equals(irancell.cur) && irancell.policy == 0, "Irancell canonical parser profile");
        check("AUTO".equals(mci.cur) && mci.policy == 0, "MCI canonical parser profile");
        check(irancell.pkgs.size() == 1 && irancell.pkgs.contains("com.myirancell"), "Irancell target package");
        check(mci.pkgs.size() == 1 && mci.pkgs.contains("ir.mci.ecareapp"), "MCI target package");

        Op custom = new Op("custom", "سفارشی", 3, "IRT", false, "ir.custom.app");
        custom.policy = 2;
        Cfg.applyBuiltInDefaults(custom, new Op("custom", "سفارشی", 3, "AUTO", true, "ir.other.app"));
        check("IRT".equals(custom.cur) && custom.policy == 2
                && custom.pkgs.contains("ir.custom.app"), "custom profile remains unchanged");
        System.out.println("PASS: canonical built-in parser defaults shared by Irancell/MCI; custom profile preserved.");
    }

    private static void check(boolean condition, String label) {
        if (!condition) throw new AssertionError(label);
    }
}
