#!/usr/bin/env python3
from pathlib import Path
root = Path(__file__).resolve().parents[2]
main = (root/'app/src/main/java/app/bastehyab/MainActivity.java').read_text()
ui = (root/'app/src/main/java/app/bastehyab/UI.java').read_text()
popup = (root/'app/src/main/java/app/bastehyab/Popup.java').read_text()
manifest = (root/'app/src/main/AndroidManifest.xml').read_text()
checks = {
    'save live scroll position at instance-state boundary': 'sv.getScrollY()' in main and 'onSaveInstanceState(Bundle out)' in main,
    'restore selected tab and per-tab scroll offsets': 'state.tab' in main and 'state.scroll.' in main and 'screenScroll.scrollTo(0, y)' in main,
    'activity explicitly supports resizable multi-window': 'android:resizeableActivity="true"' in manifest,
    'dialog content has a bounded scroll container': 'BoundedScrollView sv = boundedScroll(c, maxBodyHeight)' in ui,
    'dialog action buttons stack for narrow/large text': 'fontScale >= 1.15f' in ui and 'verticalActions' in ui,
    'long privacy disclosure uses the shared dialog': 'new UI.Dlg(this).title("توضیح مستقل دسترسی و حریم خصوصی")' in main and 'new AlertDialog.Builder' not in main,
    'floating comparison content is vertically scrollable': 'popupScroll = UI.boundedScroll(c, maxOverlayHeight(windowMetrics))' in popup,
    'floating scan controls are vertically scrollable': 'ScrollView confirmScroll = UI.boundedScroll(c, overlayMaxHeight)' in popup,
    'floating windows clamp width to current viewport': 'dm.widthPixels - UI.dp(c, 24)' in popup,
    'floating windows clamp vertical offsets': 'maxOffsetY' in popup and 'maxOverlayHeight(dm)' in popup,
    'floating comparison preserves scroll after rerender': 'oldScrollY' in popup and 'popupScroll.scrollTo(0' in popup,
    'popup rebuilds when orientation/window/font scale changes': 'confirmWindowFontScale' in popup and 'confirmWindowWidth' in popup and 'confirmWindowHeight' in popup and 'viewportChanged' in popup,
    'RTL is explicit for screen and popup roots': 'screenScroll.setLayoutDirection(View.LAYOUT_DIRECTION_RTL)' in main and 'popupContent.setLayoutDirection(View.LAYOUT_DIRECTION_RTL)' in popup,
    'edge-to-edge insets are consumed only on Android 15+': 'Build.VERSION.SDK_INT < 35 || outer == null' in main and 'WindowInsets.Type.systemBars()' in main,
}
failed = [name for name, ok in checks.items() if not ok]
for name, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ': ' + name)
if failed:
    raise SystemExit(1)
print(f'PASS: {len(checks)} responsive source guardrails')
