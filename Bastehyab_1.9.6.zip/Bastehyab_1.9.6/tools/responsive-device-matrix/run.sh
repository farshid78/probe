#!/usr/bin/env bash
# Captures real-device screenshots for each attached API 24-36 device.
# Requires: adb, installed app.bastehyab, and a debuggable device/emulator.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
OUT="${1:-$ROOT/build/responsive-screenshots}"
PKG="app.bastehyab"
mkdir -p "$OUT"
mapfile -t SERIALS < <(adb devices | awk 'NR>1 && $2=="device" {print $1}')
if ((${#SERIALS[@]} == 0)); then
  echo "ERROR: No authorized Android device/emulator is connected." >&2
  exit 2
fi
for serial in "${SERIALS[@]}"; do
  api="$(adb -s "$serial" shell getprop ro.build.version.sdk | tr -d '\r')"
  if [[ ! "$api" =~ ^[0-9]+$ ]] || ((api < 24 || api > 36)); then
    echo "SKIP $serial: API '$api' is outside supported test range 24..36"; continue
  fi
  safe="$(printf '%s' "$serial" | tr ':/' '__')"
  original_size="$(adb -s "$serial" shell wm size | tr -d '\r' | grep 'Override size:' | sed -n 's/.*: //p')"
  original_density="$(adb -s "$serial" shell wm density | tr -d '\r' | grep 'Override density:' | sed -n 's/.*: //p')"
  original_font="$(adb -s "$serial" shell settings get system font_scale | tr -d '\r')"
  original_rotation="$(adb -s "$serial" shell settings get system user_rotation | tr -d '\r')"
  original_accel="$(adb -s "$serial" shell settings get system accelerometer_rotation | tr -d '\r')"
  restore() {
    if [[ -n "$original_size" ]]; then adb -s "$serial" shell wm size "$original_size" >/dev/null 2>&1 || true; else adb -s "$serial" shell wm size reset >/dev/null 2>&1 || true; fi
    if [[ -n "$original_density" ]]; then adb -s "$serial" shell wm density "$original_density" >/dev/null 2>&1 || true; else adb -s "$serial" shell wm density reset >/dev/null 2>&1 || true; fi
    [[ -z "$original_font" || "$original_font" == "null" ]] || adb -s "$serial" shell settings put system font_scale "$original_font" >/dev/null 2>&1 || true
    [[ -z "$original_rotation" || "$original_rotation" == "null" ]] || adb -s "$serial" shell settings put system user_rotation "$original_rotation" >/dev/null 2>&1 || true
    [[ -z "$original_accel" || "$original_accel" == "null" ]] || adb -s "$serial" shell settings put system accelerometer_rotation "$original_accel" >/dev/null 2>&1 || true
  }
  trap restore EXIT
  # Force 160 dpi so each test pixel corresponds to one dp; preserve original values on exit.
  adb -s "$serial" shell wm density 160 >/dev/null
  adb -s "$serial" shell settings put system accelerometer_rotation 0
  for width in 320 360 393 480 600 800; do
    for orientation in portrait landscape; do
      if [[ "$orientation" == portrait ]]; then
        height=$((width * 16 / 9)); rotation=0
      else
        height=$((width * 3 / 4)); rotation=1
      fi
      adb -s "$serial" shell settings put system user_rotation "$rotation"
      if [[ "$orientation" == portrait ]]; then
        adb -s "$serial" shell wm size "${width}x${height}" >/dev/null
      else
        # wm size is rotation-neutral: reverse the override so logical landscape width is $width dp.
        adb -s "$serial" shell wm size "${height}x${width}" >/dev/null
      fi
      for font in 1.0 2.0; do
        adb -s "$serial" shell settings put system font_scale "$font"
        adb -s "$serial" shell am force-stop "$PKG" >/dev/null 2>&1 || true
        adb -s "$serial" shell monkey -p "$PKG" 1 >/dev/null 2>&1
        sleep 2
        file="$OUT/${safe}_api${api}_${width}dp_${orientation}_font${font}.png"
        adb -s "$serial" exec-out screencap -p > "$file"
        echo "CAPTURED $file"
      done
      # If the AndroidX test APK is installed (CI installs it via connectedAndroidTest),
      # capture every Activity page and the long dialog at both font scales for this viewport.
      if adb -s "$serial" shell pm list instrumentation | grep -q 'app.bastehyab.test/androidx.test.runner.AndroidJUnitRunner'; then
        adb -s "$serial" shell am instrument -w -e class app.bastehyab.ResponsiveScreenshotInstrumentationTest \
          app.bastehyab.test/androidx.test.runner.AndroidJUnitRunner >/dev/null
        page_dir="$OUT/${safe}_api${api}_${width}dp_${orientation}_pages"
        mkdir -p "$page_dir"
        adb -s "$serial" pull /sdcard/Android/data/app.bastehyab/files/responsive-screenshots "$page_dir" >/dev/null
        echo "CAPTURED all Activity pages and privacy Dialog for ${width}dp ${orientation} (fonts 100%/200%)"
      else
        echo "INFO $serial: AndroidX test APK not installed; page screenshots require connectedDebugAndroidTest first."
      fi
    done
  done
  # Attempt a freeform/split-window launch where the system image supports it.
  adb -s "$serial" shell settings put system font_scale 2.0
  adb -s "$serial" shell am force-stop "$PKG" >/dev/null 2>&1 || true
  if adb -s "$serial" shell am start --windowingMode 5 -n "$PKG/.MainActivity" >/dev/null 2>&1; then
    sleep 2
    file="$OUT/${safe}_api${api}_multiwindow_font2.png"
    adb -s "$serial" exec-out screencap -p > "$file"
    echo "CAPTURED $file"
  else
    echo "INFO $serial: multi-window launch mode unsupported; test split-screen manually on this device."
  fi
  restore
  trap - EXIT
  echo "DONE $serial (API $api)"
done
