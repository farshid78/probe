# Bastehyab 1.9.6 – follow-up fixes and audit

## Applied in this source package

- Kept the earlier accessibility-overlay focus fix and transient active-root retry.
- Reduced the floating scan panel height cap to 48% of display height (maximum 360dp).
- Reduced the scan-control panel width cap to 360dp.
- Reduced shared card padding/radius and chip padding in the UI helper.
- Added up to three bounded retries when an adaptive scroll request is not accepted. A failed scroll is never reported as a confirmed end-of-list.
- Updated review copy to clarify that packages with reliable extracted price/metadata are compared automatically; only ambiguous/conflicting records remain outside the definitive ranking.

## Important behavior and safety boundary

The comparison engine intentionally does not rank a package when its currency, tax treatment, identity, or classification is unresolved. Automatically approving such a record would risk comparing a Rial amount as Toman, using a pre-tax amount as a final price, or merging two different offers. The current parser already auto-compares records that pass its evidence checks; the review queue is for records that fail those checks.

## Irancell-specific diagnosis still requiring live evidence

The repository's operator fixture catalog marks Irancell as `NOT_CAPTURED` and `certified: false`. There is no sanitized live accessibility-tree fixture for the current Irancell app screen. Therefore the exact Irancell parser mismatch cannot be proven from this source archive alone. No operator-specific currency or parser assumption was introduced without evidence.

To finish that part safely, capture a sanitized accessibility fixture from the Irancell offers list (with phone/account identifiers, notifications, tokens and personal text removed), plus the new Bastehyab diagnostic after one failed scan. Do not send screenshots containing account or personal information.

## Checks run

Passed:
- `tools/android-core-smoke-tests/run.sh`
- `tools/parser-smoke-tests/run.sh`
- `tools/store-smoke-tests/run.sh`
- `tools/popup-overlay-smoke-tests/run.sh`
- `tools/ui-layout-smoke-tests/run.sh`

The popup/UI test scripts printed a non-fatal spreadsheet-runtime warmup traceback, but each script exited 0 and its own assertions reported PASS.

A full Android APK build and real-device operator test were not run in this environment.
