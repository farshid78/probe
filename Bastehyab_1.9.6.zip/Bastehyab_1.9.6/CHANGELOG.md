# تغییرات بسته‌یاب

## 1.9.6

- پنجره‌های مقایسه و کنترل اسکن شناور به ScrollView با ارتفاع محدود به viewport مجهز شدند؛ متن طولانی و فونت ۲۰۰٪ قابل پیمایش می‌ماند.
- عرض و مختصات پنجره‌های شناور با ابعاد جاری صفحه محدود می‌شود و در چرخش، تغییر اندازه و تغییر مقیاس فونت دوباره محاسبه می‌شود.
- موقعیت اسکرول صفحهٔ فعال درست در مرز `onSaveInstanceState` ذخیره می‌شود تا بازسازی Activity موقعیت کاربر را از دست ندهد.
- توضیح حریم خصوصی از AlertDialog پیش‌فرض به Dialog مشترک و اسکرول‌پذیر منتقل شد؛ Activity نیز صریحاً برای پنجرهٔ چندوظیفه‌ای قابل تغییر اندازه است.
- آزمون Instrumentation برای ثبت تصویر Splash، خانه، مقایسه، تنظیمات و Dialog در فونت ۱۰۰٪ و ۲۰۰٪ اضافه شد؛ ابزار ماتریس ADB اندازه‌های ۳۲۰، ۳۶۰، ۳۹۳، ۴۸۰، ۶۰۰ و ۸۰۰dp را در حالت عمودی/افقی ثبت می‌کند.

- تست JVM `classifiesSpecialAndInternationalLabels` با ترتیب واقعی تشخیص برچسب بین‌الملل/رومینگ در production همسان شد؛ CI دیگر به‌خاطر این تست fail نمی‌شود.
- تنظیمات parser تمام اپراتورهای داخلی در مهاجرت نسخه‌ای از یک پروفایل canonical پیروی می‌کند؛ استثنای تنظیماتی فقط برای ایرانسل حذف شد و اپراتورهای سفارشی حفظ می‌شوند.
- تست رگرسیون برای یکسان‌سازی تنظیم currency/policy و حفظ تنظیمات اپراتور سفارشی اضافه شد.


## 1.9.1

- مسیر نسخه canonical در `version.properties` نگه داشته می‌شود و release metadata از همان فایل خوانده می‌شود.
- مسیر worker اسکن completion یکتا دارد؛ exception و executor rejection در callback مالک state تحویل می‌شوند و retry خطای متوالی محدود است.
- جمع‌آوری diagnostic به داده‌های ساختاری و شمارنده‌ها محدود شد؛ raw Accessibility dump و متن اعلان/صفحه در `diag.txt` ذخیره نمی‌شود.
- مسیر انتشار CI فقط برای tag منطبق با نسخه یا `workflow_dispatch` از `main` فعال است؛ push عادی به `main` صرفاً build/test انجام می‌دهد.
- ساخت AVD در CI به `ANDROID_USER_HOME`، `ANDROID_SDK_HOME` و `ANDROID_AVD_HOME` صریح، بررسی فایل‌های AVD، نصب libpulse و کشف مسیر کتابخانه‌های emulator مجهز شد.
- تست‌های JVM قیمت، هویت، تاریخچه، استخراج helperها و تست‌های Robolectric برای Compare/Config migration/Store parser اضافه شدند.
- گزارش‌های JUnit، lint و coverage در CI به‌صورت artifact منتشر می‌شوند.
- fixture catalog پنج اپراتور به‌صورت `NOT_CAPTURED` ساخته شد؛ هیچ app version یا package count زنده حدس زده نشده و هیچ اپراتوری certified نیست.
- تصاویر مرجع و preview طراحی از پوشهٔ branding به `design/references/` منتقل شدند. دارایی‌های runtime دست‌نخورده باقی ماندند.

**محدودیت اعتبارسنجی:** در محیط ویرایش، Gradle، Android SDK و adb در دسترس نبودند؛ در نتیجه build، تست JVM تحت Gradle، lint و instrumentation روی emulator اجرا نشده‌اند. اجرای smokeهای مستقل که در گزارش تحویل مشخص می‌شود، معادل build یا device certification نیست.
