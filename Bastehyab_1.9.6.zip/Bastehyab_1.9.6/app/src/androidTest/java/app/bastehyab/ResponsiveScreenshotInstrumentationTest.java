package app.bastehyab;

import android.app.UiAutomation;
import android.content.Context;
import android.graphics.Bitmap;
import android.os.Build;
import android.os.SystemClock;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import androidx.test.core.app.ActivityScenario;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import java.io.File;
import java.io.FileOutputStream;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Locale;
import org.junit.Test;
import org.junit.runner.RunWith;
import static org.junit.Assert.*;

/** Captures real Android screenshots for every Activity page and the long disclosure dialog. */
@RunWith(AndroidJUnit4.class)
public final class ResponsiveScreenshotInstrumentationTest {
    @Test public void captureAllActivityPagesAtDefaultAnd200PercentFontScale() throws Exception {
        Context target = InstrumentationRegistry.getInstrumentation().getTargetContext();
        String previousScale = android.provider.Settings.System.getString(
                target.getContentResolver(), android.provider.Settings.System.FONT_SCALE);
        File output = target.getExternalFilesDir("responsive-screenshots");
        assertNotNull("External app files directory must be available for screenshot artifacts", output);
        assertTrue(output.exists() || output.mkdirs());
        File[] oldCaptures = output.listFiles((dir, name) -> name.endsWith(".png"));
        if (oldCaptures != null) for (File old : oldCaptures) assertTrue("Could not clear stale screenshot", old.delete());
        try {
            for (String scale : new String[]{"1.0", "2.0"}) {
                InstrumentationRegistry.getInstrumentation().getUiAutomation()
                        .executeShellCommand("settings put system font_scale " + scale).close();
                SystemClock.sleep(900L);
                try (ActivityScenario<MainActivity> scenario = ActivityScenario.launch(MainActivity.class)) {
                    scenario.onActivity(host -> {
                        try { invoke(host, "enterApp"); }
                        catch (Exception error) { throw new AssertionError(error); }
                    });
                    SystemClock.sleep(350L);
                    InstrumentationRegistry.getInstrumentation().waitForIdleSync();
                    capture(target, output, "splash", scale);

                    for (int tab = 0; tab < 3; tab++) {
                        final int selected = tab;
                        scenario.onActivity(host -> {
                            try {
                                Field tabField = MainActivity.class.getDeclaredField("tab");
                                tabField.setAccessible(true);
                                tabField.setInt(host, selected);
                                invoke(host, "render");
                            } catch (Exception error) { throw new AssertionError(error); }
                        });
                        InstrumentationRegistry.getInstrumentation().waitForIdleSync();
                        scenario.onActivity(ResponsiveScreenshotInstrumentationTest::assertNavigationDoesNotOverlapContentUnchecked);
                        SystemClock.sleep(450L);
                        capture(target, output, new String[]{"home", "compare", "settings"}[tab], scale);
                    }

                    scenario.onActivity(host -> {
                        try { invoke(host, "showAccessibilityDisclosure"); }
                        catch (Exception error) { throw new AssertionError(error); }
                    });
                    InstrumentationRegistry.getInstrumentation().waitForIdleSync();
                    SystemClock.sleep(150L);
                    capture(target, output, "privacy-dialog", scale);
                    InstrumentationRegistry.getInstrumentation().getUiAutomation()
                            .executeShellCommand("input keyevent 4").close();
                }
            }
        } finally {
            if (previousScale == null || previousScale.trim().isEmpty() || "null".equals(previousScale))
                InstrumentationRegistry.getInstrumentation().getUiAutomation()
                        .executeShellCommand("settings delete system font_scale").close();
            else
                InstrumentationRegistry.getInstrumentation().getUiAutomation()
                        .executeShellCommand("settings put system font_scale " + previousScale).close();
        }
        File[] captures = output.listFiles((dir, name) -> name.endsWith(".png"));
        assertNotNull(captures);
        assertTrue("Expected Splash + 3 tabs + disclosure screenshots at 100% and 200%", captures.length >= 10);
    }

    private static void assertNavigationDoesNotOverlapContentUnchecked(MainActivity host) {
        try { assertNavigationDoesNotOverlapContent(host); }
        catch (Exception error) { throw new AssertionError(error); }
    }

    private static void assertNavigationDoesNotOverlapContent(MainActivity host) throws Exception {
        FrameLayout body = (FrameLayout) field(host, "body");
        LinearLayout nav = (LinearLayout) field(host, "nav");
        int[] bodyLocation = new int[2], navLocation = new int[2];
        body.getLocationOnScreen(bodyLocation);
        nav.getLocationOnScreen(navLocation);
        assertTrue("Bottom navigation must remain below the scrollable page content",
                bodyLocation[1] + body.getHeight() <= navLocation[1] + 1);
        assertTrue("Body must have a usable height", body.getHeight() > 0);
        assertTrue("Bottom navigation must have a usable height", nav.getHeight() > 0);
    }

    private static void capture(Context context, File dir, String page, String scale) throws Exception {
        UiAutomation automation = InstrumentationRegistry.getInstrumentation().getUiAutomation();
        Bitmap bitmap = automation.takeScreenshot();
        assertNotNull("Screenshot should be available for " + page, bitmap);
        android.content.res.Configuration cfg = context.getResources().getConfiguration();
        String orientation = cfg.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE
                ? "landscape" : "portrait";
        String name = String.format(Locale.ROOT, "api%d_%ddp_%ddp_%s_font%s_%s.png", Build.VERSION.SDK_INT,
                cfg.screenWidthDp, cfg.screenHeightDp, orientation, scale.replace('.', '_'), page);
        File file = new File(dir, name);
        try (FileOutputStream stream = new FileOutputStream(file)) {
            assertTrue("PNG encoding failed for " + page, bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream));
            stream.flush();
        } finally { bitmap.recycle(); }
    }

    private static Object field(Object target, String name) throws Exception {
        Field f = target.getClass().getDeclaredField(name);
        f.setAccessible(true);
        return f.get(target);
    }

    private static void invoke(MainActivity host, String name) throws Exception {
        Method method = MainActivity.class.getDeclaredMethod(name);
        method.setAccessible(true);
        method.invoke(host);
    }
}
