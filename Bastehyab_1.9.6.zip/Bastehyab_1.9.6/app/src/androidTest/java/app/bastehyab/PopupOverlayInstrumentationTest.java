package app.bastehyab;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.SystemClock;
import android.provider.Settings;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import java.io.File;
import java.io.FileOutputStream;
import java.lang.reflect.Field;
import java.util.Collections;
import org.junit.Test;
import org.junit.runner.RunWith;
import static org.junit.Assert.*;

/** Real WindowManager lifecycle test. Run on an emulator/device with the app installed. */
@RunWith(AndroidJUnit4.class)
public final class PopupOverlayInstrumentationTest {
    @Test public void comparisonOverlayCanShowScreenshotHideAndRebuild() throws Exception {
        Context target = InstrumentationRegistry.getInstrumentation().getTargetContext();
        android.app.UiAutomation automation = InstrumentationRegistry.getInstrumentation().getUiAutomation(
                android.app.UiAutomation.FLAG_DONT_SUPPRESS_ACCESSIBILITY_SERVICES);
        String oldServices = Settings.Secure.getString(target.getContentResolver(),
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        String oldEnabled = Settings.Secure.getString(target.getContentResolver(),
                Settings.Secure.ACCESSIBILITY_ENABLED);
        String serviceId = target.getPackageName() + "/" + ScanService.class.getName();
        try {
            shell(automation, "settings put secure enabled_accessibility_services " + serviceId);
            shell(automation, "settings put secure accessibility_enabled 1");
            ScanService service = null;
            long deadline = SystemClock.elapsedRealtime() + 15000L;
            while (SystemClock.elapsedRealtime() < deadline) {
                service = ScanService.inst;
                if (service != null) break;
                SystemClock.sleep(200L);
            }
            assertNotNull("Accessibility service did not connect; overlay test cannot run", service);
            Field popupField = ScanService.class.getDeclaredField("popup");
            popupField.setAccessible(true);
            Popup popup = (Popup) popupField.get(service);
            assertNotNull("Popup manager was not initialized by the service", popup);

            Compare.Result result = new Compare.Result();
            result.label = "آزمون پنجره شناور";
            result.unit = "تومان";
            result.ops = 0;
            popup.show(result, Collections.<String>emptySet());
            assertTrue("Comparison overlay should be attached to the real WindowManager",
                    booleanField(popup, "attached"));
            SystemClock.sleep(600L);
            Bitmap visible = automation.takeScreenshot();
            assertNotNull("A screenshot should be captured while the popup is visible", visible);
            File dir = target.getExternalFilesDir("popup-overlay-tests");
            assertNotNull(dir);
            assertTrue(dir.exists() || dir.mkdirs());
            saveScreenshot(visible, new File(dir, "popup-visible.png"));

            popup.hide();
            assertFalse("hide() must release the comparison overlay", booleanField(popup, "attached"));
            popup.show(result, Collections.<String>emptySet());
            assertTrue("Popup must be addable again after removal", booleanField(popup, "attached"));
            assertTrue("Scan-control overlay should also be addable on the real WindowManager",
                    popup.showConfirm("آزمون", 0, 0, 0, 0, "آزمون نمایش پنجره", null, null, null));
            assertTrue("Scan-control panel should be attached", booleanField(popup, "confirmAttached"));
            SystemClock.sleep(400L);
            Bitmap controls = automation.takeScreenshot();
            assertNotNull("A screenshot should be captured while scan controls are visible", controls);
            saveScreenshot(controls, new File(dir, "scan-controls-visible.png"));
            popup.hideConfirm();
            assertFalse("hideConfirm() must remove scan controls", booleanField(popup, "confirmAttached"));
            assertTrue("Scan-control panel should be rebuildable after removal",
                    popup.showConfirm("آزمون", 0, 0, 0, 0, "بازسازی", null, null, null));
            popup.shutdown();
            assertFalse("shutdown() must remove comparison and scan-control windows",
                    booleanField(popup, "attached") || booleanField(popup, "confirmAttached"));
        } finally {
            if (oldServices == null) shell(automation, "settings delete secure enabled_accessibility_services");
            else shell(automation, "settings put secure enabled_accessibility_services '" + oldServices + "'");
            if (oldEnabled == null) shell(automation, "settings delete secure accessibility_enabled");
            else shell(automation, "settings put secure accessibility_enabled " + oldEnabled);
        }
    }

    private static void saveScreenshot(Bitmap bitmap, File file) throws Exception {
        try (FileOutputStream out = new FileOutputStream(file)) {
            assertTrue("PNG screenshot could not be written: " + file.getName(),
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, out));
        } finally { bitmap.recycle(); }
    }

    private static boolean booleanField(Object target, String name) throws Exception {
        Field field = target.getClass().getDeclaredField(name);
        field.setAccessible(true);
        return field.getBoolean(target);
    }

    private static void shell(android.app.UiAutomation automation, String command) throws Exception {
        android.os.ParcelFileDescriptor descriptor = automation.executeShellCommand(command);
        if (descriptor != null) {
            try (android.os.ParcelFileDescriptor.AutoCloseInputStream input =
                         new android.os.ParcelFileDescriptor.AutoCloseInputStream(descriptor)) {
                byte[] buffer = new byte[512];
                while (input.read(buffer) != -1) { /* drain command output */ }
            }
        }
        SystemClock.sleep(350L);
    }
}
