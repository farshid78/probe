package app.bastehyab;

import android.app.UiModeManager;
import android.content.Context;
import android.os.Debug;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelFileDescriptor;
import android.os.PowerManager;
import android.os.SystemClock;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.widget.FrameLayout;
import androidx.lifecycle.Lifecycle;
import androidx.test.core.app.ActivityScenario;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import static org.junit.Assert.*;

/** Real-device AndroidX instrumentation checks for the actual Android View/Animator runtime. */
@RunWith(AndroidJUnit4.class)
public final class AppBackdropInstrumentationTest {
    private static final String TAG = "BastehyabBackdropPerf";
    private ActivityScenario<MainActivity> scenario;
    private MainActivity activity;
    private SplashViews.AppBackdrop backdrop;
    private FrameLayout outer;
    private ProbeBackdrop performanceBackdrop;
    private String originalAppearance;
    private boolean originalReduceMotion;

    private static final class ProbeBackdrop extends SplashViews.AppBackdrop {
        volatile int drawCount;
        ProbeBackdrop(Context context) { super(context); }
        @Override protected void onDraw(android.graphics.Canvas canvas) {
            super.onDraw(canvas);
            drawCount++;
        }
        void resetDrawCount() { drawCount = 0; }
    }

    @Before public void setUp() throws Exception {
        Context target = InstrumentationRegistry.getInstrumentation().getTargetContext();
        originalAppearance = Cfg.sp(target).getString("appearance", "auto");
        originalReduceMotion = Cfg.sp(target).getBoolean("reduceMotion", false);
        Cfg.sp(target).edit().putBoolean("reduceMotion", false).apply();
        scenario = ActivityScenario.launch(MainActivity.class);
        scenario.onActivity(host -> {
            activity = host;
            backdrop = (SplashViews.AppBackdrop) field(host, "appBackdrop");
            outer = (FrameLayout) field(host, "outer");
        });
    }

    @After public void tearDown() {
        Context target = InstrumentationRegistry.getInstrumentation().getTargetContext();
        Cfg.sp(target).edit().putString("appearance", originalAppearance)
                .putBoolean("reduceMotion", originalReduceMotion).apply();
        if (scenario != null) {
            try {
                scenario.onActivity(host -> {
                    UI.applyTheme(host);
                    if (performanceBackdrop != null) performanceBackdrop.disposeLoop();
                    if (backdrop != null) backdrop.disposeLoop();
                });
            } catch (RuntimeException ignored) { /* Activity may already have been destroyed by a failing assertion. */ }
            scenario.close();
            scenario = null;
        }
        if (backdrop != null)
            assertFalse("MainActivity destruction must leave no running backdrop animator", backdrop.isLoopRunning());
    }

    @Test public void activityPauseVisibilityDetachReduceMotionAndBatterySaverStopLoop() {
        PowerManager power = (PowerManager) activity.getSystemService(Context.POWER_SERVICE);
        assertNotNull("PowerManager must be available", power);
        if (power.isPowerSaveMode()) {
            Log.i(TAG, "Lifecycle loop-start assertion skipped: device Battery Saver is active");
            return;
        }
        if (!isLoopRunning()) {
            Log.i(TAG, "Lifecycle loop-start assertion skipped: Android animator duration scale disables animation");
            return;
        }

        scenario.moveToState(Lifecycle.State.STARTED);
        assertFalse("MainActivity onPause must stop the animator", isLoopRunning());
        scenario.moveToState(Lifecycle.State.RESUMED);
        assertTrue("MainActivity onResume may restart the animator", isLoopRunning());

        scenario.onActivity(host -> backdrop.setReduceMotionEnabled(true));
        assertFalse("Reduce Motion must stop the loop", isLoopRunning());
        scenario.onActivity(host -> backdrop.setReduceMotionEnabled(false));
        assertTrue("Disabling Reduce Motion may restart the loop", isLoopRunning());

        scenario.onActivity(host -> backdrop.setBatterySaverMode(true));
        assertFalse("Battery Saver policy must stop the loop", isLoopRunning());
        scenario.onActivity(host -> backdrop.setBatterySaverMode(false));
        assertTrue("Leaving Battery Saver may restart the loop", isLoopRunning());

        scenario.onActivity(host -> backdrop.setVisibility(View.GONE));
        assertFalse("A hidden View must stop the animator", isLoopRunning());
        scenario.onActivity(host -> backdrop.setVisibility(View.VISIBLE));
        assertTrue("A visible View may restart the animator", isLoopRunning());

        scenario.onActivity(host -> host.getWindow().getDecorView().setVisibility(View.INVISIBLE));
        assertFalse("A hidden ancestor/window content must stop the animator", isLoopRunning());
        scenario.onActivity(host -> host.getWindow().getDecorView().setVisibility(View.VISIBLE));
        assertTrue("Restoring visible window content may restart the animator", isLoopRunning());

        scenario.onActivity(host -> outer.removeView(backdrop));
        assertFalse("Detaching the View must stop the animator", isLoopRunning());
        scenario.onActivity(host -> outer.addView(backdrop, 0, new FrameLayout.LayoutParams(-1, -1)));
        assertTrue("Reattaching a live Activity backdrop may restart the animator", isLoopRunning());

        scenario.onActivity(host -> {
            backdrop.disposeLoop();
            backdrop.resumeLoop();
        });
        assertFalse("Disposed backdrop must not restart", isLoopRunning());
    }

    @Test public void zeroSystemAnimatorScaleDisablesLoop() throws Exception {
        Context target = InstrumentationRegistry.getInstrumentation().getTargetContext();
        String previous = Settings.Global.getString(target.getContentResolver(), Settings.Global.ANIMATOR_DURATION_SCALE);
        try {
            runShell("settings put global animator_duration_scale 0");
            SystemClock.sleep(250L);
            scenario.onActivity(host -> backdrop.refreshMotionPolicy());
            assertFalse("System animator scale 0 must disable AppBackdrop", isLoopRunning());
        } finally {
            if (previous == null) runShell("settings delete global animator_duration_scale");
            else runShell("settings put global animator_duration_scale " + previous);
            SystemClock.sleep(250L);
            scenario.onActivity(host -> backdrop.refreshMotionPolicy());
        }
    }

    @Test public void autoThemeFollowsAndroidUiMode() {
        Context target = InstrumentationRegistry.getInstrumentation().getTargetContext();
        Cfg.sp(target).edit().putString("appearance", "auto").apply();
        scenario.onActivity(host -> UI.applyTheme(host));
        assertEquals("Auto must map system night mode to the dark palette",
                UI.isSystemNight(target), !UI.light);
        Cfg.sp(target).edit().putString("appearance", "mono").apply();
        scenario.onActivity(host -> UI.applyTheme(host));
        assertTrue("Mono override must ignore Android night mode", UI.mono);
    }

    @Test public void systemNightConfigurationChangesWithoutActivityRecreation() throws Exception {
        if (android.os.Build.VERSION.SDK_INT < 29) {
            Log.i(TAG, "System night-mode shell test requires API 29+");
            return;
        }
        UiModeManager uiMode = (UiModeManager) activity.getSystemService(Context.UI_MODE_SERVICE);
        assertNotNull("UiModeManager must be available", uiMode);
        int previousMode = uiMode.getNightMode();
        if (previousMode == UiModeManager.MODE_NIGHT_CUSTOM) {
            Log.i(TAG, "System night-mode configuration test skipped: custom bedtime schedule is active");
            return;
        }
        boolean wasNight = UI.isSystemNight(activity);
        String restoreMode = previousMode == UiModeManager.MODE_NIGHT_YES ? "yes"
                : previousMode == UiModeManager.MODE_NIGHT_NO ? "no" : "auto";
        Cfg.sp(activity).edit().putString("appearance", "auto").apply();
        scenario.onActivity(host -> UI.applyTheme(host));
        String requested = wasNight ? "no" : "yes";
        try {
            runShell("cmd uimode night " + requested);
            SystemClock.sleep(900L);
            InstrumentationRegistry.getInstrumentation().waitForIdleSync();
            assertFalse("uiMode changes must not destroy/recreate MainActivity", activity.isDestroyed());
            boolean nowNight = UI.isSystemNight(activity);
            assertEquals("Auto palette should follow the changed system night mode", nowNight, !UI.light);
            // On API 35+ the bar colour is painted by the root view (Window bar colours are ignored
            // under enforced edge-to-edge), so check what is actually visible behind the bars.
            assertEquals("Status bar area must follow the resolved palette", UI.BG, visibleSystemBarColor());
            assertEquals("Navigation bar area must follow the resolved palette", UI.BG, visibleSystemBarColor());
        } finally {
            runShell("cmd uimode night " + restoreMode);
            SystemClock.sleep(900L);
            InstrumentationRegistry.getInstrumentation().waitForIdleSync();
            Cfg.sp(activity).edit().putString("appearance", originalAppearance).apply();
            scenario.onActivity(host -> UI.applyTheme(host));
        }
    }

    @Test public void measureAnimatedAndStaticFrameRateAndCpuTime() throws Exception {
        PowerManager power = (PowerManager) activity.getSystemService(Context.POWER_SERVICE);
        if (power != null && power.isPowerSaveMode()) {
            Log.i(TAG, "Performance measurement skipped: Battery Saver is active");
            return;
        }
        if (android.os.Build.VERSION.SDK_INT >= 26 && !android.animation.ValueAnimator.areAnimatorsEnabled()) {
            Log.i(TAG, "Performance measurement skipped: Android animator duration scale is disabled");
            return;
        }

        scenario.onActivity(host -> {
            backdrop.pauseLoop();
            performanceBackdrop = new ProbeBackdrop(host);
            host.setContentView(performanceBackdrop);
            performanceBackdrop.resumeLoop();
        });
        Measurement animated = measure(false);
        Measurement reduced = measure(true);
        Log.i(TAG, String.format(java.util.Locale.ROOT,
                "Backdrop performance: animated %.1f fps / %.2f%% main-thread CPU; reduced-motion %.1f fps / %.2f%% main-thread CPU",
                animated.fps, animated.cpuPercent, reduced.fps, reduced.cpuPercent));
        assertTrue("Animated mode should produce multiple draw frames", animated.frames > 2);
        assertTrue("Reduce Motion should leave the background static", reduced.frames <= 2);
    }

    private static final class Measurement {
        final int frames;
        final double fps;
        final double cpuPercent;
        Measurement(int frames, double fps, double cpuPercent) {
            this.frames = frames; this.fps = fps; this.cpuPercent = cpuPercent;
        }
    }

    private Measurement measure(boolean reduceMotion) throws Exception {
        CountDownLatch done = new CountDownLatch(1);
        long[] startWall = new long[1];
        long[] startCpu = new long[1];
        long[] endWall = new long[1];
        long[] endCpu = new long[1];
        scenario.onActivity(host -> {
            performanceBackdrop.setBatterySaverMode(false);
            performanceBackdrop.setReduceMotionEnabled(reduceMotion);
            performanceBackdrop.refreshTheme();
            performanceBackdrop.resetDrawCount();
            startWall[0] = SystemClock.elapsedRealtimeNanos();
            startCpu[0] = Debug.threadCpuTimeNanos();
            new Handler(Looper.getMainLooper()).postDelayed(() -> {
                endCpu[0] = Debug.threadCpuTimeNanos();
                endWall[0] = SystemClock.elapsedRealtimeNanos();
                done.countDown();
            }, 2200L);
        });
        assertTrue("Measurement window should complete", done.await(5, TimeUnit.SECONDS));
        long wall = Math.max(1L, endWall[0] - startWall[0]);
        long cpu = Math.max(0L, endCpu[0] - startCpu[0]);
        int frames = performanceBackdrop.drawCount;
        return new Measurement(frames, frames * 1_000_000_000d / wall, cpu * 100d / wall);
    }

    private boolean isLoopRunning() {
        boolean[] running = new boolean[1];
        scenario.onActivity(host -> running[0] = backdrop.isLoopRunning());
        return running[0];
    }

    /** Colour actually visible behind the system bars: Window bar colour before API 35, root view after. */
    private int visibleSystemBarColor() {
        int[] color = new int[1];
        scenario.onActivity(host -> {
            if (android.os.Build.VERSION.SDK_INT < 35) {
                color[0] = host.getWindow().getStatusBarColor();
                return;
            }
            android.graphics.drawable.Drawable background = ((View) field(host, "outer")).getBackground();
            color[0] = background instanceof android.graphics.drawable.ColorDrawable
                    ? ((android.graphics.drawable.ColorDrawable) background).getColor() : 0;
        });
        return color[0];
    }

    private static Object field(Object target, String name) {
        try {
            Field field = target.getClass().getDeclaredField(name);
            field.setAccessible(true);
            return field.get(target);
        } catch (ReflectiveOperationException error) {
            throw new AssertionError("Required MainActivity test fixture missing: " + name, error);
        }
    }

    private void runShell(String command) throws IOException {
        ParcelFileDescriptor descriptor = InstrumentationRegistry.getInstrumentation()
                .getUiAutomation().executeShellCommand(command);
        if (descriptor == null) throw new IOException("Shell command did not return a descriptor: " + command);
        // Drain stdout to EOF so the shell command has completed before assertions/restoration.
        try (InputStream input = new ParcelFileDescriptor.AutoCloseInputStream(descriptor)) {
            byte[] buffer = new byte[1024];
            while (input.read(buffer) != -1) { /* command output is intentionally ignored */ }
        }
    }
}
