package app.bastehyab;

import org.junit.Test;
import java.util.List;
import static org.junit.Assert.*;

public final class HistoryTest {
    @Test public void recordsOnlyComparableSameIdentityChanges() {
        Pkg old = pkg(100_000L, 2.0, 30.0);
        Pkg current = pkg(110_000L, 3.0, 30.0);
        List<History.Change> changes = History.diff(old, current);
        assertEquals(2, changes.size());
        assertEquals("price", changes.get(0).field);
        assertEquals(10.0d, changes.get(0).percent(), 0.0001d);
        assertEquals("gb", changes.get(1).field);
    }

    @Test public void ignoresAmbiguousUnknownOrDifferentIdentity() {
        Pkg a = pkg(100_000L, 2.0, 30.0);
        Pkg b = pkg(110_000L, 2.0, 30.0); b.ambig = true;
        assertTrue(History.diff(a, b).isEmpty());
        b.ambig = false; b.key = "different";
        assertTrue(History.diff(a, b).isEmpty());
        b.key = a.key; b.currencyKnown = false;
        assertTrue(History.diff(a, b).isEmpty());
    }

    private static Pkg pkg(long price, double gb, double days) {
        Pkg p = new Pkg(); p.key = "same-id"; p.currencyKnown = true;
        p.toman = price; p.gb = gb; p.days = days; p.ts = 1000L;
        return p;
    }
}
