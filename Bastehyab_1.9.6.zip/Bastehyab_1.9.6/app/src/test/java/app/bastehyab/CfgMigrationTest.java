package app.bastehyab;

import android.content.Context;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.RuntimeEnvironment;
import org.robolectric.annotation.Config;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class)
@Config(sdk = 35)
public final class CfgMigrationTest {
    private Context context;

    @Before public void resetPreferences() throws Exception {
        context = RuntimeEnvironment.getApplication();
        Cfg.sp(context).edit().clear().commit();
        Field cache = Cfg.class.getDeclaredField("cache");
        cache.setAccessible(true);
        cache.set(null, null);
    }

    @Test public void oldMetricIndexIsMigratedToPerGbDefault() {
        Cfg.sp(context).edit().putInt("metric", Cfg.PER_GB_MONTH).commit();
        assertEquals(Cfg.PER_GB, Cfg.metric(context));
        assertEquals(1, Cfg.sp(context).getInt("metricModeVersion", 0));
    }

    @Test public void displayCurrencyChangesLabelOnly() {
        Cfg.setDisplayCurrency(context, "IRR");
        String rialLabel = Fmt.norm(Cfg.priceLabel(context, 10_000L));
        assertEquals("100,000 ریال", rialLabel);
        Cfg.setDisplayCurrency(context, "IRT");
        String tomanLabel = Fmt.norm(Cfg.priceLabel(context, 10_000L));
        assertEquals("10,000 تومان", tomanLabel);
        assertEquals(10_000L, PriceModel.toToman(10_000L, PriceModel.Currency.IRT));
    }


    @Test public void migratesBuiltInOperatorsToOneCanonicalParserProfile() throws Exception {
        List<Op> legacy = new ArrayList<>();
        Op irancell = new Op("irancell", "ایرانسل", 1, "IRR", true, "old.irancell");
        irancell.policy = 1;
        Op mci = new Op("mci", "همراه اول", 2, "IRT", true, "old.mci");
        mci.policy = 2;
        Op custom = new Op("custom", "اپراتور سفارشی", 3, "IRT", false, "ir.custom.app");
        custom.policy = 2;
        legacy.add(irancell);
        legacy.add(mci);
        legacy.add(custom);
        Cfg.saveOps(context, legacy);
        Cfg.sp(context).edit().putInt("defv", 6).commit();
        Field cache = Cfg.class.getDeclaredField("cache");
        cache.setAccessible(true);
        cache.set(null, null);

        Cfg.ops(context);
        Op migratedIrancell = Cfg.opById(context, "irancell");
        Op migratedMci = Cfg.opById(context, "mci");
        Op migratedCustom = Cfg.opById(context, "custom");
        assertNotNull(migratedIrancell);
        assertNotNull(migratedMci);
        assertNotNull(migratedCustom);
        assertEquals("AUTO", migratedIrancell.cur);
        assertEquals("AUTO", migratedMci.cur);
        assertEquals(0, migratedIrancell.policy);
        assertEquals(0, migratedMci.policy);
        assertTrue(migratedIrancell.pkgs.contains("com.myirancell"));
        assertTrue(migratedMci.pkgs.contains("ir.mci.ecareapp"));
        assertEquals("IRT", migratedCustom.cur);
        assertEquals(2, migratedCustom.policy);
        assertTrue(migratedCustom.pkgs.contains("ir.custom.app"));
        assertEquals(7, Cfg.sp(context).getInt("defv", 0));
    }

    @Test public void unknownCurrencyDoesNotGetOperatorFallbackInAuto() {
        Op operator = new Op("irancell", "ایرانسل", 1, "AUTO", true, "com.myirancell");
        assertEquals("AUTO", operator.cur);
        assertEquals(PriceModel.Currency.UNKNOWN,
                PriceModel.parse("150000", PriceModel.Currency.UNKNOWN).currency);
    }
}
