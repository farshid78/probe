package app.bastehyab;

import org.junit.Test;
import java.util.ArrayDeque;
import java.util.Queue;
import java.util.concurrent.RejectedExecutionException;
import static org.junit.Assert.*;

public final class ScanWorkerTaskTest {
    private static final class ManualPoster implements ScanWorkerTask.Poster {
        final Queue<Runnable> queue = new ArrayDeque<>();
        @Override public void post(Runnable callback) { queue.add(callback); }
        void drain() { while (!queue.isEmpty()) queue.remove().run(); }
    }

    @Test public void runtimeFailureIsDeliveredOnceOnOwnerQueue() {
        ManualPoster poster = new ManualPoster();
        final Throwable[] failure = {null};
        final int[] calls = {0};
        ScanWorkerTask<String> task = new ScanWorkerTask<>(() -> { throw new IllegalStateException("test-only"); },
                poster, (value, error) -> { calls[0]++; failure[0] = error; });
        task.run();
        assertEquals(1, poster.queue.size());
        assertEquals(0, calls[0]);
        poster.drain();
        task.reject(new RejectedExecutionException("late duplicate"));
        poster.drain();
        assertEquals(1, calls[0]);
        assertTrue(failure[0] instanceof IllegalStateException);
    }

    @Test public void executorRejectionUsesSameCompletionPath() {
        ManualPoster poster = new ManualPoster();
        final Throwable[] failure = {null};
        ScanWorkerTask<String> task = new ScanWorkerTask<>(() -> "must-not-run", poster,
                (value, error) -> failure[0] = error);
        task.reject(new RejectedExecutionException("closed"));
        task.run();
        poster.drain();
        assertTrue(failure[0] instanceof RejectedExecutionException);
    }

    @Test public void successfulValueIsDeliveredExactlyOnce() {
        ManualPoster poster = new ManualPoster();
        final String[] value = {null};
        ScanWorkerTask<String> task = new ScanWorkerTask<>(() -> "ok", poster,
                (result, failure) -> { assertNull(failure); value[0] = result; });
        task.run();
        task.run();
        poster.drain();
        assertEquals("ok", value[0]);
    }
}
