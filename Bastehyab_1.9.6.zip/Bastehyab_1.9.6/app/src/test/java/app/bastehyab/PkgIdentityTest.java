package app.bastehyab;

import org.junit.Test;
import static org.junit.Assert.*;

/** Price-independent, versioned package identity regression coverage. */
public final class PkgIdentityTest {
    private Pkg pkg(double gb, double days, long price, String why, String nearby) {
        Pkg p = new Pkg();
        p.op = "irancell";
        p.title = "بسته اینترنت ۲ گیگ ۱۵ روزه";
        p.identityTitle = "بسته اینترنت ۲ گیگ";
        p.identityKind = "DATA";
        p.gb = gb; p.days = days; p.toman = price; p.why = why;
        p.note = nearby;
        PkgIdentity.normalize(p);
        return p;
    }

    @Test public void durationAndVolumeDistinguishPackages() {
        assertNotEquals(PkgIdentity.keyOf(pkg(2, 7, 150_000, "", "")),
                PkgIdentity.keyOf(pkg(2, 30, 150_000, "", "")));
        assertNotEquals(PkgIdentity.keyOf(pkg(2, 30, 150_000, "", "")),
                PkgIdentity.keyOf(pkg(5, 30, 150_000, "", "")));
    }

    @Test public void priceAndClassificationDoNotChangeIdentity() {
        String base = PkgIdentity.keyOf(pkg(2, 30, 100_000, "", ""));
        assertEquals(base, PkgIdentity.keyOf(pkg(2, 30, 120_000, "", "")));
        assertEquals(base, PkgIdentity.keyOf(pkg(2, 30, 100_000, "شبانه", "متن اطراف")));
    }

    @Test public void unknownDimensionsAreExplicitAndNotValidDimensions() {
        Pkg unknown = pkg(0, 0, 100_000, "", "");
        Pkg valid = pkg(1, 1, 100_000, "", "");
        assertNotEquals(PkgIdentity.keyOf(unknown), PkgIdentity.keyOf(valid));
        assertTrue(PkgIdentity.keyOf(unknown).startsWith("pkg:v" + PkgIdentity.VERSION + ":fp:"));
    }

    @Test public void observedProductIdWinsOverTitleAndPrice() {
        Pkg a = pkg(2, 30, 100_000, "", "");
        Pkg b = pkg(5, 7, 300_000, "شبانه", "");
        a.code = b.code = "offer-123";
        a.productIdObserved = b.productIdObserved = true;
        assertEquals(PkgIdentity.keyOf(a), PkgIdentity.keyOf(b));
    }
}
