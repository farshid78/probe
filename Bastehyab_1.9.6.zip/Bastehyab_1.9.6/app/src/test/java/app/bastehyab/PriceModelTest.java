package app.bastehyab;

import org.junit.Test;
import static org.junit.Assert.*;

/** Canonical currency/tax boundary tests; no operator-name currency inference is permitted. */
public final class PriceModelTest {
    @Test public void convertsRialAndTomanOnce() {
        assertEquals(10_000L, PriceModel.toToman(100_000L, PriceModel.Currency.IRR));
        assertEquals(100_000L, PriceModel.toToman(100_000L, PriceModel.Currency.IRT));
    }

    @Test(expected = IllegalArgumentException.class)
    public void rejectsNonIntegralRialConversion() {
        PriceModel.toToman(100_001L, PriceModel.Currency.IRR);
    }

    @Test public void autoWithoutUnitRemainsUnknownAndNonComparable() {
        PriceModel.Parsed parsed = PriceModel.parse("100,000", PriceModel.Currency.UNKNOWN);
        assertNotNull(parsed);
        assertEquals(PriceModel.Currency.UNKNOWN, parsed.currency);
        assertEquals(PriceModel.Confidence.NONE, parsed.confidence);
        assertEquals(0L, parsed.normalizedToman);
        assertFalse(parsed.comparable());
    }

    @Test public void explicitUnitsAndPersianCompoundAmountParse() {
        assertEquals(10_000L, PriceModel.parse("100,000 ریال", PriceModel.Currency.UNKNOWN).normalizedToman);
        assertEquals(100_000L, PriceModel.parse("۱۰۰٬۰۰۰ تومان", PriceModel.Currency.UNKNOWN).normalizedToman);
        assertEquals(100_500L, PriceModel.parse("۱۰۰ هزار و ۵۰۰ تومان", PriceModel.Currency.UNKNOWN).normalizedToman);
    }

    @Test public void vatUsesOverflowSafeSingleCalculation() {
        assertEquals(110_000L, PriceModel.safeVat(100_000L, 10));
        assertEquals(100_000L, PriceModel.safeVat(100_000L, 0));
        assertEquals(100_000L, PriceModel.finalToman(100_000L, true, 10));
        assertEquals(110_000L, PriceModel.finalToman(100_000L, false, 10));
        try { PriceModel.safeVat(Long.MAX_VALUE, 100); fail("overflow must be rejected"); }
        catch (ArithmeticException expected) { /* expected */ }
    }

    @Test public void priceParserDoesNotMistakeValidityForPrice() {
        PriceModel.Parsed p = PriceModel.parse("بسته ۲ گیگ، ۱۰۰٬۰۰۰ تومان، اعتبار ۳۰ روز", PriceModel.Currency.UNKNOWN);
        assertNotNull(p);
        assertEquals(100_000L, p.normalizedToman);
        assertNull("multiple price labels are ambiguous", PriceModel.parse("۱۰۰۰۰ تومان یا ۹۰۰۰ تومان", PriceModel.Currency.UNKNOWN));
    }

    @Test public void perGbAndPerDayUseFinalPriceAndRejectZeroDuration() {
        Pkg p = new Pkg(); p.gb = 5d; p.days = 10d;
        assertEquals(22_000d, p.perGb(110_000L), 0.0001d);
        assertEquals(11_000d, p.perDay(110_000L), 0.0001d);
        p.days = 0d;
        assertEquals(Double.MAX_VALUE, p.perDay(110_000L), 0d);
    }

    @Test public void monthlyCostRoundsOnceAndRejectsInvalidInputs() {
        assertEquals(500_000L, PriceModel.monthlyCost(100_000L, 6d, 60d, 30d));
        assertEquals(500_000L, PriceModel.monthlyCost(100_000L, 2d, 7d, 10d));
        try { PriceModel.monthlyCost(100_000L, Double.NaN, 30d, 10d); fail("NaN volume must be rejected"); }
        catch (IllegalArgumentException expected) { /* expected */ }
        try { PriceModel.monthlyCost(Long.MAX_VALUE, 0.05d, 1d, 5000d); fail("overflow must be rejected"); }
        catch (ArithmeticException expected) { /* expected */ }
    }
}
