package app.bastehyab;

import org.junit.Test;
import static org.junit.Assert.*;

/** Canonical currency/tax boundary tests; no operator-name currency inference is permitted. */
public final class PriceModelTest {
    @Test public void convertsRialAndTomanOnce() {
        assertEquals(10_000L, PriceModel.toToman(100_000L, PriceModel.Currency.IRR));
        assertEquals(100_000L, PriceModel.toToman(100_000L, PriceModel.Currency.IRT));
    }

    @Test(expected = IllegalArgumentException.class)
    public void rejectsNonIntegralRialConversion() {
        PriceModel.toToman(100_001L, PriceModel.Currency.IRR);
    }

    @Test public void autoWithoutUnitRemainsUnknownAndNonComparable() {
        PriceModel.Parsed parsed = PriceModel.parse("100,000", PriceModel.Currency.UNKNOWN);
        assertNotNull(parsed);
        assertEquals(PriceModel.Currency.UNKNOWN, parsed.currency);
        assertEquals(PriceModel.Confidence.NONE, parsed.confidence);
        assertEquals(0L, parsed.normalizedToman);
        assertFalse(parsed.comparable());
    }

    @Test public void explicitUnitsAndPersianCompoundAmountParse() {
        assertEquals(10_000L, PriceModel.parse("100,000 ریال", PriceModel.Currency.UNKNOWN).normalizedToman);
        assertEquals(100_000L, PriceModel.parse("۱۰۰٬۰۰۰ تومان", PriceModel.Currency.UNKNOWN).normalizedToman);
        assertEquals(100_500L, PriceModel.parse("۱۰۰ هزار و ۵۰۰ تومان", PriceModel.Currency.UNKNOWN).normalizedToman);
    }

    @Test public void vatUsesOverflowSafeSingleCalculation() {
        assertEquals(110_000L, PriceModel.safeVat(100_000L, 10));
        assertEquals(100_000L, PriceModel.safeVat(100_000L, 0));
        try { PriceModel.safeVat(Long.MAX_VALUE, 100); fail("overflow must be rejected"); }
        catch (ArithmeticException expected) { /* expected */ }
    }
}
