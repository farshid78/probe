package app.bastehyab;

import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.annotation.Config;
import java.io.File;
import java.io.FileOutputStream;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.List;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class)
@Config(sdk = 35)
public final class StoreParserTest {
    @Test public void quarantinesBadRecordAndPreservesValidSiblings() throws Exception {
        Pkg p = new Pkg(); p.op = "irancell"; p.title = "بسته ۲ گیگ";
        p.identityTitle = p.title; p.identityKind = "DATA";
        p.gb = 2; p.days = 30; p.toman = 100_000L; p.normalizedToman = 100_000L;
        p.currencyKnown = true; p.taxKnown = true; p.taxIncluded = false;
        p.currencyConfidence = "HIGH"; p.rawCurrency = "IRT"; p.rawAmount = 100_000L;
        p.ts = System.currentTimeMillis(); p.observedAt = p.ts;
        PkgIdentity.normalize(p);

        JSONArray records = new JSONArray().put(p.json()).put(new JSONObject().put("op", "corrupt"));
        JSONObject db = new JSONObject().put("schemaVersion", 4).put("records", records);
        File file = File.createTempFile("bastehyab-store", ".json");
        try {
            try (FileOutputStream stream = new FileOutputStream(file)) {
                stream.write(db.toString().getBytes(java.nio.charset.StandardCharsets.UTF_8));
            }
            Method read = Store.class.getDeclaredMethod("readDatabase", File.class, android.content.Context.class);
            read.setAccessible(true);
            Object result = read.invoke(null, file, null);
            Field itemsField = result.getClass().getDeclaredField("items"); itemsField.setAccessible(true);
            Field quarantineField = result.getClass().getDeclaredField("quarantine"); quarantineField.setAccessible(true);
            List<?> items = (List<?>) itemsField.get(result);
            assertEquals(1, items.size());
            assertEquals(1, quarantineField.getInt(result));
        } finally {
            assertTrue(file.delete() || !file.exists());
        }
    }

    @Test public void legacyArrayIsMarkedForMigration() throws Exception {
        File file = File.createTempFile("bastehyab-store-legacy", ".json");
        try {
            try (FileOutputStream stream = new FileOutputStream(file)) { stream.write("[]".getBytes(java.nio.charset.StandardCharsets.UTF_8)); }
            Method read = Store.class.getDeclaredMethod("readDatabase", File.class, android.content.Context.class);
            read.setAccessible(true);
            Object result = read.invoke(null, file, null);
            Field schema = result.getClass().getDeclaredField("schemaVersion"); schema.setAccessible(true);
            Field migrate = result.getClass().getDeclaredField("migrate"); migrate.setAccessible(true);
            assertEquals(1, schema.getInt(result));
            assertTrue(migrate.getBoolean(result));
        } finally { assertTrue(file.delete() || !file.exists()); }
    }
}
