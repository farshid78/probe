package app.bastehyab;

import org.junit.Test;
import static org.junit.Assert.*;

/** Exercises production Extractor/Fmt parsing helpers on the JVM without fake Accessibility nodes. */
public final class ExtractorJvmTest {
    @Test public void parsesVolumeAndTitlePriceWithPersianDigits() {
        double[] volume = Extractor.vol("بسته ۲ گیگابایت اینترنت");
        assertNotNull(volume);
        assertEquals(2.0d, volume[0], 0.0001d);
        assertEquals(1.0d, volume[1], 0.0001d);
        assertEquals(333_000L, Extractor.titlePrice("۲ گیگ ۳۳۳ هزار تومان"));
    }

    @Test public void normalizesArabicAndPersianNumerals() {
        assertEquals("12,345", Fmt.norm("۱۲٬۳۴۵"));
        assertEquals("123", Fmt.norm("١٢٣"));
        assertEquals("۱۲۳", Fmt.fa("123"));
    }

    @Test public void classifiesSpecialAndInternationalLabels() {
        // International/roaming detection happens before whyOf in production callers; mirror that order here.
        String roaming = "بسته اینترنت رومینگ";
        assertTrue(Extractor.INTL.matcher(Fmt.norm(roaming)).find());
        assertEquals(Extractor.INTL_WHY, Extractor.INTL.matcher(Fmt.norm(roaming)).find() ? Extractor.INTL_WHY : Extractor.whyOf(roaming, 30, 1));
        assertFalse(Extractor.mergeWhy("", "شبانه").isEmpty());
    }
}
