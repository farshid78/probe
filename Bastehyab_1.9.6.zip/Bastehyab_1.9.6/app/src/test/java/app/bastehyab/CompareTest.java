package app.bastehyab;

import android.content.Context;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.RuntimeEnvironment;
import org.robolectric.annotation.Config;
import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.Collections;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class)
@Config(sdk = 35)
public final class CompareTest {
    private Context context;

    @Before public void resetPreferences() throws Exception {
        context = RuntimeEnvironment.getApplication();
        Cfg.sp(context).edit().clear().commit();
        Field cache = Cfg.class.getDeclaredField("cache");
        cache.setAccessible(true);
        cache.set(null, null);
        // Without this marker Cfg.metric() runs its one-time legacy migration and resets the metric to PER_GB.
        Cfg.sp(context).edit().putInt("metricModeVersion", 1).commit();
    }

    @Test public void baseAndTaxIncludedPricesAreComparedOnTheSameFinalPriceBasis() {
        Pkg baseOnly = pkg("base-only", 100_000L, false);      // 100,000 + 10% VAT = 110,000
        Pkg taxIncluded = pkg("tax-included", 105_000L, true); // already final: 105,000
        assertEquals(110_000L, Cfg.finalPrice(context, baseOnly));
        assertEquals(105_000L, Cfg.finalPrice(context, taxIncluded));
        Compare.Result result = Compare.run(context, Arrays.asList(baseOnly, taxIncluded), Collections.<String>emptySet());
        assertEquals(2, result.ranked.size());
        assertEquals("tax-included", result.ranked.get(0).key);
        assertEquals("base-only", result.ranked.get(1).key);
    }

    @Test public void combinedOperatorFreshnessVolumeDurationBucketAndSpecialFilters() {
        Cfg.sp(context).edit().putInt("fresh", 3).putInt("maxDays", 35).putInt("bucket", 2)
                .putFloat("minGb", 1f).putBoolean("restricted", false).putBoolean("intl", false).commit();
        Pkg good = pkg("good", 100_000L, false); good.gb = 2; good.days = 30;
        Pkg small = pkg("small", 100_000L, false); small.gb = 0.5;
        Pkg longPkg = pkg("long", 100_000L, false); longPkg.days = 40;
        Pkg stale = pkg("stale", 100_000L, false); stale.ts -= 10L * 86400000L;
        Pkg restricted = pkg("restricted", 100_000L, false); restricted.restricted = true; restricted.why = "شبانه";
        Pkg intl = pkg("intl", 100_000L, false); intl.why = Extractor.INTL_WHY; intl.restricted = true;
        Compare.Result domestic = Compare.run(context, Arrays.asList(good, small, longPkg, stale, restricted, intl), Collections.<String>emptySet());
        assertEquals(1, domestic.ranked.size());
        assertEquals("good", domestic.ranked.get(0).key);
        Cfg.sp(context).edit().putBoolean("intl", true).commit();
        Compare.Result withIntl = Compare.run(context, Arrays.asList(good, intl), Collections.<String>emptySet());
        assertEquals(2, withIntl.ranked.size());
    }

    @Test public void rankingOrderMatchesTheSelectedMetric() {
        Cfg.sp(context).edit().putInt("metric", Cfg.PER_GB).commit();
        Pkg lowPerGb = pkg("low-per-gb", 100_000L, false); lowPerGb.gb = 5;
        Pkg highPerGb = pkg("high-per-gb", 100_000L, false); highPerGb.gb = 2;
        Compare.Result perGb = Compare.run(context, Arrays.asList(highPerGb, lowPerGb), Collections.<String>emptySet());
        assertEquals("low-per-gb", perGb.ranked.get(0).key);
        Cfg.sp(context).edit().putInt("metric", Cfg.DURATION).commit();
        Pkg week = pkg("week", 100_000L, false); week.days = 7;
        Pkg month = pkg("month", 100_000L, false); month.days = 30;
        Compare.Result duration = Compare.run(context, Arrays.asList(week, month), Collections.<String>emptySet());
        assertEquals("month", duration.ranked.get(0).key);
    }

    private static Pkg pkg(String key, long amount, boolean taxIncluded) {
        Pkg p = new Pkg(); p.op = "irancell"; p.key = key; p.title = key;
        p.gb = 2; p.days = 30; p.toman = amount; p.normalizedToman = amount;
        p.currencyKnown = true; p.ambig = false; p.taxKnown = true; p.taxIncluded = taxIncluded;
        p.ts = System.currentTimeMillis(); p.observedAt = p.ts;
        p.restricted = false; p.why = ""; p.identityKind = "DATA"; p.identityTitle = key;
        return p;
    }
}
