package app.bastehyab;

import android.content.Context;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.RuntimeEnvironment;
import org.robolectric.annotation.Config;
import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.Collections;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class)
@Config(sdk = 35)
public final class CompareTest {
    private Context context;

    @Before public void setup() throws Exception {
        context = RuntimeEnvironment.getApplication();
        Cfg.sp(context).edit().clear().commit();
        Field cache = Cfg.class.getDeclaredField("cache"); cache.setAccessible(true); cache.set(null, null);
        Cfg.sp(context).edit().putInt("vat", 10).putInt("fresh", 3).commit();
    }

    @Test public void ranksTaxInclusiveOnceAndBasePriceWithVatOnce() {
        Pkg inclusive = pkg("inclusive", 100_000L, true);
        Pkg base = pkg("base", 100_000L, false);
        inclusive.identityLimits = "VAT_INCLUDED";
        base.identityLimits = "VAT_BASE";
        Compare.Result result = Compare.run(context, Arrays.asList(base, inclusive), Collections.<String>emptySet());
        assertEquals(2, result.ranked.size());
        assertEquals("inclusive", result.ranked.get(0).key);
        assertEquals(50_000d, result.val.get("inclusive"), 0.0001d);
        assertEquals(55_000d, result.val.get("base"), 0.0001d);
    }

    @Test public void staleAndOverDurationPackagesAreFiltered() {
        Cfg.sp(context).edit().putInt("fresh", 3).putInt("maxDays", 7).commit();
        Pkg stale = pkg("stale", 100_000L, false);
        stale.identityLimits = "STALE";
        stale.ts = System.currentTimeMillis() - 10L * 86400000L;
        Pkg longDuration = pkg("long", 100_000L, false);
        longDuration.identityLimits = "LONG";
        longDuration.days = 30;
        Compare.Result result = Compare.run(context, Arrays.asList(stale, longDuration), Collections.<String>emptySet());
        assertTrue(result.ranked.isEmpty());
    }

    @Test public void ambiguousAndRejectedRecordsNeverEnterRanking() {
        Pkg ambiguous = pkg("ambiguous", 100_000L, false); ambiguous.ambig = true;
        Pkg rejected = pkg("rejected", 100_000L, false); rejected.reviewStatus = "rejected";
        Compare.Result result = Compare.run(context, Arrays.asList(ambiguous, rejected), Collections.<String>emptySet());
        assertTrue(result.ranked.isEmpty());
        assertEquals(1, result.ambig.size());
    }

    private static Pkg pkg(String key, long amount, boolean taxIncluded) {
        Pkg p = new Pkg(); p.op = "irancell"; p.key = key; p.title = key;
        p.gb = 2; p.days = 30; p.toman = amount; p.normalizedToman = amount;
        p.currencyKnown = true; p.ambig = false; p.taxKnown = true; p.taxIncluded = taxIncluded;
        p.ts = System.currentTimeMillis(); p.observedAt = p.ts;
        p.restricted = false; p.why = ""; p.identityKind = "DATA"; p.identityTitle = key;
        return p;
    }
}
