package app.bastehyab;

import android.content.Context;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.RuntimeEnvironment;
import org.robolectric.annotation.Config;
import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.Collections;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class)
@Config(sdk = 35)
public final class CompareTest {
    private Context context;

    @Before public void setup() throws Exception {
        context = RuntimeEnvironment.getApplication();
        Cfg.sp(context).edit().clear().commit();
        Field cache = Cfg.class.getDeclaredField("cache"); cache.setAccessible(true); cache.set(null, null);
        Cfg.sp(context).edit().putInt("vat", 10).putInt("fresh", 3).putInt("metricModeVersion", 1).commit();
    }

    @Test public void ranksTaxInclusiveOnceAndBasePriceWithVatOnce() {
        Pkg inclusive = pkg("inclusive", 100_000L, true);
        Pkg base = pkg("base", 100_000L, false);
        inclusive.identityLimits = "VAT_INCLUDED";
        base.identityLimits = "VAT_BASE";
        Compare.Result result = Compare.run(context, Arrays.asList(base, inclusive), Collections.<String>emptySet());
        assertEquals(2, result.ranked.size());
        assertEquals("inclusive", result.ranked.get(0).key);
        assertEquals(50_000d, result.val.get("inclusive"), 0.0001d);
        assertEquals(55_000d, result.val.get("base"), 0.0001d);
    }

    @Test public void staleAndOverDurationPackagesAreFiltered() {
        Cfg.sp(context).edit().putInt("fresh", 3).putInt("maxDays", 7).commit();
        Pkg stale = pkg("stale", 100_000L, false);
        stale.identityLimits = "STALE";
        stale.ts = System.currentTimeMillis() - 10L * 86400000L;
        Pkg longDuration = pkg("long", 100_000L, false);
        longDuration.identityLimits = "LONG";
        longDuration.days = 30;
        Compare.Result result = Compare.run(context, Arrays.asList(stale, longDuration), Collections.<String>emptySet());
        assertTrue(result.ranked.isEmpty());
    }

    @Test public void ambiguousAndRejectedRecordsNeverEnterRanking() {
        Pkg ambiguous = pkg("ambiguous", 100_000L, false); ambiguous.ambig = true;
        Pkg rejected = pkg("rejected", 100_000L, false); rejected.reviewStatus = "rejected";
        Compare.Result result = Compare.run(context, Arrays.asList(ambiguous, rejected), Collections.<String>emptySet());
        assertTrue(result.ranked.isEmpty());
        assertEquals(1, result.ambig.size());
    }


    @Test public void rejectsNonFiniteDimensionsAndKeepsInvalidPricesOutOfRanking() {
        Pkg nan = pkg("nan", 100_000L, false); nan.gb = Double.NaN;
        Pkg infinite = pkg("infinite", 100_000L, false); infinite.days = Double.POSITIVE_INFINITY;
        Pkg noPrice = pkg("no-price", 100_000L, false); noPrice.normalizedToman = 0;
        Pkg overflow = pkg("overflow", Long.MAX_VALUE, false); overflow.normalizedToman = Long.MAX_VALUE;
        Compare.Result result = Compare.run(context, Arrays.asList(nan, infinite, noPrice, overflow), Collections.<String>emptySet());
        assertTrue(result.ranked.isEmpty());
        assertEquals(4, result.ambig.size());
    }

    @Test public void taxBasisPreventsFalseDuplicateAndVatIsAppliedOnce() {
        Pkg included = pkg("same", 100_000L, true);
        Pkg excluded = pkg("same", 100_000L, false);
        included.identityTitle = excluded.identityTitle = "بسته ۲ گیگ ۳۰ روزه";
        included.key = "included"; excluded.key = "excluded";
        Compare.Result result = Compare.run(context, Arrays.asList(included, excluded), Collections.<String>emptySet());
        assertEquals(2, result.ranked.size());
        assertEquals(50_000d, result.val.get("included"), 0.0001d);
        assertEquals(55_000d, result.val.get("excluded"), 0.0001d);
        assertEquals(110_000L, Cfg.finalPrice(context, excluded));
    }

    @Test public void combinedOperatorFreshnessVolumeDurationBucketAndSpecialFilters() {
        Cfg.sp(context).edit().putInt("fresh", 3).putInt("maxDays", 35).putInt("bucket", 2)
                .putFloat("minGb", 1f).putBoolean("restricted", false).putBoolean("intl", false).commit();
        Pkg good = pkg("good", 100_000L, false); good.gb = 2; good.days = 30;
        Pkg small = pkg("small", 100_000L, false); small.gb = 0.5;
        Pkg long = pkg("long", 100_000L, false); long.days = 40;
        Pkg stale = pkg("stale", 100_000L, false); stale.ts -= 10L * 86400000L;
        Pkg restricted = pkg("restricted", 100_000L, false); restricted.restricted = true; restricted.why = "شبانه";
        Pkg intl = pkg("intl", 100_000L, false); intl.why = Extractor.INTL_WHY; intl.restricted = true;
        Compare.Result domestic = Compare.run(context, Arrays.asList(good, small, long, stale, restricted, intl), Collections.<String>emptySet());
        assertEquals(1, domestic.ranked.size());
        assertEquals("good", domestic.ranked.get(0).key);
        Cfg.sp(context).edit().putBoolean("intl", true).commit();
        Compare.Result withIntl = Compare.run(context, Arrays.asList(good, intl), Collections.<String>emptySet());
        assertEquals(2, withIntl.ranked.size());
    }

    @Test public void rankingOrderMatchesTheSelectedMetric() {
        Cfg.sp(context).edit().putInt("metric", Cfg.PER_GB).commit();
        Pkg lowPerGb = pkg("low-per-gb", 100_000L, false); lowPerGb.gb = 5;
        Pkg highPerGb = pkg("high-per-gb", 100_000L, false); highPerGb.gb = 2;
        Compare.Result perGb = Compare.run(context, Arrays.asList(highPerGb, lowPerGb), Collections.<String>emptySet());
        assertEquals("low-per-gb", perGb.ranked.get(0).key);
        Cfg.sp(context).edit().putInt("metric", Cfg.DURATION).commit();
        Pkg week = pkg("week", 100_000L, false); week.days = 7;
        Pkg month = pkg("month", 100_000L, false); month.days = 30;
        Compare.Result duration = Compare.run(context, Arrays.asList(week, month), Collections.<String>emptySet());
        assertEquals("month", duration.ranked.get(0).key);
    }

    private static Pkg pkg(String key, long amount, boolean taxIncluded) {
        Pkg p = new Pkg(); p.op = "irancell"; p.key = key; p.title = key;
        p.gb = 2; p.days = 30; p.toman = amount; p.normalizedToman = amount;
        p.currencyKnown = true; p.ambig = false; p.taxKnown = true; p.taxIncluded = taxIncluded;
        p.ts = System.currentTimeMillis(); p.observedAt = p.ts;
        p.restricted = false; p.why = ""; p.identityKind = "DATA"; p.identityTitle = key;
        return p;
    }
}
