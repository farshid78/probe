package app.bastehyab;

/**
 * One shared, operator-neutral scroll policy for Irancell, MCI, Rightel, Samantel and Shatel.
 * Operator-specific parsing must not fork this state machine or its end-of-list rules.
 */
final class ScanStrategyPolicy {
    private ScanStrategyPolicy() {}

    /** First attempt the accessibility list action; verify movement in a later viewport read. */
    static boolean shouldUseAccessibilityActionFirst(int strategy) {
        return strategy <= 0;
    }

    /** After an unchanged viewport, try a list-region gesture; broaden after repeated stalls. */
    static boolean shouldPreferAppViewportSwipe(int strategy) {
        return strategy >= 2;
    }
}
