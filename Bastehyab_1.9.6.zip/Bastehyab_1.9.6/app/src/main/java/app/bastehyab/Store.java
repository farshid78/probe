package app.bastehyab;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.system.Os;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

/**
 * Small in-process package repository.
 *
 * Ownership rules:
 * - LOCK owns the map and repository metadata. No map value or mutable Pkg escapes it.
 * - Callers own input Pkg instances; upsert/update copy them before storing.
 * - The single STORE_IO thread owns every load, JSON encode/decode, preference history write,
 *   fsync and file rename. Public APIs never wait for this executor.
 * - Mutations capture only a short, deep-copied map snapshot while holding LOCK.
 */
final class Store {
    private static final String TAG = "BastehyabStore";
    private static final Object LOCK = new Object();
    private static final Map<String, Pkg> records = new LinkedHashMap<>();
    private static final int SCHEMA_VERSION = 4;
    private static final int MAX_RECORDS = 2500;
    // Keep 200 slots available for pending/reviewed/restricted offers before normal scans are capped.
    private static final int NORMAL_RECORD_LIMIT = MAX_RECORDS - 200;
    private static final long MAX_FILE_BYTES = 8L * 1024L * 1024L;
    private static final long RETRY_DELAY_MS = 2500L;

    private static final ScheduledExecutorService STORE_IO = Executors.newSingleThreadScheduledExecutor(
            new ThreadFactory() {
                @Override public Thread newThread(Runnable r) {
                    Thread t = new Thread(r, "Bastehyab-StoreIO");
                    t.setDaemon(true);
                    return t;
                }
            });
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static final List<Runnable> loadCallbacks = new ArrayList<>();

    private static boolean loadScheduled;
    private static boolean loadComplete;
    private static boolean writerQueued;
    private static boolean saveRequested;
    private static boolean clearAllDuringLoad;
    private static final Set<String> clearedOpsDuringLoad = new HashSet<>();
    private static long mutationVersion;
    private static long lastPersistedVersion;
    private static int quarantinedRecords;
    private static int rejectedAtCapacity;
    private static int identityMerges;
    private static volatile String lastDiagnosticCode = "OK";

    private static File primary(Context c) {
        return new File(c.getApplicationContext().getFilesDir(), "data.json");
    }
    private static File backup(Context c) {
        return new File(c.getApplicationContext().getFilesDir(), "data.json.bak");
    }

    private static void diagnostic(String code) {
        lastDiagnosticCode = code;
        // Codes only. Never log package titles, page text, identifiers or serialized records.
        Log.w(TAG, code);
    }

    /** Starts disk loading once. Loading is asynchronous and never blocks a caller/UI thread. */
    private static void ensureLoad(Context c) {
        if (c == null) return;
        Context app = c.getApplicationContext();
        synchronized (LOCK) {
            if (loadScheduled) return;
            loadScheduled = true;
        }
        STORE_IO.execute(() -> loadFromDisk(app));
    }

    /** Notify the caller on the main looper once the first disk load/recovery has completed. */
    static void whenLoaded(Context c, Runnable callback) {
        if (callback == null) return;
        ensureLoad(c);
        boolean now;
        synchronized (LOCK) {
            now = loadComplete;
            if (!now) loadCallbacks.add(callback);
        }
        if (now) MAIN.post(callback);
    }

    private static final class LoadResult {
        final List<Pkg> items = new ArrayList<>();
        int quarantine;
        int identityMerged;
        final List<Pkg[]> migrationHistory = new ArrayList<>();
        int schemaVersion;
        boolean fatal;
        boolean migrate;
        boolean recovered;
        String fatalCode = "STORE_LOAD_INVALID";
    }

    private static void loadFromDisk(Context c) {
        LoadResult result = readDatabase(primary(c), c);
        if (!primary(c).exists() && backup(c).exists()) {
            result = new LoadResult();
            result.fatal = true;
            result.fatalCode = "STORE_PRIMARY_MISSING";
        }
        if (result.fatal && backup(c).exists()) {
            LoadResult recovery = readDatabase(backup(c), c);
            if (!recovery.fatal) {
                recovery.recovered = true;
                recovery.migrate = true;
                result = recovery;
                diagnostic("STORE_BACKUP_RECOVERED");
            } else if (primary(c).exists() || backup(c).exists()) {
                diagnostic("STORE_PRIMARY_AND_BACKUP_INVALID");
            }
        }
        if (result.fatal) {
            result.items.clear();
            diagnostic(result.fatalCode);
        }

        boolean shouldSave = result.migrate || result.recovered || result.quarantine > 0
                || result.identityMerged > 0;
        List<Runnable> callbacks;
        List<Pkg[]> migrationHistory = new ArrayList<>();
        boolean overCapacity;
        synchronized (LOCK) {
            if (!clearAllDuringLoad) {
                for (Pkg loaded : result.items) {
                    if (clearedOpsDuringLoad.contains(loaded.op)) continue;
                    Pkg existing = records.get(loaded.key);
                    if (existing == null || loaded.ts >= existing.ts) records.put(loaded.key, loaded.copy());
                }
                for (Pkg[] change : result.migrationHistory) {
                    if (change != null && change.length == 2 && change[1] != null
                            && !clearedOpsDuringLoad.contains(change[1].op)) migrationHistory.add(change);
                }
            } else {
                shouldSave = true;
            }
            quarantinedRecords += result.quarantine;
            identityMerges += result.identityMerged;
            overCapacity = records.size() > MAX_RECORDS;
            loadComplete = true;
            clearedOpsDuringLoad.clear();
            callbacks = new ArrayList<>(loadCallbacks);
            loadCallbacks.clear();
            if (shouldSave) {
                saveRequested = true;
                scheduleWriterLocked(c);
            }
        }
        // Migration history is emitted after map ownership ends and on the STORE_IO thread.
        for (Pkg[] change : migrationHistory) HistoryLog.record(c, change[0], change[1]);
        if (result.quarantine > 0) diagnostic("STORE_RECORDS_QUARANTINED_" + result.quarantine);
        if (result.identityMerged > 0) diagnostic("STORE_IDENTITY_MERGED_" + result.identityMerged);
        if (overCapacity) diagnostic("STORE_OVER_CAPACITY_LEGACY_DATA");
        for (Runnable callback : callbacks) MAIN.post(callback);
    }

    private static LoadResult readDatabase(File file, Context context) {
        LoadResult out = new LoadResult();
        if (file == null || !file.exists()) return out;
        try {
            if (file.length() == 0L) {
                out.fatal = true;
                out.fatalCode = "STORE_EMPTY_FILE";
                return out;
            }
            if (file.length() > MAX_FILE_BYTES) {
                out.fatal = true;
                out.fatalCode = "STORE_FILE_TOO_LARGE";
                return out;
            }
            String json = readUtf8(file);
            JSONArray array;
            boolean legacy = false;
            if (json.trim().startsWith("[")) {
                // Version 1 was a bare JSONArray. It is migrated on the next successful write.
                array = new JSONArray(json);
                legacy = true;
                out.schemaVersion = 1;
            } else {
                JSONObject root = new JSONObject(json);
                int version = root.getInt("schemaVersion");
                out.schemaVersion = version;
                if (version < 2 || version > SCHEMA_VERSION) {
                    out.fatal = true;
                    out.fatalCode = version < SCHEMA_VERSION ? "STORE_SCHEMA_OLD" : "STORE_SCHEMA_NEWER";
                    return out;
                }
                array = root.getJSONArray("records");
                out.migrate = version < SCHEMA_VERSION;
            }
            out.migrate = out.migrate || legacy;
            for (int i = 0; i < array.length(); i++) {
                try {
                    Object value = array.get(i);
                    if (!(value instanceof JSONObject)) throw new IllegalArgumentException("record_type");
                    Pkg p = Pkg.from((JSONObject) value);
                    if (context != null) migrateCurrencyCertainty(p, context);
                    validateRecord(p);
                    sanitizeLoadedRecord(p);
                    addLoadedRecord(out, p);
                } catch (Exception badRecord) {
                    out.quarantine++;
                }
            }
        } catch (Exception badDocument) {
            out.fatal = true;
            out.fatalCode = "STORE_DOCUMENT_INVALID";
        }
        return out;
    }

    private static Pkg findByKey(List<Pkg> values, String key) {
        for (Pkg p : values) if (key.equals(p.key)) return p;
        return null;
    }

    private static String readUtf8(File file) throws Exception {
        StringBuilder sb = new StringBuilder((int) Math.min(file.length(), 1024L * 1024L));
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(
                new FileInputStream(file), StandardCharsets.UTF_8))) {
            char[] buffer = new char[8192];
            int n;
            while ((n = reader.read(buffer)) >= 0) sb.append(buffer, 0, n);
        }
        return sb.toString();
    }

    private static void migrateCurrencyCertainty(Pkg p, Context context) {
        // Compatibility with pre-Prompt5 stores: recover certainty only from explicit unit text
        // or a fixed currency profile. AUTO/unknown records remain ambiguous for human review.
        Op op = Cfg.opById(context, p.op);
        String evidence = Fmt.norm((p.title == null ? "" : p.title) + " " + (p.raw == null ? "" : p.raw));
        boolean explicit = evidence.contains("ریال") || evidence.contains("تومان") || evidence.contains("تومن");
        boolean fixed = op != null && ("IRR".equals(op.cur) || "IRT".equals(op.cur));
        if (!p.currencyKnown && (explicit || fixed)) p.currencyKnown = true;
        if (!p.currencyKnown) {
            p.ambig = true;
            if (p.note == null || p.note.isEmpty()) p.note = "واحد پول از داده ذخیره‌شده قابل تأیید نیست";
        }
    }

    private static void sanitizeLoadedRecord(Pkg p) {
        // Recover classification from this package's own persisted evidence only. It is never
        // an identity input, and raw accessibility text is discarded after migration.
        String evidence = String.valueOf(p.title) + " " + String.valueOf(p.identityTitle)
                + " " + String.valueOf(p.raw) + " " + String.valueOf(p.why);
        String parsedWhy = Extractor.whyOf(evidence, p.days, Extractor.volCount(p.title));
        String why = Extractor.mergeWhy(parsedWhy, p.why);
        if (Extractor.INTL.matcher(Fmt.norm(evidence)).find()) {
            why = Extractor.mergeWhy(Extractor.INTL_WHY, why);
        }
        p.why = why;
        p.restricted = !why.isEmpty();
        if (p.raw != null && !p.raw.isEmpty()) p.raw = "";
        if (p.identityTitle == null || p.identityTitle.trim().isEmpty()) p.identityTitle = p.title;
        if (p.identityKind == null || p.identityKind.trim().isEmpty()
                || PkgIdentity.UNKNOWN_KIND.equals(p.identityKind)) {
            p.identityKind = PkgIdentity.inferKind(p.identityTitle);
        }
        if (p.identityLimits == null || p.identityLimits.isEmpty()) {
            String inferredLimits = PkgIdentity.intrinsicLimits(p.identityTitle);
            // v2 did not persist a card-level limits field. An empty title leaf cannot prove
            // that the complete card had no intrinsic restriction, so retain that uncertainty
            // instead of treating it as a known unrestricted offer.
            p.identityLimits = inferredLimits.isEmpty() && p.identityVersion < PkgIdentity.VERSION
                    ? "LIMITS_UNKNOWN" : inferredLimits;
        }
        // Pre-v3 identity records have no trustworthy provenance bit for `code`; do not promote
        // it to an observed product ID. Store schemaVersion and identityVersion are independent.
        if (p.identityVersion < PkgIdentity.VERSION) {
            p.productIdObserved = false;
            p.identityConflictVariant = false;
        }
        PkgIdentity.normalize(p);
    }

    /** Deduplicate legacy records without discarding conflicting classification or ID evidence. */
    private static void addLoadedRecord(LoadResult result, Pkg incoming) {
        List<Pkg> values = result.items;
        Pkg existing = findByKey(values, incoming.key);
        if (existing == null) { values.add(incoming); return; }

        if (incoming.productIdObserved && existing.productIdObserved
                && !PkgIdentity.sameIdAttributes(existing, incoming)) {
            markIdentityConflict(existing);
            incoming.identityConflict = true;
            incoming.identityConflictReason = "OBSERVED_ID_ATTRIBUTE_MISMATCH";
            incoming.reviewStatus = "pending";
            incoming.note = appendNote(incoming.note, "شناسهٔ بسته با مشخصات متفاوت مشاهده شد؛ بررسی دستی لازم است");
            PkgIdentity.markConflictVariant(incoming);
            Pkg sameVariant = findByKey(values, incoming.key);
            if (sameVariant == null) values.add(incoming);
            else {
                Pkg mergedVariant = mergeSameIdentity(sameVariant, incoming);
                values.set(values.indexOf(sameVariant), mergedVariant);
                result.identityMerged++;
                result.migrationHistory.add(new Pkg[]{sameVariant.copy(), mergedVariant.copy()});
            }
            return;
        }
        Pkg merged = mergeSameIdentity(existing, incoming);
        values.set(values.indexOf(existing), merged);
        result.identityMerged++;
        result.migrationHistory.add(new Pkg[]{existing.copy(), merged.copy()});
    }

    private static Pkg mergeSameIdentity(Pkg old, Pkg fresh) {
        boolean classificationDiff = !PkgIdentity.classificationSignature(old.why)
                .equals(PkgIdentity.classificationSignature(fresh.why));
        Pkg primary = PkgIdentity.observedAt(fresh) > PkgIdentity.observedAt(old) ? fresh : old;
        Pkg merged = primary.copy();
        if (classificationDiff || old.classificationConflict || fresh.classificationConflict) {
            String primaryWhy = PkgIdentity.observedAt(old) <= PkgIdentity.observedAt(fresh) ? old.why : fresh.why;
            merged.why = primaryWhy == null ? "" : primaryWhy;
            merged.restricted = !merged.why.isEmpty();
            merged.classificationConflict = true;
            merged.classificationVariants = PkgIdentity.mergeClassificationVariants(
                    old.classificationVariants + "\n" + fresh.classificationVariants, old.why, fresh.why);
            merged.reviewStatus = "pending";
            merged.reviewSourceFingerprint = "";
            merged.note = appendNote(merged.note, "تعارض طبقه‌بندی برای یک هویت؛ نسخهٔ قدیمی‌تر به‌عنوان اصلی حفظ شد و بررسی لازم است");
        }
        merged.identityConflict = old.identityConflict || fresh.identityConflict;
        if (merged.identityConflict) {
            merged.identityConflictReason = nonBlank(old.identityConflictReason, fresh.identityConflictReason);
            merged.reviewStatus = "pending";
        }
        return merged;
    }

    private static void markIdentityConflict(Pkg p) {
        p.identityConflict = true;
        p.identityConflictReason = "OBSERVED_ID_ATTRIBUTE_MISMATCH";
        p.reviewStatus = "pending";
        p.reviewSourceFingerprint = "";
        p.note = appendNote(p.note, "شناسهٔ بسته با مشخصات متفاوت مشاهده شد؛ هر دو نسخه برای بررسی حفظ شدند");
    }

    private static String appendNote(String current, String addition) {
        String a = current == null ? "" : current.trim();
        if (a.contains(addition)) return a;
        String result = a.isEmpty() ? addition : a + "؛ " + addition;
        return result.length() > 500 ? result.substring(0, 500) : result;
    }

    private static String nonBlank(String a, String b) {
        return a != null && !a.isEmpty() ? a : (b == null ? "" : b);
    }

    private static boolean newer(Pkg a, Pkg b) {
        long at = PkgIdentity.observedAt(a), bt = PkgIdentity.observedAt(b);
        if (at != bt) return at > bt;
        // On timestamp ties keep the existing record; ties are not evidence of a newer observation.
        return false;
    }

    private static void validateRecord(Pkg p) {
        if (p == null || blank(p.op) || p.op.length() > 128
                || blank(p.key) || p.key.length() > 1024
                || blank(p.title) || p.title.length() > 500
                || (p.code != null && p.code.length() > 256)
                || (p.why != null && p.why.length() > 256)
                || (p.identityTitle != null && p.identityTitle.length() > 500)
                || (p.identityKind != null && p.identityKind.length() > 64)
                || (p.identityLimits != null && p.identityLimits.length() > 256)
                || (p.classificationVariants != null && p.classificationVariants.length() > 1024)
                || (p.identityConflictReason != null && p.identityConflictReason.length() > 128)
                || (p.note != null && p.note.length() > 500)
                || (p.reviewNote != null && p.reviewNote.length() > 240)
                || !finite(p.gb) || p.gb < 0.05 || p.gb > 5000
                || !finite(p.days) || p.days < 0 || p.days > 36500
                || p.toman < 100 || p.toman > 2000000000L
                || p.ts < 0 || p.observedAt < 0 || p.alts == null || p.alts.length > 64) {
            throw new IllegalArgumentException("record_validation");
        }
        for (long alt : p.alts) if (alt < 100 || alt > 2000000000L) {
            throw new IllegalArgumentException("record_alt_validation");
        }
        if (p.rawAmount < 0 || p.normalizedToman < 0 || p.finalToman < 0
                || p.reviewedToman < 0 || p.reviewedAt < 0 || p.vatRate < -1 || p.vatRate > 100) {
            throw new IllegalArgumentException("record_price_validation");
        }
        if (!"UNKNOWN".equals(p.rawCurrency) && !"IRR".equals(p.rawCurrency) && !"IRT".equals(p.rawCurrency)) {
            throw new IllegalArgumentException("record_currency_validation");
        }
        if (!"NONE".equals(p.currencyConfidence) && !"LOW".equals(p.currencyConfidence)
                && !"MEDIUM".equals(p.currencyConfidence) && !"HIGH".equals(p.currencyConfidence)) {
            throw new IllegalArgumentException("record_confidence_validation");
        }
        if (p.identityVersion < 0 || p.identityVersion > PkgIdentity.VERSION
                || (p.productIdObserved && !PkgIdentity.validObservedId(p.code))) {
            throw new IllegalArgumentException("record_identity_validation");
        }
        if (!"none".equals(p.reviewStatus) && !"pending".equals(p.reviewStatus)
                && !"approved".equals(p.reviewStatus) && !"rejected".equals(p.reviewStatus)) {
            throw new IllegalArgumentException("record_review_validation");
        }
        if ("approved".equals(p.reviewStatus) && (!finite(p.reviewedGb) || p.reviewedGb < 0.05
                || p.reviewedGb > 5000 || !finite(p.reviewedDays) || p.reviewedDays < 0
                || p.reviewedDays > 36500 || p.reviewedToman < 100 || p.reviewedToman > 2000000000L)) {
            throw new IllegalArgumentException("record_manual_review_validation");
        }
    }

    private static boolean finite(double value) {
        return !Double.isNaN(value) && !Double.isInfinite(value);
    }
    private static boolean blank(String value) { return value == null || value.trim().isEmpty(); }

    private static boolean isImportant(Pkg p) {
        return p.restricted || p.ambig || "pending".equals(p.reviewStatus)
                || "approved".equals(p.reviewStatus) || "rejected".equals(p.reviewStatus);
    }

    private static List<Pkg> snapshotLocked() {
        List<Pkg> copy = new ArrayList<>(records.size());
        for (Pkg p : records.values()) copy.add(p.copy());
        return copy;
    }

    static final class Snapshot {
        final long version;
        final List<Pkg> records;
        Snapshot(long version, List<Pkg> records) { this.version = version; this.records = records; }
    }

    /** Immutable-in-practice point-in-time snapshot plus its matching mutation generation. */
    static Snapshot snapshotState(Context c) {
        ensureLoad(c);
        synchronized (LOCK) { return new Snapshot(mutationVersion, snapshotLocked()); }
    }

    /** Immutable-in-practice point-in-time snapshot: both the List and every Pkg are detached. */
    static List<Pkg> snapshot(Context c) { return snapshotState(c).records; }

    /** Compatibility API; callers receive the same deep snapshot contract as snapshot(). */
    static List<Pkg> all(Context c) { return snapshot(c); }

    /** Monotonic in-process generation for cheap UI invalidation checks; no disk work is performed. */
    static long version() {
        synchronized (LOCK) { return mutationVersion; }
    }

    private static void scheduleWriterLocked(Context c) {
        if (writerQueued) return;
        writerQueued = true;
        Context app = c == null ? null : c.getApplicationContext();
        STORE_IO.execute(() -> drainWrites(app));
    }

    private static void requestSave(Context c) {
        if (c == null) return;
        synchronized (LOCK) {
            saveRequested = true;
            scheduleWriterLocked(c);
        }
    }

    /** Coalesces bursts: only the latest map snapshot is encoded/written after queued mutations. */
    private static void drainWrites(Context c) {
        if (c == null) {
            synchronized (LOCK) { writerQueued = false; }
            diagnostic("STORE_CONTEXT_UNAVAILABLE");
            return;
        }
        while (true) {
            final List<Pkg> snapshot;
            final long version;
            synchronized (LOCK) {
                if (!saveRequested) {
                    writerQueued = false;
                    return;
                }
                saveRequested = false;
                snapshot = snapshotLocked();
                version = mutationVersion;
            }
            boolean success = writeAtomic(c, snapshot);
            if (!success) {
                synchronized (LOCK) {
                    writerQueued = false;
                    saveRequested = true;
                    STORE_IO.schedule(() -> {
                        synchronized (LOCK) { scheduleWriterLocked(c); }
                    }, RETRY_DELAY_MS, TimeUnit.MILLISECONDS);
                }
                diagnostic("STORE_WRITE_FAILED");
                return;
            }
            boolean recovered;
            synchronized (LOCK) {
                lastPersistedVersion = Math.max(lastPersistedVersion, version);
                recovered = "STORE_WRITE_FAILED".equals(lastDiagnosticCode);
                if (!saveRequested) writerQueued = false;
            }
            if (recovered) diagnostic("STORE_WRITE_RECOVERED");
            synchronized (LOCK) {
                if (!saveRequested) return;
            }
        }
    }

    private static boolean writeAtomic(Context c, List<Pkg> snapshot) {
        File target = primary(c);
        File dir = target.getParentFile();
        File temp = new File(dir, "data.json.tmp");
        File backupTemp = new File(dir, "data.json.bak.tmp");
        File backup = backup(c);
        try {
            JSONObject root = new JSONObject();
            root.put("schemaVersion", SCHEMA_VERSION);
            root.put("recordCount", snapshot.size());
            JSONArray array = new JSONArray();
            for (Pkg p : snapshot) array.put(p.json());
            root.put("records", array);

            writeAndSync(temp, root.toString());

            // Refresh backup only from a fully valid current primary. Never delete a healthy backup
            // just because the current primary cannot be parsed or copied.
            if (target.exists() && isHealthyDatabase(target)) {
                copyAndSync(target, backupTemp);
                Os.rename(backupTemp.getAbsolutePath(), backup.getAbsolutePath());
                syncDirectory(dir);
            }

            // POSIX rename in the same directory atomically replaces target; readers see old or new.
            Os.rename(temp.getAbsolutePath(), target.getAbsolutePath());
            syncDirectory(dir);
            return true;
        } catch (Exception failure) {
            safeDelete(temp);
            safeDelete(backupTemp);
            return false;
        }
    }

    private static void writeAndSync(File file, String contents) throws Exception {
        try (FileOutputStream out = new FileOutputStream(file, false);
             Writer writer = new OutputStreamWriter(out, StandardCharsets.UTF_8)) {
            writer.write(contents);
            writer.flush();
            syncFile(out);
        }
    }

    private static void syncFile(FileOutputStream out) {
        try { out.getFD().sync(); }
        catch (Exception unavailable) { diagnostic("STORE_FSYNC_UNAVAILABLE"); }
    }

    private static void copyAndSync(File source, File dest) throws Exception {
        try (FileInputStream in = new FileInputStream(source);
             FileOutputStream out = new FileOutputStream(dest, false)) {
            byte[] buffer = new byte[8192];
            int count;
            while ((count = in.read(buffer)) >= 0) out.write(buffer, 0, count);
            out.flush();
            syncFile(out);
        }
    }

    private static boolean isHealthyDatabase(File file) {
        LoadResult result = readDatabase(file, null);
        return !result.fatal && result.quarantine == 0;
    }

    private static void syncDirectory(File dir) {
        // Directory fsync is not supported on every Android filesystem; file fsync is mandatory.
        try (FileInputStream in = new FileInputStream(dir)) { in.getFD().sync(); }
        catch (Exception ignored) { /* best effort */ }
    }

    private static void safeDelete(File file) {
        try { if (file != null && file.exists()) file.delete(); }
        catch (RuntimeException ignored) { /* best effort cleanup */ }
    }

    private static boolean validUpsert(Pkg p) {
        try { validateRecord(p); return true; }
        catch (RuntimeException invalid) { return false; }
    }

    private static boolean sameStoredFields(Pkg a, Pkg b) {
        return a != null && b != null
                && java.util.Objects.equals(a.op, b.op)
                && java.util.Objects.equals(a.key, b.key)
                && java.util.Objects.equals(a.title, b.title)
                && java.util.Objects.equals(a.code, b.code)
                && java.util.Objects.equals(a.why, b.why)
                && java.util.Objects.equals(a.identityTitle, b.identityTitle)
                && java.util.Objects.equals(a.identityKind, b.identityKind)
                && java.util.Objects.equals(a.identityLimits, b.identityLimits)
                && a.identityVersion == b.identityVersion && a.productIdObserved == b.productIdObserved
                && a.classificationConflict == b.classificationConflict
                && a.identityConflict == b.identityConflict && a.identityConflictVariant == b.identityConflictVariant
                && java.util.Objects.equals(a.classificationVariants, b.classificationVariants)
                && java.util.Objects.equals(a.identityConflictReason, b.identityConflictReason)
                && java.util.Objects.equals(a.note, b.note)
                && Double.compare(a.gb, b.gb) == 0
                && Double.compare(a.days, b.days) == 0
                && a.toman == b.toman && a.rawAmount == b.rawAmount
                && a.normalizedToman == b.normalizedToman && a.finalToman == b.finalToman
                && a.observedAt == b.observedAt
                && java.util.Objects.equals(a.rawCurrency, b.rawCurrency)
                && java.util.Objects.equals(a.currencyConfidence, b.currencyConfidence)
                && java.util.Objects.equals(a.priceSource, b.priceSource)
                && a.taxIncluded == b.taxIncluded && a.taxKnown == b.taxKnown && a.vatRate == b.vatRate
                && a.restricted == b.restricted && a.ambig == b.ambig
                && a.currencyKnown == b.currencyKnown
                && java.util.Objects.equals(a.reviewStatus, b.reviewStatus)
                && java.util.Objects.equals(a.reviewNote, b.reviewNote)
                && java.util.Objects.equals(a.reviewSourceFingerprint, b.reviewSourceFingerprint)
                && Double.compare(a.reviewedGb, b.reviewedGb) == 0
                && Double.compare(a.reviewedDays, b.reviewedDays) == 0
                && a.reviewedToman == b.reviewedToman && a.reviewedAt == b.reviewedAt
                && java.util.Arrays.equals(a.alts, b.alts);
    }

    // Upsert copies caller-owned records and computes a versioned identity before entering the map lock.
    static int upsert(Context c, List<Pkg> items) {
        ensureLoad(c);
        if (items == null || items.isEmpty()) return 0;
        List<Pkg> incoming = new ArrayList<>(items.size());
        for (Pkg item : items) if (item != null) {
            Pkg copy = item.copy();
            copy.raw = "";
            if (copy.identityTitle == null || copy.identityTitle.trim().isEmpty()) copy.identityTitle = copy.title;
            if (copy.identityKind == null || copy.identityKind.trim().isEmpty()
                    || PkgIdentity.UNKNOWN_KIND.equals(copy.identityKind)) copy.identityKind = PkgIdentity.inferKind(copy.identityTitle);
            if (copy.observedAt <= 0 && copy.ts <= 0) copy.observedAt = System.currentTimeMillis();
            PkgIdentity.normalize(copy);
            if (validUpsert(copy)) incoming.add(copy);
        }
        if (incoming.isEmpty()) return 0;

        int changed = 0;
        boolean writeNeeded = false;
        long now = System.currentTimeMillis();
        List<Pkg[]> history = new ArrayList<>();
        synchronized (LOCK) {
            for (Pkg candidate : incoming) {
                Pkg p = candidate.copy();
                Pkg old = records.get(p.key);

                // An explicit package ID is authoritative, but contradictory volume/duration/kind
                // evidence is preserved as a deterministic conflict variant, never silently merged.
                if (old != null && p.productIdObserved && old.productIdObserved
                        && !PkgIdentity.sameIdAttributes(old, p)) {
                    Pkg primaryBefore = old.copy();
                    markIdentityConflict(old);
                    records.put(old.key, old.copy());
                    history.add(new Pkg[]{primaryBefore, old.copy()});
                    mutationVersion++;
                    saveRequested = true;
                    writeNeeded = true;
                    p.identityConflict = true;
                    p.identityConflictReason = "OBSERVED_ID_ATTRIBUTE_MISMATCH";
                    p.reviewStatus = "pending";
                    p.reviewSourceFingerprint = "";
                    p.note = appendNote(p.note, "شناسهٔ بسته با مشخصات متفاوت مشاهده شد؛ هر دو نسخه برای بررسی حفظ شدند");
                    PkgIdentity.markConflictVariant(p);
                    old = records.get(p.key);
                }

                if (old == null && records.size() >= (isImportant(p) ? MAX_RECORDS : NORMAL_RECORD_LIMIT)) {
                    rejectedAtCapacity++;
                    continue;
                }
                Pkg toStore;
                if (old != null) {
                    boolean classificationDiff = !PkgIdentity.classificationSignature(old.why)
                            .equals(PkgIdentity.classificationSignature(p.why));
                    boolean useIncoming = newer(p, old) || PkgIdentity.observedAt(p) == PkgIdentity.observedAt(old)
                            && observationQuality(p) > observationQuality(old);
                    toStore = (useIncoming ? p : old).copy();
                    if (classificationDiff || old.classificationConflict || p.classificationConflict) {
                        // Preserve the older classification as the canonical label and expose all
                        // observed labels in the review queue rather than minting another identity.
                        toStore.why = PkgIdentity.observedAt(old) <= PkgIdentity.observedAt(p) ? old.why : p.why;
                        toStore.restricted = toStore.why != null && !toStore.why.isEmpty();
                        toStore.classificationConflict = true;
                        toStore.classificationVariants = PkgIdentity.mergeClassificationVariants(
                                old.classificationVariants + "\n" + p.classificationVariants, old.why, p.why);
                        toStore.reviewStatus = "pending";
                        toStore.reviewSourceFingerprint = "";
                        toStore.note = appendNote(toStore.note, "تعارض طبقه‌بندی برای یک هویت؛ بررسی دستی لازم است");
                    } else if (("approved".equals(old.reviewStatus) || "rejected".equals(old.reviewStatus))
                            && old.sourceFingerprint().equals(p.sourceFingerprint())) {
                        toStore.reviewStatus = old.reviewStatus; toStore.reviewNote = old.reviewNote;
                        toStore.reviewSourceFingerprint = old.reviewSourceFingerprint;
                        toStore.reviewedGb = old.reviewedGb; toStore.reviewedDays = old.reviewedDays;
                        toStore.reviewedToman = old.reviewedToman; toStore.reviewedAt = old.reviewedAt;
                    } else if (toStore.ambig || !toStore.currencyKnown) {
                        toStore.reviewStatus = "pending";
                    }
                    toStore.identityConflict = old.identityConflict || p.identityConflict;
                    if (toStore.identityConflict) {
                        toStore.identityConflictReason = nonBlank(old.identityConflictReason, p.identityConflictReason);
                        toStore.reviewStatus = "pending";
                    }
                    history.add(new Pkg[]{old.copy(), toStore.copy()});
                } else {
                    toStore = p.copy();
                    if (toStore.ambig || !toStore.currencyKnown || toStore.classificationConflict || toStore.identityConflict)
                        toStore.reviewStatus = "pending";
                }

                if (old == null || old.toman != toStore.toman || Math.abs(old.gb - toStore.gb) > 1e-9
                        || old.days != toStore.days || old.restricted != toStore.restricted
                        || old.ambig != toStore.ambig || old.currencyKnown != toStore.currencyKnown
                        || old.classificationConflict != toStore.classificationConflict
                        || old.identityConflict != toStore.identityConflict) changed++;
                toStore.ts = old == null ? now : (newer(p, old)
                        || PkgIdentity.observedAt(p) == PkgIdentity.observedAt(old)
                        && observationQuality(p) > observationQuality(old) ? now : old.ts);
                if (old == null || old.ts != toStore.ts || !sameStoredFields(old, toStore)) {
                    records.put(toStore.key, toStore.copy());
                    mutationVersion++;
                    saveRequested = true;
                    writeNeeded = true;
                }
            }
        }
        if (rejectedAtCapacity > 0) diagnostic("STORE_CAPACITY_REACHED");
        Context app = c == null ? null : c.getApplicationContext();
        for (Pkg[] pair : history) STORE_IO.execute(() -> HistoryLog.record(app, pair[0], pair[1]));
        if (writeNeeded) requestSave(app);
        return changed;
    }

    private static int observationQuality(Pkg p) {
        int score = 0;
        if (p.currencyKnown) score += 8;
        if (p.taxKnown) score += 4;
        if (p.normalizedToman > 0) score += 2;
        if (!p.ambig) score += 1;
        return score;
    }

    /** Explicit update API: mutator receives a detached copy; only a validated copy is committed. */
    static boolean update(Context c, String key, Consumer<Pkg> mutator) {
        ensureLoad(c);
        if (blank(key) || mutator == null) return false;
        boolean[] changed = {false};
        synchronized (LOCK) {
            Pkg current = records.get(key);
            if (current == null) return false;
            Pkg candidate = current.copy();
            mutator.accept(candidate);
            candidate.raw = "";
            PkgIdentity.normalize(candidate);
            // Mutations may change prices/review but may not silently move a map entry to a new identity.
            if (!java.util.Objects.equals(candidate.key, key)) return false;
            if (!validUpsert(candidate)) return false;
            if (!sameStoredFields(current, candidate)) {
                records.put(key, candidate.copy());
                mutationVersion++;
                changed[0] = true;
            }
        }
        if (changed[0]) requestSave(c);
        return changed[0];
    }

    /** Enqueue a final snapshot write. This method never waits for disk and is safe from lifecycle callbacks. */
    static void flush(Context c) {
        ensureLoad(c);
        requestSave(c);
    }

    static List<Pkg> reviewQueue(Context c) {
        List<Pkg> out = new ArrayList<>();
        for (Pkg p : snapshot(c)) {
            boolean approvalCurrent = p.hasCurrentManualApproval();
            if ((p.ambig || !p.currencyKnown || p.classificationConflict || p.identityConflict) && !approvalCurrent
                    && !"rejected".equals(p.reviewStatus)) out.add(p);
        }
        out.sort((a, b) -> Long.compare(b.ts, a.ts));
        return out;
    }

    /** Persists a review through the same mutation/snapshot queue as scan updates. */
    static boolean saveReview(Context c, String key, boolean approve,
                              double gb, double days, long toman, String note) {
        if (approve && (!finite(gb) || gb < 0.05 || gb > 5000 || !finite(days)
                || days < 0 || days > 36500 || toman < 100 || toman > 2000000000L)) return false;
        final Pkg[] changed = {null};
        boolean saved = update(c, key, p -> {
            p.reviewStatus = approve ? "approved" : "rejected";
            String safeNote = note == null ? "" : note.trim();
            p.reviewNote = safeNote.length() > 240 ? safeNote.substring(0, 240) : safeNote;
            p.reviewedAt = System.currentTimeMillis();
            p.reviewSourceFingerprint = p.sourceFingerprint();
            if (approve) {
                p.reviewedGb = gb; p.reviewedDays = days; p.reviewedToman = toman;
            } else {
                p.reviewedGb = 0; p.reviewedDays = 0; p.reviewedToman = 0;
            }
            changed[0] = p.copy();
        });
        if (saved && changed[0] != null) {
            Pkg p = changed[0];
            Context app = c == null ? null : c.getApplicationContext();
            STORE_IO.execute(() -> HistoryLog.recordReview(app, p, approve));
        }
        return saved;
    }

    static void clearOp(Context c, String opId) {
        ensureLoad(c);
        if (blank(opId)) return;
        synchronized (LOCK) {
            if (!loadComplete) clearedOpsDuringLoad.add(opId);
            Iterator<Pkg> it = records.values().iterator();
            while (it.hasNext()) if (opId.equals(it.next().op)) it.remove();
            mutationVersion++;
            saveRequested = true;
        }
        requestSave(c);
    }

    static void reprice(Context c, String opId, int policy) {
        if (blank(opId) || (policy != 1 && policy != 2)) return;
        ensureLoad(c);
        synchronized (LOCK) {
            for (Pkg existing : records.values()) {
                if (!opId.equals(existing.op) || existing.alts == null || existing.alts.length < 2) continue;
                Pkg p = existing.copy();
                long best = p.alts[0];
                for (long amount : p.alts) best = policy == 1 ? Math.max(best, amount) : Math.min(best, amount);
                p.toman = best;
                // Keep the Prompt5 canonical price synchronized with the selected raw alternative.
                if (p.currencyKnown && p.normalizedToman > 0) p.normalizedToman = best;
                p.finalToman = p.taxIncluded ? best : 0L;
                records.put(p.key, p);
                mutationVersion++;
            }
            saveRequested = true;
        }
        requestSave(c);
    }

    static void clearAll(Context c) {
        ensureLoad(c);
        synchronized (LOCK) {
            if (!loadComplete) clearAllDuringLoad = true;
            clearedOpsDuringLoad.clear();
            records.clear();
            mutationVersion++;
            saveRequested = true;
        }
        requestSave(c);
        // Serialize history deletion behind already queued history writes. This prevents an
        // in-flight scan/review from recreating history after the user clears all local data.
        Context app = c == null ? null : c.getApplicationContext();
        if (app != null) STORE_IO.execute(() -> HistoryLog.clear(app));
    }

    /** Non-sensitive operational diagnostics; no package/page values are returned. */
    static String diagnostics() {
        synchronized (LOCK) {
            return "code=" + lastDiagnosticCode + ", quarantined=" + quarantinedRecords
                    + ", identityMerged=" + identityMerges + ", capacityRejected=" + rejectedAtCapacity
                    + ", records=" + records.size() + ", persistedVersion=" + lastPersistedVersion
                    + ", mutationVersion=" + mutationVersion;
        }
    }
}
