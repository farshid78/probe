package app.bastehyab;

import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.ColorFilter;
import android.graphics.drawable.Drawable;

/**
 * Soft-UI (neumorphic) surface used by every card, button, chip, input and switch.
 *
 * Shadows are approximated with a few stacked, low-alpha rounded rectangles instead of
 * BlurMaskFilter / setShadowLayer, because those are unreliable on hardware-accelerated
 * canvases below API 28 (minSdk is 24). Only drawRoundRect/drawPath/clipPath are used.
 *
 * RAISED: light shadow top-left, dark shadow bottom-right (drawn OUTSIDE the bounds, so the
 *         parents in the view tree must not clip children; see UI.unclip()).
 * INSET : the surface looks pressed into the panel (inner dark edge top-left, inner light
 *         edge bottom-right). Everything is drawn inside the bounds.
 * FLAT  : gradient body with hairline border and optional glow; no external shadow.
 */
final class NeuDrawable extends Drawable {
    static final int RAISED = 0, INSET = 1, FLAT = 2;
    private static final int LAYERS = 5;

    private final int mode;
    private final float radius;      // px
    private final float depth;       // px, shadow reach
    private final int top, bottom;   // body gradient (TL -> BR)
    private final int lightShadow, darkShadow;
    private final int strokeColor;   // 0 = none
    private final float strokeWidth; // px
    private final int glowColor;     // 0 = none
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private final Path clip = new Path();
    private int alpha = 255;
    private Shader bodyShader;
    private Shader strokeShader;
    private int shaderW = -1, shaderH = -1;

    NeuDrawable(int mode, float radiusPx, float depthPx, int top, int bottom,
                int lightShadow, int darkShadow, int strokeColor, float strokeWidthPx, int glowColor) {
        this.mode = mode;
        this.radius = radiusPx;
        this.depth = depthPx;
        this.top = top;
        this.bottom = bottom;
        this.lightShadow = lightShadow;
        this.darkShadow = darkShadow;
        this.strokeColor = strokeColor;
        this.strokeWidth = strokeWidthPx;
        this.glowColor = glowColor;
    }

    private static int withAlpha(int color, float a) {
        int base = color >>> 24;
        int v = Math.max(0, Math.min(255, Math.round(base * a)));
        return (v << 24) | (color & 0x00FFFFFF);
    }

    @Override protected void onBoundsChange(android.graphics.Rect b) {
        super.onBoundsChange(b);
        shaderW = -1; // rebuild lazily
    }

    private void buildShaders(RectF r) {
        int w = Math.max(1, Math.round(r.width())), h = Math.max(1, Math.round(r.height()));
        if (w == shaderW && h == shaderH && bodyShader != null) return;
        shaderW = w; shaderH = h;
        bodyShader = new LinearGradient(r.left, r.top, r.right, r.bottom, top, bottom, Shader.TileMode.CLAMP);
        if (strokeColor != 0 && mode != INSET) {
            // The hairline is brighter on the lit (top-left) side and fades towards the shade side.
            strokeShader = new LinearGradient(r.left, r.top, r.right, r.bottom,
                    strokeColor, withAlpha(strokeColor, .25f), Shader.TileMode.CLAMP);
        } else {
            strokeShader = null;
        }
    }

    @Override public void draw(Canvas canvas) {
        Rect0.set(rect, getBounds());
        if (rect.width() <= 1 || rect.height() <= 1) return;
        float rad = Math.min(radius, Math.min(rect.width(), rect.height()) / 2f);
        buildShaders(rect);
        float a = alpha / 255f;

        if (mode == RAISED && depth > 0) {
            float off = depth * .42f;
            for (int i = LAYERS; i >= 1; i--) {
                float t = (float) i / LAYERS;
                float grow = depth * t * .75f;
                float k = (1f - t) * (1f - t) * .9f + .08f;     // soft falloff, strongest near the edge
                paint.setShader(null);
                paint.setStyle(Paint.Style.FILL);
                paint.setColor(withAlpha(darkShadow, k * .23f * a));
                canvas.drawRoundRect(rect.left - grow + off, rect.top - grow + off,
                        rect.right + grow + off, rect.bottom + grow + off, rad + grow, rad + grow, paint);
                paint.setColor(withAlpha(lightShadow, k * .19f * a));
                canvas.drawRoundRect(rect.left - grow - off, rect.top - grow - off,
                        rect.right + grow - off, rect.bottom + grow - off, rad + grow, rad + grow, paint);
            }
        }

        if (mode == RAISED && glowColor != 0) drawGlow(canvas, rad, a);

        // Body.
        paint.setStyle(Paint.Style.FILL);
        paint.setShader(bodyShader);
        paint.setAlpha(Math.round(255 * a));
        canvas.drawRoundRect(rect, rad, rad, paint);
        paint.setShader(null);

        if (mode == INSET) drawInnerShadow(canvas, rad, a);
        if (mode == FLAT && glowColor != 0) drawGlow(canvas, rad, a);

        if (strokeColor != 0 && strokeWidth > 0) {
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(strokeWidth);
            float half = strokeWidth / 2f;
            if (strokeShader != null) paint.setShader(strokeShader); else paint.setColor(withAlpha(strokeColor, a));
            canvas.drawRoundRect(rect.left + half, rect.top + half, rect.right - half, rect.bottom - half,
                    Math.max(0, rad - half), Math.max(0, rad - half), paint);
            paint.setShader(null);
        }
        if (mode == INSET && glowColor != 0) {
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(Math.max(1f, strokeWidth));
            paint.setColor(withAlpha(glowColor, .55f * a));
            float half = Math.max(1f, strokeWidth) / 2f;
            canvas.drawRoundRect(rect.left + half, rect.top + half, rect.right - half, rect.bottom - half,
                    Math.max(0, rad - half), Math.max(0, rad - half), paint);
        }
        paint.setStyle(Paint.Style.FILL);
    }

    /** Coloured neon halo just outside the body (used by primary buttons and active items). */
    private void drawGlow(Canvas canvas, float rad, float a) {
        float reach = Math.max(depth, strokeWidth * 4f);
        paint.setShader(null);
        paint.setStyle(Paint.Style.STROKE);
        for (int i = 1; i <= 5; i++) {
            float t = (float) i / 5f;
            float w = reach * t * .6f;
            paint.setStrokeWidth(w * 2f);
            paint.setColor(withAlpha(glowColor, (1f - t) * (1f - t) * .32f * a));
            canvas.drawRoundRect(rect.left - w * .5f, rect.top - w * .5f + depth * .15f,
                    rect.right + w * .5f, rect.bottom + w * .5f + depth * .15f, rad + w * .5f, rad + w * .5f, paint);
        }
        paint.setStyle(Paint.Style.FILL);
    }

    private void drawInnerShadow(Canvas canvas, float rad, float a) {
        float reach = Math.max(2f, depth);
        clip.reset();
        clip.addRoundRect(rect, rad, rad, Path.Direction.CW);
        canvas.save();
        canvas.clipPath(clip);
        paint.setShader(null);
        paint.setStyle(Paint.Style.STROKE);
        for (int i = 0; i < LAYERS; i++) {
            float t = (float) i / LAYERS;
            float w = reach * .5f;
            float shift = reach * .30f + reach * t * .55f;
            float k = (1f - t) * (1f - t);
            paint.setStrokeWidth(w * 2f);
            paint.setColor(withAlpha(darkShadow, k * .30f * a));
            canvas.drawRoundRect(rect.left - w + shift, rect.top - w + shift,
                    rect.right + w + shift, rect.bottom + w + shift, rad, rad, paint);
            paint.setColor(withAlpha(lightShadow, k * .20f * a));
            canvas.drawRoundRect(rect.left - w - shift, rect.top - w - shift,
                    rect.right + w - shift, rect.bottom + w - shift, rad, rad, paint);
        }
        canvas.restore();
        paint.setStyle(Paint.Style.FILL);
    }

    private int intrinsicW = -1, intrinsicH = -1;
    void setIntrinsicSize(int w, int h) { intrinsicW = w; intrinsicH = h; }
    @Override public int getIntrinsicWidth() { return intrinsicW; }
    @Override public int getIntrinsicHeight() { return intrinsicH; }

    @Override public void setAlpha(int alpha) { this.alpha = alpha; invalidateSelf(); }
    @Override public void setColorFilter(ColorFilter colorFilter) { paint.setColorFilter(colorFilter); invalidateSelf(); }
    @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }

    /** Tiny helper kept separate so the class compiles against minimal test stubs too. */
    private static final class Rect0 {
        static void set(RectF out, android.graphics.Rect b) { out.set(b.left, b.top, b.right, b.bottom); }
    }
}
