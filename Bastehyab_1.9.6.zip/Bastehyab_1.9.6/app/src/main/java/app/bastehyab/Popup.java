package app.bastehyab;

import android.content.Context;
import android.graphics.PixelFormat;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.text.TextUtils;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.RejectedExecutionException;

/** Floating comparison card drawn as an accessibility overlay (no extra permission needed). */
final class Popup {
    private final Context c;
    private final WindowManager wm;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final ExecutorService rankWorker = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "Bastehyab-PopupRank");
        t.setDaemon(true);
        return t;
    });
    private volatile int rankGeneration;
    private final Runnable autoHide = this::hide;
    private LinearLayout root;
    private LinearLayout popupContent;
    private UI.BoundedScrollView popupScroll;
    private int popupWindowWidth = -1, popupWindowHeight = -1;
    private float popupWindowFontScale = -1f;
    /** Comparison overlay position is kept independently from the scan-control panel. */
    private int popupSavedX, popupSavedY;
    private boolean popupPositionSaved;
    private WindowManager.LayoutParams lp;
    private boolean attached, compact;
    private Runnable onClose;
    private Compare.Result last;
    private Set<String> screen;
    private String lastSig = "";
    private static volatile long overlayAt;

    /** True right after one of our own overlays was added/removed (it may raise a window event). */
    static boolean recentOverlayChange() {
        return android.os.SystemClock.elapsedRealtime() - overlayAt < 1500L;
    }

    private View confirmRoot;
    private LinearLayout confirmPanel;
    private WindowManager.LayoutParams confirmParams;
    private boolean confirmAttached;
    private boolean confirmTouchBlocked;
    /** Last successful WindowManager health check; throttles checks during noisy accessibility events. */
    private long confirmLastVerifiedAt;
    private int confirmMode = -1; // 0: waiting, 1: scanning, 2: paused
    private String confirmOperator = "";
    private String confirmError = "";
    private int confirmWindowWidth = -1, confirmWindowHeight = -1;
    private float confirmWindowFontScale = -1f;
    private ProgressBar confirmProgress;
    private TextView confirmProgressLabel;
    private TextView confirmStatus;
    private TextView confirmDetails;
    /** Last position chosen by the user; reused when the panel is rebuilt for a new mode. */
    private int savedX = -1, savedY = -1;

    /**
     * View.isAttachedToWindow() stays false until the first traversal AFTER WindowManager.addView(),
     * so it can never be used right after adding. The add/remove flags below are authoritative and
     * these listeners only clear them if the system detaches an overlay by itself.
     */
    private final View.OnAttachStateChangeListener rootWatch = new View.OnAttachStateChangeListener() {
        @Override public void onViewAttachedToWindow(View v) {}
        @Override public void onViewDetachedFromWindow(View v) { if (v == root) attached = false; }
    };
    private final View.OnAttachStateChangeListener confirmWatch = new View.OnAttachStateChangeListener() {
        @Override public void onViewAttachedToWindow(View v) {}
        @Override public void onViewDetachedFromWindow(View v) { if (v == confirmRoot) confirmAttached = false; }
    };

    /**
     * The service context must be retained (not replaced with the application context),
     * because TYPE_ACCESSIBILITY_OVERLAY is owned by the connected accessibility service.
     */
    Popup(Context context) {
        if (context == null) throw new IllegalArgumentException("context == null");
        c = context;
        UI.applyTheme(context);
        try {
            android.content.SharedPreferences prefs = Cfg.sp(context);
            popupPositionSaved = prefs.getBoolean("popup_position_saved", false);
            popupSavedX = prefs.getInt("popup_position_x", 0);
            popupSavedY = prefs.getInt("popup_position_y", 0);
            if (prefs.getBoolean("confirm_position_saved", false)) {
                savedX = prefs.getInt("confirm_position_x", -1);
                savedY = prefs.getInt("confirm_position_y", -1);
            }
        } catch (RuntimeException ignored) {
            popupPositionSaved = false;
        }
        wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        if (wm == null) throw new IllegalStateException("WindowManager is unavailable");
    }

    void onClose(Runnable callback) {
        onClose = callback;
    }

    /**
     * The comparison card and scan controls are mutually exclusive overlays.
     * Both use TYPE_ACCESSIBILITY_OVERLAY and both receive touches inside their bounds;
     * allowing them to coexist can cover the scan buttons or consume operator-page gestures.
     */
    private boolean isConfirmVisible() {
        if (!confirmAttached || confirmRoot == null || confirmParams == null) return false;
        long now = android.os.SystemClock.elapsedRealtime();
        // The internal flag can outlive a window removed by Android/OEM window transitions.
        // Verify with WindowManager occasionally, not on every accessibility event.
        if (now - confirmLastVerifiedAt >= 1200L) {
            try {
                wm.updateViewLayout(confirmRoot, confirmParams);
                confirmLastVerifiedAt = now;
            } catch (RuntimeException staleWindow) {
                confirmLastVerifiedAt = now;
                confirmError = staleWindow.getClass().getSimpleName();
                android.util.Log.w("BastehyabPopup", "Scan controls are no longer attached: "
                        + confirmError);
                hideConfirm();
                return false;
            }
        }
        return true;
    }

    /** True while the scan-control panel is on screen (cheap; safe to call on every event). */
    boolean isConfirmShown() {
        return isConfirmVisible();
    }

    /** Show/update the comparison card only when no full extraction/control panel is active. */
    void show(Compare.Result result, Set<String> onScreen) {
        if (result == null) return;
        if (ScanService.fullMode || isConfirmVisible()) {
            // Defensive central guard: callers such as the settings preview must not
            // place a touchable comparison window above the operator during extraction.
            hide();
            return;
        }
        rankGeneration++; // invalidate any slower filter-preview calculation
        last = result;
        screen = onScreen == null ? new HashSet<String>() : new HashSet<>(onScreen);

        // `attached` is maintained by our own add/remove calls (see rootWatch); never query
        // isAttachedToWindow() here because it is false until the first frame is drawn.
        String signature;
        try {
            signature = sig(result);
            DisplayMetrics currentMetrics = c.getResources().getDisplayMetrics();
            float currentFontScale = c.getResources().getConfiguration().fontScale;
            boolean viewportChanged = popupWindowWidth != currentMetrics.widthPixels
                    || popupWindowHeight != currentMetrics.heightPixels
                    || Math.abs(popupWindowFontScale - currentFontScale) >= 0.01f;
            boolean changed = !attached || !signature.equals(lastSig) || viewportChanged;
            if (root == null) {
                root = new LinearLayout(c);
                root.setOrientation(LinearLayout.VERTICAL);
                root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
                root.addOnAttachStateChangeListener(rootWatch);
                attached = false;
            }

            if (changed) {
                render();
                lastSig = signature;
            }

            if (attached && lp != null) updateParamsForCurrentWindow();
            if (!attached) {
                makeParams();
                overlayAt = android.os.SystemClock.elapsedRealtime();
                UI.applyTypefaceTree(root);
                UI.unclip(root);
                wm.addView(root, lp);
                attached = true;
            } else {
                try {
                    wm.updateViewLayout(root, lp);
                } catch (RuntimeException updateError) {
                    // A failed update does not prove that WindowManager released the view.
                    // Remove it synchronously before attempting a fresh add to avoid an orphan
                    // or a duplicate-add failure.
                    removeWindowSafely(root, "Stale comparison popup");
                    attached = false;
                    makeParams();
                    overlayAt = android.os.SystemClock.elapsedRealtime();
                    UI.applyTypefaceTree(root);
                    UI.unclip(root);
                    wm.addView(root, lp);
                    attached = true;
                }
            }
        } catch (Exception error) {
            android.util.Log.w("BastehyabPopup", "Could not show comparison popup: "
                    + error.getClass().getSimpleName());
            // Force the next refresh to rebuild/retry even when the window survived the error.
            lastSig = "";
            if (!attached) lp = null;
        }

        h.removeCallbacks(autoHide);
        int seconds;
        try {
            seconds = Cfg.hideSec(c);
        } catch (RuntimeException configError) {
            seconds = 0;
            android.util.Log.w("BastehyabPopup", "Could not read popup timeout: "
                    + configError.getClass().getSimpleName());
        }
        if (attached && seconds > 0) h.postDelayed(autoHide, seconds * 1000L);
    }


    /** Best-effort synchronous cleanup for overlays during service interruption/destruction. */
    private void removeWindowSafely(View view, String label) {
        if (view == null) return;
        try {
            wm.removeView(view);
        } catch (RuntimeException first) {
            try {
                wm.removeViewImmediate(view);
            } catch (RuntimeException second) {
                android.util.Log.d("BastehyabPopup", label + " already detached: "
                        + second.getClass().getSimpleName());
            }
        }
    }

    /** True when the comparison card is currently registered as a WindowManager overlay. */
    boolean isComparisonShown() { return attached && root != null; }

    /** Rebuild the comparison surface after rotation, split-screen resize or font-scale change. */
    void onConfigurationChanged() {
        if (attached && last != null && !ScanService.fullMode) show(last, screen);
    }

    /** Hide only the comparison popup; floating scan controls remain visible. */
    void hide() {
        rankGeneration++;
        h.removeCallbacks(autoHide);
        final LinearLayout view = root;
        if (view != null && attached) {
            overlayAt = android.os.SystemClock.elapsedRealtime();
            removeWindowSafely(view, "Comparison popup");
        }
        attached = false;
        root = null;      // a fresh view is built next time; no stale window can ever be orphaned
        lp = null;
        lastSig = "";
    }

    /**
     * Shows a movable accessibility overlay. The same panel becomes scan controls after
     * confirmation and remains available for pause/resume until the user exits.
     * Exactly one such window can exist: it is tracked by explicit add/remove state, because
     * isAttachedToWindow() is still false right after addView() and trusting it used to leave
     * orphaned, un-removable and un-movable windows behind (one per refresh).
     * @param mode 0 = waiting for confirmation, 1 = scanning, 2 = paused, 3 = final report
     */
    boolean showConfirm(String operatorName, int mode, int percent, int steps,
                        int packageCount, String status, final Runnable onPrimary,
                        final Runnable onExit, final Runnable onLater) {
        if (mode < 0 || mode > 3) return false;
        // Enforce overlay exclusivity in the opposite direction as well: the scan panel
        // must never be added on top of a still-visible comparison card.
        hide();
        String safeName = operatorName == null || operatorName.trim().isEmpty()
                ? "اپراتور" : operatorName.trim();
        if (confirmAttached && confirmRoot != null && confirmParams != null
                && confirmMode == mode && safeName.equals(confirmOperator)
                && confirmWindowWidth == c.getResources().getDisplayMetrics().widthPixels
                && confirmWindowHeight == c.getResources().getDisplayMetrics().heightPixels
                && Math.abs(confirmWindowFontScale - c.getResources().getConfiguration().fontScale) < 0.01f) {
            try {
                // Revalidate the window instead of trusting a stale local attached flag.
                wm.updateViewLayout(confirmRoot, confirmParams);
                confirmLastVerifiedAt = android.os.SystemClock.elapsedRealtime();
                confirmError = "";
                updateConfirmProgress(percent, steps, packageCount, status);
                return true;
            } catch (RuntimeException staleWindow) {
                confirmError = staleWindow.getClass().getSimpleName();
                android.util.Log.w("BastehyabPopup", "Rebuilding stale scan controls: " + confirmError);
            }
        }

        // Remove the previous panel (if any) before building the next one.
        hideConfirm();
        confirmError = "";
        final LinearLayout panel = new LinearLayout(c);
        boolean added = false;
        try {
            int pad = UI.dp(c, 12);
            panel.setOrientation(LinearLayout.VERTICAL);
            panel.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
            panel.setPadding(pad, pad, pad, pad);
            panel.setBackground(UI.panel(c, 20));

            DisplayMetrics dm = c.getResources().getDisplayMetrics();
            int width = Math.max(UI.dp(c, 1), Math.min(dm.widthPixels - UI.dp(c, 32), UI.dp(c, 360)));
            final WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                    width, WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                            | WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                    PixelFormat.TRANSLUCENT);
            params.gravity = Gravity.TOP | Gravity.LEFT;
            params.x = savedX >= 0 ? Math.max(0, Math.min(savedX, Math.max(0, dm.widthPixels - width)))
                    : Math.max(0, (dm.widthPixels - width) / 2);
            int overlayMaxHeight = maxOverlayHeight(dm);
            int maxOffsetY = Math.max(0, dm.heightPixels - overlayMaxHeight - UI.dp(c, 12));
            params.y = savedY >= 0 ? Math.max(0, Math.min(savedY, maxOffsetY))
                    : Math.min(UI.dp(c, 76), maxOffsetY);
            params.setTitle("Bastehyab scan controls");

            LinearLayout header = UI.hbox(c);
            header.setGravity(Gravity.CENTER_VERTICAL);
            String title = mode == 0 ? "آماده‌ی شروع اسکن " + safeName
                    : mode == 1 ? "استخراج خودکار " + safeName
                    : mode == 2 ? "اسکن موقتاً متوقف است"
                    : "گزارش نهایی اسکن " + safeName;
            TextView titleView = UI.tv(c, title, 12, UI.PRIMARY, true);
            header.addView(titleView, UI.lpw(1f));
            TextView drag = UI.tv(c, "⠿ جابه‌جایی", 10, UI.MUTED, true);
            drag.setGravity(Gravity.CENTER);
            drag.setPadding(UI.dp(c, 12), UI.dp(c, 10), UI.dp(c, 12), UI.dp(c, 10));
            drag.setMinWidth(UI.dp(c, 92));
            drag.setMinHeight(UI.dp(c, 48));
            drag.setBackground(UI.inset(c, 12));
            drag.setContentDescription("دستگیرهٔ جابه‌جایی پنجره؛ برای حرکت با لمس بکشید");
            drag.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
            header.addView(drag);
            // The listener is bound to THIS panel and THIS params object (not to mutable fields),
            // so it always moves the window the finger is actually on.
            View.OnTouchListener mover = new View.OnTouchListener() {
                float downX, downY;
                int startX, startY;
                @Override public boolean onTouch(View v, MotionEvent e) {
                    if (panel != confirmPanel || confirmRoot == null || !confirmAttached) return false;
                    switch (e.getActionMasked()) {
                        case MotionEvent.ACTION_DOWN:
                            downX = e.getRawX();
                            downY = e.getRawY();
                            startX = params.x;
                            startY = params.y;
                            return true;
                        case MotionEvent.ACTION_MOVE:
                            DisplayMetrics metrics = c.getResources().getDisplayMetrics();
                            int w = confirmRoot != null && confirmRoot.getWidth() > 0 ? confirmRoot.getWidth() : params.width;
                            int hh = Math.max(confirmRoot == null ? 0 : confirmRoot.getHeight(), UI.dp(c, 96));
                            int maxX = Math.max(0, metrics.widthPixels - w);
                            int maxY = Math.max(0, metrics.heightPixels - hh - UI.dp(c, 12));
                            params.x = Math.max(0, Math.min(maxX,
                                    startX + Math.round(e.getRawX() - downX)));
                            params.y = Math.max(0, Math.min(maxY,
                                    startY + Math.round(e.getRawY() - downY)));
                            savedX = params.x;
                            savedY = params.y;
                            try {
                                wm.updateViewLayout(confirmRoot, params);
                            } catch (RuntimeException ex) {
                                confirmError = ex.getClass().getSimpleName();
                                android.util.Log.w("BastehyabPopup", "Could not move scan controls: "
                                        + confirmError);
                            }
                            return true;
                        case MotionEvent.ACTION_UP:
                        case MotionEvent.ACTION_CANCEL:
                            if (savedX >= 0 && savedY >= 0) {
                                try {
                                    Cfg.sp(c).edit().putBoolean("confirm_position_saved", true)
                                            .putInt("confirm_position_x", savedX)
                                            .putInt("confirm_position_y", savedY).apply();
                                } catch (RuntimeException saveError) {
                                    android.util.Log.w("BastehyabPopup", "Could not persist scan-control position: "
                                            + saveError.getClass().getSimpleName());
                                }
                            }
                            return true;
                        default:
                            return true;
                    }
                }
            };
            // Both the handle and the title can drag the panel; buttons below keep normal clicks.
            drag.setClickable(true);
            drag.setLongClickable(false);
            drag.setOnTouchListener(mover);
            titleView.setOnTouchListener(mover);
            panel.addView(header);

            String message = mode == 0
                    ? "با تأیید، فقط صفحهٔ بسته‌های همین اپراتور خوانده می‌شود؛ برای دیدن موارد پایین‌تر ممکن است اسکرول یا swipe عمودی خودکار انجام شود. خرید یا پرداختی انجام نمی‌شود."
                    : mode == 1
                    ? "اسکن فعال است؛ برای مکث، توقف را بزنید."
                    : mode == 2
                    ? "اطلاعات حفظ شده؛ ادامه از همین صفحه انجام می‌شود."
                    : "این گزارش نتیجه‌ی آخرین تلاش اسکن را نشان می‌دهد.";
            panel.addView(UI.tv(c, message, 10, UI.TEXT, false),
                    UI.lp(c, -1, -2, 0, 4, 0, 5));

            confirmProgressLabel = UI.tv(c, mode == 3 ? "نتیجه‌ی پیمایش" : "پیشرفت تقریبی پیمایش • ۰٪",
                    10, UI.PRIMARY, true);
            panel.addView(confirmProgressLabel, UI.lp(c, -1, -2, 0, 1, 0, 2));
            confirmProgress = UI.progress(c);
            confirmProgress.setMax(100);
            confirmProgress.setProgress(0);
            panel.addView(confirmProgress, UI.lp(c, -1, 8, 0, 2, 0, 4));
            confirmStatus = UI.tv(c, c.getString(R.string.scan_waiting), 14, UI.MUTED, false);
            confirmStatus.setSingleLine(false);
            confirmStatus.setMaxLines(Integer.MAX_VALUE);
            confirmStatus.setSingleLine(false);
            confirmStatus.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE);
            confirmStatus.setFocusable(false);
            panel.addView(confirmStatus, UI.lp(c, -1, -2, 0, 0, 0, 2));
            confirmDetails = UI.tv(c, "", 13, UI.MUTED, false);
            confirmDetails.setSingleLine(false);
            panel.addView(confirmDetails, UI.lp(c, -1, -2, 0, 0, 0, 7));

            float popupFontScale = c.getResources().getConfiguration().fontScale;
            boolean stackedActions = UI.compact(c) || popupFontScale >= 1.5f;
            LinearLayout row = stackedActions ? UI.vbox(c) : UI.hbox(c);
            if (mode == 3) {
                row.addView(UI.btn(c, c.getString(R.string.scan_new), UI.PRIMARY, 0xFF0B1220,
                        v -> { if (onPrimary != null) onPrimary.run(); }), popupActionParams(stackedActions, 0));
                row.addView(UI.btn(c, c.getString(R.string.scan_close_report), UI.CARD2, UI.TEXT,
                        v -> { if (onExit != null) onExit.run(); }), popupActionParams(stackedActions, 7));
            } else {
                if (mode == 0) {
                    row.addView(UI.btn(c, c.getString(R.string.scan_confirm_start), UI.PRIMARY, 0xFF0B1220,
                            v -> { if (onPrimary != null) onPrimary.run(); }), popupActionParams(stackedActions, 0));
                    row.addView(UI.btn(c, c.getString(R.string.scan_later), UI.CARD2, UI.TEXT,
                            v -> { if (onLater != null) onLater.run(); }), popupActionParams(stackedActions, 7));
                } else if (mode == 1) {
                    row.addView(UI.btn(c, c.getString(R.string.scan_stop), UI.CARD2, UI.PRIMARY,
                            v -> { if (onPrimary != null) onPrimary.run(); }), popupActionParams(stackedActions, 0));
                } else {
                    row.addView(UI.btn(c, c.getString(R.string.scan_resume), UI.PRIMARY, 0xFF0B1220,
                            v -> { if (onPrimary != null) onPrimary.run(); }), popupActionParams(stackedActions, 0));
                }
                row.addView(UI.btn(c, c.getString(R.string.scan_exit), UI.CARD2, UI.DANGER,
                        v -> { if (onExit != null) onExit.run(); }), popupActionParams(stackedActions, 7));
            }
            panel.addView(row);

            // Long privacy/status text and 200% font scale must remain reachable on short windows.
            ScrollView confirmScroll = UI.boundedScroll(c, overlayMaxHeight);
            confirmScroll.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
            confirmScroll.addView(panel, new ScrollView.LayoutParams(-1, -2));
            confirmScroll.addOnAttachStateChangeListener(confirmWatch);
            confirmRoot = confirmScroll;
            confirmPanel = panel;
            confirmParams = params;
            confirmMode = mode;
            confirmOperator = safeName;
            confirmWindowWidth = dm.widthPixels;
            confirmWindowHeight = dm.heightPixels;
            confirmWindowFontScale = c.getResources().getConfiguration().fontScale;
            confirmTouchBlocked = false;
            overlayAt = android.os.SystemClock.elapsedRealtime();
            UI.applyTypefaceTree(confirmScroll);
            UI.unclip(confirmScroll);
            wm.addView(confirmScroll, params);
            added = true;
            confirmAttached = true;   // authoritative: the window now exists in WindowManager
            confirmLastVerifiedAt = android.os.SystemClock.elapsedRealtime();
            updateConfirmProgress(percent, steps, packageCount, status);
            return true;
        } catch (Exception e) {
            confirmError = e.getClass().getSimpleName();
            if (added) removeWindowSafely(confirmRoot, "Failed scan-control creation");
            confirmAttached = false;
            confirmRoot = null;
            confirmPanel = null;
            confirmParams = null;
            confirmMode = -1;
            confirmOperator = "";
            confirmWindowWidth = -1;
            confirmWindowHeight = -1;
            confirmWindowFontScale = -1f;
            confirmTouchBlocked = false;
            confirmProgress = null;
            confirmProgressLabel = null;
            confirmStatus = null;
            confirmDetails = null;
            android.util.Log.w("BastehyabPopup", "Could not show scan controls: " + confirmError);
            return false;
        }
    }

    String confirmError() { return confirmError; }

    /**
     * Temporarily lets injected scroll gestures pass through this control panel. The scan worker
     * requests this only for the 420ms swipe; all buttons and dragging are restored on completion.
     * Must be called on the service main thread.
     */
    void setConfirmTouchBlocked(boolean blocked) {
        if (!confirmAttached || confirmRoot == null || confirmParams == null
                || confirmTouchBlocked == blocked) return;
        int flags = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
        if (blocked) flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE | WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
        confirmParams.flags = flags;
        try {
            wm.updateViewLayout(confirmRoot, confirmParams);
            confirmTouchBlocked = blocked;
        } catch (RuntimeException error) {
            confirmError = error.getClass().getSimpleName();
            android.util.Log.w("BastehyabPopup", "Could not update scan-control touch mode: "
                    + confirmError);
        }
    }

    /** Removes the scan-control window for sure; safe to call repeatedly. */
    void hideConfirm() {
        final View panel = confirmRoot;
        if (panel != null && confirmAttached) {
            overlayAt = android.os.SystemClock.elapsedRealtime();
            removeWindowSafely(panel, "Scan controls");
        }
        confirmAttached = false;
        confirmTouchBlocked = false;
        confirmLastVerifiedAt = 0L;
        confirmRoot = null;
        confirmPanel = null;
        confirmParams = null;
        confirmMode = -1;
        confirmOperator = "";
        confirmWindowWidth = -1;
        confirmWindowHeight = -1;
        confirmWindowFontScale = -1f;
        confirmProgress = null;
        confirmProgressLabel = null;
        confirmStatus = null;
        confirmDetails = null;
    }

    private void updateConfirmProgress(int percent, int steps, int packageCount, String status) {
        int safePercent = Math.max(0, Math.min(100, percent));
        if (confirmProgress != null) confirmProgress.setProgress(safePercent);
        if (confirmProgressLabel != null) {
            String prefix = confirmMode == 3 ? "نتیجه‌ی پیمایش" : "پیشرفت تقریبی پیمایش";
            String label = prefix + " • " + Fmt.fa(String.valueOf(safePercent)) + "٪";
            if (!label.contentEquals(confirmProgressLabel.getText())) confirmProgressLabel.setText(label);
            // Progress itself is exposed by ProgressBar; avoid announcing every percentage tick.
            confirmProgressLabel.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        }
        String safeStatus = (status == null || status.trim().isEmpty()) ? c.getString(R.string.scan_waiting) : status.trim();
        if (confirmStatus != null && !safeStatus.contentEquals(confirmStatus.getText())) {
            confirmStatus.setText(safeStatus);
        }
        if (confirmDetails != null) {
            String details = Fmt.fa(String.valueOf(steps)) + " مرحله، "
                    + Fmt.fa(String.valueOf(packageCount)) + " بستهٔ یکتا";
            if (!details.contentEquals(confirmDetails.getText())) confirmDetails.setText(details);
        }
    }

    private String sig(Compare.Result r) {
        StringBuilder b = new StringBuilder();
        b.append(Cfg.pmode(c)).append('|').append(Cfg.rows(c)).append('|').append(compact).append('|')
                .append(r.metric).append('|').append(r.bucket).append('|').append(Cfg.displayCurrency(c)).append('|').append(r.ranked.size());
        int n = Math.min(12, r.ranked.size());
        for (int i = 0; i < n; i++) b.append(r.ranked.get(i).key).append(Cfg.finalPrice(c, r.ranked.get(i)));
        for (Pkg p : r.screen) b.append('#').append(p.key).append(Cfg.finalPrice(c, p));
        for (Op o : Cfg.ops(c)) b.append(o.cmp ? '1' : '0');
        return b.toString();
    }

    private int maxOverlayHeight(DisplayMetrics dm) {
        int margin = UI.dp(c, 12);
        int available = Math.max(UI.dp(c, 24), dm.heightPixels - margin * 2);
        int byWindow = Math.max(UI.dp(c, 24), Math.round(dm.heightPixels * 0.58f));
        return Math.max(UI.dp(c, 24), Math.min(available,
                Math.min(byWindow, UI.dp(c, 440))));
    }

    private int popupWidth(DisplayMetrics dm) {
        int margin = UI.dp(c, 16);
        int available = Math.max(UI.dp(c, 1), dm.widthPixels - margin * 2);
        return Math.min(available, UI.dp(c, 400));
    }

    private int maxPopupX(DisplayMetrics dm, int width) {
        // CENTER_HORIZONTAL uses a signed offset from the display center.
        return Math.max(0, (dm.widthPixels - width) / 2);
    }

    private void updateParamsForCurrentWindow() {
        if (lp == null) return;
        DisplayMetrics dm = c.getResources().getDisplayMetrics();
        lp.width = popupWidth(dm);
        int maxX = maxPopupX(dm, lp.width);
        lp.x = Math.max(-maxX, Math.min(lp.x, maxX));
        int maxOffsetY = Math.max(0, dm.heightPixels - maxOverlayHeight(dm) - UI.dp(c, 12));
        lp.y = Math.max(0, Math.min(lp.y, maxOffsetY));
        popupSavedX = lp.x;
        popupSavedY = lp.y;
    }

    private void makeParams() {
        DisplayMetrics dm = c.getResources().getDisplayMetrics();
        boolean bottom = Cfg.bottom(c);
        int width = popupWidth(dm);
        int maxOffsetY = Math.max(0, dm.heightPixels - maxOverlayHeight(dm) - UI.dp(c, 12));
        lp = new WindowManager.LayoutParams(
                width, WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        lp.gravity = (bottom ? Gravity.BOTTOM : Gravity.TOP) | Gravity.CENTER_HORIZONTAL;
        int maxX = maxPopupX(dm, width);
        lp.x = popupPositionSaved ? Math.max(-maxX, Math.min(popupSavedX, maxX)) : 0;
        lp.y = popupPositionSaved ? Math.max(0, Math.min(popupSavedY, maxOffsetY))
                : Math.min(UI.dp(c, bottom ? 90 : 48), maxOffsetY);
    }

    private LinearLayout.LayoutParams popupActionParams(boolean stacked, int top) {
        return stacked ? UI.lp(c, -1, -2, 0, top, 0, 0) : UI.lp(c, -2, -2, top, 0, 0, 0);
    }

    private void recalculateAsync() {
        final int token = ++rankGeneration;
        final Set<String> onScreen = screen == null ? new HashSet<String>() : new HashSet<>(screen);
        try {
            rankWorker.execute(() -> {
                final Compare.Result refreshed;
                try {
                    Store.Snapshot snapshot = Store.snapshotState(c);
                    refreshed = Compare.run(c, snapshot.records, onScreen);
                } catch (RuntimeException failure) {
                    android.util.Log.w("BastehyabPopup", "Background ranking failed: " + failure.getClass().getSimpleName());
                    return;
                }
                h.post(() -> {
                    if (token != rankGeneration || !attached || ScanService.fullMode) return;
                    last = refreshed;
                    screen = onScreen;
                    try {
                        render();
                        lastSig = sig(refreshed);
                        wm.updateViewLayout(root, lp);
                    } catch (RuntimeException refreshError) {
                        android.util.Log.w("BastehyabPopup", "Could not refresh comparison popup: "
                                + refreshError.getClass().getSimpleName());
                        // A partially rebuilt hierarchy must not remain interactive or leak.
                        removeWindowSafely(root, "Asynchronously refreshed comparison popup");
                        attached = false;
                        lastSig = "";
                    }
                });
            });
        } catch (RejectedExecutionException ignored) {
            // The service is shutting down; the last valid ranking remains visible until hide().
        }
    }

    /** Close the popup and release its ranking executor when the accessibility service disconnects. */
    void shutdown() {
        rankGeneration++;
        rankWorker.shutdownNow();
        hide();
        hideConfirm();
    }

    private View ticks() {
        HorizontalScrollView hs = new HorizontalScrollView(c);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout r = UI.hbox(c);
        List<Op> ops = Cfg.ops(c);
        for (final Op o : ops) {
            TextView t = UI.choice(c, (o.cmp ? "✓ " : "○ ") + o.name, o.cmp);
            t.setPadding(UI.dp(c, 12), UI.dp(c, 7), UI.dp(c, 12), UI.dp(c, 7));
            t.setContentDescription(c.getString(R.string.a11y_compare_operator, o.name));
            t.setOnClickListener(v -> {
                o.cmp = !o.cmp;
                t.setSelected(o.cmp);
                UI.setStateDescription(t, o.cmp ? c.getString(R.string.a11y_selected) : c.getString(R.string.a11y_unselected));
                t.setContentDescription(c.getString(o.cmp ? R.string.a11y_operator_selected : R.string.a11y_operator_unselected, o.name));
                Cfg.saveOps(c, ops);
                recalculateAsync();
            });
            r.addView(t, UI.lp(c, -2, -2, 0, 4, 8, 6));
        }
        hs.addView(r);
        return hs;
    }

    private void render() {
        final Compare.Result r = last;
        int pad = UI.dp(c, 12);
        final int oldScrollY = popupScroll == null ? 0 : popupScroll.getScrollY();
        root.removeAllViews();
        root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setPadding(0, 0, 0, 0);
        root.setBackground(UI.panel(c, 20));
        DisplayMetrics windowMetrics = c.getResources().getDisplayMetrics();
        popupScroll = UI.boundedScroll(c, maxOverlayHeight(windowMetrics));
        popupWindowWidth = windowMetrics.widthPixels;
        popupWindowHeight = windowMetrics.heightPixels;
        popupWindowFontScale = c.getResources().getConfiguration().fontScale;
        popupScroll.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        popupContent = UI.vbox(c);
        popupContent.setPadding(pad, pad, pad, pad);
        popupContent.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        // Correct hierarchy: root -> ScrollView -> content. The previous code added the
        // ScrollView back into its own descendant, creating an illegal parent cycle and
        // making the comparison overlay fail before WindowManager.addView().
        popupScroll.addView(popupContent, new ScrollView.LayoutParams(-1, -2));
        root.addView(popupScroll, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout hd = UI.hbox(c);
        TextView liveMark = UI.mono(c, "⚡ LIVE", 12, UI.ACCENT);
        liveMark.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        hd.addView(liveMark, UI.lp(c, -2, -2, 0, 0, 8, 0));
        hd.addView(UI.tv(c, "مقایسه‌ی آنی", 15, UI.TEXT, true), UI.lpw(1f));
        TextView min = UI.iconButton(c, compact ? "▴" : "▾",
                compact ? c.getString(R.string.a11y_expand_compare) : c.getString(R.string.a11y_collapse_compare),
                compact ? "بسته" : "باز", v -> {
                    compact = !compact;
                    lastSig = "";
                    render();
                });
        TextView x = UI.iconButton(c, "✕", c.getString(R.string.a11y_close_compare), null, v -> {
            hide();
            if (onClose != null) onClose.run();
        });
        hd.addView(min);
        hd.addView(x);
        hd.setOnTouchListener(new View.OnTouchListener() {
            float sx, sy;
            int ox, oy;
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        if (lp == null || !attached) return false;
                        sx = e.getRawX(); sy = e.getRawY();
                        ox = lp.x; oy = lp.y;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        if (lp == null || root == null || !attached) return false;
                        DisplayMetrics dm = c.getResources().getDisplayMetrics();
                        int width = root.getWidth() > 0 ? root.getWidth() : lp.width;
                        int maxX = maxPopupX(dm, width);
                        int maxY = Math.max(0, dm.heightPixels - maxOverlayHeight(dm) - UI.dp(c, 12));
                        boolean bottom = (lp.gravity & Gravity.BOTTOM) == Gravity.BOTTOM;
                        lp.x = Math.max(-maxX, Math.min(maxX, ox + Math.round(e.getRawX() - sx)));
                        lp.y = Math.max(0, Math.min(maxY, oy + Math.round((bottom ? -1f : 1f) * (e.getRawY() - sy))));
                        popupSavedX = lp.x; popupSavedY = lp.y; popupPositionSaved = true;
                        try { wm.updateViewLayout(root, lp); }
                        catch (RuntimeException moveError) {
                            android.util.Log.w("BastehyabPopup", "Could not move comparison popup: "
                                    + moveError.getClass().getSimpleName());
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        if (popupPositionSaved) {
                            try {
                                Cfg.sp(c).edit().putBoolean("popup_position_saved", true)
                                        .putInt("popup_position_x", popupSavedX)
                                        .putInt("popup_position_y", popupSavedY).apply();
                            } catch (RuntimeException saveError) {
                                android.util.Log.w("BastehyabPopup", "Could not persist popup position: "
                                        + saveError.getClass().getSimpleName());
                            }
                        }
                        return true;
                    default: return true;
                }
            }
        });
        popupContent.addView(hd);

        String sub = Fmt.fa(String.valueOf(r.ranked.size())) + " بسته از " + Fmt.fa(String.valueOf(r.ops))
                + " اپراتور • " + r.label + (r.bucket != 0 ? " • " + Compare.BUCKETS[r.bucket] : "");
        popupContent.addView(UI.tv(c, sub, 11, UI.MUTED, false), UI.lp(c, -1, -2, 0, 0, 0, 6));
        if (!compact) popupContent.addView(ticks(), UI.lp(c, -1, -2, 0, 0, 0, 6));

        int mode = Cfg.pmode(c);
        boolean showScreen = mode != 1, showAll = mode != 2;

        if (compact) {
            if (showAll && !r.ranked.isEmpty()) popupContent.addView(mini("برترین کل", r, r.ranked.get(0)), UI.lp(c, -1, -2, 0, 5, 0, 5));
            if (showScreen && !r.screen.isEmpty()) popupContent.addView(mini("✓ این صفحه", r, r.screen.get(0)), UI.lp(c, -1, -2, 0, 5, 0, 5));
            popupScroll.post(() -> popupScroll.scrollTo(0, Math.min(oldScrollY,
                    Math.max(0, popupContent.getHeight() - popupScroll.getHeight()))));
            return;
        }

        Set<String> shown = new HashSet<>();
        // Cfg.rows is a user preference, but the floating surface must remain bounded:
        // no more than eight package cards in total (current page + global ranking).
        final int maxRows = Math.max(1, Math.min(8, Cfg.rows(c)));
        int displayedRows = 0;
        if (showScreen && !r.screen.isEmpty() && displayedRows < maxRows) {
            popupContent.addView(UI.tv(c, "✓ بهترین‌های همین صفحه (از " + Fmt.fa(String.valueOf(r.screen.size())) + " بسته)", 11, UI.PRIMARY, true), UI.lp(c, -1, -2, 0, 4, 0, 2));
            int k = Math.min(Math.min(3, r.screen.size()), maxRows);
            for (int i = 0; i < k; i++) {
                Pkg p = r.screen.get(i);
                if (!shown.add(p.key)) continue;
                displayedRows++;
                popupContent.addView(row(r, p, r.rank.containsKey(p.key) ? r.rank.get(p.key) : i + 1, true), UI.lp(c, -1, -2, 0, 5, 0, 5));
            }
        }
        if (showAll && !r.ranked.isEmpty() && displayedRows < maxRows) {
            popupContent.addView(UI.tv(c, "برترین‌ها در همه‌ی اپراتورهای تیک‌خورده", 11, UI.ACCENT, true), UI.lp(c, -1, -2, 0, 6, 0, 2));
            for (Pkg p : r.ranked) {
                if (displayedRows >= maxRows) break;
                if (!shown.add(p.key)) continue;
                displayedRows++;
                popupContent.addView(row(r, p, r.rank.containsKey(p.key) ? r.rank.get(p.key) : displayedRows, false), UI.lp(c, -1, -2, 0, 5, 0, 5));
            }
        }

        String foot;
        if (r.ranked.isEmpty()) {
            foot = "هیچ اپراتوری تیک نخورده یا با فیلترهای شما بسته‌ای نمانده است.";
        } else if (r.screen.isEmpty() && screen != null && !screen.isEmpty()) {
            foot = "بسته‌های همین صفحه با فیلترها (حجم، مدت، ویژه‌ها) جور نیستند؛ بالا فقط برترین‌های اپراتورهای دیگر است.";
        } else if (r.ops < 2) {
            foot = "برای مقایسه‌ی بین اپراتورها، برنامه‌ی اپراتور دیگری را هم باز کنید.";
        } else if (r.bestScreen != null && r.metric == Cfg.DURATION) {
            double bestDays = r.ranked.get(0).days, mineDays = r.bestScreen.days;
            long difference = Math.max(0L, Math.round(bestDays - mineDays));
            foot = r.rankScreen == 1 ? "بسته‌ی همین صفحه بیشترین اعتبار را دارد."
                    : "بسته‌ی همین صفحه رتبه‌ی " + Fmt.fa(String.valueOf(r.rankScreen)) + " را دارد و "
                    + Fmt.fa(String.valueOf(difference)) + " روز اعتبار کمتری از برترین دارد.";
        } else if (r.bestScreen != null) {
            double best = r.val.get(r.ranked.get(0).key), mine = r.val.get(r.bestScreen.key);
            long pct = best > 0 ? Math.round((mine - best) / best * 100) : 0;
            foot = r.rankScreen == 1 ? "رتبه ۱ صفحه، برترین کل است."
                    : "بهترین بسته‌ی همین صفحه، رتبه‌ی " + Fmt.fa(String.valueOf(r.rankScreen)) + " کل است و "
                    + Fmt.fa(String.valueOf(pct)) + "٪ گران‌تر از برترین.";
        } else {
            foot = "برای دقت بیشتر، لیست بسته‌ها را تا آخر اسکرول کنید.";
        }
        popupContent.addView(UI.tv(c, foot, 11, UI.MUTED, false), UI.lp(c, -1, -2, 0, 6, 0, 0));
        popupScroll.post(() -> popupScroll.scrollTo(0, Math.min(oldScrollY,
                Math.max(0, popupContent.getHeight() - popupScroll.getHeight()))));
    }

    private View mini(String label, Compare.Result r, Pkg p) {
        Op op = Cfg.opById(c, p.op);
        int col = op == null ? UI.MUTED : op.color;
        LinearLayout card = UI.vbox(c);
        int pd = UI.dp(c, 8);
        card.setPadding(pd, pd, pd, pd);
        card.setBackground(UI.raisedSmall(c, 14));

        int numericRank = r.rank.containsKey(p.key) ? r.rank.get(p.key) : 0;
        LinearLayout header = UI.hbox(c);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView badge = UI.tv(c, Fmt.fa(String.valueOf(numericRank)), 12, UI.TEXT, true);
        badge.setGravity(Gravity.CENTER);
        badge.setIncludeFontPadding(false);
        badge.setBackground(numericRank == 1 ? UI.inset(c, 10, UI.ACCENT) : UI.inset(c, 10));
        header.addView(badge, UI.lp(c, 28, 28, 0, 0, 7, 0));
        TextView section = UI.tv(c, label, 11, UI.MUTED, true);
        section.setMaxLines(2);
        header.addView(section, UI.lpw(1f));
        header.addView(UI.chip(c, op == null ? p.op : op.name, UI.tint(col), col));
        card.addView(header);

        LinearLayout details = UI.hbox(c);
        details.setGravity(Gravity.CENTER_VERTICAL);
        TextView packageLabel = UI.tv(c, p.label(), 12, UI.TEXT, true);
        packageLabel.setMaxLines(2);
        packageLabel.setTextDirection(View.TEXT_DIRECTION_RTL);
        details.addView(packageLabel, UI.lpw(1f));
        String value = r.metric == Cfg.DURATION ? Fmt.dec(p.days) :
                Fmt.num(Math.round(Cfg.displayMetric(c, r.val.get(p.key))));
        String unit = r.metric == Cfg.DURATION ? " روز" : " " + Cfg.metricUnit(c, r.unit);
        TextView metric = UI.tv(c, value + unit, 12, UI.PRIMARY, true);
        metric.setMaxLines(2);
        details.addView(metric, UI.lp(c, -2, -2, 6, 0, 0, 0));
        card.addView(details, UI.lp(c, -1, -2, 0, 6, 0, 0));
        return card;
    }

    private View row(Compare.Result r, Pkg p, int badgeNo, boolean here) {
        Op op = Cfg.opById(c, p.op);
        int g = r.rank.containsKey(p.key) ? r.rank.get(p.key) : badgeNo;
        int col = op == null ? UI.MUTED : op.color;
        LinearLayout card = UI.vbox(c);
        int pd = UI.dp(c, 9);
        card.setPadding(pd, pd, pd, pd);
        card.setBackground(here || g == 1
                ? new NeuDrawable(NeuDrawable.RAISED, UI.dp(c, 16), UI.dp(c, 5), UI.CARD2, UI.CARD, UI.LSH, UI.DSH,
                        (UI.PRIMARY & 0x00FFFFFF) | 0xAA000000, UI.dp(c, 1.2f), 0)
                : UI.raisedSmall(c, 16));

        LinearLayout head = UI.hbox(c);
        TextView badge = UI.tv(c, Fmt.fa(String.valueOf(g)), 12, UI.TEXT, true);
        badge.setGravity(Gravity.CENTER);
        badge.setIncludeFontPadding(false);
        badge.setBackground(g == 1 ? UI.inset(c, 10, UI.ACCENT) : UI.inset(c, 10));
        head.addView(badge, UI.lp(c, 30, 30, 0, 0, 7, 0));
        head.addView(UI.chip(c, op == null ? p.op : op.name, UI.tint(col), col));
        card.addView(head);

        // Keep status tags on their own RTL row so long operator names never collide with them.
        if (p.restricted || r.cheap.contains(p.key)) {
            LinearLayout flags = UI.hbox(c);
            if (p.restricted) flags.addView(UI.chip(c, "ویژه", UI.tint(UI.WARN), UI.WARN),
                    UI.lp(c, -2, -2, 0, 6, 5, 0));
            if (r.cheap.contains(p.key)) flags.addView(UI.chip(c, "بررسی قیمت", UI.tint(UI.WARN), UI.WARN),
                    UI.lp(c, -2, -2, 0, 6, 5, 0));
            card.addView(flags);
        }

        TextView label = UI.tv(c, p.label(), 13, UI.TEXT, true);
        label.setMaxLines(3);
        label.setEllipsize(null);
        label.setTextDirection(View.TEXT_DIRECTION_RTL);
        card.addView(label, UI.lp(c, -1, -2, 0, 5, 0, 5));

        LinearLayout foot = UI.hbox(c);
        LinearLayout total = UI.vbox(c);
        total.addView(UI.tv(c, "قیمت نهایی", 9, UI.MUTED, false));
        total.addView(UI.tv(c, Cfg.priceLabel(c, Cfg.finalPrice(c, p)), 11, UI.TEXT, true));
        foot.addView(total, UI.lpw(1f));
        LinearLayout metric = UI.vbox(c);
        metric.setGravity(Gravity.CENTER_HORIZONTAL);
        metric.addView(UI.tv(c, "مقایسه", 9, UI.MUTED, false));
        String metricValue = r.metric == Cfg.DURATION ? Fmt.dec(p.days) :
                Fmt.num(Math.round(Cfg.displayMetric(c, r.val.get(p.key))));
        String metricUnit = r.metric == Cfg.DURATION ? "روز" : Cfg.metricUnit(c, r.unit);
        metric.addView(UI.tv(c, metricValue + " " + metricUnit,
                11, g == 1 ? UI.PRIMARY : UI.TEXT, true));
        foot.addView(metric, UI.lpw(1f));
        card.addView(foot);
        return card;
    }
}
