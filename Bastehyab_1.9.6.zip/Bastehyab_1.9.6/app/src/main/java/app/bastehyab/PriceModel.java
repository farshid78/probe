package app.bastehyab;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Canonical money parsing/conversion. Internal unit is whole toman; unknown units never normalize. */
final class PriceModel {
    enum Currency { UNKNOWN, IRR, IRT }
    enum Confidence { NONE, LOW, MEDIUM, HIGH }
    static final class Parsed {
        final long rawAmount, normalizedToman; final Currency currency; final Confidence confidence;
        Parsed(long raw, long toman, Currency c, Confidence f) { rawAmount=raw; normalizedToman=toman; currency=c; confidence=f; }
        boolean comparable() { return currency != Currency.UNKNOWN && confidence != Confidence.NONE && normalizedToman > 0; }
    }
    private PriceModel() {}
    static long toToman(long amount, Currency currency) {
        if (amount <= 0) throw new IllegalArgumentException("amount");
        if (currency == Currency.UNKNOWN) throw new IllegalArgumentException("currency");
        if (currency == Currency.IRT) return amount;
        if (amount % 10L != 0L) throw new IllegalArgumentException("rial_amount_not_divisible_by_ten");
        return amount / 10L;
    }
    static long safeVat(long toman, int percent) {
        if (toman <= 0 || percent < 0 || percent > 100) throw new IllegalArgumentException("money/vat");
        return BigDecimal.valueOf(toman).multiply(BigDecimal.valueOf(100L + percent))
                .divide(BigDecimal.valueOf(100), 0, RoundingMode.HALF_UP).longValueExact();
    }

    /** The one canonical tax boundary used by UI labels and ranking. Input is always pre-tax toman. */
    static long finalToman(long normalizedToman, boolean taxIncluded, int vatPercent) {
        if (normalizedToman <= 0) throw new IllegalArgumentException("money");
        return taxIncluded ? normalizedToman : safeVat(normalizedToman, vatPercent);
    }

    static boolean validAmount(long toman) { return toman >= 100L && toman <= 2_000_000_000L; }

    /** Finite, positive metric conversion. BigDecimal prevents intermediate overflow and NaN. */
    static double ratio(long price, double denominator) {
        if (price <= 0 || !Double.isFinite(denominator) || denominator <= 0) return Double.MAX_VALUE;
        try {
            double value = BigDecimal.valueOf(price).divide(BigDecimal.valueOf(denominator), 12,
                    RoundingMode.HALF_UP).doubleValue();
            return Double.isFinite(value) && value > 0 ? value : Double.MAX_VALUE;
        } catch (RuntimeException invalid) { return Double.MAX_VALUE; }
    }

    static long ceilPositive(double numerator, double denominator) {
        if (!Double.isFinite(numerator) || !Double.isFinite(denominator)
                || numerator <= 0 || denominator <= 0) throw new IllegalArgumentException("ratio");
        return ceilPositive(BigDecimal.valueOf(numerator), BigDecimal.valueOf(denominator));
    }

    private static long ceilPositive(BigDecimal numerator, BigDecimal denominator) {
        if (numerator == null || denominator == null || numerator.signum() <= 0 || denominator.signum() <= 0)
            throw new IllegalArgumentException("ratio");
        return numerator.divide(denominator, 0, RoundingMode.CEILING).longValueExact();
    }

    /** Monthly usage cost in whole toman, rounded once at the final boundary. */
    static long monthlyCost(long price, double gb, double days, double usage) {
        if (price <= 0 || !Double.isFinite(gb) || gb <= 0 || !Double.isFinite(days) || days <= 0
                || !Double.isFinite(usage) || usage <= 0) throw new IllegalArgumentException("usage_cost");
        BigDecimal count;
        BigDecimal result;
        if (days >= 30.0d) {
            BigDecimal monthlyGb = BigDecimal.valueOf(gb).multiply(BigDecimal.valueOf(30))
                    .divide(BigDecimal.valueOf(days), 18, RoundingMode.HALF_UP);
            long packages = ceilPositive(BigDecimal.valueOf(usage), monthlyGb);
            result = BigDecimal.valueOf(price).multiply(BigDecimal.valueOf(packages))
                    .multiply(BigDecimal.valueOf(30)).divide(BigDecimal.valueOf(days), 18, RoundingMode.HALF_UP);
        } else {
            long byVolume = ceilPositive(BigDecimal.valueOf(usage), BigDecimal.valueOf(gb));
            long byCoverage = ceilPositive(BigDecimal.valueOf(30.0d), BigDecimal.valueOf(days));
            count = BigDecimal.valueOf(Math.max(1L, Math.max(byVolume, byCoverage)));
            result = count.multiply(BigDecimal.valueOf(price));
        }
        return result.setScale(0, RoundingMode.HALF_UP).longValueExact();
    }
    static Parsed parse(String input, Currency context) {
        if (input == null || input.length() > 300) return null;
        String s = Fmt.norm(input).toLowerCase(java.util.Locale.ROOT);
        if (s.matches(".*(?:^|\\s)-\\s*[0-9].*")) return null;
        Currency explicit = s.contains("ریال") ? Currency.IRR
                : (s.contains("تومان") || s.contains("تومن")) ? Currency.IRT : Currency.UNKNOWN;
        Currency currency = explicit != Currency.UNKNOWN ? explicit
                : (context == null ? Currency.UNKNOWN : context);
        Confidence confidence = explicit != Currency.UNKNOWN ? Confidence.HIGH
                : currency == Currency.UNKNOWN ? Confidence.NONE : Confidence.LOW;

        Pattern compound = Pattern.compile("([0-9][0-9,،.]*)\\s*هزار\\s*و\\s*([0-9][0-9,،.]*)\\s*(تومان|تومن|ریال)");
        Matcher cm = compound.matcher(s);
        if (cm.find()) {
            try {
                Currency suffix = "ریال".equals(cm.group(3)) ? Currency.IRR : Currency.IRT;
                if (explicit != Currency.UNKNOWN && explicit != suffix) return null;
                long a = parseWhole(cm.group(1));
                long b = parseWhole(cm.group(2));
                long raw = Math.addExact(Math.multiplyExact(a, 1000L), b);
                long normalized = toToman(raw, suffix);
                if (!validAmount(normalized)) return null;
                if (cm.find()) return null; // multiple price expressions are ambiguous
                return new Parsed(raw, normalized, suffix, Confidence.HIGH);
            } catch (RuntimeException invalid) { return null; }
        }

        Pattern withUnit = Pattern.compile("(?<![\\p{L}\\d])([0-9][0-9,،.]*(?:\\s*(?:هزار|میلیون))?)\\s*(تومان|تومن|ریال)(?![\\p{L}])");
        Matcher m = withUnit.matcher(s);
        if (m.find()) {
            try {
                Currency suffix = "ریال".equals(m.group(2)) ? Currency.IRR : Currency.IRT;
                if (explicit != Currency.UNKNOWN && explicit != suffix) return null;
                long raw = parseAmount(m.group(1));
                if (m.find()) return null;
                long normalized = toToman(raw, suffix);
                if (!validAmount(normalized)) return null;
                return new Parsed(raw, normalized, suffix, Confidence.HIGH);
            } catch (RuntimeException invalid) { return null; }
        }

        // Context currency is only a low-confidence fallback for a single, amount-only string.
        // A bare numeric value with no currency remains explicitly unknown; malformed text is rejected.
        if (!s.matches("[0-9][0-9,،.]*")) return null;
        if (currency == Currency.UNKNOWN)
            return new Parsed(0L, 0L, Currency.UNKNOWN, Confidence.NONE);
        try {
            long raw = parseWhole(s);
            long normalized = toToman(raw, currency);
            if (!validAmount(normalized)) return null;
            return new Parsed(raw, normalized, currency, Confidence.LOW);
        } catch (RuntimeException invalid) { return null; }
    }

    private static long parseWhole(String value) {
        String n = value.replace(",", "").replace("،", "");
        if (n.matches("[0-9]{1,3}(?:\\.[0-9]{3})+")) n = n.replace(".", "");
        if (!n.matches("[0-9]+")) throw new IllegalArgumentException("not_whole");
        return new BigDecimal(n).longValueExact();
    }

    private static long parseAmount(String value) {
        String n = Fmt.norm(value).replace(",", "").replace("،", "").replace(" ", "");
        boolean thousand = n.endsWith("هزار");
        boolean million = n.endsWith("میلیون");
        if (thousand) n = n.substring(0, n.length() - 4);
        if (million) n = n.substring(0, n.length() - 6);
        long base = parseWhole(n);
        return thousand ? Math.multiplyExact(base, 1000L)
                : million ? Math.multiplyExact(base, 1_000_000L) : base;
    }
}
