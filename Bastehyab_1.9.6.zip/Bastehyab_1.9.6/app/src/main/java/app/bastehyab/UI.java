package app.bastehyab;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.StateListDrawable;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.ClipDrawable;
import android.graphics.drawable.InsetDrawable;
import android.app.Dialog;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;

/** Shared visual system for Bastehyab: restrained cyber-security surfaces and semantic colour tokens. */
final class UI {
    private UI() { }

    static boolean light, mono;
    static int BG, CARD, CARD2, STROKE, PRIMARY, ACCENT, TEXT, MUTED, DANGER, BLUE, SUCCESS;
    /** Neumorphic tokens: recessed surface, light/dark shadow colours, primary-button gradient, warning. */
    static int INSET, LSH, DSH, G1, G2, WARN, INFO;
    static Typeface BODY, MEDIUM, BOLD;

    static String appearancePreference(Context c) {
        String appearance = Cfg.sp(c).getString("appearance", "auto");
        if ("dark".equals(appearance) || "light".equals(appearance) || "mono".equals(appearance))
            return appearance;
        return "auto";
    }

    static boolean isSystemNight(Context c) {
        int mask = c.getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
        return mask == Configuration.UI_MODE_NIGHT_YES;
    }

    static void applyTheme(Context c) {
        String appearance = appearancePreference(c);
        boolean useLightPalette = "light".equals(appearance)
                || ("auto".equals(appearance) && !isSystemNight(c));
        light = useLightPalette;
        mono = "mono".equals(appearance);
        if (light) {
            // Cool blue surfaces keep the same cyber identity in the optional light appearance.
            BG = 0xFFEAF0F8; CARD = 0xFFF3F7FC; CARD2 = 0xFFE2EAF5; INSET = 0xFFDCE6F2; STROKE = 0xFFC5D4E7;
            LSH = 0xFFFFFFFF; DSH = 0xFF9EADC2;
            PRIMARY = 0xFF1769D2; ACCENT = 0xFF087484; TEXT = 0xFF14243A;
            MUTED = 0xFF52677F; DANGER = 0xFFBE4055; BLUE = 0xFF347FE8;
            SUCCESS = 0xFF087A59; WARN = 0xFF986000; INFO = 0xFF246CC5; G1 = 0xFF155AB5; G2 = 0xFF176CCB;
        } else if (mono) {
            // Stealth: graphite soft-UI with a single cold highlight.
            BG = 0xFF14161A; CARD = 0xFF181B20; CARD2 = 0xFF1F2329; INSET = 0xFF0F1114; STROKE = 0xFF343A43;
            LSH = 0xFF2B3038; DSH = 0xFF050607;
            PRIMARY = 0xFFD0D6E0; ACCENT = 0xFF8FB4C9; TEXT = 0xFFF1F3F6;
            MUTED = 0xFF9AA2AD; DANGER = 0xFFE58B91; BLUE = 0xFF9DB8C9;
            SUCCESS = 0xFF7ED3B2; WARN = 0xFFE0B96A; INFO = 0xFF9DB8C9; G1 = 0xFF565D68; G2 = 0xFF6B737F;
        } else {
            // Deep navy, electric blue actions, cyan data accents and semantic status colours.
            BG = 0xFF081426; CARD = 0xFF101F35; CARD2 = 0xFF172A45; INSET = 0xFF09182B; STROKE = 0xFF294362;
            LSH = 0xFF203A58; DSH = 0xFF030914;
            PRIMARY = 0xFF438BFF; ACCENT = 0xFF35D6E8; TEXT = 0xFFF0F6FF;
            MUTED = 0xFF9CB0C9; DANGER = 0xFFFF7185; BLUE = 0xFF69A7FF;
            SUCCESS = 0xFF39D6A0; WARN = 0xFFFFC15C; INFO = 0xFF72B5FF; G1 = 0xFF155FC7; G2 = 0xFF1670C8;
        }
        if (BODY == null || MEDIUM == null || BOLD == null) {
            try {
                BODY = Typeface.createFromAsset(c.getAssets(), "fonts/NotoSansArabic-Regular.ttf");
                MEDIUM = Typeface.createFromAsset(c.getAssets(), "fonts/NotoSansArabic-Medium.ttf");
                BOLD = Typeface.createFromAsset(c.getAssets(), "fonts/NotoSansArabic-Bold.ttf");
            } catch (RuntimeException fontError) {
                BODY = Typeface.create("sans-serif", Typeface.NORMAL);
                MEDIUM = Typeface.create("sans-serif-medium", Typeface.NORMAL);
                BOLD = Typeface.create("sans-serif", Typeface.BOLD);
            }
        }
    }

    static int themeColor(int color) {
        int alpha = color >>> 24;
        int rgb = color & 0x00FFFFFF;
        int mapped = rgb;
        if (mono) {
            // Keep current semantic tokens intact; legacy decorative colours collapse
            // to a restrained grayscale ramp for the classic black-and-white theme.
            if (rgb == (BG & 0x00FFFFFF) || rgb == (CARD & 0x00FFFFFF)
                    || rgb == (CARD2 & 0x00FFFFFF) || rgb == (STROKE & 0x00FFFFFF)
                    || rgb == (PRIMARY & 0x00FFFFFF) || rgb == (ACCENT & 0x00FFFFFF)
                    || rgb == (TEXT & 0x00FFFFFF) || rgb == (MUTED & 0x00FFFFFF)
                    || rgb == (DANGER & 0x00FFFFFF) || rgb == (BLUE & 0x00FFFFFF)
                    || rgb == (SUCCESS & 0x00FFFFFF) || rgb == (WARN & 0x00FFFFFF) || rgb == (INFO & 0x00FFFFFF)) {
                mapped = rgb;
            } else {
                int r = (rgb >> 16) & 255, g = (rgb >> 8) & 255, b = rgb & 255;
                int luminance = (r * 212 + g * 715 + b * 73) / 1000;
                if (luminance < 28) mapped = BG;
                else if (luminance < 82) mapped = CARD;
                else if (luminance < 150) mapped = CARD2;
                else if (luminance < 218) mapped = MUTED;
                else mapped = TEXT;
            }
        } else if (light) {
            switch (rgb) {
                case 0x07101F: case 0x050B15: case 0x0C1B31: case 0x091426: case 0x0B172A:
                case 0x101828: case 0x10182D: case 0x07152F: case 0x0B2348: mapped = BG; break;
                case 0x11213A: case 0x101F37: case 0x0E1A30: case 0x0E1A2D: case 0x0E1A32:
                case 0x1B2942: case 0x182D4A: case 0x172238: mapped = CARD; break;
                case 0x1B3150: case 0x28415F: case 0x182B47: case 0x263B5A: case 0x16283A:
                case 0x152D42: case 0x0C1931: case 0x1A2D4A: case 0x142642: mapped = CARD2; break;
                case 0xF7FAFF: case 0xFFFFFF: mapped = TEXT; break;
                case 0xB3C1D7: case 0xB9D5E9: case 0x8393B0: mapped = MUTED; break;
                case 0x4AD9EA: case 0x55E8FF: case 0x54E8F7: case 0x41DDF4: case 0x35D9F5:
                case 0x37DFF4: case 0x38DDF2: mapped = ACCENT; break;
                case 0xB39BFF: case 0x9D78FF: case 0x9D7BFF: mapped = PRIMARY; break;
                case 0xFF829A: case 0xFF718F: mapped = DANGER; break;
                case 0x3A557A: case 0x516C91: case 0x587396: case 0x74518D: mapped = STROKE; break;
                case 0x373449: case 0x29283A: case 0x49315F: case 0x29273F: mapped = CARD; break;
                case 0x353349: case 0x48445F: mapped = CARD2; break;
                case 0xB65AF2: case 0xB65FE4: case 0xCE55EA: case 0x8F53C8: case 0x6245D0: mapped = PRIMARY; break;
                case 0x5B4DB2: case 0x8F4DD4: case 0x7646E8: case 0xCB58B9: mapped = PRIMARY; break;
                case 0xF08ADF: case 0xFF7F9C: case 0xE879D9: case 0xF5B84B:
                case 0xEC4899: case 0xF97316: mapped = DANGER; break;
                case 0xFFF3E7FB: case 0xFFEFE7FA: mapped = CARD2; break;
                case 0x45C995: case 0x55DDA8: case 0x63DDAA: case 0x70DFAF: case 0x22C55E: mapped = SUCCESS; break;
                case 0x06B6D4: mapped = ACCENT; break;
                default: break;
            }
        } else {
            switch (rgb) {
                case 0x07101F: case 0x050B15: case 0x0C1B31: case 0x091426: case 0x0B172A:
                case 0x101828: case 0x10182D: case 0x07152F: case 0x0B2348: mapped = BG; break;
                case 0x11213A: case 0x101F37: case 0x0E1A30: case 0x0E1A2D: case 0x0E1A32:
                case 0x1B2942: case 0x182D4A: case 0x172238: mapped = CARD; break;
                case 0x1B3150: case 0x28415F: case 0x182B47: case 0x263B5A: case 0x16283A:
                case 0x152D42: case 0x0C1931: case 0x1A2D4A: case 0x142642: mapped = CARD2; break;
                case 0xF7FAFF: case 0xFFFFFF: mapped = TEXT; break;
                case 0xB3C1D7: case 0xB9D5E9: case 0x8393B0: mapped = MUTED; break;
                case 0x4AD9EA: case 0x55E8FF: case 0x54E8F7: case 0x41DDF4: case 0x35D9F5:
                case 0x37DFF4: case 0x38DDF2: mapped = ACCENT; break;
                case 0xB39BFF: case 0x9D78FF: case 0x9D7BFF: mapped = PRIMARY; break;
                case 0xFF829A: case 0xFF718F: mapped = DANGER; break;
                case 0x3A557A: case 0x516C91: case 0x587396: case 0x74518D: mapped = STROKE; break;
                case 0x373449: case 0x29283A: case 0x49315F: case 0x29273F: mapped = CARD; break;
                case 0x353349: case 0x48445F: mapped = CARD2; break;
                case 0xB65AF2: case 0xB65FE4: case 0xCE55EA: case 0x8F53C8: case 0x6245D0: mapped = PRIMARY; break;
                case 0x5B4DB2: case 0x8F4DD4: case 0x7646E8: case 0xCB58B9: mapped = PRIMARY; break;
                case 0xF08ADF: case 0xFF7F9C: case 0xE879D9: case 0xF5B84B:
                case 0xEC4899: case 0xF97316: mapped = DANGER; break;
                case 0xFFF3E7FB: case 0xFFEFE7FA: mapped = CARD2; break;
                case 0x45C995: case 0x55DDA8: case 0x63DDAA: case 0x70DFAF: case 0x22C55E: mapped = SUCCESS; break;
                case 0x06B6D4: mapped = ACCENT; break;
                default: break;
            }
        }
        return (alpha << 24) | (mapped & 0x00FFFFFF);
    }

    static void applyTypefaceTree(View view) {
        if (view instanceof TextView) {
            TextView text = (TextView) view;
            if (text instanceof Button || text instanceof android.widget.Switch) text.setTypeface(MEDIUM);
            else if (text.getTypeface() != null && text.getTypeface().isBold()) text.setTypeface(BOLD);
            else text.setTypeface(BODY);
            text.setIncludeFontPadding(false);
        }
        if (view instanceof android.view.ViewGroup) {
            android.view.ViewGroup group = (android.view.ViewGroup) view;
            for (int i = 0; i < group.getChildCount(); i++) applyTypefaceTree(group.getChildAt(i));
        }
    }

    static int dp(Context c, float v) { return Math.round(v * c.getResources().getDisplayMetrics().density); }
    static int sz(Context c, int v) { return v > 0 ? dp(c, v) : v; }

    static int surfaceColor(int color) {
        if ((color & 0x00FFFFFF) == 0x00FFFFFF || (color >>> 24) == 0) return color;
        return themeColor(color);
    }
    private static int shade(int color, float factor) {
        int a = color & 0xFF000000;
        int red = Math.max(0, Math.min(255, Math.round(((color >> 16) & 255) * factor)));
        int green = Math.max(0, Math.min(255, Math.round(((color >> 8) & 255) * factor)));
        int blue = Math.max(0, Math.min(255, Math.round((color & 255) * factor)));
        return a | (red << 16) | (green << 8) | blue;
    }
    static GradientDrawable rr(Context c, int fill, float r) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(surfaceColor(fill));
        g.setCornerRadius(dp(c, r));
        return g;
    }
    static GradientDrawable rr(Context c, int fill, float r, int stroke) {
        GradientDrawable g = rr(c, fill, r); g.setStroke(dp(c, 1), surfaceColor(stroke)); return g;
    }
    static GradientDrawable grad(Context c, int a, int b, float r) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{surfaceColor(a), surfaceColor(b)}); g.setCornerRadius(dp(c, r)); return g;
    }
    static Drawable appBackground(Context c) {
        return new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{BG, CARD, BG});
    }
    static int tint(int color) { return (themeColor(color) & 0x00FFFFFF) | 0x22000000; }
    static int contrastText(int background) {
        double r = ((background >> 16) & 255) / 255.0;
        double g = ((background >> 8) & 255) / 255.0;
        double b = (background & 255) / 255.0;
        r = r <= 0.04045 ? r / 12.92 : Math.pow((r + 0.055) / 1.055, 2.4);
        g = g <= 0.04045 ? g / 12.92 : Math.pow((g + 0.055) / 1.055, 2.4);
        b = b <= 0.04045 ? b / 12.92 : Math.pow((b + 0.055) / 1.055, 2.4);
        double luminance = 0.2126 * r + 0.7152 * g + 0.0722 * b;
        return luminance > 0.42 ? 0xFF182338 : 0xFFFFFFFF;
    }

    static TextView tv(Context c, String s, float sp, int color, boolean bold) {
        TextView t = new TextView(c); t.setText(s); t.setTextSize(Math.max(12f, sp)); t.setTextColor(themeColor(color));
        t.setTypeface(bold ? BOLD : BODY);
        t.setTextDirection(View.TEXT_DIRECTION_RTL); t.setGravity(Gravity.TOP | Gravity.START);
        t.setTextAlignment(View.TEXT_ALIGNMENT_GRAVITY); t.setIncludeFontPadding(false);
        t.setLineSpacing(dp(c, 4f), 1.16f);
        return t;
    }
    static LinearLayout vbox(Context c) {
        LinearLayout l = new LinearLayout(c); l.setOrientation(LinearLayout.VERTICAL);
        l.setLayoutDirection(View.LAYOUT_DIRECTION_RTL); return l;
    }
    static LinearLayout hbox(Context c) {
        LinearLayout l = new LinearLayout(c); l.setOrientation(LinearLayout.HORIZONTAL);
        l.setLayoutDirection(View.LAYOUT_DIRECTION_RTL); l.setGravity(Gravity.CENTER_VERTICAL); return l;
    }
    static LinearLayout.LayoutParams lp(Context c, int w, int h, float s, float t, float e, float b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(sz(c, w), sz(c, h));
        p.setMargins(0, dp(c, t), 0, dp(c, b)); p.setMarginStart(dp(c, s)); p.setMarginEnd(dp(c, e)); return p;
    }
    static LinearLayout.LayoutParams lp2(Context c, float start) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        p.setMarginStart(dp(c, start)); return p;
    }
    static LinearLayout.LayoutParams lpw(float weight) { return new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, weight); }
    // ------------------------------------------------------------ soft-UI surfaces

    private static int a(int color, int alpha) { return (alpha << 24) | (color & 0x00FFFFFF); }

    /** Raised soft surface. depth is the shadow reach in dp. */
    static Drawable raised(Context c, float r, float depth, boolean hairline) {
        return new NeuDrawable(NeuDrawable.RAISED, dp(c, r), dp(c, depth),
                light ? CARD : shade(CARD, 1.07f), CARD, LSH, DSH,
                hairline ? a(light ? 0xFFFFFFFF : STROKE, light ? 0xAA : 0x99) : 0, dp(c, 1), 0);
    }
    static Drawable raised(Context c, float r) { return raised(c, r, 7, true); }
    static Drawable raisedSmall(Context c, float r) { return raised(c, r, 4, true); }

    /** Pressed-in / recessed surface (inputs, tracks, selected choices). */
    static Drawable inset(Context c, float r, int glow) {
        return new NeuDrawable(NeuDrawable.INSET, dp(c, r), dp(c, 5), INSET, INSET, LSH, DSH,
                0, dp(c, 1), glow);
    }
    static Drawable inset(Context c, float r) { return inset(c, r, 0); }

    /** Flat body with hairline border: overlay windows, where an outer shadow would be clipped. */
    static Drawable panel(Context c, float r) {
        return new NeuDrawable(NeuDrawable.FLAT, dp(c, r), dp(c, 6),
                CARD2, CARD, LSH, DSH, a(PRIMARY, 0x66), dp(c, 1.2f), 0);
    }

    /** Pads a drawable so an outer shadow stays inside the view bounds (rarely needed). */
    static Drawable padded(Drawable d, int px) { return new InsetDrawable(d, px); }

    /** Walks the tree once so soft shadows drawn outside child bounds are not clipped. */
    static void unclip(View v) {
        if (v instanceof ViewGroup && !(v instanceof ScrollView)) {
            ViewGroup g = (ViewGroup) v;
            g.setClipChildren(false);
            g.setClipToPadding(false);
            for (int i = 0; i < g.getChildCount(); i++) unclip(g.getChildAt(i));
        } else if (v instanceof ScrollView) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) unclip(g.getChildAt(i));
        }
    }

    static LinearLayout card(Context c) {
        LinearLayout l = vbox(c);
        int p = dp(c, 12);
        l.setPadding(p, p, p, p);
        l.setBackground(raised(c, 16));
        return l;
    }

    /** Status tag: tinted pill with a hairline in the same hue. */
    static TextView chip(Context c, String s, int bg, int fg) {
        TextView t = tv(c, s, 11, fg, true);
        t.setPadding(dp(c, 9), dp(c, 6), dp(c, 9), dp(c, 6));
        t.setMaxLines(2);
        int fgc = themeColor(fg);
        GradientDrawable g = new GradientDrawable();
        g.setColor(a(fgc, light ? 0x1A : 0x24));
        g.setCornerRadius(dp(c, 12));
        g.setStroke(dp(c, 1), a(fgc, 0x66));
        t.setBackground(g);
        t.setGravity(Gravity.CENTER);
        return t;
    }

    /** Selectable option (segmented chips, operator pills): raised when off, glowing inset when on. */
    static TextView choice(Context c, String s, boolean on) {
        TextView t = tv(c, s, 14, on ? PRIMARY : TEXT, on);
        t.setGravity(Gravity.CENTER);
        t.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        t.setPadding(dp(c, 10), dp(c, 10), dp(c, 10), dp(c, 10));
        t.setMinWidth(dp(c, 48));
        t.setMinHeight(dp(c, 48));
        t.setMaxLines(3);
        t.setFocusable(true);
        t.setClickable(true);
        t.setSelected(on);
        t.setBackground(on ? inset(c, 14, PRIMARY) : raisedSmall(c, 14));
        String accessibleLabel = s.replace("✓", "").replace("○", "").replace("✔", "").trim();
        t.setContentDescription(accessibleLabel);
        setStateDescription(t, on ? "انتخاب‌شده" : "انتخاب‌نشده");
        t.setAccessibilityDelegate(new View.AccessibilityDelegate() {
            @Override public void onInitializeAccessibilityNodeInfo(View host,
                    android.view.accessibility.AccessibilityNodeInfo info) {
                super.onInitializeAccessibilityNodeInfo(host, info);
                info.setClassName(android.widget.Button.class.getName());
                info.setCheckable(true);
                info.setChecked(host.isSelected());
            }
        });
        return t;
    }

    static void setStateDescription(View view, String description) {
        if (android.os.Build.VERSION.SDK_INT >= 30) view.setStateDescription(description);
    }

    static void markButton(View view, String label, String state) {
        view.setFocusable(true);
        view.setClickable(true);
        view.setMinimumWidth(dp(view.getContext(), 48));
        view.setMinimumHeight(dp(view.getContext(), 48));
        view.setContentDescription(label);
        if (state != null) setStateDescription(view, state);
        view.setAccessibilityDelegate(new View.AccessibilityDelegate() {
            @Override public void onInitializeAccessibilityNodeInfo(View host,
                    android.view.accessibility.AccessibilityNodeInfo info) {
                super.onInitializeAccessibilityNodeInfo(host, info);
                info.setClassName(android.widget.Button.class.getName());
            }
        });
    }

    /** Accessible icon-only action with a Persian name and a minimum 48dp target. */
    static TextView iconButton(Context c, String glyph, String label, String state,
                               View.OnClickListener listener) {
        TextView v = tv(c, glyph, 18, TEXT, true);
        v.setGravity(Gravity.CENTER);
        v.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        v.setMinWidth(dp(c, 48));
        v.setMinHeight(dp(c, 48));
        v.setPadding(dp(c, 8), dp(c, 8), dp(c, 8), dp(c, 8));
        v.setBackground(raisedSmall(c, 14));
        v.setFocusable(true);
        v.setClickable(true);
        v.setContentDescription(label);
        if (state != null) setStateDescription(v, state);
        v.setOnClickListener(listener);
        if (android.os.Build.VERSION.SDK_INT >= 21) {
            v.setAccessibilityDelegate(new View.AccessibilityDelegate() {
                @Override public void onInitializeAccessibilityNodeInfo(View host,
                        android.view.accessibility.AccessibilityNodeInfo info) {
                    super.onInitializeAccessibilityNodeInfo(host, info);
                    info.setClassName(android.widget.Button.class.getName());
                    info.addAction(android.view.accessibility.AccessibilityNodeInfo.AccessibilityAction.ACTION_CLICK);
                }
            });
        }
        return v;
    }

    /** Small monospace caption, e.g. "// OVERVIEW"; reinforces the security-console mood. */
    static TextView mono(Context c, String s, float sp, int color) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(Math.max(12f, sp));
        t.setTextColor(themeColor(color));
        t.setTypeface(MEDIUM != null ? MEDIUM : Typeface.create("sans-serif-medium", Typeface.NORMAL));
        t.setLetterSpacing(0.08f);
        t.setTextDirection(View.TEXT_DIRECTION_RTL);
        t.setGravity(Gravity.START);
        t.setIncludeFontPadding(false);
        return t;
    }

    private static Drawable primaryShape(Context c, float r, boolean pressed) {
        int g1 = pressed ? shade(G1, .82f) : G1, g2 = pressed ? shade(G2, .82f) : G2;
        return new NeuDrawable(pressed ? NeuDrawable.FLAT : NeuDrawable.RAISED, dp(c, r), dp(c, 5),
                g2, g1, LSH, DSH, a(0xFFFFFFFF, pressed ? 0x22 : 0x44), dp(c, 1),
                0);
    }

    /**
     * Button. Primary (bg == PRIMARY): electric-blue gradient with a restrained halo.
     * Everything else: raised key that turns into an inset key when pressed.
     */
    static Button btn(Context c, String s, int bg, int fg, View.OnClickListener l) {
        Button b = new Button(c);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextSize(14);
        b.setTypeface(MEDIUM);
        boolean primary = (themeColor(bg) & 0x00FFFFFF) == (PRIMARY & 0x00FFFFFF);
        boolean danger = (themeColor(fg) & 0x00FFFFFF) == (DANGER & 0x00FFFFFF);
        StateListDrawable states = new StateListDrawable();
        if (primary) {
            states.addState(new int[]{android.R.attr.state_pressed}, primaryShape(c, 16, true));
            states.addState(new int[]{}, primaryShape(c, 16, false));
            b.setTextColor(0xFFFFFFFF);
        } else {
            states.addState(new int[]{android.R.attr.state_pressed}, inset(c, 16, danger ? DANGER : 0));
            states.addState(new int[]{}, raisedSmall(c, 16));
            b.setTextColor(themeColor(fg));
        }
        b.setBackground(states);
        b.setStateListAnimator(null);
        b.setElevation(0);
        b.setMinHeight(dp(c, 48));
        b.setMinimumHeight(dp(c, 48));
        b.setGravity(Gravity.CENTER);
        b.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        b.setTextDirection(View.TEXT_DIRECTION_RTL);
        b.setPadding(dp(c, 16), dp(c, 10), dp(c, 16), dp(c, 10));
        b.setFocusable(true);
        b.setContentDescription(s);
        b.setOnClickListener(l);
        return b;
    }

    /** Text field: recessed, mono hint colour, LTR-agnostic. */
    static void styleInput(Context c, EditText e) {
        e.setHintTextColor(MUTED);
        e.setTextColor(TEXT);
        e.setBackground(inset(c, 14));
        e.setPadding(dp(c, 14), dp(c, 11), dp(c, 14), dp(c, 11));
    }

    /** Horizontal progress bar with a recessed track and an electric-blue-to-cyan fill. */
    static ProgressBar progress(Context c) {
        ProgressBar p = new ProgressBar(c, null, android.R.attr.progressBarStyleHorizontal);
        GradientDrawable fill = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{G2, ACCENT});
        fill.setCornerRadius(dp(c, 4));
        LayerDrawable layers = new LayerDrawable(new Drawable[]{
                inset(c, 4),
                new ClipDrawable(fill, Gravity.START, ClipDrawable.HORIZONTAL)});
        layers.setId(0, android.R.id.background);
        layers.setId(1, android.R.id.progress);
        p.setProgressDrawable(layers);
        return p;
    }

    /** Switch with a recessed capsule track and a raised, glowing thumb when on. */
    static void styleSwitch(Context c, Switch sw) {
        int w = dp(c, 50), h = dp(c, 28), t = dp(c, 24);
        Drawable trackOn = inset(c, 14, ACCENT);
        Drawable trackOff = inset(c, 14);
        StateListDrawable track = new StateListDrawable();
        track.addState(new int[]{android.R.attr.state_checked}, trackOn);
        track.addState(new int[]{}, trackOff);
        ((NeuDrawable) trackOn).setIntrinsicSize(w, h);
        ((NeuDrawable) trackOff).setIntrinsicSize(w, h);
        sw.setTrackDrawable(track);
        GradientDrawable thumbOn = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{ACCENT, BLUE});
        thumbOn.setShape(GradientDrawable.OVAL);
        thumbOn.setSize(t, t);
        GradientDrawable thumbOff = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{CARD2, shade(CARD2, .85f)});
        thumbOff.setShape(GradientDrawable.OVAL);
        thumbOff.setSize(t, t);
        thumbOff.setStroke(dp(c, 1), STROKE);
        StateListDrawable thumb = new StateListDrawable();
        thumb.addState(new int[]{android.R.attr.state_checked}, thumbOn);
        thumb.addState(new int[]{}, thumbOff);
        sw.setThumbDrawable(new InsetDrawable(thumb, dp(c, 2)));
    }

    /** Section heading: compact technical caption + title, with a cyan marker. */
    static View sectionHeader(Context c, String tag, String title, String subtitle) {
        LinearLayout box = hbox(c);
        View bar = new View(c);
        GradientDrawable g = new GradientDrawable();
        g.setColor(ACCENT);
        g.setCornerRadius(dp(c, 2));
        bar.setBackground(g);
        box.addView(bar, lp(c, 3, 30, 0, 0, 10, 0));
        LinearLayout labels = vbox(c);
        if (tag != null && !tag.isEmpty()) {
            TextView eyebrow = tv(c, tag, 11, MUTED, true);
            labels.addView(eyebrow);
        }
        labels.addView(tv(c, title, 15, TEXT, true), lp(c, -1, -2, 0, tag == null ? 0 : 2, 0, 0));
        if (subtitle != null && !subtitle.isEmpty()) labels.addView(tv(c, subtitle, 10, MUTED, false), lp(c, -1, -2, 0, 2, 0, 0));
        box.addView(labels, lpw(1f));
        return box;
    }

    // ------------------------------------------------------------ dialogs

    interface DialogCb { void on(Dialog d); }

    static final class BoundedScrollView extends ScrollView {
        private final int maxHeight;
        BoundedScrollView(Context context, int maxHeight) { super(context); this.maxHeight = Math.max(dp(context, 24), maxHeight); }
        @Override protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
            int parentMode = MeasureSpec.getMode(heightMeasureSpec);
            int parentSize = MeasureSpec.getSize(heightMeasureSpec);
            int cap = parentMode == MeasureSpec.UNSPECIFIED ? maxHeight : Math.min(maxHeight, parentSize);
            int bounded = MeasureSpec.makeMeasureSpec(Math.max(0, cap), MeasureSpec.AT_MOST);
            super.onMeasure(widthMeasureSpec, bounded);
        }
    }

    /** Scroll container capped to the current app window, including split-screen and landscape. */
    static BoundedScrollView boundedScroll(Context c, int maxHeight) {
        BoundedScrollView scroll = new BoundedScrollView(c, maxHeight);
        scroll.setFillViewport(false);
        scroll.setVerticalScrollBarEnabled(false);
        scroll.setClipToPadding(false);
        scroll.setOverScrollMode(View.OVER_SCROLL_IF_CONTENT_SCROLLS);
        return scroll;
    }

    static boolean compact(Context c) {
        android.util.DisplayMetrics dm = c.getResources().getDisplayMetrics();
        return dm.widthPixels / dm.density < 380f || c.getResources().getConfiguration().fontScale >= 1.2f;
    }

    /** Themed replacement for AlertDialog. A button with a null callback just dismisses. */
    static final class Dlg {
        private final Context c;
        private String title, message;
        private View content;
        private final java.util.List<String> labels = new java.util.ArrayList<>();
        private final java.util.List<Integer> kinds = new java.util.ArrayList<>(); // 0 primary, 1 neutral, 2 danger
        private final java.util.List<DialogCb> callbacks = new java.util.ArrayList<>();

        Dlg(Context c) { this.c = c; }
        Dlg title(String t) { title = t; return this; }
        Dlg message(String m) { message = m; return this; }
        Dlg view(View v) { content = v; return this; }
        Dlg button(String label, int kind, DialogCb cb) { labels.add(label); kinds.add(kind); callbacks.add(cb); return this; }

        Dialog show() {
            final Dialog d = new Dialog(c);
            d.requestWindowFeature(Window.FEATURE_NO_TITLE);
            FrameLayout shell = new FrameLayout(c);
            shell.setPadding(dp(c, 12), dp(c, 12), dp(c, 12), dp(c, 12));
            LinearLayout panel = vbox(c);
            panel.setPadding(dp(c, 18), dp(c, 18), dp(c, 18), dp(c, 14));
            panel.setBackground(raised(c, 20, 6, true));
            if (title != null) {
                TextView heading = tv(c, title, 17, TEXT, true);
                heading.setContentDescription(title);
                heading.setFocusable(true);
                panel.addView(heading, lp(c, -1, -2, 0, 0, 0, 8));
            }
            LinearLayout body = vbox(c);
            if (message != null) {
                TextView messageView = tv(c, message, 14, MUTED, false);
                messageView.setTextDirection(View.TEXT_DIRECTION_RTL);
                messageView.setGravity(Gravity.TOP | Gravity.START);
                messageView.setSingleLine(false);
                messageView.setMaxLines(Integer.MAX_VALUE);
                body.addView(messageView, lp(c, -1, -2, 0, 0, 0, 10));
            }
            if (content != null) body.addView(content, lp(c, -1, -2, 0, 0, 0, 6));
            android.util.DisplayMetrics dm = c.getResources().getDisplayMetrics();
            // Reserve enough room for dialog chrome and actions even in short split-screen windows.
            int maxBodyHeight = Math.max(dp(c, 24), Math.min(dp(c, 480), dm.heightPixels - dp(c, 160)));
            BoundedScrollView sv = boundedScroll(c, maxBodyHeight);
            sv.setVerticalScrollBarEnabled(false);
            sv.setFillViewport(false);
            sv.addView(body, new FrameLayout.LayoutParams(-1, -2));
            panel.addView(sv, new LinearLayout.LayoutParams(-1, -2));
            float fontScale = c.getResources().getConfiguration().fontScale;
            boolean verticalActions = dm.widthPixels / dm.density < 400f || fontScale >= 1.15f || labels.size() >= 3;
            LinearLayout row = verticalActions ? vbox(c) : hbox(c);
            for (int i = 0; i < labels.size(); i++) {
                final DialogCb cb = callbacks.get(i);
                int kind = kinds.get(i);
                Button b = btn(c, labels.get(i), kind == 0 ? PRIMARY : CARD2,
                        kind == 2 ? DANGER : kind == 0 ? TEXT : MUTED, v -> { if (cb == null) d.dismiss(); else cb.on(d); });
                b.setTextSize(16f);
                b.setSingleLine(false);
                b.setMaxLines(3);
                b.setMinHeight(dp(c, 52));
                b.setContentDescription(labels.get(i));
                LinearLayout.LayoutParams actionParams = verticalActions
                        ? lp(c, -1, -2, 0, i == 0 ? 0 : 8, 0, 0)
                        : lp2(c, i == 0 ? 0 : 8);
                row.addView(b, actionParams);
            }
            if (!labels.isEmpty()) panel.addView(row, lp(c, -1, -2, 0, 10, 0, 4));
            shell.addView(panel, new FrameLayout.LayoutParams(-1, -2));
            applyTypefaceTree(shell);
            unclip(shell);
            d.setContentView(shell);
            Window w = d.getWindow();
            if (w != null) {
                w.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(0x00000000));
                w.setDimAmount(0.62f);
                w.setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
                        | android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
                int availableWidth = Math.max(dp(c, 1), c.getResources().getDisplayMetrics().widthPixels - dp(c, 24));
                int width = Math.min(availableWidth, dp(c, 440));
                w.setLayout(width, ViewGroup.LayoutParams.WRAP_CONTENT);
            }
            d.show();
            return d;
        }
    }
}
