package app.bastehyab;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

/** Bounded local history. Failure codes never include page text, account data or package contents. */
final class HistoryLog {
    private static final String KEY = "history";
    private static final String ERROR_COUNT = "history_error_count";
    private static final String LAST_ERROR = "history_error_last";

    static final class Entry {
        final String title, field, note, operatorId, packageKey;
        final double before, after;
        final long ts;
        Entry(String title, String field, double before, double after, long ts, String note,
              String operatorId, String packageKey) {
            this.title=title; this.field=field; this.before=before; this.after=after; this.ts=ts;
            this.note=note; this.operatorId=operatorId; this.packageKey=packageKey;
        }
    }

    private static String safeLabel(String value) {
        if (value == null) return "بسته";
        String clean = value.replaceAll("[\\p{Cc}\\u202A-\\u202E\\u2066-\\u2069]", " ").trim();
        if (clean.isEmpty()) return "بسته";
        return clean.length() > 120 ? clean.substring(0, 120) : clean;
    }

    /** Never replace a corrupt history document with an empty list: preserve it for recovery. */
    private static String safeIdentity(String value) {
        if (value == null) return "";
        String clean = value.replaceAll("[\\p{Cc}\\u202A-\\u202E\\u2066-\\u2069]", " ").trim();
        return clean.length() > 1024 ? clean.substring(0, 1024) : clean;
    }

    private static JSONArray readExisting(SharedPreferences sp) throws Exception {
        String raw = sp.getString(KEY, "[]");
        JSONArray array = new JSONArray(raw);
        for (int i = 0; i < array.length(); i++) array.getJSONObject(i);
        return array;
    }

    private static void markError(Context c, String code) {
        try {
            SharedPreferences sp = Cfg.sp(c);
            int count = sp.getInt(ERROR_COUNT, 0);
            sp.edit().putInt(ERROR_COUNT, Math.min(1000000, count + 1))
                    .putString(LAST_ERROR, code).apply();
            android.util.Log.w("BastehyabHistory", "History operation failed: " + code);
        } catch (RuntimeException ignored) {
            android.util.Log.w("BastehyabHistory", "History error could not be persisted");
        }
    }

    static synchronized boolean hasError(Context c) {
        try { return Cfg.sp(c).getInt(ERROR_COUNT, 0) > 0; }
        catch (RuntimeException e) { return true; }
    }

    static synchronized String errorSummary(Context c) {
        try {
            SharedPreferences sp = Cfg.sp(c);
            int count = sp.getInt(ERROR_COUNT, 0);
            if (count <= 0) return "";
            String code = sp.getString(LAST_ERROR, "UNKNOWN");
            return "یک مشکل در تاریخچه ثبت شده است (" + count + " مورد؛ کد " + code + ").";
        } catch (RuntimeException e) {
            return "وضعیت تاریخچه قابل خواندن نیست.";
        }
    }

    static synchronized void clearError(Context c) {
        try { Cfg.sp(c).edit().remove(ERROR_COUNT).remove(LAST_ERROR).apply(); }
        catch (RuntimeException e) {
            // The warning cannot be cleared if preferences are unavailable; keep a local log code.
            android.util.Log.w("BastehyabHistory", "History error indicator could not be cleared");
        }
    }

    static synchronized void record(Context c, Pkg old, Pkg cur) {
        List<History.Change> changes = History.diff(old, cur);
        if (changes.isEmpty()) return;
        SharedPreferences sp;
        try { sp = Cfg.sp(c); }
        catch (RuntimeException e) { markError(c, "PREF_UNAVAILABLE"); return; }
        JSONArray a;
        try { a = readExisting(sp); }
        catch (Exception e) { markError(c, "JSON_CORRUPT_PRESERVED"); return; }
        try {
            for (History.Change ch : changes) {
                JSONObject x = new JSONObject();
                x.put("title", safeLabel(cur.title)); x.put("field", ch.field);
                x.put("operatorId", safeIdentity(cur.op)); x.put("packageKey", safeIdentity(cur.key));
                x.put("before", ch.before); x.put("after", ch.after); x.put("ts", ch.ts);
                a.put(x);
            }
            persist(sp, a);
        } catch (Exception e) { markError(c, "JSON_WRITE_FAILED"); }
    }

    static synchronized void recordReview(Context c, Pkg p, boolean approved) {
        try {
            SharedPreferences sp = Cfg.sp(c);
            JSONArray a;
            try { a = readExisting(sp); }
            catch (Exception corrupt) { markError(c, "JSON_CORRUPT_PRESERVED"); return; }
            JSONObject event = new JSONObject();
            event.put("title", safeLabel(p.title));
            event.put("field", approved ? "review_approved" : "review_rejected");
            event.put("operatorId", safeIdentity(p.op)); event.put("packageKey", safeIdentity(p.key));
            event.put("before", p.toman);
            event.put("after", approved ? p.reviewedToman : 0);
            event.put("ts", p.reviewedAt);
            // Free-form review notes are deliberately excluded from history storage.
            a.put(event);
            persist(sp, a);
        } catch (Exception e) { markError(c, "REVIEW_HISTORY_FAILED"); }
    }

    private static void persist(SharedPreferences sp, JSONArray a) throws Exception {
        JSONArray bounded = new JSONArray();
        for (int i=Math.max(0,a.length()-300); i<a.length(); i++) bounded.put(a.getJSONObject(i));
        boolean committed = sp.edit().putString(KEY, bounded.toString()).commit();
        if (!committed) throw new IllegalStateException("history_commit_failed");
    }

    static synchronized List<Entry> recent(Context c, int limit) {
        List<Entry> out = new ArrayList<>();
        if (limit <= 0) return out;
        try {
            JSONArray a = new JSONArray(Cfg.sp(c).getString(KEY, "[]"));
            for (int i=a.length()-1; i>=0 && out.size()<limit; i--) {
                JSONObject x=a.getJSONObject(i);
                String field = x.optString("field", "");
                double before = x.optDouble("before", Double.NaN);
                double after = x.optDouble("after", Double.NaN);
                long ts = x.optLong("ts", 0);
                if (field.isEmpty() || (Double.isNaN(before) || Double.isInfinite(before)) || (Double.isNaN(after) || Double.isInfinite(after)) || ts < 0) continue;
                out.add(new Entry(safeLabel(x.optString("title", "")), field,
                        before, after, ts, "", safeIdentity(x.optString("operatorId", "")),
                        safeIdentity(x.optString("packageKey", ""))));
            }
        } catch (RuntimeException e) {
            markError(c, "PREF_READ_FAILED");
        } catch (Exception e) {
            markError(c, "JSON_READ_FAILED");
        }
        return out;
    }

    static synchronized void clear(Context c) {
        try {
            if (!Cfg.sp(c).edit().remove(KEY).commit()) markError(c, "CLEAR_FAILED");
        } catch (RuntimeException e) { markError(c, "CLEAR_FAILED"); }
    }
}
