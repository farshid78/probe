package app.bastehyab;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Versioned, price-independent package identity. Classification is deliberately not an input. */
final class PkgIdentity {
    static final int VERSION = 3;
    static final String UNKNOWN_VOLUME = "VOLUME_UNKNOWN";
    static final String UNKNOWN_DURATION = "DURATION_UNKNOWN";
    static final String UNKNOWN_KIND = "KIND_UNKNOWN";
    private static final Pattern PRICE = Pattern.compile(
            "(?<![\\p{L}\\d])(?:\\d{1,3}(?:[,،.]\\d{3})+|\\d+(?:\\.\\d+)?)\\s*(?:هزار|میلیون)?\\s*(?:تومان|تومن|ریال|ت)(?![\\p{L}])",
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    private static final Pattern ID = Pattern.compile(
            "(?:کد\\s*(?:بسته|محصول)|شناسه\\s*(?:بسته|محصول)|package\\s*id|product\\s*id|offer\\s*id)\\s*[:#：-]?\\s*([a-z0-9][a-z0-9._-]{2,63})",
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    private static final Pattern COMBO = Pattern.compile(
            "پیامک|sms|مکالمه|تماس|دقیقه", Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    private static final Pattern NETWORK_ONLY = Pattern.compile(
            "(?:فقط\\s*(?:در\\s*)?(?:شبکه\\s*)?|only\\s*)(2g|3g|4g|5g)",
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    private static final Pattern FAIR_USE = Pattern.compile(
            "(?:مصرف\\s*منصفانه|حد\\s*مصرف(?:\\s*منصفانه)?|سقف\\s*مصرف)\\s*(?:حداکثر\\s*)?(\\d+(?:\\.\\d+)?)\\s*(گیگ(?:ابایت)?|gb|مگ(?:ابایت)?|mb)",
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    private static final Pattern APP_ONLY = Pattern.compile(
            "(?:فقط\\s*(?:برای\\s*)?(?:اپلیکیشن|برنامه)|ویژه\\s*(?:اپلیکیشن|برنامه))\\s*[:：-]?\\s*([\\p{L}\\p{N}][\\p{L}\\p{N}._-]{1,39})",
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);

    private PkgIdentity() {}

    /** Only an explicitly labelled ID inside the card is accepted as observed identity. */
    static String observedId(String cardText) {
        if (cardText == null || cardText.isEmpty()) return "";
        Matcher matcher = ID.matcher(Fmt.norm(cardText));
        if (!matcher.find()) return "";
        String value = matcher.group(1).trim();
        return validObservedId(value) ? value.toLowerCase(Locale.ROOT) : "";
    }

    static boolean validObservedId(String value) {
        if (value == null) return false;
        String v = Fmt.norm(value).trim();
        if (v.length() < 3 || v.length() > 64 || !v.matches("[A-Za-z0-9][A-Za-z0-9._-]{2,63}")) return false;
        String lower = v.toLowerCase(Locale.ROOT);
        return !lower.equals("unknown") && !lower.equals("null") && !lower.equals("none")
                && !lower.equals("undefined") && !lower.equals("0");
    }

    static String inferKind(String cardText) {
        String text = Fmt.norm(cardText);
        if (text.isEmpty()) return UNKNOWN_KIND;
        // Kind describes the product's structure, not its restriction/classification labels.
        return COMBO.matcher(text).find() ? "COMBO" : "DATA";
    }

    /** Extract explicit card-intrinsic limits (network, fair-use quota, app-only), not classification labels. */
    static String intrinsicLimits(String cardText) {
        if (cardText == null || cardText.isEmpty()) return "";
        String normalized = Fmt.norm(cardText);
        Set<String> values = new LinkedHashSet<>();
        Matcher matcher = NETWORK_ONLY.matcher(normalized);
        while (matcher.find()) values.add("NETWORK_ONLY_" + matcher.group(1).toUpperCase(Locale.ROOT));
        Matcher fair = FAIR_USE.matcher(normalized);
        while (fair.find()) {
            double amount;
            try { amount = Double.parseDouble(fair.group(1)); }
            catch (NumberFormatException invalid) { continue; }
            String unit = fair.group(2).toLowerCase(Locale.ROOT);
            double mb = unit.startsWith("گ") || unit.equals("gb") ? amount * 1024.0 : amount;
            if (Double.isFinite(mb) && mb > 0 && mb <= 5_120_000) {
                values.add("FAIR_USE_MB_" + Math.round(mb));
            }
        }
        Matcher app = APP_ONLY.matcher(normalized);
        while (app.find()) {
            String name = app.group(1).toLowerCase(Locale.ROOT).trim();
            if (!name.isEmpty()) values.add("APP_ONLY_" + name.replaceAll("[^\\p{L}\\p{N}._-]", ""));
        }
        List<String> sorted = new ArrayList<>(values);
        Collections.sort(sorted);
        return join(sorted, ",");
    }

    static void normalize(Pkg p) {
        if (p == null) return;
        if (p.identityTitle == null || p.identityTitle.trim().isEmpty()) p.identityTitle = p.title == null ? "" : p.title;
        if (p.identityKind == null || p.identityKind.trim().isEmpty()
                || UNKNOWN_KIND.equals(p.identityKind)) p.identityKind = inferKind(p.identityTitle);
        if (p.identityLimits == null) p.identityLimits = "";
        if (!validObservedId(p.code)) p.productIdObserved = false;
        p.identityVersion = VERSION;
        p.key = keyOf(p);
    }

    static String keyOf(Pkg p) {
        if (p == null) return "";
        String operator = safe(p.op);
        if (p.productIdObserved && validObservedId(p.code)) {
            String base = "pkg:v" + VERSION + ":id:" + sha256(operator + "\u0000" + p.code.toLowerCase(Locale.ROOT));
            return p.identityConflictVariant ? base + ":variant:" + sha256(attributeDescriptor(p)).substring(0, 16) : base;
        }
        String volume = volumeToken(p.gb);
        String duration = durationToken(p.days);
        String title = normalizeTitle(p.identityTitle == null ? p.title : p.identityTitle);
        String kind = safeKind(p.identityKind);
        String limits = normalizeLimits(p.identityLimits);
        String payload = field(operator) + field(title) + field(volume) + field(duration)
                + field(kind) + field(limits);
        return "pkg:v" + VERSION + ":fp:" + sha256(payload);
    }

    static void markConflictVariant(Pkg p) {
        if (p == null) return;
        p.identityConflictVariant = true;
        normalize(p);
    }

    private static String attributeDescriptor(Pkg p) {
        return field(volumeToken(p == null ? 0 : p.gb))
                + field(durationToken(p == null ? 0 : p.days))
                + field(safeKind(p == null ? null : p.identityKind))
                + field(normalizeLimits(p == null ? null : p.identityLimits));
    }

    static boolean sameIdAttributes(Pkg a, Pkg b) {
        return a != null && b != null
                && volumeToken(a.gb).equals(volumeToken(b.gb))
                && durationToken(a.days).equals(durationToken(b.days))
                && safeKind(a.identityKind).equals(safeKind(b.identityKind))
                && normalizeLimits(a.identityLimits).equals(normalizeLimits(b.identityLimits));
    }

    static String classificationSignature(String why) {
        if (why == null || why.trim().isEmpty()) return "GENERAL";
        String normalized = Fmt.norm(why).toLowerCase(Locale.ROOT);
        Set<String> parts = new LinkedHashSet<>();
        for (String part : normalized.split("[,،|]")) {
            String item = part.trim().replaceAll("\\s+", " ");
            if (!item.isEmpty()) parts.add(item);
        }
        List<String> sorted = new ArrayList<>(parts);
        Collections.sort(sorted);
        return join(sorted, "|");
    }

    static String mergeClassificationVariants(String existing, String first, String second) {
        Set<String> variants = new LinkedHashSet<>();
        addVariants(variants, existing);
        addVariants(variants, first);
        addVariants(variants, second);
        List<String> sorted = new ArrayList<>(variants);
        Collections.sort(sorted);
        return join(sorted, "\n");
    }

    private static void addVariants(Set<String> out, String input) {
        if (input == null || input.trim().isEmpty()) { out.add("GENERAL"); return; }
        for (String part : input.split("\\n")) {
            String value = part.trim();
            if (!value.isEmpty()) out.add(value.length() > 256 ? value.substring(0, 256) : value);
        }
    }

    static long observedAt(Pkg p) {
        if (p == null) return 0;
        return p.observedAt > 0 ? p.observedAt : p.ts;
    }

    private static String volumeToken(double gb) {
        if (Double.isNaN(gb) || Double.isInfinite(gb) || gb < 0.05 || gb > 5000) return UNKNOWN_VOLUME;
        return "MB:" + Math.round(gb * 1024.0);
    }

    private static String durationToken(double days) {
        if (Double.isNaN(days) || Double.isInfinite(days) || days <= 0 || days > 36500) return UNKNOWN_DURATION;
        return "H:" + Math.round(days * 24.0);
    }

    private static String normalizeTitle(String title) {
        String normalized = Fmt.norm(title).toLowerCase(Locale.ROOT);
        normalized = PRICE.matcher(normalized).replaceAll(" ");
        normalized = normalized.replaceAll("\\s+", " ").trim();
        normalized = normalized.replaceAll("[^\\p{L}\\p{N}]+", " ").replaceAll("\\s+", " ").trim();
        return normalized.isEmpty() ? "TITLE_UNKNOWN" : normalized;
    }

    private static String normalizeLimits(String limits) {
        String value = Fmt.norm(limits).toUpperCase(Locale.ROOT).replaceAll("[^\\p{L}\\p{N}_,-]", "");
        return value.isEmpty() ? "LIMITS_NONE" : value;
    }

    private static String safeKind(String kind) {
        String value = kind == null ? "" : kind.trim().toUpperCase(Locale.ROOT);
        return value.isEmpty() ? UNKNOWN_KIND : value;
    }

    private static String safe(String value) { return value == null ? "" : Fmt.norm(value); }
    private static String field(String value) { return value.length() + ":" + value + "|"; }
    private static String join(List<String> values, String separator) {
        StringBuilder out = new StringBuilder();
        for (String value : values) {
            if (out.length() > 0) out.append(separator);
            out.append(value);
        }
        return out.toString();
    }
    private static String sha256(String value) {
        try {
            byte[] bytes = MessageDigest.getInstance("SHA-256").digest(value.getBytes(StandardCharsets.UTF_8));
            StringBuilder out = new StringBuilder(bytes.length * 2);
            for (byte b : bytes) out.append(String.format(Locale.ROOT, "%02x", b & 0xff));
            return out.toString();
        } catch (Exception impossible) {
            // SHA-256 is required by Android's Java security providers. Fail closed, not to a weak hash.
            throw new IllegalStateException("SHA-256 unavailable", impossible);
        }
    }
}
