package app.bastehyab;

import org.json.JSONArray;
import org.json.JSONObject;

final class Pkg {
    String op, key, title, code = "", why = "";
    // Identity metadata is independent from the mutable classification/reason field `why`.
    String identityTitle = "", identityKind = PkgIdentity.UNKNOWN_KIND, identityLimits = "";
    int identityVersion = PkgIdentity.VERSION;
    boolean productIdObserved, classificationConflict, identityConflict, identityConflictVariant;
    String classificationVariants = "", identityConflictReason = "";
    double gb, days;
    long toman, ts;
    long rawAmount, normalizedToman, finalToman, observedAt;
    String rawCurrency = "UNKNOWN", currencyConfidence = "NONE", priceSource = "legacy";
    boolean taxIncluded, taxKnown;
    int vatRate = -1;
    boolean restricted, ambig, currencyKnown = true;
    String note = "", raw = "";
    // Manual review is a separate, auditable layer; raw extracted fields are never overwritten.
    String reviewStatus = "none", reviewNote = "", reviewSourceFingerprint = "";
    double reviewedGb, reviewedDays;
    long reviewedToman, reviewedAt;
    long[] alts = new long[0];

    double perGb() { return PriceModel.ratio(normalizedToman > 0 ? normalizedToman : toman, gb); }

    /** Cost per GB using the already tax-normalized final price supplied by the caller. */
    double perGb(long finalPriceToman) { return PriceModel.ratio(finalPriceToman, gb); }

    /** Cost per validity day using the already tax-normalized final price supplied by the caller. */
    double perDay(long finalPriceToman) { return PriceModel.ratio(finalPriceToman, days); }

    /** volume this package would give per 30 days if renewed back to back */
    double monthlyGb() {
        return Double.isFinite(gb) && gb > 0 && Double.isFinite(days) && days > 0
                ? gb * 30.0 / days : 0;
    }

    /** price per GB for each month of validity (1 GB kept for 30 days = 1 GB-month) */
    double perGbMonth() {
        if (!Double.isFinite(days) || days <= 0) return Double.MAX_VALUE;
        return PriceModel.ratio(normalizedToman > 0 ? normalizedToman : toman, gb * days / 30.0);
    }

    /**
     * Cost of getting `usage` GB in a 30-day month with this package.
     *  - 30 days or longer: the price is spread over the months it lasts (toman * 30 / days),
     *    and extra packages are added when one package per month is not enough.
     *  - shorter than 30 days: include both the packages required by volume and the minimum
     *    renewals required to keep the offer available throughout the 30-day comparison window.
     */
    double monthlyCost(double usage) {
        long price = normalizedToman > 0 ? normalizedToman : toman;
        try { return (double) PriceModel.monthlyCost(price, gb, days, usage); }
        catch (RuntimeException invalid) { return Double.MAX_VALUE; }
    }

    double monthlyCost(double usage, long effectivePriceToman) {
        try { return (double) PriceModel.monthlyCost(effectivePriceToman, gb, days, usage); }
        catch (RuntimeException invalid) { return Double.MAX_VALUE; }
    }

    /** Comparison-equivalence signature (intentionally includes price/class); storage identity is PkgIdentity. */
    String sig() {
        // A night-only / app-only offer is not interchangeable with a general-purpose offer,
        // even when volume, validity and price happen to match.
        String kind = Fmt.norm(why == null ? "" : why).replace(" ", "");
        String conflictSuffix = (classificationConflict || identityConflict) ? "|conflict:" + String.valueOf(key) : "";
        String productKind = identityKind == null ? PkgIdentity.UNKNOWN_KIND : identityKind;
        String intrinsic = identityLimits == null ? "" : identityLimits;
        long comparablePrice = normalizedToman > 0 ? normalizedToman : toman;
        // Tax basis is part of equivalence: the same numeric amount before/after VAT is not a twin.
        return op + "|" + Math.round(gb * 1024) + "|" + Math.round(days * 24) + "|" + comparablePrice
                + "|tax:" + taxKnown + ":" + taxIncluded + ":" + vatRate
                + "|" + kind + "|" + productKind + "|" + intrinsic + conflictSuffix;
    }

    boolean isIntl() {
        String normalized = Fmt.norm(why == null ? "" : why);
        return normalized.startsWith("بین الملل") || normalized.startsWith("رومینگ")
                || normalized.contains("بین الملل/") || normalized.contains("بین الملل ");
    }

    String sourceFingerprint() {
        return String.valueOf(key) + "|" + String.valueOf(title) + "|" + String.valueOf(code)
                + "|" + gb + "|" + days + "|" + toman + "|" + currencyKnown + "|" + ambig
                + "|" + String.valueOf(why) + "|" + String.valueOf(identityTitle) + "|" + identityKind
                + "|" + identityLimits + "|" + productIdObserved + "|" + classificationConflict
                + "|" + identityConflict + "|" + classificationVariants + "|" + identityConflictReason
                + "|" + java.util.Arrays.toString(alts);
    }

    boolean hasCurrentManualApproval() {
        return "approved".equals(reviewStatus) && reviewedAt > 0
                && reviewedGb >= 0.05 && reviewedGb <= 5000
                && reviewedDays >= 0 && reviewedDays <= 36500
                && reviewedToman >= 100 && reviewedToman <= 2000000000L
                && sourceFingerprint().equals(reviewSourceFingerprint);
    }

    Pkg comparisonVersion() {
        if (!hasCurrentManualApproval()) return this;
        Pkg p = copy();
        // Manual approval explicitly resolves a stored identity/classification conflict for the
        // comparison view while retaining the original conflict evidence in the repository.
        p.classificationConflict = false;
        p.identityConflict = false;
        p.gb = reviewedGb; p.days = reviewedDays; p.toman = reviewedToman;
        p.normalizedToman = reviewedToman; p.finalToman = 0L; p.priceSource = "manual-review"; p.currencyConfidence = "HIGH"; p.taxKnown = true; p.taxIncluded = false;
        p.currencyKnown = true; p.ambig = false;
        p.note = reviewNote == null || reviewNote.isEmpty() ? "تأیید دستی" : "تأیید دستی: " + reviewNote;
        return p;
    }

    Pkg copy() {
        Pkg p = new Pkg();
        p.op=op; p.key=key; p.title=title; p.code=code; p.why=why; p.gb=gb; p.days=days;
        p.identityTitle=identityTitle; p.identityKind=identityKind; p.identityLimits=identityLimits;
        p.identityVersion=identityVersion; p.productIdObserved=productIdObserved;
        p.classificationConflict=classificationConflict; p.identityConflict=identityConflict; p.identityConflictVariant=identityConflictVariant;
        p.classificationVariants=classificationVariants; p.identityConflictReason=identityConflictReason;
        p.toman=toman; p.normalizedToman=normalizedToman > 0 ? normalizedToman : toman; p.finalToman=finalToman; p.rawAmount=rawAmount; p.rawCurrency=rawCurrency; p.currencyConfidence=currencyConfidence; p.priceSource=priceSource; p.taxIncluded=taxIncluded; p.taxKnown=taxKnown; p.vatRate=vatRate; p.observedAt=observedAt; p.ts=ts; p.restricted=restricted; p.ambig=ambig; p.currencyKnown=currencyKnown;
        p.note=note; p.raw=raw; p.alts=alts == null ? new long[0] : alts.clone();
        p.reviewStatus=reviewStatus; p.reviewNote=reviewNote; p.reviewSourceFingerprint=reviewSourceFingerprint;
        p.reviewedGb=reviewedGb; p.reviewedDays=reviewedDays; p.reviewedToman=reviewedToman; p.reviewedAt=reviewedAt;
        return p;
    }

    String label() {
        String v = gb < 1 ? Fmt.num(Math.round(gb * 1024)) + " مگ" : Fmt.dec(gb) + " گیگ";
        String d = "";
        if (days > 0 && days < 1) d = " • " + Fmt.num(Math.max(1, Math.round(days * 24))) + " ساعت";
        else if (days > 0) d = " • " + Fmt.dec(days) + " روز";
        return v + d;
    }

    JSONObject json() throws Exception {
        JSONObject o = new JSONObject();
        o.put("op", op);
        o.put("key", key);
        o.put("identityVersion", identityVersion);
        o.put("identityTitle", identityTitle);
        o.put("identityKind", identityKind);
        o.put("identityLimits", identityLimits);
        o.put("productIdObserved", productIdObserved);
        o.put("classificationConflict", classificationConflict);
        o.put("classificationVariants", classificationVariants);
        o.put("identityConflict", identityConflict);
        o.put("identityConflictVariant", identityConflictVariant);
        o.put("identityConflictReason", identityConflictReason);
        o.put("title", title);
        o.put("code", code);
        o.put("why", why);
        o.put("gb", gb);
        o.put("days", days);
        o.put("toman", toman);
        o.put("rawAmount", rawAmount); o.put("rawCurrency", rawCurrency);
        o.put("normalizedToman", normalizedToman > 0 ? normalizedToman : toman);
        o.put("taxIncluded", taxIncluded); o.put("taxKnown", taxKnown); o.put("vatRate", vatRate);
        o.put("finalToman", finalToman); o.put("currencyConfidence", currencyConfidence);
        o.put("priceSource", priceSource); o.put("observedAt", observedAt);
        o.put("ts", ts);
        o.put("r", restricted);
        o.put("am", ambig);
        o.put("ck", currencyKnown);
        o.put("note", note);
        o.put("reviewStatus", reviewStatus);
        o.put("reviewNote", reviewNote);
        o.put("reviewSource", reviewSourceFingerprint);
        o.put("reviewedGb", reviewedGb);
        o.put("reviewedDays", reviewedDays);
        o.put("reviewedToman", reviewedToman);
        o.put("reviewedAt", reviewedAt);
        JSONArray a = new JSONArray();
        for (long v : alts) a.put(v);
        o.put("alts", a);
        return o;
    }

    static Pkg from(JSONObject o) throws Exception {
        Pkg p = new Pkg();
        p.op = o.getString("op");
        p.key = o.getString("key");
        p.identityVersion = o.optInt("identityVersion", 0);
        p.identityTitle = o.optString("identityTitle", "");
        p.identityKind = o.optString("identityKind", PkgIdentity.UNKNOWN_KIND);
        p.identityLimits = o.optString("identityLimits", "");
        p.productIdObserved = o.optBoolean("productIdObserved", false);
        p.classificationConflict = o.optBoolean("classificationConflict", false);
        p.classificationVariants = o.optString("classificationVariants", "");
        p.identityConflict = o.optBoolean("identityConflict", false);
        p.identityConflictVariant = o.optBoolean("identityConflictVariant", false);
        p.identityConflictReason = o.optString("identityConflictReason", "");
        p.title = o.optString("title", "");
        p.code = o.optString("code", "");
        p.why = o.optString("why", "");
        p.gb = o.getDouble("gb");
        p.days = o.optDouble("days", 0);
        p.toman = o.getLong("toman");
        // Backward-compatible migration: legacy toman is retained as canonical, but tax/currency provenance is unknown.
        p.normalizedToman = o.optLong("normalizedToman", p.toman);
        p.rawAmount = o.optLong("rawAmount", 0); p.rawCurrency = o.optString("rawCurrency", "UNKNOWN");
        p.taxIncluded = o.optBoolean("taxIncluded", false); p.taxKnown = o.optBoolean("taxKnown", false);
        p.vatRate = o.optInt("vatRate", -1); p.finalToman = o.optLong("finalToman", 0);
        p.currencyConfidence = o.optString("currencyConfidence", o.optBoolean("ck", false) ? "MEDIUM" : "NONE");
        p.priceSource = o.optString("priceSource", "legacy-migrated"); p.observedAt = o.optLong("observedAt", o.optLong("ts", 0));
        p.ts = o.optLong("ts", 0);
        p.restricted = o.optBoolean("r", false);
        p.ambig = o.optBoolean("am", false);
        p.currencyKnown = o.optBoolean("ck", false);
        p.note = o.optString("note", "");
        p.reviewStatus = o.optString("reviewStatus", "none");
        if (!"none".equals(p.reviewStatus) && !"pending".equals(p.reviewStatus)
                && !"approved".equals(p.reviewStatus) && !"rejected".equals(p.reviewStatus)) p.reviewStatus = "none";
        p.reviewNote = o.optString("reviewNote", "");
        p.reviewSourceFingerprint = o.optString("reviewSource", "");
        p.reviewedGb = o.optDouble("reviewedGb", 0);
        p.reviewedDays = o.optDouble("reviewedDays", 0);
        p.reviewedToman = o.optLong("reviewedToman", 0);
        p.reviewedAt = o.optLong("reviewedAt", 0);
        p.raw = o.optString("raw", "");
        JSONArray a = o.optJSONArray("alts");
        if (a != null) {
            p.alts = new long[a.length()];
            for (int i = 0; i < a.length(); i++) p.alts[i] = a.getLong(i);
        }
        return p;
    }
}
