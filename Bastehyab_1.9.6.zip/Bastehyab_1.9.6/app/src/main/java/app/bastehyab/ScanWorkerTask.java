package app.bastehyab;

import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Executes one scan operation and delivers exactly one terminal result on the owner thread.
 * Executor rejection and worker exceptions use the same completion path as a normal result.
 */
final class ScanWorkerTask<T> implements Runnable {
    interface Work<T> { T run() throws Exception; }
    interface Poster { void post(Runnable callback); }
    interface Completion<T> { void complete(T value, Throwable failure); }

    private final Work<T> work;
    private final Poster poster;
    private final Completion<T> completion;
    private final AtomicBoolean delivered = new AtomicBoolean(false);

    ScanWorkerTask(Work<T> work, Poster poster, Completion<T> completion) {
        if (work == null || poster == null || completion == null) throw new IllegalArgumentException("task callbacks required");
        this.work = work;
        this.poster = poster;
        this.completion = completion;
    }

    @Override public void run() {
        T value = null;
        Throwable failure = null;
        try {
            value = work.run();
        } catch (Exception unexpected) {
            failure = unexpected;
        } finally {
            deliver(value, failure);
        }
    }

    void reject(Throwable rejection) {
        deliver(null, rejection == null ? new IllegalStateException("executor-rejected") : rejection);
    }

    private void deliver(final T value, final Throwable failure) {
        if (!delivered.compareAndSet(false, true)) return;
        poster.post(() -> completion.complete(value, failure));
    }
}
