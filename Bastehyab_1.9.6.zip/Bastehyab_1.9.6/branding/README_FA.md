# هویت بصری بسته‌یاب

- `bastehyab-app-icon.svg`: منبع برداری آیکون اپلیکیشن.
- `bastehyab-app-icon.png`: preview PNG آیکون؛ معادل باینری لوگوتایپ نیست.
- `bastehyab-logo.svg`: منبع برداری لوگوتایپ فارسی؛ README اصلی از همین فایل استفاده می‌کند.
- `bastehyab-logo.png`: بایت‌به‌بایت/محتوایی همسان با PNG آیکون است و لوگوتایپ نیست؛ فعلاً برای سازگاری بیرونی حذف نشده است. حذف آن نیازمند تأیید owner است.
- `creator-avatar-original.png`: منبع طراحی باکیفیت؛ فایل runtime جداگانه در منابع برنامه حفظ شده است.
- `../app/src/main/res/drawable-nodpi/brand_mark.png`: asset runtime نشان برند.
- `../app/src/main/res/drawable/ic_launcher_bg.xml` و `ic_launcher_fg.xml`: اجزای Adaptive Launcher Icon.
- `../app/src/main/res/drawable/ic_launcher_mono.xml`: آیکون تک‌رنگ سازگار با لانچر.

پیش‌نمایش‌های طراحی و تصاویر مرجع در `../design/references/` نگه‌داری می‌شوند و نباید به `app/src/main/res/` منتقل شوند.
