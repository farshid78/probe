# بدهی فنی باقی‌مانده (پس از ۱.۸.۳۰)

## ترتیب کار پیشنهادی
1. **کاهش وابستگی static** — در حال انجام: UI از ScanStatus؛ APIهای `hasInstance` / `hideComparisonPopupIfPresent`؛ labels قیمت در ExtractRules.
2. **fixture واقعی** — قالب `tools/fixtures/TEMPLATE_real_dump.txt` آماده؛ نیاز به dump دستگاه.
3. **PRICE pairing** — فقط برچسب‌ها منتقل شدند؛ موتور pairing هنوز در Extractor.
4. **Compose** — خارج از محدوده این مسیر.

## انجام‌شده اخیر
- ScanService facade برای instance
- PRICE_OLD/BASE/MAIN/DISC/UNIT_RATE در ExtractRules
- قالب fixture واقعی

## هنوز پرریسک
- حذف فیلدهای static از ScanService
- جابه‌جایی الگوریتم pairing قیمت
