# پیشرفت ۱.۸.۲۷

## انجام‌شده
1. تمرکز بیشتر regex محدودیت در ExtractRules
2. اتصال Extractor

## باقی‌مانده
- static alias
- fixture واقعی
- PRICE/pairing هنوز در Extractor
- Compose
