# پیشرفت ۱.۸.۱۲

## انجام‌شده
1. HomeOperatorList
2. HomeBestOffer
3. کاهش بیشتر MainActivity (~1146 خط)

## باقی‌مانده
- static alias ScanService
- fixture واقعی
- Compose / rule-pack کامل
- helperهای کوچک home (آمار/privacy strip)
