# گزارش اعمال اصلاحات و پیشنهادات — نسخه ۱.۸.۳

**تاریخ:** ۲۰۲۶-۱۱-۱۰  
**مبنای بررسی:** تحلیل ایستای سورس ۱.۸.۲ و پیشنهادات ارائه‌شده

## خلاصه تغییرات اعمال‌شده

| حوزه | مشکل قبلی | اقدام انجام‌شده |
|------|-----------|-----------------|
| Diagnostic | نسخه سخت‌کد ۱.۶.۸ | استفاده از `Cfg.VERSION` (۱.۸.۳) + ثبت `endState` |
| نسخه‌گذاری | پراکندگی رشته نسخه | منبع واحد `Cfg.VERSION` + همگام‌سازی با `versionName` |
| Release build | `minifyEnabled false` | فعال‌سازی R8 + `shrinkResources` + `proguard-rules.pro` اختصاصی |
| Live refresh | رندر هر ۱.۵s بدون شرط | رندر شرطی بر اساس تغییر فاز + فاصله ۲۲۰۰ms + `render(false)` |
| Extractor | محدودیت سخت درخت | عمق ۶۴ و ۶۵۰۰ گره (کاهش incomplete کاذب) |
| مستندات | — | به‌روزرسانی CHANGELOG و این گزارش |

## فایل‌های تغییر یافته
- `app/build.gradle` — minify، versionName ۱.۸.۳
- `app/proguard-rules.pro` — **جدید**
- `app/src/main/java/app/bastehyab/Cfg.java` — `VERSION`
- `app/src/main/java/app/bastehyab/ScanService.java` — diagnostic
- `app/src/main/java/app/bastehyab/MainActivity.java` — live refresh
- `app/src/main/java/app/bastehyab/Extractor.java` — محدودیت درخت
- `CHANGELOG.md`
- این گزارش

## محدودیت‌های باقی‌مانده (عمداً یا خارج از محدوده این دور)
- معماری کامل ViewModel / Compose / Room هنوز اعمال نشده (نیاز به بازنویسی بزرگ و تغییر فلسفه بدون‌وابستگی).
- Gradle Wrapper کامل هنوز در مخزن نیست (CI از setup-gradle استفاده می‌کند).
- تست‌های واحد بیشتر و fixtureهای واقعی اپراتور هنوز محدود هستند.
- static volatileهای ScanService برای ارتباط ساده Service↔UI حفظ شده‌اند؛ encapsulate کامل نیاز به طراحی مجدد lifecycle دارد.

## نکات ایمنی
- هیچ مسیر خرید یا کلیک عملیاتی خودکار اضافه نشده است.
- حریم خصوصی و محدودیت scope اسکن حفظ شده است.
- قوانین ProGuard طوری نوشته شده‌اند که entry pointهای Accessibility و مدل‌های JSON شکسته نشوند.

## توصیه بعدی
1. اجرای کامل CI و ساخت APK release برای تأیید minify.
2. تست دستی اسکن روی ایرانسل‌من و همراه‌من پس از نصب.
3. در دور بعد: استخراج تدریجی state اسکن به کلاس غیر-static و افزودن fixtureهای sanitized بیشتر.
