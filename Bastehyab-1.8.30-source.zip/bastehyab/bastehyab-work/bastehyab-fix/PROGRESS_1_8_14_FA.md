# پیشرفت ۱.۸.۱۴

## انجام‌شده
1. HomeHero (برند + دسترسی)
2. تب home تقریباً کاملاً به helperها شکسته شد
3. isFullMode در live refresh

## باقی‌مانده
- static alias ScanService
- fixture واقعی
- Compose / rule-pack کامل
- compare/settings هنوز نسبتاً بزرگ
