# پیشرفت ۱.۸.۱۶

## انجام‌شده
1. FormControls (helperهای فرم مشترک)
2. MainActivity ~۹۰۲ خط

## باقی‌مانده
- static alias ScanService
- fixture واقعی
- Compose / rule-pack کامل
- thin wrappers در MainActivity هنوز وجود دارند
