# پیشرفت اعمال موارد باقی‌مانده — ۱.۸.۴

## انجام‌شده در این دور

1. **Gradle Wrapper کامل**
   - `gradlew`، `gradlew.bat`، `gradle/wrapper/gradle-wrapper.jar`، `gradle-wrapper.properties` (Gradle 8.7)
   - CI به‌روزرسانی شد تا وجود Wrapper را بررسی کند

2. **بهبود مدیریت state (گام اول)**
   - کلاس جدید `ScanStatus` به‌عنوان snapshot فقط‌خواندنی
   - صفحه خانه و live-refresh از آن استفاده می‌کنند
   - کاهش پراکندگی دسترسی مستقیم به staticهای ScanService در UI

3. **تست**
   - `ScanStatusTest` اضافه شد

4. **نسخه و مستندات**
   - versionName و `Cfg.VERSION` → ۱.۸.۴
   - CHANGELOG و README به‌روز شدند

## هنوز باقی‌مانده (به ترتیب پیشنهادی بعدی)

| اولویت | مورد | توضیح |
|--------|------|--------|
| بالا | encapsulate کامل‌تر state اسکن | انتقال تدریجی فیلدهای mutable به یک holder غیر-static با lifecycle مشخص |
| بالا | fixture و تست‌های Extractor | اضافه کردن dumpهای sanitized واقعی و regression |
| متوسط | استخراج بخش‌هایی از MainActivity | شکستن متدهای بزرگ UI به کلاس‌های کمکی |
| متوسط | امکانات آماری ساده | تاریخچه قیمت / بهترین پیشنهاد در بازه زمانی (بدون backend) |
| پایین | مهاجرت تدریجی UI به Compose یا XML | کار بزرگ و پرریسک |
| پایین | پلاگین قوانین استخراج | نیاز به طراحی API پایدار |

## توصیه ادامه کار
دور بعدی منطقی: گسترش fixture/parser tests + شروع encapsulate state در ScanService بدون شکستن API موجود.
