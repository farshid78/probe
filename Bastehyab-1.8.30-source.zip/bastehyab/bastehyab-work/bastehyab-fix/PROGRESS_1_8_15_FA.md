# پیشرفت ۱.۸.۱۵

## انجام‌شده
1. ComparePkgRow
2. CompareOperatorTicks
3. CompareScreen.appendHeader
4. کاهش MainActivity به ~۹۶۷ خط

## باقی‌مانده
- static alias ScanService
- فیلترهای chips در compare/settings هنوز در MainActivity
- fixture واقعی
- Compose / rule-pack کامل
