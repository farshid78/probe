# پیشرفت ۱.۸.۱۷

## انجام‌شده
1. PackageDetail
2. ScanLimits
3. OperatorSettingsList بدون styleSwitch در Host
4. MainActivity ~۸۷۴ خط

## باقی‌مانده
- static alias ScanService (سازگاری داخلی)
- fixture واقعی
- Compose / rule-pack کامل
