# پیشرفت ۱.۸.۱۹

## انجام‌شده
1. sync گسترده‌تر session در حلقه اسکن
2. settle retry همگام با session
3. OperatorRules hint اسکرول

## باقی‌مانده
- حلقه هنوز روی فیلدهای static می‌نویسد سپس sync می‌کند (حذف کامل static نیاز به بازنویسی بزرگ‌تر دارد)
- fixture واقعی
- Compose / rule-pack کامل
