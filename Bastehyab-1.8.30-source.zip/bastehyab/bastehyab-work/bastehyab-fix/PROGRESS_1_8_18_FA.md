# پیشرفت ۱.۸.۱۸

## انجام‌شده
1. ScreenChrome
2. ExtractRules گسترده‌تر + classifyRestriction
3. isFullMode فقط session
4. MainActivity ~۸۵۴ خط

## باقی‌مانده
- static aliasهای میانی ScanService (هنوز برای writes حلقه اسکن)
- fixture واقعی از دستگاه
- Compose / rule-pack کامل per-operator
