# پیشرفت ۱.۸.۷

## انجام‌شده
1. کاهش dual-write در confirm / begin scan / پایان finishScan
2. ExtractRules (پایه پلاگین قوانین)
3. SettingsScreen (بخش درباره)
4. smoke parser PASS

## باقی‌مانده
- انتقال کامل همهٔ writes داخل حلقه اسکن به session (حذف aliasهای static در میان‌مدت)
- fixture واقعی اپراتور
- شکستن کامل settings و متدهای بزرگ MainActivity
- Compose/XML
