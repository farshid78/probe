# پیشرفت ۱.۸.۲۵

## انجام‌شده
1. OperatorRules غنی‌تر
2. rulePack در diagnostic
3. fixture شاتل

## باقی‌مانده
- static alias
- fixture واقعی
- Compose / rule-pack اجرایی کامل
