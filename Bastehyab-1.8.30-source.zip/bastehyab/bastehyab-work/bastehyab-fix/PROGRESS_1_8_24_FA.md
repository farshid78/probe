# پیشرفت ۱.۸.۲۴

## انجام‌شده
1. scheduleNextScanAt / setSettleRetried / setPromptDismissed
2. سند بدهی فنی REMAINING_DEBT_FA.md

## باقی‌مانده
- حذف کامل static alias (پرریسک)
- fixture واقعی
- Compose / rule-pack کامل
