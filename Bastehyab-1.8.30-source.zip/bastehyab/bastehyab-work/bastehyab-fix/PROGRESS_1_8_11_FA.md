# پیشرفت ۱.۸.۱۱

## انجام‌شده
1. OperatorLogo مستقل
2. OperatorSettingsList
3. liveHandler از ScanStatus
4. کاهش حجم MainActivity

## باقی‌مانده
- static aliasهای ScanService (سازگاری)
- ردیف‌های home اپراتور هنوز در MainActivity
- fixture واقعی
- Compose / rule-pack کامل
