# پیشرفت ۱.۸.۲۰

## انجام‌شده
1. setScrollMethod / setGestureResult
2. finishFullScroll sync
3. fixture سامانتل

## باقی‌مانده
- static mid-loop writes (با sync)
- fixture واقعی دستگاه
- Compose / rule-pack کامل
