# پیشرفت ۱.۸.۲۶

## انجام‌شده
1. اتصال OperatorRules به ScanStrategyPolicy
2. settle زمان‌بندی‌شده per-operator (فعلاً extra=0)
3. نمایش profile در HomeScanCard

## باقی‌مانده
- static alias
- fixture واقعی
- rule-pack اجرایی استخراج
- Compose
