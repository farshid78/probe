# پیشرفت ۱.۸.۹

## انجام‌شده
1. شکستن بیشتر settings (heading / data / review / privacy)
2. OperatorRules + اتصال به Cfg
3. progress از session
4. اعتبارسنجی fixture در CI
5. تست‌ها PASS

## باقی‌مانده
- حذف کامل static aliasها در ScanService
- fixture واقعی از دستگاه
- شکستن باقی settings (اپراتورها، ظاهر، popup)
- Compose / rule-pack واقعی
