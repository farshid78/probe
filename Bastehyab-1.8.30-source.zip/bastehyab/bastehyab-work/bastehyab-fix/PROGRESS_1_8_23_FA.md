# پیشرفت ۱.۸.۲۳

## انجام‌شده
1. markStepAdvanced / markNoMove / markViewportMoved / setEndState
2. advanceFull از helperهای dual-write استفاده می‌کند

## باقی‌مانده
- فیلدهای static هنوز وجود دارند (alias)
- fixture واقعی
- Compose / rule-pack کامل
