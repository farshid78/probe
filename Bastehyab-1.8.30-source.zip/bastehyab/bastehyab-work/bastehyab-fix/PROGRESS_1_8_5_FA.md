# پیشرفت ۱.۸.۵

## انجام‌شده
1. encapsulate بیشتر state → ScanStatus غنی‌تر + استفاده در Popup و HomeScanCard
2. شکستن بخشی از MainActivity → HomeScanCard
3. امکان آماری ساده → Stats + ردیف «روند قیمت‌ها» در خانه
4. fixture/regression Extractor → موارد جدید در ParserSmokeTest + encoding UTF-8
5. تست smoke parser با موفقیت اجرا شد

## باقی‌مانده
- encapsulate کامل فیلدهای mutable داخل ScanService (holder داخلی)
- fixtureهای واقعی sanitized از اپراتورها
- شکستن بیشتر MainActivity (compare/settings)
- مهاجرت UI به Compose/XML
- پلاگین قوانین استخراج
