# پیشرفت ۱.۸.۲۸

## انجام‌شده
1. CsvExport
2. MainActivity ~۸۲۸ خط
3. درباره غنی‌تر

## باقی‌مانده
- static alias
- fixture واقعی
- PRICE در Extractor
- Compose
