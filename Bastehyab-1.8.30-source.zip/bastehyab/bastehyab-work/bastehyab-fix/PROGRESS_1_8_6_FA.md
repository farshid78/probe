# پیشرفت ۱.۸.۶

## انجام‌شده
1. ScanSession + همگام‌سازی lifecycle (start/stop/pause/resume)
2. ScanStatus مبتنی بر session
3. CompareScreen (empty + summary)
4. fixtures synthetic در tools/fixtures
5. ScanSessionTest
6. parser smoke همچنان PASS

## باقی‌مانده
- نوشتن کامل mid-scan از session به‌جای dual-write با static aliasها
- fixtureهای sanitized واقعی اپراتور (نیاز به dump از دستگاه)
- شکستن settings و بقیه MainActivity
- Compose/XML و پلاگین استخراج
