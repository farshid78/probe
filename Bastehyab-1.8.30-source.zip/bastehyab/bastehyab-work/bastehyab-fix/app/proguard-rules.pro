# Bastehyab ProGuard / R8 rules (1.8.2+)
# Keep Accessibility Service entry points and reflection-sensitive parts.

-keep class app.bastehyab.ScanService { *; }
-keep class app.bastehyab.MainActivity { *; }
-keep class app.bastehyab.Popup { *; }

# Keep model and config classes used by JSON / SharedPreferences serialization paths.
-keepclassmembers class app.bastehyab.Op {
    <fields>;
    <init>(...);
    *** from(...);
}
-keepclassmembers class app.bastehyab.Pkg {
    <fields>;
    <init>(...);
}
-keepclassmembers class app.bastehyab.OpSnapshot {
    <fields>;
}

# Preserve native method names if any future JNI is added.
-keepclasseswithmembernames class * {
    native <methods>;
}

# Accessibility framework callbacks must not be renamed.
-keepclassmembers class * extends android.accessibilityservice.AccessibilityService {
    public void onAccessibilityEvent(...);
    public void onInterrupt();
    public void onServiceConnected();
}

# Keep line numbers for crash reports (optional but useful).
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile

# Do not warn about missing optional Android classes in unit-test stubs.
-dontwarn android.**
-dontwarn org.json.**
