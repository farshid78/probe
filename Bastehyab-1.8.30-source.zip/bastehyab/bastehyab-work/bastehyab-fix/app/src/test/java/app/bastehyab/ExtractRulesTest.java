package app.bastehyab;

import org.junit.Test;
import static org.junit.Assert.*;

public final class ExtractRulesTest {
    @Test public void internationalDetection() {
        assertTrue(ExtractRules.isInternational("بسته رومینگ اروپا"));
        assertTrue(ExtractRules.isInternational("بین الملل ۳۰ روزه"));
        assertFalse(ExtractRules.isInternational("بسته اینترنت داخلی شبانه"));
    }

    @Test public void nightAndUnlimited() {
        assertTrue(ExtractRules.isNight("بسته شبانه ۳۰ روزه"));
        assertTrue(ExtractRules.isUnlimited("نامحدود با مصرف منصفانه"));
        assertFalse(ExtractRules.isUnlimited("۵ گیگابایت ۳۰ روزه"));
    }

    @Test public void packIdStable() {
        assertNotNull(ExtractRules.packId());
        assertTrue(ExtractRules.packId().startsWith("builtin"));
    }

    @Test public void classifyRestriction() {
        assertEquals("intl", ExtractRules.classifyRestriction("رومینگ اروپا"));
        assertEquals("night", ExtractRules.classifyRestriction("بسته شبانه"));
        assertEquals("app", ExtractRules.classifyRestriction("بسته اینستاگرام"));
        assertEquals("new_user", ExtractRules.classifyRestriction("ویژه مشترکین جدید"));
        assertEquals("national", ExtractRules.classifyRestriction("ترافیک ملی"));
        assertEquals("", ExtractRules.classifyRestriction("بسته ۳۰ روزه معمولی"));
    }

    @Test public void sharedMatchersNotNull() {
        assertNotNull(ExtractRules.VOLUME);
        assertNotNull(ExtractRules.DURATION);
        assertNotNull(ExtractRules.TIME_WINDOW);
        assertNotNull(ExtractRules.INTERNAL_NET);
    }
}
