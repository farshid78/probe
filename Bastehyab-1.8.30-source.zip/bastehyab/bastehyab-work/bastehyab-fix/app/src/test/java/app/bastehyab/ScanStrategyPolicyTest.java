package app.bastehyab;

import org.junit.Test;
import static org.junit.Assert.*;

public class ScanStrategyPolicyTest {
    @Test public void accessibilityFirstOnlyAtStrategyZero() {
        assertTrue(ScanStrategyPolicy.shouldUseAccessibilityActionFirst(0, "mci"));
        assertFalse(ScanStrategyPolicy.shouldUseAccessibilityActionFirst(1, "mci"));
        assertFalse(ScanStrategyPolicy.shouldUseAccessibilityActionFirst(2, "mci"));
    }

    @Test public void settleIncludesOperatorExtra() {
        assertEquals(ScanLimits.FULL_SCROLL_SETTLE_MS,
                ScanStrategyPolicy.scrollSettleMs("mci"));
        assertTrue(ScanStrategyPolicy.settleRetryMs("irancell") >= ScanLimits.FULL_SETTLE_RETRY_MS);
    }

    @Test public void appViewportAfterEscalation() {
        assertFalse(ScanStrategyPolicy.shouldPreferAppViewportSwipe(0));
        assertTrue(ScanStrategyPolicy.shouldPreferAppViewportSwipe(2));
    }
}
