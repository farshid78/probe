package app.bastehyab;

import org.junit.Test;
import static org.junit.Assert.*;

/** Basic regression for the read-only scan status snapshot. */
public final class ScanStatusTest {
    @Test public void versionConstantIsPresent() {
        assertNotNull(Cfg.VERSION);
        assertFalse(Cfg.VERSION.trim().isEmpty());
        assertTrue(Cfg.VERSION.matches("\\d+\\.\\d+\\.\\d+"));
    }

    @Test public void currentSnapshotDoesNotThrow() {
        // Service statics default to idle; snapshot must be safe without a live service.
        ScanStatus st = ScanStatus.current();
        assertNotNull(st);
        assertNotNull(st.phase);
        assertNotNull(st.status);
        assertFalse(st.isActive());
    }
}
