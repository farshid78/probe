package app.bastehyab;

import org.junit.Test;
import static org.junit.Assert.*;

public final class OperatorRulesTest {
    @Test public void samantelPrefersRial() {
        assertTrue(OperatorRules.prefersRialDisplay("samantel"));
        assertEquals("IRR", OperatorRules.defaultCurrency("samantel"));
        assertFalse(OperatorRules.prefersRialDisplay("mci"));
        assertEquals("AUTO", OperatorRules.defaultCurrency("mci"));
    }

    @Test public void packIdIncludesOperator() {
        String pack = OperatorRules.packFor("mci");
        assertTrue(pack.contains("mci"));
        assertTrue(pack.startsWith(ExtractRules.packId()));
    }

    @Test public void profiles() {
        assertTrue(OperatorRules.isBuiltin("mci"));
        assertFalse(OperatorRules.isBuiltin("custom-op"));
        assertEquals("سامانتل (ریال)", OperatorRules.profileLabel("samantel"));
        assertEquals(0L, OperatorRules.extraSettleMs("mci"));
    }
}
