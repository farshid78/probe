package app.bastehyab;

import org.junit.Test;
import static org.junit.Assert.*;

public final class ScanSessionTest {
    @Test public void resetForStartArmsWaitingConfirm() {
        ScanSession s = new ScanSession();
        s.resetForStart("mci", "ir.mci.ecareapp");
        assertTrue(s.fullMode);
        assertFalse(s.fullConfirmed);
        assertFalse(s.fullStartedScanning);
        assertEquals("mci", s.fullTargetOpId);
        assertEquals("ir.mci.ecareapp", s.fullTargetPackage);
        assertEquals("WAITING_CONFIRM", s.phase());
    }

    @Test public void markStoppedClearsActiveMode() {
        ScanSession s = new ScanSession();
        s.resetForStart("mci", "ir.mci.ecareapp");
        s.fullConfirmed = true;
        s.fullStartedScanning = true;
        s.fullEndState = ListEndDetector.State.END_CONFIRMED;
        s.markStopped("پایان", true);
        assertFalse(s.fullMode);
        assertTrue(s.fullFinished);
        assertEquals("FINISHED", s.phase());
    }

    @Test public void pauseAndResumeTogglePhase() {
        ScanSession s = new ScanSession();
        s.resetForStart("mci", "ir.mci.ecareapp");
        s.fullConfirmed = true;
        s.fullStartedScanning = true;
        s.pause();
        assertEquals("PAUSED", s.phase());
        s.resume();
        assertEquals("SCANNING", s.phase());
    }
}
