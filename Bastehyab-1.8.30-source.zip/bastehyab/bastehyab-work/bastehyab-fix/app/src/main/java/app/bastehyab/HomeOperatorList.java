package app.bastehyab;

import android.app.Activity;
import android.widget.LinearLayout;
import java.util.List;

/** Home-tab operator status rows and scan/open buttons. */
final class HomeOperatorList {
    interface Host {
        int dp(float v);
        void launch(Op o);
    }

    private HomeOperatorList() {}

    static void append(Activity a, LinearLayout col, List<Op> ops, List<Pkg> all, Host host) {
        if (ops == null) return;
        for (final Op o : ops) {
            int count = 0;
            long ts = 0;
            if (all != null) {
                for (Pkg p : all) {
                    if (p.op.equals(o.id)) {
                        count++;
                        if (p.ts > ts) ts = p.ts;
                    }
                }
            }
            LinearLayout row = UI.hbox(a);
            row.setPadding(host.dp(13), host.dp(11), host.dp(13), host.dp(11));
            row.setMinimumHeight(host.dp(68));
            row.setBackground(UI.rr(a, UI.CARD, 18, UI.STROKE));
            row.addView(new OperatorLogo(a, o.id), UI.lp(a, 42, 34, 0, 0, 10, 0));
            LinearLayout info = UI.vbox(a);
            info.addView(UI.tv(a, o.name, 13, UI.TEXT, true));
            String status = !o.enabled
                    ? "اسکن غیرفعال"
                    : count > 0
                    ? Fmt.fa(String.valueOf(count)) + " بسته • " + Fmt.ago(ts)
                    : "آماده‌ی اسکن • هنوز داده‌ای نیست";
            info.addView(UI.tv(a, status, 10, count > 0 ? UI.PRIMARY : UI.MUTED, false),
                    UI.lp(a, -1, -2, 0, 2, 0, 0));
            row.addView(info, UI.lpw(1f));
            row.addView(UI.btn(a, o.enabled ? "اسکن" : "بازکردن", UI.CARD2, UI.PRIMARY, v -> host.launch(o)));
            col.addView(row, UI.lp(a, -1, -2, 0, 0, 0, 7));
        }
    }
}
