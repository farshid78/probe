package app.bastehyab;

import android.app.Activity;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Ranked package card used on the compare tab. */
final class ComparePkgRow {
    interface Host {
        int dp(float v);
        void showDetail(Pkg p);
    }

    private ComparePkgRow() {}

    static View build(Activity a, Pkg p, int rank, Compare.Result cr, Host host) {
        Op op = Cfg.opById(a, p.op);
        int actualRank = cr.rank.containsKey(p.key) ? cr.rank.get(p.key) : rank;
        int opColor = op == null ? UI.MUTED : op.color;
        double metric = cr.val.containsKey(p.key) ? cr.val.get(p.key) : 0d;
        double med = cr.median;
        int discount = med > 0 && metric > 0 && metric < med
                ? Math.round((float) ((med - metric) * 100d / med)) : 0;

        LinearLayout card = UI.vbox(a);
        card.setPadding(host.dp(14), host.dp(13), host.dp(14), host.dp(13));
        int fill = actualRank == 1 ? UI.CARD2 : UI.CARD;
        int border = actualRank == 1 ? UI.PRIMARY : UI.STROKE;
        card.setBackground(UI.rr(a, fill, 20, border));
        card.setMinimumHeight(host.dp(156));
        card.setElevation(actualRank == 1 ? host.dp(7) : host.dp(5));

        LinearLayout top = UI.hbox(a);
        TextView badge = UI.tv(a, Fmt.fa(String.valueOf(actualRank)), 13,
                actualRank == 1 ? 0xFFFFFFFF : UI.TEXT, true);
        badge.setGravity(Gravity.CENTER);
        badge.setBackground(UI.rr(a, actualRank == 1 ? UI.PRIMARY : UI.CARD2, 12));
        top.addView(badge, UI.lp(a, 34, 34, 0, 0, 8, 0));
        top.addView(new OperatorLogo(a, op == null ? p.op : op.id), UI.lp(a, 34, 30, 0, 0, 7, 0));
        top.addView(UI.chip(a, op == null ? p.op : op.name, UI.tint(opColor), opColor));
        if (p.restricted) {
            top.addView(UI.chip(a, "بسته‌ی ویژه", UI.tint(UI.DANGER), UI.DANGER),
                    UI.lp(a, -2, -2, 5, 0, 0, 0));
        }
        if (discount > 0) {
            top.addView(UI.chip(a, Fmt.fa(String.valueOf(discount)) + "٪ زیر میانه",
                    UI.tint(UI.SUCCESS), UI.SUCCESS), UI.lp(a, -2, -2, 5, 0, 0, 0));
        }
        card.addView(top);

        TextView label = UI.tv(a, p.label(), 16, UI.TEXT, true);
        label.setMaxLines(2);
        label.setEllipsize(android.text.TextUtils.TruncateAt.END);
        label.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
        label.setTextAlignment(View.TEXT_ALIGNMENT_GRAVITY);
        card.addView(label, UI.lp(a, -1, -2, 0, 9, 0, 3));
        card.addView(UI.tv(a, "اعتبار بسته: " + Fmt.dec(p.days) + " روز", 10, UI.MUTED, false),
                UI.lp(a, -1, -2, 0, 0, 0, 10));

        LinearLayout metrics = UI.hbox(a);
        LinearLayout total = UI.vbox(a);
        total.addView(UI.tv(a, "قیمت نهایی", 9, UI.MUTED, false));
        total.addView(UI.tv(a, Cfg.priceLabel(a, Cfg.finalPrice(a, p)), 13, UI.TEXT, true),
                UI.lp(a, -1, -2, 0, 3, 0, 0));
        metrics.addView(total, UI.lpw(1f));

        LinearLayout per = UI.vbox(a);
        per.setGravity(Gravity.CENTER);
        per.addView(UI.tv(a, "هزینه‌ی هر گیگ", 9, UI.MUTED, false));
        double perGbToman = p.gb > 0 ? Cfg.finalPrice(a, p) / p.gb : 0;
        TextView perValue = UI.tv(a, Cfg.priceLabel(a, Math.round(perGbToman)).replace(" تومان", "")
                .replace(" ریال", "") + " / گیگ", 12, actualRank == 1 ? UI.PRIMARY : UI.TEXT, true);
        perValue.setGravity(Gravity.CENTER);
        perValue.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        per.addView(perValue, UI.lp(a, -1, -2, 0, 3, 0, 0));
        metrics.addView(per, UI.lpw(1f));
        card.addView(metrics);
        card.setOnClickListener(v -> host.showDetail(p));
        return card;
    }
}
