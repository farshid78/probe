package app.bastehyab;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.RippleDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Shared visual system for Bastehyab. All screens consume the same dark, light and monochrome tokens. */
final class UI {
    private UI() { }

    static boolean light, mono;
    static int BG, CARD, CARD2, STROKE, PRIMARY, ACCENT, TEXT, MUTED, DANGER, BLUE, SUCCESS;
    static Typeface BODY, MEDIUM, BOLD;

    static void applyTheme(Context c) {
        String appearance = Cfg.sp(c).getString("appearance", "dark");
        light = "light".equals(appearance);
        mono = "mono".equals(appearance);
        if (light) {
            BG = 0xFFF5F8F9; CARD = 0xFFFFFFFF; CARD2 = 0xFFEAF3F2; STROKE = 0xFFD8E4E5;
            PRIMARY = 0xFF238F83; ACCENT = 0xFF4D9FAD; TEXT = 0xFF1C2B2D;
            MUTED = 0xFF61777A; DANGER = 0xFFAD4D5A; BLUE = 0xFF438FAE;
            SUCCESS = 0xFF21765F;
        } else if (mono) {
            BG = 0xFF161C24; CARD = 0xFF202832; CARD2 = 0xFF293540; STROKE = 0xFF3B4A55;
            PRIMARY = 0xFF55C9B8; ACCENT = 0xFF78B9C5; TEXT = 0xFFF1F6F6;
            MUTED = 0xFFA8B8BC; DANGER = 0xFFE08A91; BLUE = 0xFF75B8C0;
            SUCCESS = 0xFF58C6A3;
        } else {
            // Obsidian: soft graphite surfaces with lively but restrained aqua accents.
            BG = 0xFF161C24; CARD = 0xFF1F252B; CARD2 = 0xFF293139; STROKE = 0xFF3B4851;
            PRIMARY = 0xFF55C9B8; ACCENT = 0xFF78B9C5; TEXT = 0xFFF1F6F7;
            MUTED = 0xFFAAB9BE; DANGER = 0xFFE58B9A; BLUE = 0xFF5EA6C4;
            SUCCESS = 0xFF45C995;
        }
        if (BODY == null || MEDIUM == null || BOLD == null) {
            try {
                BODY = Typeface.createFromAsset(c.getAssets(), "fonts/NotoSansArabic-Regular.ttf");
                MEDIUM = Typeface.createFromAsset(c.getAssets(), "fonts/NotoSansArabic-Medium.ttf");
                BOLD = Typeface.createFromAsset(c.getAssets(), "fonts/NotoSansArabic-Bold.ttf");
            } catch (RuntimeException fontError) {
                BODY = Typeface.create("sans-serif", Typeface.NORMAL);
                MEDIUM = Typeface.create("sans-serif-medium", Typeface.NORMAL);
                BOLD = Typeface.create("sans-serif", Typeface.BOLD);
            }
        }
    }

    static int themeColor(int color) {
        int alpha = color >>> 24;
        int rgb = color & 0x00FFFFFF;
        int mapped = rgb;
        if (mono) {
            // Keep current semantic tokens intact; legacy decorative colours collapse
            // to a restrained grayscale ramp for the classic black-and-white theme.
            if (rgb == (BG & 0x00FFFFFF) || rgb == (CARD & 0x00FFFFFF)
                    || rgb == (CARD2 & 0x00FFFFFF) || rgb == (STROKE & 0x00FFFFFF)
                    || rgb == (PRIMARY & 0x00FFFFFF) || rgb == (ACCENT & 0x00FFFFFF)
                    || rgb == (TEXT & 0x00FFFFFF) || rgb == (MUTED & 0x00FFFFFF)
                    || rgb == (DANGER & 0x00FFFFFF) || rgb == (BLUE & 0x00FFFFFF)) {
                mapped = rgb;
            } else {
                int r = (rgb >> 16) & 255, g = (rgb >> 8) & 255, b = rgb & 255;
                int luminance = (r * 212 + g * 715 + b * 73) / 1000;
                if (luminance < 28) mapped = BG;
                else if (luminance < 82) mapped = CARD;
                else if (luminance < 150) mapped = CARD2;
                else if (luminance < 218) mapped = MUTED;
                else mapped = TEXT;
            }
        } else if (light) {
            switch (rgb) {
                case 0x07101F: case 0x050B15: case 0x0C1B31: case 0x091426: case 0x0B172A:
                case 0x101828: case 0x10182D: case 0x07152F: case 0x0B2348: mapped = BG; break;
                case 0x11213A: case 0x101F37: case 0x0E1A30: case 0x0E1A2D: case 0x0E1A32:
                case 0x1B2942: case 0x182D4A: case 0x172238: mapped = CARD; break;
                case 0x1B3150: case 0x28415F: case 0x182B47: case 0x263B5A: case 0x16283A:
                case 0x152D42: case 0x0C1931: case 0x1A2D4A: case 0x142642: mapped = CARD2; break;
                case 0xF7FAFF: case 0xFFFFFF: mapped = TEXT; break;
                case 0xB3C1D7: case 0xB9D5E9: case 0x8393B0: mapped = MUTED; break;
                case 0x4AD9EA: case 0x55E8FF: case 0x54E8F7: case 0x41DDF4: case 0x35D9F5:
                case 0x37DFF4: case 0x38DDF2: mapped = PRIMARY; break;
                case 0xB39BFF: case 0x9D78FF: case 0x9D7BFF: mapped = ACCENT; break;
                case 0xFF829A: case 0xFF718F: mapped = DANGER; break;
                case 0x3A557A: case 0x516C91: case 0x587396: case 0x74518D: mapped = STROKE; break;
                case 0x373449: case 0x29283A: case 0x49315F: case 0x29273F: mapped = CARD; break;
                case 0x353349: case 0x48445F: mapped = CARD2; break;
                case 0xB65AF2: case 0xB65FE4: case 0xCE55EA: case 0x8F53C8: case 0x6245D0: mapped = ACCENT; break;
                case 0x5B4DB2: case 0x8F4DD4: case 0x7646E8: case 0xCB58B9: mapped = PRIMARY; break;
                case 0xF08ADF: case 0xFF7F9C: case 0xE879D9: case 0xF5B84B:
                case 0xEC4899: case 0xF97316: mapped = DANGER; break;
                case 0xFFF3E7FB: case 0xFFEFE7FA: mapped = CARD2; break;
                case 0x45C995: case 0x55DDA8: case 0x63DDAA: case 0x70DFAF: case 0x22C55E: mapped = SUCCESS; break;
                case 0x06B6D4: mapped = PRIMARY; break;
                default: break;
            }
        } else {
            switch (rgb) {
                case 0x07101F: case 0x050B15: case 0x0C1B31: case 0x091426: case 0x0B172A:
                case 0x101828: case 0x10182D: case 0x07152F: case 0x0B2348: mapped = BG; break;
                case 0x11213A: case 0x101F37: case 0x0E1A30: case 0x0E1A2D: case 0x0E1A32:
                case 0x1B2942: case 0x182D4A: case 0x172238: mapped = CARD; break;
                case 0x1B3150: case 0x28415F: case 0x182B47: case 0x263B5A: case 0x16283A:
                case 0x152D42: case 0x0C1931: case 0x1A2D4A: case 0x142642: mapped = CARD2; break;
                case 0xF7FAFF: case 0xFFFFFF: mapped = TEXT; break;
                case 0xB3C1D7: case 0xB9D5E9: case 0x8393B0: mapped = MUTED; break;
                case 0x4AD9EA: case 0x55E8FF: case 0x54E8F7: case 0x41DDF4: case 0x35D9F5:
                case 0x37DFF4: case 0x38DDF2: mapped = PRIMARY; break;
                case 0xB39BFF: case 0x9D78FF: case 0x9D7BFF: mapped = ACCENT; break;
                case 0xFF829A: case 0xFF718F: mapped = DANGER; break;
                case 0x3A557A: case 0x516C91: case 0x587396: case 0x74518D: mapped = STROKE; break;
                case 0x373449: case 0x29283A: case 0x49315F: case 0x29273F: mapped = CARD; break;
                case 0x353349: case 0x48445F: mapped = CARD2; break;
                case 0xB65AF2: case 0xB65FE4: case 0xCE55EA: case 0x8F53C8: case 0x6245D0: mapped = ACCENT; break;
                case 0x5B4DB2: case 0x8F4DD4: case 0x7646E8: case 0xCB58B9: mapped = PRIMARY; break;
                case 0xF08ADF: case 0xFF7F9C: case 0xE879D9: case 0xF5B84B:
                case 0xEC4899: case 0xF97316: mapped = DANGER; break;
                case 0xFFF3E7FB: case 0xFFEFE7FA: mapped = CARD2; break;
                case 0x45C995: case 0x55DDA8: case 0x63DDAA: case 0x70DFAF: case 0x22C55E: mapped = SUCCESS; break;
                case 0x06B6D4: mapped = PRIMARY; break;
                default: break;
            }
        }
        return (alpha << 24) | (mapped & 0x00FFFFFF);
    }

    static void applyTypefaceTree(View view) {
        if (view instanceof TextView) {
            TextView text = (TextView) view;
            if (text instanceof Button || text instanceof android.widget.Switch) text.setTypeface(MEDIUM);
            else if (text.getTypeface() != null && text.getTypeface().isBold()) text.setTypeface(BOLD);
            else text.setTypeface(BODY);
            text.setIncludeFontPadding(false);
        }
        if (view instanceof android.view.ViewGroup) {
            android.view.ViewGroup group = (android.view.ViewGroup) view;
            for (int i = 0; i < group.getChildCount(); i++) applyTypefaceTree(group.getChildAt(i));
        }
    }

    static int dp(Context c, float v) { return Math.round(v * c.getResources().getDisplayMetrics().density); }
    static int sz(Context c, int v) { return v > 0 ? dp(c, v) : v; }

    static int surfaceColor(int color) {
        if ((color & 0x00FFFFFF) == 0x00FFFFFF || (color >>> 24) == 0) return color;
        return themeColor(color);
    }
    private static int shade(int color, float factor) {
        int a = color & 0xFF000000;
        int red = Math.max(0, Math.min(255, Math.round(((color >> 16) & 255) * factor)));
        int green = Math.max(0, Math.min(255, Math.round(((color >> 8) & 255) * factor)));
        int blue = Math.max(0, Math.min(255, Math.round((color & 255) * factor)));
        return a | (red << 16) | (green << 8) | blue;
    }
    static GradientDrawable rr(Context c, int fill, float r) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(surfaceColor(fill));
        g.setCornerRadius(dp(c, r));
        return g;
    }
    static GradientDrawable rr(Context c, int fill, float r, int stroke) {
        GradientDrawable g = rr(c, fill, r); g.setStroke(dp(c, 1), surfaceColor(stroke)); return g;
    }
    static GradientDrawable grad(Context c, int a, int b, float r) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{surfaceColor(a), surfaceColor(b)}); g.setCornerRadius(dp(c, r)); return g;
    }
    static Drawable appBackground(Context c) {
        if (light) return new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{0xFFF6FAFC, 0xFFEAF1F5, 0xFFE4EBF0});
        if (mono) return new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{0xFF090A0C, 0xFF14161A, 0xFF202329});
        // The same restrained midnight palette is used when a solid drawable is needed.
        return new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{BG, CARD, 0xFF1B2933});
    }
    static int tint(int color) { return (themeColor(color) & 0x00FFFFFF) | 0x22000000; }
    static int contrastText(int background) {
        double r = ((background >> 16) & 255) / 255.0;
        double g = ((background >> 8) & 255) / 255.0;
        double b = (background & 255) / 255.0;
        r = r <= 0.04045 ? r / 12.92 : Math.pow((r + 0.055) / 1.055, 2.4);
        g = g <= 0.04045 ? g / 12.92 : Math.pow((g + 0.055) / 1.055, 2.4);
        b = b <= 0.04045 ? b / 12.92 : Math.pow((b + 0.055) / 1.055, 2.4);
        double luminance = 0.2126 * r + 0.7152 * g + 0.0722 * b;
        return luminance > 0.42 ? 0xFF182338 : 0xFFFFFFFF;
    }

    static TextView tv(Context c, String s, float sp, int color, boolean bold) {
        TextView t = new TextView(c); t.setText(s); t.setTextSize(Math.max(10.5f, sp)); t.setTextColor(themeColor(color));
        t.setTypeface(bold ? BOLD : BODY);
        t.setTextDirection(View.TEXT_DIRECTION_RTL); t.setGravity(Gravity.TOP | Gravity.START);
        t.setTextAlignment(View.TEXT_ALIGNMENT_GRAVITY); t.setIncludeFontPadding(false);
        t.setLineSpacing(dp(c, 3f), 1.14f);
        return t;
    }
    static LinearLayout vbox(Context c) {
        LinearLayout l = new LinearLayout(c); l.setOrientation(LinearLayout.VERTICAL);
        l.setLayoutDirection(View.LAYOUT_DIRECTION_RTL); return l;
    }
    static LinearLayout hbox(Context c) {
        LinearLayout l = new LinearLayout(c); l.setOrientation(LinearLayout.HORIZONTAL);
        l.setLayoutDirection(View.LAYOUT_DIRECTION_RTL); l.setGravity(Gravity.CENTER_VERTICAL); return l;
    }
    static LinearLayout.LayoutParams lp(Context c, int w, int h, float s, float t, float e, float b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(sz(c, w), sz(c, h));
        p.setMargins(0, dp(c, t), 0, dp(c, b)); p.setMarginStart(dp(c, s)); p.setMarginEnd(dp(c, e)); return p;
    }
    static LinearLayout.LayoutParams lp2(Context c, float start) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        p.setMarginStart(dp(c, start)); return p;
    }
    static LinearLayout.LayoutParams lpw(float weight) { return new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, weight); }
    static LinearLayout card(Context c) {
        LinearLayout l = vbox(c);
        int p = dp(c, 16);
        l.setPadding(p, p, p, p);
        GradientDrawable panel = rr(c, CARD, 20, STROKE);
        l.setBackground(panel);
        l.setClipToOutline(true);
        l.setElevation(dp(c, 2));
        return l;
    }
    static TextView chip(Context c, String s, int bg, int fg) {
        TextView t = tv(c, s, 11, fg, true);
        t.setPadding(dp(c, 11), dp(c, 8), dp(c, 11), dp(c, 8));
        boolean selected = (themeColor(bg) & 0x00FFFFFF) == (PRIMARY & 0x00FFFFFF);
        if (selected) {
            t.setTextColor(contrastText(PRIMARY));
            t.setBackground(rr(c, PRIMARY, 13, STROKE));
        } else t.setBackground(rr(c, bg, 13, STROKE));
        t.setGravity(Gravity.CENTER);
        return t;
    }
    static Button btn(Context c, String s, int bg, int fg, View.OnClickListener l) {
        Button b = new Button(c);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextSize(13);
        b.setTypeface(MEDIUM);
        boolean primary = (themeColor(bg) & 0x00FFFFFF) == (PRIMARY & 0x00FFFFFF);
        GradientDrawable shape = new GradientDrawable();
        shape.setColor(primary ? surfaceColor(PRIMARY) : surfaceColor(bg));
        shape.setCornerRadius(dp(c, 14));
        shape.setStroke(dp(c, 1), primary ? (mono ? 0xFFB9C1CC : light ? 0xFF5F9AB3 : 0xFF4696A9) : STROKE);
        b.setTextColor(primary ? contrastText(PRIMARY) : themeColor(fg));
        b.setBackground(new RippleDrawable(ColorStateList.valueOf(0x33FFFFFF), shape,
                rr(c, 0xFFFFFFFF, 16)));
        b.setStateListAnimator(null);
        b.setElevation(dp(c, 2));
        b.setMinHeight(dp(c, 48));
        b.setMinimumHeight(dp(c, 48));
        b.setGravity(Gravity.CENTER);
        b.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        b.setTextDirection(View.TEXT_DIRECTION_RTL);
        b.setPadding(dp(c, 16), dp(c, 10), dp(c, 16), dp(c, 10));
        b.setOnClickListener(l);
        return b;
    }
}
