package app.bastehyab;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.drawable.GradientDrawable;
import android.provider.Settings;
import android.widget.ImageView;
import android.widget.LinearLayout;

/** Home-tab hero brand strip and accessibility permission banner. */
final class HomeHero {
    interface Host {
        int dp(float v);
    }

    private HomeHero() {}

    static void append(Activity a, LinearLayout col, boolean permission, Host host) {
        LinearLayout hero = UI.hbox(a);
        hero.setPadding(host.dp(17), host.dp(17), host.dp(17), host.dp(17));
        GradientDrawable heroBg = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                UI.mono ? new int[]{0xFF202833, UI.CARD}
                        : UI.light ? new int[]{0xFFF7FAFC, UI.CARD}
                        : new int[]{UI.CARD2, UI.CARD});
        heroBg.setCornerRadius(host.dp(22));
        heroBg.setStroke(host.dp(1), UI.STROKE);
        hero.setElevation(host.dp(2));
        hero.setBackground(heroBg);
        ImageView mark = new ImageView(a);
        mark.setImageResource(R.mipmap.ic_launcher);
        mark.setScaleType(ImageView.ScaleType.FIT_CENTER);
        hero.addView(mark, UI.lp(a, 70, 70, 0, 0, 14, 0));
        LinearLayout brand = UI.vbox(a);
        brand.addView(UI.tv(a, "بسته‌یاب", 24, UI.TEXT, true));
        brand.addView(UI.tv(a, "مقایسه‌ی هوشمند بسته‌های اینترنت", 11, UI.MUTED, false),
                UI.lp(a, -1, -2, 0, 3, 0, 6));
        brand.addView(UI.chip(a, permission ? "● دسترسی فعال" : "● دسترسی غیرفعال",
                permission ? UI.tint(UI.SUCCESS) : UI.tint(UI.DANGER),
                permission ? UI.SUCCESS : UI.DANGER));
        hero.addView(brand, UI.lpw(1f));
        col.addView(hero);

        if (!permission) {
            LinearLayout access = UI.card(a);
            access.addView(UI.tv(a, "برای شروع، دسترسی اسکن را فعال کنید", 14, UI.TEXT, true));
            access.addView(UI.tv(a,
                    "بسته‌یاب فقط محتوای قابل‌مشاهده‌ی صفحه‌ی بسته‌های اپراتوری را که خودتان باز می‌کنید می‌خواند؛ خریدی انجام نمی‌دهد و اطلاعاتی ارسال نمی‌کند.",
                    11, UI.MUTED, false), UI.lp(a, -1, -2, 0, 5, 0, 9));
            access.addView(UI.btn(a, "فعال‌سازی دسترسی اندروید", UI.PRIMARY, 0xFF061326, v ->
                    new AlertDialog.Builder(a)
                            .setTitle("تأیید دسترسی")
                            .setMessage("این سرویس فقط برای خواندن اطلاعات قابل‌مشاهده‌ی بسته‌ها در اپراتور انتخابی استفاده می‌شود. متن خام صفحه ذخیره یا ارسال نمی‌شود و هیچ خریدی انجام نمی‌شود. برای ادامه، تنظیمات دسترسی‌پذیری باز شود؟")
                            .setNegativeButton("فعلاً نه", null)
                            .setPositiveButton("باز کردن تنظیمات",
                                    (dialog, which) -> a.startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)))
                            .show()), UI.lp(a, -1, -2, 0, 0, 0, 0));
            col.addView(access, UI.lp(a, -1, -2, 0, 12, 0, 0));
        }
    }
}
