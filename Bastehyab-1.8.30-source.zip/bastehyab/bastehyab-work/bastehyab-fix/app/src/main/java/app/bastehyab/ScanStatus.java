package app.bastehyab;

/**
 * Read-only snapshot of the current scan session for UI and diagnostics.
 * Keeps callers from reaching into dozens of individual static fields.
 * The authoritative mutable state remains in {@link ScanService}.
 */
final class ScanStatus {
    final String phase;
    final String status;
    final String opId;
    final String targetOpId;
    final String error;
    final String emptyReason;
    final String packageStatus;
    final String scrollMethod;
    final String gestureResult;
    final String popupError;
    final boolean fullMode;
    final boolean paused;
    final boolean finished;
    final boolean confirmed;
    final boolean startedScanning;
    final int steps;
    final int unique;
    final int scanned;
    final int valid;
    final int suspicious;
    final int duplicates;
    final int nodeCount;
    final int observedScrollPercent;
    final long durationMs;
    final long completedAt;
    final ListEndDetector.State endState;

    private ScanStatus(
            String phase, String status, String opId, String targetOpId, String error, String emptyReason,
            String packageStatus, String scrollMethod, String gestureResult, String popupError,
            boolean fullMode, boolean paused, boolean finished, boolean confirmed, boolean startedScanning,
            int steps, int unique, int scanned, int valid, int suspicious, int duplicates,
            int nodeCount, int observedScrollPercent, long durationMs, long completedAt,
            ListEndDetector.State endState) {
        this.phase = phase;
        this.status = status;
        this.opId = opId;
        this.targetOpId = targetOpId;
        this.error = error;
        this.emptyReason = emptyReason;
        this.packageStatus = packageStatus;
        this.scrollMethod = scrollMethod;
        this.gestureResult = gestureResult;
        this.popupError = popupError;
        this.fullMode = fullMode;
        this.paused = paused;
        this.finished = finished;
        this.confirmed = confirmed;
        this.startedScanning = startedScanning;
        this.steps = steps;
        this.unique = unique;
        this.scanned = scanned;
        this.valid = valid;
        this.suspicious = suspicious;
        this.duplicates = duplicates;
        this.nodeCount = nodeCount;
        this.observedScrollPercent = observedScrollPercent;
        this.durationMs = durationMs;
        this.completedAt = completedAt;
        this.endState = endState;
    }

    /** Capture a consistent snapshot of the current service state. */
    static ScanStatus current() {
        ScanSession s = ScanService.session;
        // Prefer session (source of truth after lifecycle methods); fall back is unnecessary
        // because publishSession keeps aliases aligned for mid-scan field writes.
        return new ScanStatus(
                s.phase(),
                s.lastScanStatus,
                s.lastOpId,
                s.fullTargetOpId,
                s.lastScanError,
                s.lastEmptyReason,
                s.lastPackageStatus,
                s.lastScrollMethod,
                s.lastGestureResult,
                s.lastPopupError,
                s.fullMode,
                s.fullPaused,
                s.fullFinished,
                s.fullConfirmed,
                s.fullStartedScanning,
                s.fullSteps,
                s.fullSeen.size(),
                s.lastScannedPackages,
                s.lastValidPackages,
                s.lastSuspiciousPackages,
                s.lastDuplicatePackages,
                s.lastNodeCount,
                s.fullObservedScrollPercent,
                s.lastScanDurationMs,
                s.lastCompletedScanAt,
                s.fullEndState
        );
    }

    boolean isActive() {
        return fullMode && !finished;
    }

    boolean isScanning() {
        return "SCANNING".equals(phase);
    }

    /** Progress 1..100 for UI bars; capped while still running. */
    int progressPercent(int maxSteps) {
        if (finished) return 100;
        if (maxSteps <= 0) return 0;
        return Math.min(95, Math.max(1, steps * 100 / maxSteps));
    }

    String humanPhaseLabel() {
        if (fullMode) {
            if (paused) return "اسکن موقتاً متوقف";
            if (startedScanning) return "استخراج خودکار";
            if (confirmed) return "در انتظار صفحه‌ی بسته‌ها";
            return "در انتظار تایید شما";
        }
        if (finished) return "استخراج پایان یافت";
        if (steps > 0) return "استخراج متوقف شد؛ نیازمند بررسی";
        return "گزارش اسکن";
    }
}
