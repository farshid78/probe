package app.bastehyab;

import java.util.regex.Pattern;

/**
 * Central registry for extraction patterns. Complex price/pairing regexes may still
 * live in {@link Extractor}; classification and shared matchers belong here so rule packs
 * can evolve without scattering literals.
 */
final class ExtractRules {
    private static final int F = Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE;

    /** International / roaming packages — never treated as domestic substitutes. */
    static final Pattern INTL = Pattern.compile("بین[\\s\\u200c]?الملل|رومینگ|خارج\\s?از\\s?کشور");

    static final Pattern VOLUME = Pattern.compile(
            "(\\d+(?:\\.\\d+)?)\\s*(گیگابایت|گیگا|گیگ|مگابایت|مگا|مگ|ترابایت|ترا|gb|mb|tb)", F);
    static final Pattern DURATION = Pattern.compile("(\\d+(?:\\.\\d+)?)\\s*(روز|ماه|هفته|ساعت|سال)");
    static final Pattern CURRENCY = Pattern.compile("تومان|تومن|ریال");
    static final Pattern UNLIMITED = Pattern.compile("نامحدود|مصرف منصفانه|حد[\\s\\u200c]?مصرف");
    static final Pattern NIGHT = Pattern.compile("شبانه|نیمه\\s?شب|بامداد|\\d\\s*(?:تا|الی)\\s*\\d\\s*(?:صبح|بامداد)");
    static final Pattern APP_SPECIFIC = Pattern.compile(
            "اپلیکیشن|اینستاگرام|تلگرام|واتس|یوتیوب|آپارات|روبیکا|(?<![\\p{L}])ایتا(?![\\p{L}])|(?<![\\p{L}])بله(?![\\p{L}])|سروش|تیک ?تاک|شبکه های اجتماعی|پیام ?رسان");
    static final Pattern BUNDLE = Pattern.compile("پیامک|مکالمه|تماس|sms|دقیقه\\s*(?:مکالمه)?|بسته[ی ]+ترکیبی");
    static final Pattern SUBSCRIPTION = Pattern.compile("اشتراک|سرویس دیجیتال|فیلیمو|نماوا|فیلم[\\s\\u200c]?نت|طاقچه");
    static final Pattern TIME_WINDOW = Pattern.compile(
            "نیمه\\s?شب|بامداد|صبح|ظهر|عصر|ساعات?\\s*خاص|بسته[ی ]+ساعتی|(?:از\\s*)?ساعت\\s*\\d\\s*(?:تا|الی)\\s*\\d|\\d\\s*(?:تا|الی)\\s*\\d\\s*(?:صبح|بامداد|ظهر|عصر|شب)");
    static final Pattern NAZR = Pattern.compile("نذر\\s*آب");
    static final Pattern WEEKDAY = Pattern.compile(
            "(?<![\\p{L}])(?:یک|دو|سه|چهار|پنج|\\d)?\\s?شنبه|جمعه|آخر\\s?هفته|تعطیل");
    static final Pattern NEW_USER = Pattern.compile(
            "مشترکین جدید|مشترک جدید|ثبت ?نام|ویژه مشترک|اولین خرید|دعوت");
    static final Pattern NATIONAL_NET = Pattern.compile(
            "آی ?نو|اینترنت ملی|ترافیک ملی|ترافیک ایرانی|سایت[\\s\\u200c]?های? ایرانی");
    static final Pattern RENEWAL = Pattern.compile("تمدید خودکار|رزرو");
    static final Pattern SPECIAL = Pattern.compile("ویژه(?:\\s?ی)?\\s+(?!شما(?![\\p{L}]))\\p{L}{3,}");
    static final Pattern INTERNAL_NET = Pattern.compile(
            "ترافیک داخلی|اینترنت داخلی|مخصوص سایت|مخصوص وب.?سایت|شبکه ملی");
    /** Labels that mark a price leaf as non-current / list price. */
    static final Pattern PRICE_OLD = Pattern.compile("قبل از|پیش از|قیمت اصلی|بدون تخفیف|قیمت قبلی|قبلی");
    static final Pattern PRICE_BASE = Pattern.compile("قیمت\\s*پایه|مبلغ\\s*پایه");
    static final Pattern PRICE_MAIN = Pattern.compile(
            "قیمت|مبلغ|با تخفیف|پس از تخفیف|نهایی|قابل ?پرداخت|با مالیات|شامل مالیات");
    static final Pattern PRICE_DISC = Pattern.compile(
            "تخفیف|هدیه|اعتبار هدیه|پاداش|جایزه|کش ?بک|بازگشت|مالیات|ارزش ?افزوده|صرفه ?جویی");
    static final Pattern PRICE_UNIT_RATE = Pattern.compile(
            "ماهانه|ماهیانه|هر ?ماه|در ?ماه|ماهی|/ ?ماه|هر ?گیگ|به ?ازای|روزانه|هر ?روز|در ?روز|هفتگی|هر ?هفته|قسط|اقساط");

    private ExtractRules() {}

    static String packId() {
        return "builtin-core";
    }

    static boolean isInternational(String text) {
        return text != null && INTL.matcher(text).find();
    }

    static boolean isUnlimited(String text) {
        return text != null && UNLIMITED.matcher(text).find();
    }

    static boolean isNight(String text) {
        return text != null && NIGHT.matcher(text).find();
    }

    static boolean isAppSpecific(String text) {
        return text != null && APP_SPECIFIC.matcher(text).find();
    }

    static boolean isBundle(String text) {
        return text != null && BUNDLE.matcher(text).find();
    }

    static boolean isSubscription(String text) {
        return text != null && SUBSCRIPTION.matcher(text).find();
    }

    /** Coarse restriction class for diagnostics (not a full parser replacement). */
    static String classifyRestriction(String text) {
        if (text == null || text.isEmpty()) return "";
        if (isInternational(text)) return "intl";
        if (isNight(text) || (text != null && TIME_WINDOW.matcher(text).find())) return "night";
        if (isAppSpecific(text)) return "app";
        if (isBundle(text)) return "bundle";
        if (isSubscription(text)) return "subscription";
        if (text != null && NEW_USER.matcher(text).find()) return "new_user";
        if (text != null && NATIONAL_NET.matcher(text).find()) return "national";
        if (isUnlimited(text)) return "unlimited";
        return "";
    }
}
