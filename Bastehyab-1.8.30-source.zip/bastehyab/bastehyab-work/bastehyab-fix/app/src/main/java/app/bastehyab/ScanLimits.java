package app.bastehyab;

/** Shared scan limits (single place for UI progress and ScanService caps). */
final class ScanLimits {
    static final int FULL_MAX_STEPS = 120;
    static final long FULL_WAIT_MS = 240000L;
    static final long FULL_MAX_MS = 300000L;
    static final long FULL_SCROLL_SETTLE_MS = 380L;
    static final long FULL_SETTLE_RETRY_MS = 180L;

    private ScanLimits() {}
}
