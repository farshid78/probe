package app.bastehyab;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.provider.Settings;
import android.text.InputType;
import android.text.TextUtils;
import android.graphics.drawable.GradientDrawable;
import android.widget.Button;
import android.view.Gravity;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;

import android.widget.LinearLayout;
import android.widget.ProgressBar;

import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    interface IntCb extends FormControls.IntCb {}
    interface StrCb extends FormControls.StrCb {}

    private static final int[] ICONS = {R.drawable.ic_home, R.drawable.ic_compare, R.drawable.ic_tune};
    private static final String[] NAMES = {"خانه", "مقایسه", "تنظیمات"};

    private FrameLayout body;
    private FrameLayout outer;
    private SplashViews.AppBackdrop appBackdrop;
    private View splashView;
    private boolean splashShowing;
    private final Handler splashHandler = new Handler(Looper.getMainLooper());
    private final Handler liveHandler = new Handler(Looper.getMainLooper());
    private String lastLivePhase = "";
    private final Runnable liveRefresh = new Runnable() {
        @Override public void run() {
            if (isFinishing()) return;
            if (tab == 0 && !splashShowing) {
                ScanStatus st = ScanStatus.current();
                // Only re-render when scan phase actually changes or while actively scanning.
                if (!st.phase.equals(lastLivePhase) || st.isScanning() || "WAITING_PAGE".equals(st.phase)) {
                    lastLivePhase = st.phase;
                    render(false); // do not capture scroll; preserve current position
                }
            }
            if (ScanService.isFullMode()) liveHandler.postDelayed(this, 2200L);
        }
    };
    private LinearLayout nav;
    private ScrollView sv;
    private int tab;
    private final int[] scroll = new int[3];
    private String newName = "", newPkg = "";
    private int newCur;

    private int dp(float v) { return UI.dp(this, v); }

    private void applySystemBars() {
        getWindow().setStatusBarColor(UI.BG);
        getWindow().setNavigationBarColor(UI.CARD);
        int flags = UI.light ? (View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR) : 0;
        getWindow().getDecorView().setSystemUiVisibility(flags);
    }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        UI.applyTheme(this);
        applySystemBars();
        LinearLayout root = UI.vbox(this);
        root.setBackgroundColor(0x00000000);
        body = new FrameLayout(this);
        root.addView(body, new LinearLayout.LayoutParams(-1, 0, 1f));
        nav = UI.hbox(this);
        nav.setBackground(UI.rr(this, UI.CARD, 24, UI.STROKE));
        nav.setElevation(dp(12));
        nav.setPadding(dp(7), dp(7), dp(7), dp(7));
        LinearLayout.LayoutParams navParams = new LinearLayout.LayoutParams(-1, -2);
        navParams.setMargins(dp(14), dp(5), dp(14), dp(12));
        root.addView(nav, navParams);
        outer = new FrameLayout(this);
        appBackdrop = new SplashViews.AppBackdrop(this);
        outer.addView(appBackdrop, new FrameLayout.LayoutParams(-1, -1));
        outer.addView(root, new FrameLayout.LayoutParams(-1, -1));
        setContentView(outer);
        if (b == null) showCreatorSplash();
        else {
            tab = Cfg.clamp(b.getInt("state.tab", 0), 0, 2);
            for (int i = 0; i < scroll.length; i++) scroll[i] = Math.max(0, b.getInt("state.scroll." + i, 0));
            render(); // Rebuild the visible screen and restore the selected tab/scroll position.
        }
    }

    private void showCreatorSplash() {
        splashShowing = true;
        FrameLayout shell = new FrameLayout(this);
        // Reuse the activity's static cyber wallpaper: one compositor, no stacked animation layers.
        shell.setBackgroundColor(0x00000000);
        View veil = new View(this);
        veil.setBackground(UI.grad(this, UI.light ? 0x22FFFFFF : UI.tint(UI.PRIMARY),
                UI.light ? 0x11EAF0FA : UI.tint(UI.ACCENT), 0));
        shell.addView(veil, new FrameLayout.LayoutParams(-1, -1));

        ScrollView scrollView = new ScrollView(this);
        scrollView.setFillViewport(true);
        scrollView.setVerticalScrollBarEnabled(false);
        shell.addView(scrollView, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout col = UI.vbox(this);
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        col.setPadding(dp(24), dp(30), dp(24), dp(24));
        scrollView.addView(col, new ScrollView.LayoutParams(-1, -2));

        FrameLayout logo = new FrameLayout(this);
        logo.setElevation(dp(12));
        logo.addView(new SplashViews.LogoHalo(this),
                new FrameLayout.LayoutParams(dp(128), dp(128), Gravity.CENTER));
        SplashViews.BrandMark brandMark = new SplashViews.BrandMark(this);
        brandMark.setElevation(dp(7));
        logo.addView(brandMark,
                new FrameLayout.LayoutParams(dp(120), dp(120), Gravity.CENTER));
        col.addView(logo, UI.lp(this, 140, 140, 0, 0, 0, 12));

        TextView title = UI.tv(this, "بسته‌یاب", 34, UI.TEXT, true);
        title.setGravity(Gravity.CENTER);
        col.addView(title, UI.lp(this, -1, -2, 0, 0, 0, 2));
        TextView latin = UI.tv(this, "BASTEHYAB", 11, UI.PRIMARY, true);
        latin.setLetterSpacing(0.18f);
        latin.setTextDirection(View.TEXT_DIRECTION_LTR);
        latin.setGravity(Gravity.CENTER);
        col.addView(latin, UI.lp(this, -1, -2, 0, 0, 0, 5));
        TextView subtitle = UI.tv(this, "مقایسه‌ی هوشمند بسته‌های اینترنت", 14, UI.ACCENT, true);
        subtitle.setGravity(Gravity.CENTER);
        col.addView(subtitle, UI.lp(this, -1, -2, 0, 0, 0, 20));

        LinearLayout features = UI.hbox(this);
        features.setGravity(Gravity.CENTER);
        String[] featureNames = {"اسکن محلی", "مقایسه قیمت", "بدون ارسال داده"};
        for (int i=0;i<featureNames.length;i++) {
            TextView f = UI.chip(this, featureNames[i], UI.tint(UI.ACCENT), UI.ACCENT);
            features.addView(f, UI.lp(this, -2, -2, i==0?0:5, 0, 0, 0));
        }
        col.addView(features, UI.lp(this, -1, -2, 0, 0, 0, 18));

        LinearLayout how = UI.card(this);
        how.setPadding(dp(16), dp(15), dp(16), dp(15));
        how.addView(UI.tv(this, "سه گام تا مقایسه", 14, UI.TEXT, true));
        LinearLayout steps = UI.hbox(this);
        String[] stepsText = {"بازکردن اپراتور", "ورود به بسته‌ها", "مقایسه خودکار"};
        for (int i=0;i<stepsText.length;i++) {
            LinearLayout step = UI.vbox(this);
            step.setGravity(Gravity.CENTER);
            TextView n = UI.tv(this, Fmt.fa(String.valueOf(i+1)), 12, UI.TEXT, true);
            n.setGravity(Gravity.CENTER);
            n.setBackground(UI.rr(this, UI.tint(UI.ACCENT), 18, UI.STROKE));
            step.addView(n, UI.lp(this, 30, 30, 0, 0, 0, 5));
            TextView label = UI.tv(this, stepsText[i], 10, UI.MUTED, true);
            label.setGravity(Gravity.CENTER);
            label.setMaxLines(2);
            step.addView(label);
            steps.addView(step, new LinearLayout.LayoutParams(0, -2, 1f));
        }
        how.addView(steps, UI.lp(this, -1, -2, 0, 12, 0, 0));
        col.addView(how, UI.lp(this, -1, -2, 0, 0, 0, 14));

        TextView enter = UI.btn(this, "ورود به برنامه", UI.PRIMARY, 0xFF061326, v -> enterApp());
        col.addView(enter, UI.lp(this, -1, -2, 0, 0, 0, 14));

        LinearLayout creator = UI.hbox(this);
        creator.setGravity(Gravity.CENTER_VERTICAL);
        creator.setPadding(dp(14), dp(13), dp(14), dp(13));
        creator.setBackground(UI.rr(this, UI.CARD2, 18, UI.STROKE));
        creator.setElevation(dp(6));
        creator.addView(new SplashViews.PersonAvatar(this), UI.lp(this, 66, 66, 0, 0, 12, 0));
        LinearLayout creatorText = UI.vbox(this);
        creatorText.addView(UI.tv(this, "طراحی و توسعه", 10, UI.MUTED, false));
        creatorText.addView(UI.tv(this, "فرشید نبی‌پور", 16, UI.TEXT, true),
                UI.lp(this, -1, -2, 0, 3, 0, 0));
        creator.addView(creatorText, UI.lpw(1f));
        TextView contact = UI.tv(this, "ارتباط با سازنده  ↗", 10, UI.PRIMARY, true);
        contact.setGravity(Gravity.CENTER);
        contact.setPadding(dp(10), dp(10), dp(10), dp(10));
        contact.setBackground(UI.rr(this, UI.tint(UI.ACCENT), 12, UI.STROKE));
        contact.setOnClickListener(v -> {
            try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/Farshid_Np"))); }
            catch (Exception e) { toast("امکان باز کردن پیوند ارتباطی وجود ندارد"); }
        });
        creator.addView(contact, UI.lp(this, -2, -2, 8, 0, 0, 0));
        col.addView(creator, UI.lp(this, -1, -2, 0, 0, 0, 8));

        TextView privacy = UI.tv(this, "پردازش روی همین گوشی انجام می‌شود؛ اطلاعات صفحه به سرور ارسال نمی‌شود.\nنسخه ۱.۷.۹  •  © ۲۰۲۶", 10, UI.MUTED, false);
        privacy.setGravity(Gravity.CENTER);
        privacy.setMaxLines(3);
        col.addView(privacy, UI.lp(this, -1, -2, 0, 0, 0, 0));

        UI.applyTypefaceTree(shell);
        splashView = shell;
        outer.addView(splashView, new FrameLayout.LayoutParams(-1, -1));
    }

    private void enterApp() {
        if (!splashShowing) return;
        View fading = splashView;
        if (fading == null) {
            splashShowing = false;
            render();
            return;
        }
        fading.animate().alpha(0f).setDuration(180L).withEndAction(() -> {
            if (splashView == fading) {
                outer.removeView(fading);
                splashView = null;
                splashShowing = false;
                render();
            }
        }).start();
    }

    @Override protected void onSaveInstanceState(Bundle out) {
        out.putInt("state.tab", tab);
        for (int i = 0; i < scroll.length; i++) out.putInt("state.scroll." + i, scroll[i]);
        super.onSaveInstanceState(out);
    }

    @Override protected void onResume() {
        super.onResume();
        if (appBackdrop != null) appBackdrop.resumeLoop();
        if (!splashShowing) render();
        if (ScanService.isFullMode()) liveHandler.post(liveRefresh);
    }

    @Override protected void onPause() {
        liveHandler.removeCallbacks(liveRefresh);
        if (appBackdrop != null) appBackdrop.pauseLoop();
        Store.flush(this);
        super.onPause();
    }

    @Override protected void onDestroy() {
        splashHandler.removeCallbacksAndMessages(null);
        liveHandler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }

    // ---------------------------------------------------------------- shell

    private void render() { render(true); }

    private void render(boolean captureCurrentScroll) {
        if (captureCurrentScroll && sv != null) scroll[tab] = sv.getScrollY();
        body.removeAllViews();
        final ScrollView screenScroll = new ScrollView(this);
        screenScroll.setFillViewport(true);
        screenScroll.setVerticalScrollBarEnabled(false);
        screenScroll.setOverScrollMode(View.OVER_SCROLL_NEVER);
        screenScroll.setClipToPadding(false);
        screenScroll.setClipChildren(false);
        sv = screenScroll;
        LinearLayout col = UI.vbox(this);
        col.setClipChildren(false);
        col.setPadding(dp(18), dp(18), dp(18), dp(28));
        screenScroll.addView(col, new FrameLayout.LayoutParams(-1, -2));
        body.addView(screenScroll, new FrameLayout.LayoutParams(-1, -1));
        if (tab == 0) home(col);
        else if (tab == 1) compare(col);
        else settings(col);
        UI.applyTypefaceTree(col);
        final int y = scroll[tab];
        screenScroll.post(() -> screenScroll.scrollTo(0, y));
        buildNav();
    }

    private void buildNav() {
        nav.removeAllViews();
        nav.setPadding(dp(7), dp(7), dp(7), dp(7));
        GradientDrawable navBg = UI.rr(this, UI.CARD, 24, UI.STROKE);
        navBg.setStroke(dp(1), UI.STROKE);
        nav.setBackground(navBg);
        for (int i = 0; i < 3; i++) {
            final int idx = i;
            boolean on = i == tab;
            LinearLayout it = UI.vbox(this);
            it.setGravity(Gravity.CENTER);
            it.setPadding(dp(7), dp(7), dp(7), dp(7));
            it.setBackground(on
                    ? UI.rr(this, UI.CARD2, 17, UI.PRIMARY)
                    : UI.rr(this, 0x00000000, 17));
            ImageView im = new ImageView(this);
            im.setImageResource(ICONS[i]);
            im.setColorFilter(on ? UI.PRIMARY : UI.MUTED);
            it.addView(im, UI.lp(this, 22, 22, 0, 1, 0, 0));
            TextView label = UI.tv(this, NAMES[i], 10, on ? UI.PRIMARY : UI.MUTED, on);
            label.setGravity(Gravity.CENTER);
            it.addView(label, UI.lp(this, -2, -2, 0, 3, 0, 0));
            it.setContentDescription(NAMES[i] + (on ? "، صفحه فعلی" : "، رفتن به صفحه"));
            it.setSelected(on);
            it.setOnClickListener(v -> {
                // Re-tapping the active destination is intentionally a no-op.
                // Rebuilding the same screen used to reset focus/layout and cause a visible jump.
                if (idx == tab) return;
                if (sv != null) scroll[tab] = sv.getScrollY();
                tab = idx;
                // The target tab already owns its own saved scroll position; do not
                // overwrite it with the outgoing tab's scroll offset during render.
                render(false);
            });
            nav.addView(it, new LinearLayout.LayoutParams(0, -2, 1f));
        }
    }

    private boolean serviceOn() {
        String en = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        return en != null && en.contains(getPackageName());
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }

    // ---------------------------------------------------------------- home

    private void home(LinearLayout col) {
        boolean permission = serviceOn();
        List<Op> ops = Cfg.ops(this);
        List<Pkg> all = Store.all(this);
        Compare.Result cr = Compare.run(this, new HashSet<String>());

        HomeHero.append(this, col, permission, v -> MainActivity.this.dp(v));

        HomeStatsStrip.Host statsHost = new HomeStatsStrip.Host() {
            @Override public int dp(float v) { return MainActivity.this.dp(v); }
            @Override public View sectionTitle(String title, String subtitle) { return MainActivity.this.sectionTitle(title, subtitle); }
        };
        HomeStatsStrip.appendOverview(this, col, ops, all, cr, statsHost);

        HomeScanCard.append(this, col, 12);

        HomeBestOffer.append(this, col, cr, () -> { tab = 1; render(); });

        col.addView(sectionTitle("اپراتورها", "وضعیت داده و شروع اسکن هر اپراتور"), UI.lp(this, -1, -2, 0, 16, 0, 8));
        HomeOperatorList.append(this, col, ops, all, new HomeOperatorList.Host() {
            @Override public int dp(float v) { return MainActivity.this.dp(v); }
            @Override public void launch(Op o) { MainActivity.this.launch(o); }
        });
        HomeStatsStrip.appendPrivacy(this, col, statsHost);
    }




    private void launch(Op o) {
        String targetPackage = null;
        Intent launchIntent = null;
        for (String p : o.pkgs) {
            Intent candidate = getPackageManager().getLaunchIntentForPackage(p);
            if (candidate != null) {
                targetPackage = p;
                launchIntent = candidate;
                break;
            }
        }
        if (launchIntent == null || targetPackage == null) {
            toast("برنامه‌ی " + o.name + " پیدا نشد؛ نصب بودن برنامه و نام پکیج را بررسی کنید.");
            return;
        }

        boolean auto = ScanService.hasInstance() && o.enabled;
        if (auto) ScanService.startFull(o.id, targetPackage);
        try {
            startActivity(launchIntent);
            if (auto) {
                liveHandler.removeCallbacks(liveRefresh);
                liveHandler.post(liveRefresh);
                toast("برنامه‌ی " + o.name + " باز شد؛ پس از ورود به بخش بسته‌های اینترنت، در پنجره‌ی شناور «تایید و شروع» را بزنید. برای مکث از «توقف اسکن» استفاده کنید.");
            } else if (!o.enabled) {
                toast("برنامه باز شد؛ این اپراتور در تنظیمات غیرفعال است و استخراج انجام نمی‌شود.");
            } else {
                toast("برنامه باز شد؛ برای استخراج خودکار، ابتدا سرویس دسترسی بسته‌یاب را فعال کنید.");
            }
        } catch (RuntimeException e) {
            if (auto) ScanService.stopFull("باز کردن برنامه‌ی اپراتور ناموفق بود");
            toast("باز کردن برنامه‌ی " + o.name + " ناموفق بود: " + e.getClass().getSimpleName());
        }
    }

    // ---------------------------------------------------------------- compare

    private void compare(LinearLayout col) {
        CompareScreen.appendHeader(this, col, Store.all(this).size());

        LinearLayout filter = UI.card(this);
        filter.addView(UI.tv(this, "معیار رتبه‌بندی", 13, UI.TEXT, true));
        chips(filter, new String[]{"ارزان‌ترین هر گیگ", "بیشترین اعتبار", "هزینه مصرف من"}, Cfg.metric(this), i -> {
            Cfg.setInt(this, "metric", i); scroll[1] = 0; render();
        });
        filter.addView(UI.tv(this, "مقایسه‌ی بسته‌های هم‌اعتبار", 11, UI.MUTED, false), UI.lp(this, -1, -2, 0, 5, 0, 0));
        chips(filter, Compare.BUCKETS, Cfg.bucket(this), i -> {
            Cfg.setInt(this, "bucket", i); scroll[1] = 0; render();
        });
        if (Cfg.metric(this) == Cfg.MY_USAGE) {
            stepRow(filter, "مصرف ماهانه‌ی شما", "برآورد برای محاسبه‌ی هزینه‌ی مصرف", (int) Cfg.usage(this), 5, 500, 5, " گیگ", v -> {
                Cfg.setFloat(this, "usage", v); render();
            });
        }
        col.addView(filter, UI.lp(this, -1, -2, 0, 12, 0, 0));

        col.addView(CompareOperatorTicks.build(this, new CompareOperatorTicks.Host() {
            @Override public int dp(float v) { return MainActivity.this.dp(v); }
            @Override public void setAllCmp(boolean on) { MainActivity.this.setAllCmp(on); }
            @Override public void render() { MainActivity.this.render(); }
        }), UI.lp(this, -1, -2, 0, 10, 0, 6));
        Compare.Result cr = Compare.run(this, new HashSet<String>());
        if (cr.ranked.isEmpty()) {
            CompareScreen.appendEmptyState(this, col, anyCmp());
            return;
        }
        CompareScreen.appendSummary(this, col, cr);

        int n = Math.min(80, cr.ranked.size());
        ComparePkgRow.Host rowHost = new ComparePkgRow.Host() {
            @Override public int dp(float v) { return MainActivity.this.dp(v); }
            @Override public void showDetail(Pkg p) { MainActivity.this.showDetail(p); }
        };
        for (int i = 0; i < n; i++) col.addView(ComparePkgRow.build(this, cr.ranked.get(i), i + 1, cr, rowHost), UI.lp(this, -1, -2, 0, 0, 0, 8));
        if (cr.ranked.size() > n) {
            col.addView(UI.tv(this, "برای سبک ماندن صفحه، ۸۰ نتیجه‌ی نخست نمایش داده می‌شود.", 10, UI.MUTED, false), UI.lp(this, -1, -2, 0, 4, 0, 0));
        }
    }

    private boolean anyCmp() {
        for (Op o : Cfg.ops(this)) if (o.cmp) return true;
        return false;
    }

    private void setAllCmp(boolean on) {
        List<Op> ops = Cfg.ops(this);
        for (Op o : ops) o.cmp = on;
        Cfg.saveOps(this, ops);
        render();
    }



    private void showDetail(final Pkg p) { PackageDetail.show(this, p); }

    // ---------------------------------------------------------------- settings

    private void settings(LinearLayout col) {
        SettingsScreen.appendHeading(this, col);

        LinearLayout display = SettingsScreen.beginAppearance(this, col);
        int activeTheme = UI.mono ? 1 : UI.light ? 2 : 0;
        chips(display, new String[]{"سایبری", "تک‌رنگ", "روشن"},
                activeTheme, i -> {
                    String selected = i == 1 ? "mono" : i == 2 ? "light" : "dark";
                    Cfg.sp(this).edit().putString("appearance", selected).apply();
                    UI.applyTheme(this);
                    applySystemBars();
                    if (appBackdrop != null) appBackdrop.refreshTheme();
                    render();
                });
        SettingsScreen.appendAppearanceHints(this, display);
        chips(display, new String[]{"تومان", "ریال"}, "IRR".equals(Cfg.displayCurrency(this)) ? 1 : 0, i -> {
            Cfg.setDisplayCurrency(this, i == 1 ? "IRR" : "IRT");
            ScanService.hideComparisonPopupIfPresent();
            render();
        });
        SettingsScreen.appendCurrencyHint(this, display);

        LinearLayout c = SettingsScreen.beginOperators(this, col);
        List<Op> ops = Cfg.ops(this);
        OperatorSettingsList.append(this, c, ops, new OperatorSettingsList.Host() {
            @Override public void editOp(Op o) { MainActivity.this.editOp(o); }
            @Override public void render() { MainActivity.this.render(); }
        });
        int enabledCount = 0;
        for (Op o : ops) if (o.cmp) enabledCount++;
        stepRow(c, "حداقل تعداد اپراتور برای مقایسه", "برای نمایش کادر مقایسه‌ی چنداپراتوری", Cfg.minOps(this), 1, Math.max(1, enabledCount), 1, "", v -> {
            Cfg.setInt(this, "minOps", v); render();
        });

        LinearLayout custom = SettingsScreen.beginCustomOperator(this, col);
        custom.addView(input("نام اپراتور", newName, s -> newName = s), UI.lp(this, -1, -2, 0, 3, 0, 6));
        EditText pkgInput = input("نام بسته‌ی برنامه؛ مانند ir.example.app", newPkg, s -> newPkg = s);
        pkgInput.setTextDirection(View.TEXT_DIRECTION_LTR);
        custom.addView(pkgInput, UI.lp(this, -1, -2, 0, 0, 0, 6));
        chips(custom, new String[]{"واحد خودکار", "ریال", "تومان"}, newCur, i -> { newCur = i; render(); });
        custom.addView(UI.btn(this, "افزودن اپراتور", UI.PRIMARY, 0xFF061326, v -> addOp()), UI.lp(this, -1, -2, 0, 8, 0, 0));

        LinearLayout comparison = SettingsScreen.beginComparisonFilters(this, col);
        chips(comparison, new String[]{"ارزان‌ترین هر گیگ", "بیشترین اعتبار", "هزینه مصرف من"}, Cfg.metric(this), i -> { Cfg.setInt(this, "metric", i); render(); });
        numberRow(comparison, "حداقل حجم بسته (مگابایت؛ صفر = همه)", Fmt.num(Math.round(Cfg.minGb(this) * 1024)),
                s -> Cfg.setFloat(this, "minGb", Math.max(0f, Math.min(5120000f, (float) (Fmt.parse(s, 0) / 1024.0)))));
        numberRow(comparison, "حداکثر اعتبار (روز؛ صفر = بدون محدودیت)", Fmt.dec(Cfg.maxDays(this)),
                s -> Cfg.setInt(this, "maxDays", Cfg.clamp((int) Fmt.parse(s, 0), 0, 36500)));
        numberRow(comparison, "مصرف ماهانه‌ی من (گیگ)", Fmt.dec(Cfg.usage(this)),
                s -> Cfg.setFloat(this, "usage", Cfg.finiteClamp((float) Fmt.parse(s, 30), 0.1f, 5000f, 30f)));
        numberRow(comparison, "ارزش افزوده (درصد)", Fmt.num(Cfg.vat(this)), s -> Cfg.setInt(this, "vat", Math.max(0, Math.min(100, (int) Fmt.parse(s, Cfg.vat(this))))));
        swRow(comparison, "نمایش بسته‌های ویژه", "شبانه، هدیه، اپلیکیشن و محدود", Cfg.restricted(this), (bv, on) -> Cfg.setBool(this, "restricted", on));
        swRow(comparison, "نمایش بسته‌های بین‌الملل و رومینگ", "جدا از مقایسه‌ی بسته‌های داخلی", Cfg.intl(this), (bv, on) -> Cfg.setBool(this, "intl", on));

        LinearLayout popup = SettingsScreen.beginPopupSection(this, col);
        swRow(popup, "نمایش خودکار پنجره‌ی مقایسه", "پس از شناسایی بسته‌ها نمایش داده شود", Cfg.popup(this), (bv, on) -> Cfg.setBool(this, "popup", on));
        popup.addView(UI.tv(this, "محتوای پنجره", 12, UI.TEXT, true), UI.lp(this, -1, -2, 0, 8, 0, 0));
        chips(popup, new String[]{"هر دو", "برترین کل", "همین صفحه"}, Cfg.pmode(this), i -> { Cfg.setInt(this, "pmode", i); render(); });
        stepRow(popup, "تعداد ردیف‌های پنجره", null, Cfg.rows(this), 3, 8, 1, "", v -> { Cfg.setInt(this, "rows", v); render(); });
        int[] hv = {0, 8, 15, 30}; int hsel = 0;
        for (int i=0;i<hv.length;i++) if (hv[i] == Cfg.hideSec(this)) hsel = i;
        chips(popup, new String[]{"بدون بستن خودکار", "۸ ثانیه", "۱۵ ثانیه", "۳۰ ثانیه"}, hsel, i -> { Cfg.setInt(this, "hide", hv[i]); render(); });
        chips(popup, new String[]{"بالای صفحه", "پایین صفحه"}, Cfg.bottom(this) ? 1 : 0, i -> { Cfg.setBool(this, "bottom", i == 1); render(); });
        popup.addView(UI.btn(this, "آزمایش پنجره‌ی شناور", UI.CARD2, UI.PRIMARY, v -> {
            ScanService service = ScanService.inst; // instance for binding-only ops
            if (service == null) toast("ابتدا دسترسی اسکن را فعال کنید"); else service.showTest();
        }), UI.lp(this, -1, -2, 0, 8, 0, 0));

        LinearLayout data = SettingsScreen.beginDataSection(this, col);
        int[] fresh = {3, 7, 14, 30}; int sel = 0;
        for (int i=0;i<fresh.length;i++) if (fresh[i] == Cfg.fresh(this)) sel = i;
        chips(data, new String[]{"۳ روز", "۷ روز", "۱۴ روز", "۳۰ روز"}, sel, i -> { Cfg.setInt(this, "fresh", fresh[i]); render(); });
        List<Pkg> pendingReview = Store.reviewQueue(this);
        SettingsScreen.appendReviewButton(this, data, pendingReview.size(), v -> showReviewQueue());
        if (HistoryLog.hasError(this)) {
            LinearLayout historyWarning = UI.card(this);
            historyWarning.addView(UI.tv(this, HistoryLog.errorSummary(this), 10, UI.DANGER, false));
            historyWarning.addView(UI.btn(this, "پاک‌کردن هشدار پس از بررسی", UI.CARD2, UI.TEXT, v -> {
                HistoryLog.clearError(this); render();
            }), UI.lp(this, -1, -2, 0, 6, 0, 0));
            data.addView(historyWarning, UI.lp(this, -1, -2, 0, 8, 0, 0));
        }
        data.addView(UI.btn(this, "خروجی بسته‌ها (CSV / Excel)", UI.CARD2, UI.PRIMARY, v -> exportCsv()), UI.lp(this, -1, -2, 0, 10, 0, 0));
        data.addView(UI.btn(this, "خروجی گزارش خطا (TXT)", UI.CARD2, UI.TEXT, v -> exportDiag()), UI.lp(this, -1, -2, 0, 7, 0, 0));
        SettingsScreen.appendHistoryCard(this, data, HistoryLog.recent(this, 6));
        data.addView(UI.btn(this, "پاک‌کردن بسته‌های ذخیره‌شده", UI.tint(UI.DANGER), UI.DANGER, v -> new AlertDialog.Builder(this)
                .setTitle("پاک‌کردن اطلاعات")
                .setMessage("همه‌ی بسته‌های ذخیره‌شده و تاریخچه‌ی تغییرات حذف شوند؟")
                .setNegativeButton("انصراف", null)
                .setPositiveButton("پاک شود", (d, w) -> { Store.clearAll(this); HistoryLog.clear(this); HistoryLog.clearError(this); toast("اطلاعات پاک شد"); render(); })
                .show()), UI.lp(this, -1, -2, 0, 8, 0, 0));

        SettingsScreen.appendAbout(this, col);
        SettingsScreen.appendDataPolicyNote(this, col);

        SettingsScreen.appendPrivacyFooter(this, col);
    }

    private void showReviewQueue() {
        List<Pkg> queue = Store.reviewQueue(this);
        if (queue.isEmpty()) {
            toast("بسته‌ای برای بازبینی باقی نمانده است");
            return;
        }
        String[] labels = new String[queue.size()];
        for (int i = 0; i < queue.size(); i++) {
            Pkg p = queue.get(i);
            Op op = Cfg.opById(this, p.op);
            String owner = op == null ? p.op : op.name;
            labels[i] = owner + " • " + (p.title == null || p.title.isEmpty() ? "بسته‌ی بدون عنوان" : p.title)
                    + "\n" + p.label() + " • " + (p.currencyKnown ? Cfg.priceLabel(this, p.toman) : "واحد/قیمت نیازمند بررسی");
        }
        new AlertDialog.Builder(this).setTitle("صف بازبینی بسته‌های مبهم")
                .setItems(labels, (dialog, which) -> editReview(queue.get(which)))
                .setNegativeButton("بستن", null).show();
    }

    private void editReview(Pkg source) {
        final EditText volume = input("حجم صحیح بر حسب گیگ", Fmt.dec(source.gb), value -> {});
        final EditText days = input("مدت صحیح بر حسب روز؛ صفر اگر نامشخص است", Fmt.dec(source.days), value -> {});
        final EditText price = input("قیمت صحیح بر حسب تومان", String.valueOf(source.toman), value -> {});
        volume.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        days.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        price.setInputType(InputType.TYPE_CLASS_NUMBER);
        volume.setTextDirection(View.TEXT_DIRECTION_LTR);
        days.setTextDirection(View.TEXT_DIRECTION_LTR);
        price.setTextDirection(View.TEXT_DIRECTION_LTR);
        volume.setGravity(Gravity.CENTER); days.setGravity(Gravity.CENTER); price.setGravity(Gravity.CENTER);
        volume.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        days.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        price.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        final EditText note = input("یادداشت بازبین (اختیاری)", "", value -> {});
        LinearLayout fields = UI.vbox(this);
        fields.setPadding(dp(20), dp(8), dp(20), dp(4));
        String reviewReason = source.note == null || source.note.trim().isEmpty()
                ? (source.why == null || source.why.trim().isEmpty() ? "شواهد کافی برای تأیید خودکار وجود ندارد." : source.why)
                : source.note;
        fields.addView(UI.tv(this, "علت نیاز به بازبینی: " + reviewReason, 10, UI.DANGER, false),
                UI.lp(this, -1, -2, 0, 0, 0, 8));
        fields.addView(UI.tv(this, "مقادیر استخراج‌شده تغییر نمی‌کنند؛ مقادیر تأییدشده جدا ذخیره می‌شوند و فقط پس از تأیید وارد مقایسه خواهند شد.",
                10, UI.MUTED, false), UI.lp(this, -1, -2, 0, 0, 0, 8));
        fields.addView(volume, UI.lp(this, -1, -2, 0, 0, 0, 6));
        fields.addView(days, UI.lp(this, -1, -2, 0, 0, 0, 6));
        fields.addView(price, UI.lp(this, -1, -2, 0, 0, 0, 6));
        fields.addView(note, UI.lp(this, -1, -2, 0, 0, 0, 0));

        final AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("بازبینی: " + (source.title == null ? "بسته" : source.title))
                .setView(fields)
                .setPositiveButton("تأیید و ورود به مقایسه", (d, which) -> {})
                .setNeutralButton("رد این بسته", (d, which) -> {})
                .setNegativeButton("لغو", null)
                .create();
        dialog.setOnShowListener(ignored -> {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                double gb = Fmt.parse(volume.getText().toString(), -1);
                double validity = Fmt.parse(days.getText().toString(), -1);
                double priceValue = Fmt.parse(price.getText().toString(), -1);
                long toman = priceValue < 0 || priceValue > 2000000000L ? -1 : Math.round(priceValue);
                boolean saved = Store.saveReview(this, source.key, true, gb, validity, toman, note.getText().toString());
                if (!saved) { toast("مقادیر معتبر وارد کنید: حجم حداقل ۰٫۰۵ گیگ و قیمت به تومان"); return; }
                dialog.dismiss(); toast("بازبینی ذخیره شد؛ مقادیر تأییدشده وارد مقایسه شدند"); render();
            });
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v -> {
                boolean saved = Store.saveReview(this, source.key, false, 0, 0, 0, note.getText().toString());
                if (!saved) { toast("ثبت رد بسته انجام نشد؛ دوباره تلاش کنید"); return; }
                dialog.dismiss(); toast("بسته از صف بازبینی و رتبه‌بندی حذف شد"); render();
            });
        });
        dialog.show();
    }

    private View sectionTitle(String title, String subtitle) {
        return ScreenChrome.sectionTitle(this, title, subtitle, this::dp);
    }

    private LinearLayout section(LinearLayout col, String title) {
        return ScreenChrome.section(this, col, title);
    }


    private void swRow(LinearLayout c, String title, String sub, boolean on, CompoundButton.OnCheckedChangeListener l) {
        FormControls.swRow(this, c, title, sub, on, l);
    }

    private void chips(LinearLayout c, String[] labels, int sel, final IntCb cb) {
        FormControls.chips(this, c, labels, sel, cb, this::dp);
    }

    private void stepRow(LinearLayout c, String title, String sub, final int val, final int min, final int max, final int step, String suffix, final IntCb cb) {
        FormControls.stepRow(this, c, title, sub, val, min, max, step, suffix, cb, this::dp);
    }

    private EditText input(String hint, String text, final StrCb cb) {
        return FormControls.input(this, hint, text, cb, this::dp);
    }

    private void numberRow(LinearLayout c, String label, String cur, StrCb cb) {
        FormControls.numberRow(this, c, label, cur, cb, this::dp);
    }

    private void addOp() {
        String name = newName == null ? "" : newName.trim();
        String pkg = newPkg == null ? "" : newPkg.trim();
        if (name.isEmpty() || pkg.isEmpty() || name.length() > 40) {
            toast("نام اپراتور و نام پکیج معتبر (حداکثر ۴۰ نویسه برای نام) وارد کنید");
            return;
        }
        if (!Cfg.validPackageName(pkg)) {
            toast("نام پکیج معتبر نیست؛ نمونه: ir.example.app");
            return;
        }
        List<Op> l = Cfg.ops(this);
        for (Op existing : l) if (existing.pkgs.contains(pkg)) {
            toast("این پکیج قبلاً به «" + existing.name + "» اختصاص داده شده است");
            return;
        }
        int[] pal = {0xFF8B5CF6, 0xFFEC4899, 0xFF22C55E, 0xFFF97316, 0xFF06B6D4};
        String[] cur = {"AUTO", "IRR", "IRT"};
        l.add(new Op("c" + System.currentTimeMillis(), name, pal[l.size() % pal.length], cur[Math.max(0, Math.min(2, newCur))], false, pkg));
        Cfg.saveOps(this, l);
        newName = "";
        newPkg = "";
        render();
    }

    private void editOp(final Op o) {
        final EditText e = input("com.example.app, com.example.beta", TextUtils.join(", ", o.pkgs), s -> {});
        e.setTextDirection(View.TEXT_DIRECTION_LTR);
        FrameLayout f = new FrameLayout(this);
        f.setPadding(dp(20), dp(8), dp(20), 0);
        f.addView(e);
        final AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("پکیج‌های " + o.name)
                .setMessage("نام پکیج برنامه‌ها را با ویرگول جدا کنید.")
                .setView(f)
                .setPositiveButton("ذخیره", (dlg, w) -> {})
                .setNegativeButton("لغو", null)
                .create();
        dialog.setOnShowListener(v -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(button -> {
            List<String> proposed = new ArrayList<>();
            for (String raw : e.getText().toString().split("[,\\s]+")) {
                String value = raw.trim();
                if (value.isEmpty()) continue;
                if (!Cfg.validPackageName(value)) {
                    toast("نام پکیج نامعتبر است: " + value);
                    return;
                }
                if (proposed.contains(value)) {
                    toast("پکیج تکراری وارد شده است: " + value);
                    return;
                }
                for (Op other : Cfg.ops(this)) {
                    if (!other.id.equals(o.id) && other.pkgs.contains(value)) {
                        toast("این پکیج به «" + other.name + "» اختصاص دارد: " + value);
                        return;
                    }
                }
                proposed.add(value);
            }
            if (proposed.isEmpty()) {
                toast("حداقل یک نام پکیج معتبر وارد کنید");
                return;
            }
            List<Op> updated = Cfg.ops(this);
            boolean found = false;
            for (Op item : updated) {
                if (item.id.equals(o.id)) {
                    item.pkgs.clear(); item.pkgs.addAll(proposed); found = true; break;
                }
            }
            if (!found) { toast("اپراتور تغییر کرده است؛ صفحه را تازه کنید"); return; }
            Cfg.saveOps(this, updated);
            dialog.dismiss();
            render();
        }));
        dialog.show();
    }

    // ---------------------------------------------------------------- export


    private void exportCsv() {
        final List<Pkg> all = Store.all(this);
        if (all.isEmpty()) {
            toast("داده‌ای برای خروجی نیست");
            return;
        }
        String ts = new SimpleDateFormat("MMdd_HHmmss", Locale.US).format(new Date());
        try {
            String where = LocalFileExport.save(this, "bastehyab_" + ts + ".csv", "text/csv", o ->
                    o.write(CsvExport.build(this, all).getBytes(StandardCharsets.UTF_8)));
            toast("ذخیره شد: " + where);
        } catch (Exception e) {
            toast(e.toString());
        }
    }

    private void exportDiag() {
        // Flush the in-memory snapshot first; otherwise a fast tap just after a scan may
        // incorrectly report that no diagnostic exists because the debounce has not fired.
        ScanService.flushDiagnostics();
        final File f = new File(getFilesDir(), "diag.txt");
        if (!f.exists()) {
            toast("هنوز گزارشی ساخته نشده؛ برنامه‌ی اپراتور را باز کنید و صفحه‌ی بسته‌ها را ببینید.");
            return;
        }
        String ts = new SimpleDateFormat("MMdd_HHmmss", Locale.US).format(new Date());
        try {
            String where = LocalFileExport.save(this, "diag_" + ts + ".txt", "text/plain", o -> {
                try (InputStream i = new FileInputStream(f)) {
                    byte[] buf = new byte[8192];
                    int n;
                    while ((n = i.read(buf)) > 0) o.write(buf, 0, n);
                }
            });
            toast("ذخیره شد: " + where);
        } catch (Exception e) {
            toast(e.toString());
        }
    }
}
