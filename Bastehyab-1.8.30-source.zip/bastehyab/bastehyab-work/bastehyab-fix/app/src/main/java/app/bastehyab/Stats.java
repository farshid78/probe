package app.bastehyab;

import android.content.Context;
import java.util.ArrayList;
import java.util.List;

/**
 * Lightweight local statistics derived from HistoryLog (no network).
 * Used for simple trend chips on the home screen.
 */
final class Stats {
    static final class Summary {
        final int priceDrops;
        final int priceRises;
        final int totalChanges;
        final String headline;

        Summary(int drops, int rises, int total, String headline) {
            this.priceDrops = drops;
            this.priceRises = rises;
            this.totalChanges = total;
            this.headline = headline;
        }
    }

    /** Summarize recent history entries (newest first, bounded). */
    static Summary summarize(Context c, int maxEntries) {
        List<HistoryLog.Entry> entries;
        try {
            entries = HistoryLog.recent(c, Math.max(1, maxEntries));
        } catch (Throwable t) {
            return new Summary(0, 0, 0, "آمار تاریخچه در دسترس نیست");
        }
        if (entries == null || entries.isEmpty()) {
            return new Summary(0, 0, 0, "هنوز تغییری ثبت نشده است");
        }
        int drops = 0, rises = 0;
        for (HistoryLog.Entry e : entries) {
            if (!"price".equals(e.field)) continue;
            if (e.after < e.before) drops++;
            else if (e.after > e.before) rises++;
        }
        int total = entries.size();
        String headline;
        if (drops > rises && drops > 0) {
            headline = Fmt.fa(String.valueOf(drops)) + " کاهش قیمت اخیر";
        } else if (rises > drops && rises > 0) {
            headline = Fmt.fa(String.valueOf(rises)) + " افزایش قیمت اخیر";
        } else if (total > 0) {
            headline = Fmt.fa(String.valueOf(total)) + " تغییر ثبت‌شده";
        } else {
            headline = "بدون تغییر قیمت اخیر";
        }
        return new Summary(drops, rises, total, headline);
    }
}
