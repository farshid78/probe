package app.bastehyab;

import android.content.Context;
import android.view.View;

/** Uses the installed operator application's real launcher identity (offline, no remote logo fetch). */
final class OperatorLogo extends View {

        private final String id;
        private final android.graphics.Paint paint = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
        private final android.graphics.drawable.Drawable operatorIcon;
        private final int brandColor;

        OperatorLogo(Context c, String id) {
            super(c);
            this.id = id == null ? "" : id;
            Op op = Cfg.opById(c, this.id);
            brandColor = op == null ? 0xFF9C72E8 : op.color;
            android.graphics.drawable.Drawable found = null;
            if (op != null && op.pkgs != null) {
                for (String pkg : op.pkgs) {
                    try {
                        found = c.getPackageManager().getApplicationIcon(pkg);
                        break;
                    } catch (android.content.pm.PackageManager.NameNotFoundException ignored) { }
                }
            }
            operatorIcon = found == null ? null : found.getConstantState() == null
                    ? found : found.getConstantState().newDrawable(c.getResources()).mutate();
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
            setContentDescription(op == null ? "نشان اپراتور" : "نشان برنامه‌ی " + op.name);
        }

        @Override protected void onDraw(android.graphics.Canvas c) {
            float w = getWidth(), h = getHeight();
            if (w <= 0 || h <= 0) return;
            float side = Math.min(w, h) * .90f;
            float left = (w - side) * .5f, top = (h - side) * .5f;
            paint.setStyle(android.graphics.Paint.Style.FILL);
            paint.setColor(0x22FFFFFF);
            c.drawRoundRect(left - UI.dp(getContext(), 2), top - UI.dp(getContext(), 2),
                    left + side + UI.dp(getContext(), 2), top + side + UI.dp(getContext(), 2),
                    UI.dp(getContext(), 11), UI.dp(getContext(), 11), paint);
            if (operatorIcon != null) {
                operatorIcon.setBounds(Math.round(left), Math.round(top), Math.round(left + side), Math.round(top + side));
                operatorIcon.draw(c);
            } else {
                paint.setColor((brandColor & 0x00FFFFFF) | 0xFF000000);
                c.drawRoundRect(left, top, left + side, top + side, UI.dp(getContext(), 12), UI.dp(getContext(), 12), paint);
                paint.setColor(0xFFFFFFFF);
                paint.setTextAlign(android.graphics.Paint.Align.CENTER);
                paint.setTypeface(android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.BOLD));
                paint.setTextSize(side * .40f);
                String mark = id.equals("irancell") ? "I" : id.equals("mci") ? "M"
                        : id.equals("rightel") ? "R" : id.equals("samantel") ? "S" : "SM";
                c.drawText(mark, w * .5f, h * .5f + side * .14f, paint);
            }
        }
    
}
