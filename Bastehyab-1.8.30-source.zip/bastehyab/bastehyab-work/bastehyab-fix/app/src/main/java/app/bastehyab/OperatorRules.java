package app.bastehyab;

/**
 * Per-operator extraction hints. Today all operators share {@link ExtractRules};
 * this class is the extension point for future operator-specific overrides without
 * forking the scanner pipeline.
 */
final class OperatorRules {
    private OperatorRules() {}

    /** Returns the active rule pack id for diagnostics. */
    static String packFor(String operatorId) {
        if (operatorId == null || operatorId.isEmpty()) return ExtractRules.packId();
        return ExtractRules.packId() + ":" + operatorId;
    }

    /**
     * Whether this operator's prices are stored in Rial in the operator app UI.
     * Samantel historically exposes explicit Rial amounts.
     */
    static boolean prefersRialDisplay(String operatorId) {
        return "samantel".equals(operatorId);
    }

    /** Currency profile string used by {@link Op} defaults. */
    static String defaultCurrency(String operatorId) {
        if ("samantel".equals(operatorId)) return "IRR";
        return "AUTO";
    }

    /**
     * Whether the adaptive scroller should try ACTION_SCROLL_FORWARD before gestures.
     * Reserved for future per-operator tuning; currently all operators share the same path.
     */
    static boolean preferAccessibilityScrollFirst(String operatorId) {
        return true;
    }

    /**
     * Extra settle delay after a scroll before the next tree read, in milliseconds.
     * Reserved for OEM/operator-specific slow lists; default uses ScanService constants.
     */
    static long extraSettleMs(String operatorId) {
        return 0L;
    }

    /** Short human label for diagnostics / about screens. */
    static String profileLabel(String operatorId) {
        if (operatorId == null || operatorId.isEmpty()) return "پیش‌فرض";
        switch (operatorId) {
            case "mci": return "همراه‌اول";
            case "irancell": return "ایرانسل";
            case "rightel": return "رایتل";
            case "samantel": return "سامانتل (ریال)";
            case "shatel": return "شاتل";
            default: return operatorId;
        }
    }

    /** True when the operator id is one of the built-in profiles. */
    static boolean isBuiltin(String operatorId) {
        if (operatorId == null) return false;
        switch (operatorId) {
            case "mci":
            case "irancell":
            case "rightel":
            case "samantel":
            case "shatel":
                return true;
            default:
                return false;
        }
    }
}
