package app.bastehyab;

import android.app.Activity;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.List;

/**
 * Settings-tab builders extracted from {@link MainActivity}.
 */
final class SettingsScreen {
    private SettingsScreen() {}

    static void appendHeading(Activity a, LinearLayout col) {
        LinearLayout heading = UI.hbox(a);
        LinearLayout title = UI.vbox(a);
        title.addView(UI.tv(a, "تنظیمات", 22, UI.TEXT, true));
        title.addView(UI.tv(a, "کنترل اسکن، مقایسه و خروجی اطلاعات", 11, UI.MUTED, false),
                UI.lp(a, -1, -2, 0, 3, 0, 0));
        heading.addView(title, UI.lpw(1f));
        heading.addView(UI.chip(a, "ذخیره‌ی خودکار", UI.tint(UI.ACCENT), UI.PRIMARY));
        col.addView(heading);
    }

    /** Shell for appearance section; caller adds theme/currency chips. */
    static LinearLayout beginAppearance(Activity a, LinearLayout col) {
        LinearLayout display = section(a, col, "ظاهر و نمایش");
        display.addView(UI.tv(a, "حالت رنگی برنامه", 12, UI.TEXT, true));
        return display;
    }

    static void appendAppearanceHints(Activity a, LinearLayout display) {
        display.addView(UI.tv(a,
                "سایبری: سرمه‌ای عمیق با شبکه‌ی مدارهای زنده با پالس‌های آرام و تأکید فیروزه‌ای؛ تک‌رنگ: مینیمال؛ روشن: زمینه‌ی روشن و کم‌کنتراست.",
                10, UI.MUTED, false), UI.lp(a, -1, -2, 0, 0, 0, 12));
        display.addView(UI.tv(a, "واحد نمایش قیمت‌ها", 12, UI.TEXT, true));
    }

    static void appendCurrencyHint(Activity a, LinearLayout display) {
        display.addView(UI.tv(a,
                "قیمت‌ها در حافظه بر اساس تومان نگهداری می‌شوند؛ تغییر این گزینه فقط واحد نمایش را عوض می‌کند.",
                10, UI.MUTED, false), UI.lp(a, -1, -2, 0, 2, 0, 0));
    }

    static LinearLayout beginOperators(Activity a, LinearLayout col) {
        LinearLayout c = section(a, col, "اسکن اپراتورها");
        c.addView(UI.tv(a, "اسکن فقط برای اپراتورهای روشن انجام می‌شود.", 10, UI.MUTED, false));
        return c;
    }

    static LinearLayout beginCustomOperator(Activity a, LinearLayout col) {
        return section(a, col, "افزودن اپراتور سفارشی");
    }

    static LinearLayout beginComparisonFilters(Activity a, LinearLayout col) {
        LinearLayout comparison = section(a, col, "فیلترهای مقایسه");
        comparison.addView(UI.tv(a, "معیار رتبه‌بندی", 12, UI.TEXT, true));
        return comparison;
    }

    static LinearLayout beginPopupSection(Activity a, LinearLayout col) {
        LinearLayout popup = section(a, col, "پنجره‌ی شناور و اعلان‌ها");
        return popup;
    }

    static void appendAbout(Activity a, LinearLayout col) {
        LinearLayout about = section(a, col, "درباره");
        about.addView(UI.tv(a, "بسته‌یاب " + Cfg.VERSION, 14, UI.TEXT, true));
        about.addView(UI.tv(a,
                "استخراج محلی بسته‌های اینترنت از برنامه‌های اپراتور با Accessibility. بدون اینترنت، بدون خرید خودکار.",
                11, UI.MUTED, false), UI.lp(a, -1, -2, 0, 6, 0, 0));
        about.addView(UI.tv(a,
                "قوانین استخراج: " + ExtractRules.packId() + " • وضعیت اسکن از طریق ScanSession همگام می‌شود.",
                10, UI.MUTED, false), UI.lp(a, -1, -2, 0, 4, 0, 0));
    }

    static void appendDataPolicyNote(Activity a, LinearLayout col) {
        LinearLayout card = section(a, col, "سیاست داده");
        card.addView(UI.tv(a,
                "همه پردازش‌ها روی دستگاه است. قوانین استخراج: " + ExtractRules.packId()
                        + " • اسکرول تطبیقی از OperatorRules پیروی می‌کند.",
                10, UI.MUTED, false));
    }

    static void appendPrivacyFooter(Activity a, LinearLayout col) {
        TextView privacy = UI.tv(a,
                "حریم خصوصی: اسکن و پردازش به‌صورت محلی انجام می‌شود؛ اطلاعات صفحه به سرور ارسال نمی‌شود.",
                10, UI.MUTED, false);
        privacy.setGravity(Gravity.CENTER);
        col.addView(privacy, UI.lp(a, -1, -2, 0, 16, 0, 0));
    }

    static LinearLayout beginDataSection(Activity a, LinearLayout col) {
        LinearLayout data = section(a, col, "اعتبار داده و خروجی");
        data.addView(UI.tv(a, "داده‌های قدیمی‌تر از این مدت از مقایسه کنار گذاشته می‌شوند.", 10, UI.MUTED, false));
        return data;
    }

    static void appendReviewButton(Activity a, LinearLayout data, int pendingCount, View.OnClickListener onClick) {
        data.addView(UI.tv(a, "بسته‌های مبهم تا زمان تأیید دستی وارد رتبه‌بندی قطعی نمی‌شوند.",
                10, UI.MUTED, false), UI.lp(a, -1, -2, 0, 8, 0, 0));
        data.addView(UI.btn(a, "بازبینی بسته‌های نیازمند تأیید  •  " + Fmt.fa(String.valueOf(pendingCount)),
                UI.CARD2, UI.PRIMARY, onClick), UI.lp(a, -1, -2, 0, 7, 0, 0));
    }

    /** Renders recent history entries into a card and attaches it under data. */
    static void appendHistoryCard(Activity a, LinearLayout data, List<HistoryLog.Entry> changes) {
        LinearLayout history = UI.card(a);
        history.addView(UI.tv(a, "تاریخچه‌ی تغییرات بسته‌ها", 13, UI.TEXT, true));
        if (changes == null || changes.isEmpty()) {
            history.addView(UI.tv(a, "هنوز تغییری بین دو اسکن ثبت نشده است.", 10, UI.MUTED, false),
                    UI.lp(a, -1, -2, 0, 6, 0, 0));
        } else {
            for (HistoryLog.Entry ch : changes) {
                boolean reviewApproved = "review_approved".equals(ch.field);
                boolean reviewRejected = "review_rejected".equals(ch.field);
                if (reviewApproved || reviewRejected) {
                    String label = reviewApproved ? "تأیید دستی" : "رد دستی";
                    String detail = ch.note == null || ch.note.isEmpty() ? "" : "\n" + ch.note;
                    history.addView(UI.tv(a, label + " • " + ch.title + detail + "  ·  " + Fmt.ago(ch.ts),
                            10, reviewApproved ? UI.PRIMARY : UI.DANGER, false),
                            UI.lp(a, -1, -2, 0, 7, 0, 0));
                    continue;
                }
                boolean price = "price".equals(ch.field);
                String field = price ? "قیمت" : ("gb".equals(ch.field) ? "حجم" : "مدت");
                String before = price ? Cfg.priceLabel(a, (long) ch.before)
                        : Fmt.dec(ch.before) + ("gb".equals(ch.field) ? " گیگ" : " روز");
                String after = price ? Cfg.priceLabel(a, (long) ch.after)
                        : Fmt.dec(ch.after) + ("gb".equals(ch.field) ? " گیگ" : " روز");
                history.addView(UI.tv(a, field + " • " + ch.title + "\n" + before + " ← " + after
                                + "  ·  " + Fmt.ago(ch.ts), 10, price ? UI.ACCENT : UI.MUTED, false),
                        UI.lp(a, -1, -2, 0, 7, 0, 0));
            }
        }
        data.addView(history, UI.lp(a, -1, -2, 0, 10, 0, 0));
    }

    static LinearLayout section(Activity a, LinearLayout col, String title) {
        col.addView(UI.tv(a, title, 13, UI.PRIMARY, true), UI.lp(a, -1, -2, 0, 16, 0, 8));
        LinearLayout card = UI.card(a);
        col.addView(card, UI.lp(a, -1, -2, 0, 0, 0, 0));
        return card;
    }
}
