package app.bastehyab;

import android.app.Activity;
import android.content.res.ColorStateList;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;

/** Shared form widgets used by settings and compare tabs. */
final class FormControls {
    interface IntCb { void on(int v); }
    interface StrCb { void on(String s); }
    interface Dp { int dp(float v); }

    private FormControls() {}

    static void styleSwitch(Switch sw) {
        int[][] states = new int[][]{{android.R.attr.state_checked}, {}};
        sw.setThumbTintList(new ColorStateList(states, new int[]{UI.PRIMARY, UI.MUTED}));
        sw.setTrackTintList(new ColorStateList(states, new int[]{
                (UI.PRIMARY & 0x00FFFFFF) | 0x88000000, (UI.STROKE & 0x00FFFFFF) | 0x66000000}));
    }

    static void swRow(Activity a, LinearLayout c, String title, String sub, boolean on,
                      CompoundButton.OnCheckedChangeListener l) {
        LinearLayout r = UI.hbox(a);
        LinearLayout t = UI.vbox(a);
        t.addView(UI.tv(a, title, 14, UI.TEXT, false));
        if (sub != null) t.addView(UI.tv(a, sub, 11, UI.MUTED, false));
        r.addView(t, UI.lpw(1f));
        Switch s = new Switch(a);
        styleSwitch(s);
        s.setChecked(on);
        s.setOnCheckedChangeListener(l);
        r.addView(s);
        c.addView(r, UI.lp(a, -1, -2, 0, 8, 0, 4));
    }

    static void chips(Activity a, LinearLayout c, String[] labels, int sel, IntCb cb, Dp dp) {
        LinearLayout r = UI.hbox(a);
        for (int i = 0; i < labels.length; i++) {
            final int idx = i;
            boolean on = i == sel;
            TextView t = UI.tv(a, labels[i], 12, on ? UI.contrastText(UI.PRIMARY) : UI.TEXT, on);
            t.setGravity(Gravity.CENTER);
            t.setPadding(dp.dp(6), dp.dp(9), dp.dp(6), dp.dp(9));
            t.setBackground(on
                    ? UI.grad(a, UI.PRIMARY, UI.BLUE, 13)
                    : UI.rr(a, UI.CARD2, 13, UI.STROKE));
            t.setOnClickListener(v -> cb.on(idx));
            r.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
            if (i < labels.length - 1) {
                r.addView(new View(a), new LinearLayout.LayoutParams(dp.dp(6), 1));
            }
        }
        c.addView(r, UI.lp(a, -1, -2, 0, 6, 0, 6));
    }

    static void stepRow(Activity a, LinearLayout c, String title, String sub, final int val,
                        final int min, final int max, final int step, String suffix, IntCb cb, Dp dp) {
        LinearLayout r = UI.hbox(a);
        LinearLayout t = UI.vbox(a);
        t.addView(UI.tv(a, title, 13, UI.TEXT, false));
        if (sub != null) t.addView(UI.tv(a, sub, 10, UI.MUTED, false));
        r.addView(t, UI.lpw(1f));
        r.addView(UI.btn(a, "−", UI.CARD2, UI.TEXT, v -> cb.on(Math.max(min, val - step))));
        TextView n = UI.tv(a, Fmt.fa(String.valueOf(val)) + suffix, 14, UI.PRIMARY, true);
        n.setGravity(Gravity.CENTER);
        n.setMinWidth(dp.dp(56));
        r.addView(n);
        r.addView(UI.btn(a, "+", UI.CARD2, UI.TEXT, v -> cb.on(Math.min(max, val + step))));
        c.addView(r, UI.lp(a, -1, -2, 0, 6, 0, 6));
    }

    static EditText input(Activity a, String hint, String text, StrCb cb, Dp dp) {
        EditText e = new EditText(a);
        e.setHint(hint);
        e.setHintTextColor(UI.MUTED);
        e.setTextColor(UI.TEXT);
        e.setTextSize(13);
        e.setSingleLine();
        e.setInputType(InputType.TYPE_CLASS_TEXT);
        e.setText(text);
        e.setBackground(UI.rr(a, UI.CARD2, 12, UI.STROKE));
        e.setPadding(dp.dp(14), dp.dp(11), dp.dp(14), dp.dp(11));
        e.setMinHeight(dp.dp(46));
        e.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
        e.setTextDirection(View.TEXT_DIRECTION_ANY_RTL);
        e.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int st, int c, int a2) {}
            @Override public void onTextChanged(CharSequence s, int st, int b, int c) {}
            @Override public void afterTextChanged(Editable s) { cb.on(s.toString()); }
        });
        return e;
    }

    static void numberRow(Activity a, LinearLayout c, String label, String cur, StrCb cb, Dp dp) {
        c.addView(UI.tv(a, label, 13, UI.TEXT, false), UI.lp(a, -1, -2, 0, 10, 0, 4));
        EditText value = input(a, "", cur, cb, dp);
        value.setTextDirection(View.TEXT_DIRECTION_LTR);
        value.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        value.setGravity(Gravity.CENTER);
        value.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        c.addView(value);
    }
}
