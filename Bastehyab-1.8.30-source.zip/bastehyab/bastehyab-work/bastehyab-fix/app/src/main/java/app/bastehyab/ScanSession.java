package app.bastehyab;

import java.util.Collections;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * Mutable scan-session state. Owned by {@link ScanService}; UI reads a snapshot via {@link ScanStatus}.
 * Grouping these fields here documents the session lifecycle and makes future non-static migration safer.
 */
final class ScanSession {
    volatile String lastScanStatus = "هنوز اسکن انجام نشده است";
    volatile int lastScannedPackages, lastValidPackages, lastSuspiciousPackages, lastDuplicatePackages;
    volatile long lastCompletedScanAt;
    volatile long lastScanDurationMs;
    volatile String lastOpId = "";
    volatile String lastEmptyReason = "";
    volatile String lastPackageStatus = "";
    volatile String lastScanError = "";
    volatile int lastNodeCount;

    volatile boolean fullMode;
    volatile boolean fullStartedScanning;
    volatile boolean fullTargetObservedOnce;
    volatile String fullTargetOpId = "";
    volatile String fullTargetPackage = "";
    volatile long fullStartedAt;
    volatile long fullLastStepAt;
    volatile long fullNextScanAt;
    volatile int fullSteps, fullNoNew;
    volatile int fullPageProbeCount;
    volatile int fullNoMove, fullScrollStrategy;
    volatile int fullObservedScrollPercent = -1;
    volatile int fullLastScrollY = -1, fullLastMaxScrollY = -1;
    volatile int fullLastScrollItemCount = -1, fullLastScrollToIndex = -1;
    volatile long fullLastScrollEventAt = 0L;
    volatile String lastScrollMethod = "هنوز اسکرولی انجام نشده";
    volatile String lastGestureResult = "not-run";
    volatile String lastPopupError = "";
    volatile boolean fullFinished;
    volatile ListEndDetector.State fullEndState = ListEndDetector.State.UNKNOWN;
    final ListEndDetector endDetector = new ListEndDetector();
    volatile Map<String, OpSnapshot> fullOperatorSnapshot = Collections.emptyMap();
    volatile boolean fullConfirmed;
    volatile boolean fullPaused;
    volatile long fullPausedAt;
    volatile boolean promptDismissed;
    volatile boolean settleRetried;
    final Set<String> fullSeen = new HashSet<>();
    volatile String fullLastFingerprint = "";

    String phase() {
        if (!fullMode) return fullFinished ? "FINISHED" : "IDLE";
        if (!fullConfirmed) return "WAITING_CONFIRM";
        if (fullPaused) return "PAUSED";
        return fullStartedScanning ? "SCANNING" : "WAITING_PAGE";
    }

    /** Reset counters and detectors for a new full extraction. */
    void resetForStart(String operatorId, String targetPackage) {
        fullSeen.clear();
        fullSteps = 0;
        fullNoNew = 0;
        fullPageProbeCount = 0;
        fullNoMove = 0;
        endDetector.reset();
        fullEndState = ListEndDetector.State.UNKNOWN;
        fullOperatorSnapshot = Collections.emptyMap();
        fullScrollStrategy = 0;
        fullObservedScrollPercent = -1;
        fullLastScrollY = -1;
        fullLastMaxScrollY = -1;
        fullLastScrollItemCount = -1;
        fullLastScrollToIndex = -1;
        fullLastScrollEventAt = 0L;
        lastScrollMethod = "هنوز اسکرولی انجام نشده";
        lastGestureResult = "not-run";
        lastPopupError = "";
        fullFinished = false;
        fullConfirmed = false;
        fullPaused = false;
        fullPausedAt = 0L;
        promptDismissed = false;
        settleRetried = false;
        fullLastFingerprint = "";
        fullStartedScanning = false;
        fullTargetObservedOnce = false;
        fullTargetOpId = operatorId == null ? "" : operatorId;
        fullTargetPackage = targetPackage == null ? "" : targetPackage;
        fullMode = true;
        fullStartedAt = System.currentTimeMillis();
        fullLastStepAt = fullStartedAt;
        fullNextScanAt = 0L;
        lastOpId = fullTargetOpId;
        lastScanError = "";
        lastEmptyReason = "";
        lastPackageStatus = "";
        lastScanStatus = "در انتظار تأیید صفحه بسته‌ها";
    }

    void markStopped(String reason, boolean finishedConfirmed) {
        fullMode = false;
        fullPaused = false;
        fullFinished = finishedConfirmed || fullEndState == ListEndDetector.State.END_CONFIRMED;
        fullStartedScanning = false;
        if (reason != null && !reason.isEmpty()) {
            lastScanStatus = reason;
        }
        lastCompletedScanAt = System.currentTimeMillis();
        if (fullStartedAt > 0) {
            lastScanDurationMs = Math.max(0L, lastCompletedScanAt - fullStartedAt);
        }
    }

    void pause() {
        if (!fullMode || fullPaused) return;
        fullPaused = true;
        fullPausedAt = System.currentTimeMillis();
        lastScanStatus = "اسکن موقتاً متوقف شد";
    }

    void resume() {
        if (!fullMode || !fullPaused) return;
        fullPaused = false;
        fullPausedAt = 0L;
        fullLastStepAt = System.currentTimeMillis();
        lastScanStatus = "ادامه اسکن";
    }
}
