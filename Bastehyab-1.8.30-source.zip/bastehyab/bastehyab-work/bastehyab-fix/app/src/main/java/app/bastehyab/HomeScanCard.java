package app.bastehyab;

import android.content.Context;
import android.content.res.ColorStateList;
import android.widget.LinearLayout;
import android.widget.ProgressBar;

/** Builds the home-screen "last scan status" card to keep MainActivity smaller. */
final class HomeScanCard {
    private HomeScanCard() {}

    static void append(Context c, LinearLayout col, int topPadDp) {
        ScanStatus st = ScanStatus.current();
        LinearLayout scan = UI.card(c);
        LinearLayout scanHead = UI.hbox(c);
        scanHead.addView(UI.tv(c, "وضعیت آخرین اسکن", 14, UI.TEXT, true), UI.lpw(1f));
        scanHead.addView(UI.chip(c, st.fullMode ? (st.paused ? "متوقف موقت" : "در حال اجرا") : "گزارش اسکن",
                st.fullMode ? UI.tint(UI.PRIMARY) : UI.tint(UI.ACCENT), st.fullMode ? UI.PRIMARY : UI.MUTED));
        scan.addView(scanHead);
        String scanAge = st.completedAt > 0 ? " • " + Fmt.ago(st.completedAt) : "";
        scan.addView(UI.tv(c, st.status + scanAge, 12, UI.MUTED, false), UI.lp(c, -1, -2, 0, 7, 0, 0));
        if (st.completedAt > 0) {
            scan.addView(UI.tv(c, "مدت پردازش: " + Fmt.fa(String.valueOf(st.durationMs)) + " میلی‌ثانیه",
                    9, UI.MUTED, false), UI.lp(c, -1, -2, 0, 4, 0, 0));
        }
        scan.addView(UI.tv(c, "شناسایی " + Fmt.fa(String.valueOf(st.scanned))
                + "  |  معتبر " + Fmt.fa(String.valueOf(st.valid))
                + "  |  مشکوک " + Fmt.fa(String.valueOf(st.suspicious))
                + "  |  تکراری " + Fmt.fa(String.valueOf(st.duplicates)), 10, UI.MUTED, false),
                UI.lp(c, -1, -2, 0, 5, 0, 0));
        if (st.fullMode || st.steps > 0) {
            int pct = st.progressPercent(ScanLimits.FULL_MAX_STEPS);
            Op target = Cfg.opById(c, st.targetOpId);
            String packHint = OperatorRules.profileLabel(st.targetOpId);
            scan.addView(UI.tv(c, st.humanPhaseLabel() + (target == null ? "" : " • " + target.name)
                    + "  •  " + Fmt.fa(String.valueOf(pct)) + "٪"
                    + (packHint.isEmpty() ? "" : "  •  " + packHint),
                    10, UI.PRIMARY, true), UI.lp(c, -1, -2, 0, 7, 0, 3));
            ProgressBar progress = new ProgressBar(c, null, android.R.attr.progressBarStyleHorizontal);
            progress.setProgressTintList(ColorStateList.valueOf(UI.PRIMARY));
            progress.setProgressBackgroundTintList(ColorStateList.valueOf(UI.STROKE));
            progress.setMax(100);
            progress.setProgress(pct);
            scan.addView(progress, UI.lp(c, -1, 5, 0, 0, 0, 0));
        }
        col.addView(scan, UI.lp(c, -1, -2, 0, topPadDp, 0, 0));
    }
}
