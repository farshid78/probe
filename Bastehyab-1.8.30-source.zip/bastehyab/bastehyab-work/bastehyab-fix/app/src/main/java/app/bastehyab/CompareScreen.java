package app.bastehyab;

import android.app.Activity;
import android.view.Gravity;
import android.widget.LinearLayout;
import java.util.HashSet;

/**
 * Builds the compare-tab chrome (header + ranking filters).
 * Ranking rows are built by ComparePkgRow; operator ticks by CompareOperatorTicks.
 */
final class CompareScreen {
    interface IntCb { void on(int v); }

    private CompareScreen() {}

    static void appendHeaderAndFilters(Activity a, LinearLayout col,
                                       IntCb onMetric, IntCb onBucket, IntCb onUsage) {
        LinearLayout header = UI.hbox(a);
        LinearLayout titles = UI.vbox(a);
        titles.addView(UI.tv(a, "مقایسه‌ی بسته‌ها", 22, UI.TEXT, true));
        titles.addView(UI.tv(a, "رتبه‌بندی قیمت، حجم و اعتبار", 11, UI.MUTED, false),
                UI.lp(a, -1, -2, 0, 3, 0, 0));
        header.addView(titles, UI.lpw(1f));
        header.addView(UI.chip(a, Fmt.fa(String.valueOf(Store.all(a).size())) + " ثبت‌شده",
                UI.tint(UI.ACCENT), UI.PRIMARY));
        col.addView(header);

        LinearLayout filter = UI.card(a);
        filter.addView(UI.tv(a, "معیار رتبه‌بندی", 13, UI.TEXT, true));
        // chips helper lives on MainActivity; keep filter body there for now.
        col.addView(filter, UI.lp(a, -1, -2, 0, 12, 0, 0));
        // Placeholder: MainActivity still owns interactive chips because of private helpers.
        filter.setTag("compare-filter");
    }

    static void appendHeader(Activity a, LinearLayout col, int storedCount) {
        LinearLayout header = UI.hbox(a);
        LinearLayout titles = UI.vbox(a);
        titles.addView(UI.tv(a, "مقایسه‌ی بسته‌ها", 22, UI.TEXT, true));
        titles.addView(UI.tv(a, "رتبه‌بندی قیمت، حجم و اعتبار", 11, UI.MUTED, false),
                UI.lp(a, -1, -2, 0, 3, 0, 0));
        header.addView(titles, UI.lpw(1f));
        header.addView(UI.chip(a, Fmt.fa(String.valueOf(storedCount)) + " ثبت‌شده",
                UI.tint(UI.ACCENT), UI.PRIMARY));
        col.addView(header);
    }

    static void appendEmptyState(Activity a, LinearLayout col, boolean anyOperatorEnabled) {
        LinearLayout empty = UI.card(a);
        empty.setGravity(Gravity.CENTER);
        empty.addView(UI.tv(a, anyOperatorEnabled ? "هنوز بسته‌ی قابل مقایسه‌ای نیست" : "اپراتوری انتخاب نشده است",
                15, UI.TEXT, true));
        empty.addView(UI.tv(a,
                "اپراتور را انتخاب کنید و از صفحه‌ی خانه وارد برنامه‌ی آن شوید تا فهرست بسته‌ها خوانده شود.",
                11, UI.MUTED, false), UI.lp(a, -1, -2, 0, 7, 0, 0));
        col.addView(empty);
    }

    static void appendSummary(Activity a, LinearLayout col, Compare.Result cr) {
        LinearLayout summary = UI.hbox(a);
        int pad = UI.dp(a, 12);
        summary.setPadding(pad, UI.dp(a, 10), pad, UI.dp(a, 10));
        summary.setBackground(UI.rr(a, UI.tint(UI.ACCENT), 13, UI.STROKE));
        summary.addView(UI.tv(a, Fmt.fa(String.valueOf(cr.ranked.size())) + " بسته‌ی قطعی", 11, UI.PRIMARY, true),
                UI.lpw(1f));
        summary.addView(UI.tv(a, cr.label, 10, UI.MUTED, false));
        col.addView(summary, UI.lp(a, -1, -2, 0, 10, 0, 8));
    }
}
