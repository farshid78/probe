package app.bastehyab;

import android.app.Activity;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.List;

/** Operator include/exclude pills for the compare tab. */
final class CompareOperatorTicks {
    interface Host {
        int dp(float v);
        void setAllCmp(boolean on);
        void render();
    }

    private CompareOperatorTicks() {}

    static View build(Activity a, Host host) {
        LinearLayout c = UI.card(a);
        List<Op> ops = Cfg.ops(a);
        LinearLayout hd = UI.hbox(a);
        hd.addView(UI.tv(a, "انتخاب اپراتورها", 13, UI.TEXT, true), UI.lpw(1f));
        hd.addView(UI.btn(a, "همه", UI.CARD2, UI.PRIMARY, v -> host.setAllCmp(true)),
                UI.lp(a, -2, -2, 0, 0, 5, 0));
        hd.addView(UI.btn(a, "هیچ‌کدام", UI.CARD2, UI.MUTED, v -> host.setAllCmp(false)));
        c.addView(hd);
        LinearLayout pills = UI.vbox(a);
        for (int i = 0; i < ops.size(); i += 2) {
            LinearLayout row = UI.hbox(a);
            for (int j = i; j < Math.min(i + 2, ops.size()); j++) {
                final Op o = ops.get(j);
                TextView pill = UI.tv(a, (o.cmp ? "✓  " : "○  ") + o.name, 11,
                        o.cmp ? UI.contrastText(o.color) : UI.MUTED, true);
                if (o.cmp) pill.setTextColor(UI.contrastText(UI.PRIMARY));
                pill.setGravity(Gravity.CENTER);
                pill.setPadding(host.dp(8), host.dp(9), host.dp(8), host.dp(9));
                pill.setBackground(o.cmp
                        ? UI.grad(a, UI.PRIMARY, UI.BLUE, 13)
                        : UI.rr(a, UI.CARD2, 13, UI.STROKE));
                pill.setOnClickListener(v -> {
                    o.cmp = !o.cmp;
                    Cfg.saveOps(a, ops);
                    host.render();
                });
                LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(0, -2, 1f);
                pp.setMargins(host.dp(3), host.dp(8), host.dp(3), 0);
                row.addView(pill, pp);
            }
            if (ops.size() % 2 == 1 && i + 1 == ops.size() - 1) {
                row.addView(new View(a), new LinearLayout.LayoutParams(0, 1, 1f));
            }
            pills.addView(row);
        }
        c.addView(pills);
        int selected = 0;
        for (Op o : ops) if (o.cmp) selected++;
        c.addView(UI.tv(a, selected == 0 ? "برای نمایش نتیجه، یک اپراتور را انتخاب کنید."
                : Fmt.fa(String.valueOf(selected)) + " اپراتور در مقایسه شرکت می‌کنند.",
                10, UI.MUTED, false), UI.lp(a, -1, -2, 0, 7, 0, 0));
        return c;
    }
}
