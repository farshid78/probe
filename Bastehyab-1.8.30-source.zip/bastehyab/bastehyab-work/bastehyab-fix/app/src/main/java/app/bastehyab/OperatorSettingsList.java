package app.bastehyab;

import android.app.Activity;
import android.text.TextUtils;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;
import java.util.List;

/** Builds the operator enable/configure rows on the settings tab. */
final class OperatorSettingsList {
    interface Host {
        void editOp(Op o);
        void render();
    }

    private OperatorSettingsList() {}

    static void append(Activity a, LinearLayout parent, List<Op> ops, Host host) {
        if (ops == null) return;
        for (final Op o : ops) {
            LinearLayout r = UI.hbox(a);
            LinearLayout t = UI.vbox(a);
            r.addView(new OperatorLogo(a, o.id), UI.lp(a, 42, 34, 0, 0, 10, 0));
            t.addView(UI.tv(a, o.name, 13, UI.TEXT, true));
            String curLabel = o.cur.equals("IRR") ? "ریال" : o.cur.equals("IRT") ? "تومان" : "واحد خودکار";
            TextView pk = UI.tv(a, TextUtils.join("، ", o.pkgs) + " • " + curLabel, 9, UI.MUTED, false);
            pk.setTextDirection(View.TEXT_DIRECTION_RTL);
            t.addView(pk, UI.lp(a, -1, -2, 0, 2, 0, 0));
            r.addView(t, UI.lpw(1f));
            r.addView(UI.btn(a, "پیکربندی", UI.CARD2, UI.PRIMARY, v -> host.editOp(o)),
                    UI.lp(a, -2, -2, 0, 0, 6, 0));
            Switch sw = new Switch(a);
            FormControls.styleSwitch(sw);
            sw.setChecked(o.enabled);
            sw.setOnCheckedChangeListener((bv, enabled) -> {
                o.enabled = enabled;
                Cfg.saveOps(a, ops);
            });
            r.addView(sw);
            parent.addView(r, UI.lp(a, -1, -2, 0, 8, 0, 8));
            if (!o.builtin) {
                parent.addView(UI.btn(a, "حذف اپراتور سفارشی: " + o.name, UI.tint(UI.DANGER), UI.DANGER, v -> {
                    ops.remove(o);
                    Cfg.saveOps(a, ops);
                    Store.clearOp(a, o.id);
                    host.render();
                }), UI.lp(a, -1, -2, 0, 0, 0, 5));
            }
        }
    }
}
