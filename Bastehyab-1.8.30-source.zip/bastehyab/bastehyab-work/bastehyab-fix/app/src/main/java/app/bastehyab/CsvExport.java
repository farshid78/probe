package app.bastehyab;

import android.content.Context;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Builds a privacy-safe CSV of unique packages for local export. */
final class CsvExport {
    private CsvExport() {}

    static String build(Context c, List<Pkg> all) {
        StringBuilder sb = new StringBuilder(
                "\uFEFFoperator,title,gb,days,price_toman,price_with_vat_toman,vat_percent,"
                        + "currency_known,ambiguous,per_gb_toman,restricted,reason,review_note,captured\n");
        Map<String, Pkg> uniqueRows = new LinkedHashMap<>();
        if (all != null) {
            for (Pkg p : all) {
                if (p.op == null || p.op.isEmpty()) continue;
                Pkg prev = uniqueRows.get(p.sig());
                if (prev == null || p.ts > prev.ts) uniqueRows.put(p.sig(), p);
            }
        }
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US);
        for (Pkg p : uniqueRows.values()) {
            Op op = Cfg.opById(c, p.op);
            sb.append(csv(op == null ? p.op : op.name)).append(',')
                    .append(csv(p.title)).append(',')
                    .append(p.gb).append(',').append(p.days).append(',')
                    .append(p.currencyKnown ? String.valueOf(p.toman) : "").append(',')
                    .append(p.currencyKnown ? String.valueOf(Cfg.finalPrice(c, p)) : "").append(',')
                    .append(Cfg.vat(c)).append(',')
                    .append(p.currencyKnown).append(',')
                    .append(p.ambig).append(',')
                    .append(p.currencyKnown && !p.ambig ? String.valueOf(Math.round(p.perGb())) : "").append(',')
                    .append(p.restricted).append(',').append(csv(p.why)).append(',')
                    .append(csv(p.note)).append(',')
                    .append(df.format(new Date(p.ts))).append('\n');
        }
        return sb.toString();
    }

    private static String csv(String value) {
        String safe = value == null ? "" : value.replace("\"", "\"\"");
        return "\"" + safe + "\"";
    }
}
