package app.bastehyab;

/**
 * Operator-aware scan/scroll policy. Default path matches the MCI-validated order;
 * {@link OperatorRules} may bias the first attempt per operator without forking the pipeline.
 */
final class ScanStrategyPolicy {
    private ScanStrategyPolicy() {}

    /**
     * Use ACTION_SCROLL_FORWARD first when strategy is still at the initial tier
     * and the operator profile prefers accessibility scroll.
     */
    static boolean shouldUseAccessibilityActionFirst(int strategy, String operatorId) {
        if (strategy > 0) return false;
        return OperatorRules.preferAccessibilityScrollFirst(operatorId);
    }

    /** After the first failed movement, prefer a gesture in the full app content viewport. */
    static boolean shouldPreferAppViewportSwipe(int strategy) {
        return strategy >= 2;
    }

    /** Base settle delay after a scroll, plus any operator-specific extra. */
    static long scrollSettleMs(String operatorId) {
        return ScanLimits.FULL_SCROLL_SETTLE_MS + Math.max(0L, OperatorRules.extraSettleMs(operatorId));
    }

    static long settleRetryMs(String operatorId) {
        return ScanLimits.FULL_SETTLE_RETRY_MS + Math.max(0L, OperatorRules.extraSettleMs(operatorId) / 2);
    }
}
