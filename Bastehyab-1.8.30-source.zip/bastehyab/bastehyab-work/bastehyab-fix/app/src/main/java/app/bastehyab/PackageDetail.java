package app.bastehyab;

import android.app.Activity;
import android.app.AlertDialog;

/** Dialog showing verified package price details (never invents an unverified amount). */
final class PackageDetail {
    private PackageDetail() {}

    static void show(Activity a, Pkg p) {
        if (p == null) return;
        Op op = Cfg.opById(a, p.op);
        String operator = op == null ? p.op : op.name;
        StringBuilder sb = new StringBuilder();
        sb.append(operator).append("\n");
        sb.append(p.label()).append("\n");
        if (p.currencyKnown && !p.ambig) {
            sb.append("قیمت پایه: ").append(Cfg.priceLabel(a, p.toman)).append("\n");
            sb.append("با ارزش افزوده: ").append(Cfg.priceLabel(a, Cfg.finalPrice(a, p))).append("\n");
        } else {
            sb.append("قیمت این بسته به‌صورت قطعی شناسایی نشد.\n");
            sb.append("تا بررسی دوباره، در رتبه‌بندی و مقایسه استفاده نمی‌شود.");
        }
        if (p.restricted && !p.ambig) {
            sb.append("\nمحدودیت: ").append(p.why);
        }
        new AlertDialog.Builder(a)
                .setTitle("جزئیات بسته")
                .setMessage(sb.toString())
                .setPositiveButton("بستن", null)
                .show();
    }
}
