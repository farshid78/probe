package app.bastehyab;

import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

/** Writes bytes to app Downloads (scoped storage aware). */
final class LocalFileExport {
    interface Writer {
        void write(OutputStream o) throws Exception;
    }

    private LocalFileExport() {}

    static String save(Context c, String name, String mime, Writer w) throws Exception {
        if (Build.VERSION.SDK_INT < 29) {
            File dir = c.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
            if (dir == null) throw new java.io.IOException("حافظه‌ی خارجی در دسترس نیست");
            if (!dir.exists() && !dir.mkdirs()) throw new java.io.IOException("ساخت پوشه‌ی خروجی ناموفق بود");
            File out = new File(dir, name);
            try (OutputStream o = new FileOutputStream(out)) {
                w.write(o);
            } catch (Exception e) {
                //noinspection ResultOfMethodCallIgnored
                out.delete();
                throw e;
            }
            return out.getAbsolutePath();
        }
        ContentValues v = new ContentValues();
        v.put(MediaStore.Downloads.DISPLAY_NAME, name);
        v.put(MediaStore.Downloads.MIME_TYPE, mime);
        Uri u = c.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
        if (u == null) throw new java.io.IOException("ساخت فایل در Downloads ناموفق بود");
        try (OutputStream o = c.getContentResolver().openOutputStream(u)) {
            if (o == null) throw new java.io.IOException("دسترسی نوشتن به فایل خروجی برقرار نشد");
            w.write(o);
        } catch (Exception e) {
            c.getContentResolver().delete(u, null, null);
            throw e;
        }
        return "Downloads";
    }
}
