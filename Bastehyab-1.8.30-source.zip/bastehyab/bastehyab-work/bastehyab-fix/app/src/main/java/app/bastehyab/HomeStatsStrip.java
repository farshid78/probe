package app.bastehyab;

import android.app.Activity;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.HashSet;
import java.util.List;

/** Home-tab overview stats and offline-privacy strip. */
final class HomeStatsStrip {
    interface Host {
        int dp(float v);
        View sectionTitle(String title, String subtitle);
    }

    private HomeStatsStrip() {}

    static void appendOverview(Activity a, LinearLayout col, List<Op> ops, List<Pkg> all,
                               Compare.Result cr, Host host) {
        int active = 0, withData = 0;
        long latest = 0;
        if (ops != null) {
            for (Op o : ops) if (o.enabled) active++;
            for (Op o : ops) {
                if (all == null) break;
                for (Pkg p : all) {
                    if (p.op.equals(o.id)) { withData++; break; }
                }
            }
        }
        if (all != null) {
            for (Pkg p : all) if (p.ts > latest) latest = p.ts;
        }
        int ranked = cr == null || cr.ranked == null ? 0 : cr.ranked.size();

        col.addView(host.sectionTitle("نمای کلی", "آمار ذخیره‌شده روی این گوشی"),
                UI.lp(a, -1, -2, 0, 16, 0, 8));
        LinearLayout stats1 = UI.hbox(a);
        stats1.addView(stat(a, host, Fmt.fa(String.valueOf(ranked)), "بسته‌ی معتبر"), UI.lpw(1f));
        stats1.addView(stat(a, host, Fmt.fa(String.valueOf(withData)), "اپراتور دارای داده"), UI.lp2(a, 8));
        LinearLayout stats2 = UI.hbox(a);
        stats2.addView(stat(a, host, Fmt.fa(String.valueOf(active)), "اپراتور فعال"), UI.lpw(1f));
        stats2.addView(stat(a, host, latest == 0 ? "—" : Fmt.ago(latest), "آخرین دریافت"), UI.lp2(a, 8));
        col.addView(stats1, UI.lp(a, -1, -2, 0, 0, 0, 8));
        col.addView(stats2, UI.lp(a, -1, -2, 0, 0, 0, 8));
        Stats.Summary trend = Stats.summarize(a, 40);
        LinearLayout stats3 = UI.hbox(a);
        stats3.addView(stat(a, host, trend.headline, "روند قیمت‌ها"), UI.lpw(1f));
        col.addView(stats3, UI.lp(a, -1, -2, 0, 0, 0, 0));
    }

    static void appendPrivacy(Activity a, LinearLayout col, Host host) {
        LinearLayout privacy = UI.hbox(a);
        privacy.setPadding(host.dp(12), host.dp(10), host.dp(12), host.dp(10));
        privacy.setBackground(UI.rr(a, UI.tint(UI.ACCENT), 13, UI.STROKE));
        privacy.addView(UI.tv(a, "پردازش آفلاین روی همین گوشی", 10, UI.PRIMARY, true), UI.lpw(1f));
        privacy.addView(UI.tv(a, "بدون ارسال اطلاعات", 9, UI.MUTED, false));
        col.addView(privacy, UI.lp(a, -1, -2, 0, 8, 0, 0));
    }

    private static View stat(Activity a, Host host, String big, String small) {
        LinearLayout c = UI.vbox(a);
        c.setGravity(Gravity.CENTER);
        c.setPadding(host.dp(8), host.dp(12), host.dp(8), host.dp(12));
        c.setMinimumHeight(host.dp(96));
        c.setOrientation(LinearLayout.VERTICAL);
        c.setBackground(UI.rr(a, UI.CARD, 18, UI.STROKE));
        c.setElevation(host.dp(5));
        TextView number = UI.tv(a, big, 23, UI.PRIMARY, true);
        number.setGravity(Gravity.CENTER);
        number.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        c.addView(number);
        TextView t = UI.tv(a, small, 10, UI.MUTED, false);
        t.setGravity(Gravity.CENTER);
        t.setSingleLine(true);
        t.setEllipsize(android.text.TextUtils.TruncateAt.END);
        c.addView(t);
        return c;
    }
}
