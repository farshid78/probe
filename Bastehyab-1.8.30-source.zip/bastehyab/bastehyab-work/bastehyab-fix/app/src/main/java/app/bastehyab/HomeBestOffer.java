package app.bastehyab;

import android.app.Activity;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;

/** Home-tab "best current offer" card. */
final class HomeBestOffer {
    interface Host {
        void openCompareTab();
    }

    private HomeBestOffer() {}

    static void append(Activity a, LinearLayout col, Compare.Result cr, Host host) {
        LinearLayout best = UI.card(a);
        LinearLayout bh = UI.hbox(a);
        bh.addView(UI.tv(a, "بهترین پیشنهاد فعلی", 14, UI.TEXT, true), UI.lpw(1f));
        bh.addView(UI.chip(a, "پیشنهاد هوشمند", UI.tint(UI.ACCENT), UI.ACCENT));
        best.addView(bh);
        if (cr == null || cr.ranked.isEmpty()) {
            best.addView(UI.tv(a,
                    "هنوز بسته‌ی معتبر برای مقایسه ثبت نشده است. یکی از اپراتورها را باز کنید و وارد صفحه‌ی بسته‌ها شوید.",
                    11, UI.MUTED, false), UI.lp(a, -1, -2, 0, 8, 0, 0));
        } else {
            Pkg p = cr.ranked.get(0);
            Op op = Cfg.opById(a, p.op);
            LinearLayout offer = UI.hbox(a);
            LinearLayout details = UI.vbox(a);
            details.addView(UI.chip(a, op == null ? p.op : op.name,
                    UI.tint(op == null ? UI.MUTED : op.color), op == null ? UI.MUTED : op.color));
            details.addView(UI.tv(a, p.label(), 17, UI.TEXT, true), UI.lp(a, -1, -2, 0, 7, 0, 3));
            details.addView(UI.tv(a, "اعتبار " + Fmt.dec(p.days) + " روز", 10, UI.MUTED, false));
            details.addView(UI.tv(a, "قیمت نهایی: " + Cfg.priceLabel(a, Cfg.finalPrice(a, p)),
                    11, UI.MUTED, false), UI.lp(a, -1, -2, 0, 5, 0, 0));
            offer.addView(details, UI.lpw(1f));
            LinearLayout metric = UI.vbox(a);
            metric.setGravity(Gravity.CENTER);
            String metricValue = cr.metric == Cfg.DURATION
                    ? Fmt.dec(p.days)
                    : Fmt.num(Math.round(Cfg.displayMetric(a, cr.val.get(p.key))));
            metric.addView(UI.tv(a, metricValue, 22, UI.PRIMARY, true));
            metric.addView(UI.tv(a, Cfg.metricUnit(a, cr.unit), 9, UI.MUTED, false));
            offer.addView(metric);
            best.addView(offer, UI.lp(a, -1, -2, 0, 10, 0, 0));
            best.addView(UI.btn(a, "مشاهده‌ی رتبه‌بندی بسته‌ها", UI.PRIMARY, 0xFF061326,
                    v -> host.openCompareTab()), UI.lp(a, -1, -2, 0, 12, 0, 0));
        }
        col.addView(best, UI.lp(a, -1, -2, 0, 12, 0, 0));
    }
}
