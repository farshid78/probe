package app.bastehyab;

import android.app.Activity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Shared section headers used across home/settings/compare. */
final class ScreenChrome {
    interface Dp {
        int dp(float v);
    }

    private ScreenChrome() {}

    static View sectionTitle(Activity a, String title, String subtitle, Dp dp) {
        LinearLayout box = UI.hbox(a);
        View accent = new View(a);
        accent.setBackground(UI.rr(a, UI.PRIMARY, 3));
        box.addView(accent, UI.lp(a, 4, 27, 0, 0, 10, 0));
        LinearLayout labels = UI.vbox(a);
        labels.addView(UI.tv(a, title, 15, UI.TEXT, true));
        if (subtitle != null && !subtitle.isEmpty()) {
            labels.addView(UI.tv(a, subtitle, 10, UI.MUTED, false), UI.lp(a, -1, -2, 0, 2, 0, 0));
        }
        box.addView(labels, UI.lpw(1f));
        return box;
    }

    static LinearLayout section(Activity a, LinearLayout col, String title) {
        LinearLayout heading = UI.hbox(a);
        View accent = new View(a);
        accent.setBackground(UI.rr(a, UI.PRIMARY, 3));
        heading.addView(accent, UI.lp(a, 4, 20, 0, 0, 9, 0));
        TextView label = UI.tv(a, title, 13, UI.TEXT, true);
        heading.addView(label, UI.lpw(1f));
        col.addView(heading, UI.lp(a, -1, -2, 0, 18, 0, 8));
        LinearLayout c = UI.card(a);
        col.addView(c);
        return c;
    }
}
