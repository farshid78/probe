# پیشرفت ۱.۸.۱۳

## انجام‌شده
1. HomeStatsStrip (آمار + privacy)
2. حذف helperهای مرده MainActivity
3. isFullMode()
4. fixture سوم (رایتل)

## باقی‌مانده
- static alias ScanService (سازگاری)
- hero/access banner هنوز در home
- fixture واقعی
- Compose / rule-pack کامل
