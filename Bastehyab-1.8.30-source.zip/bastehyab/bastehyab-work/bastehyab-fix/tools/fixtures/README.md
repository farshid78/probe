# Fixtures

Synthetic accessibility-style offer lists for offline validation.

| File | Notes |
|------|--------|
| sample_mci_like.txt | MCI-style toman packages |
| sample_irancell_like.txt | Irancell-style |
| sample_rightel_like.txt | Rightel-style |
| sample_samantel_like.txt | Samantel-style (Rial amounts) |
| sample_shatel_like.txt | Shatel-style |

## Rules
- Never commit phone numbers, account IDs, or raw editable fields.
- Sanitize real dumps with `tools/fixture-sanitizer` before adding them here.
- Run `bash tools/fixtures/validate_fixtures.sh` (also in CI).
