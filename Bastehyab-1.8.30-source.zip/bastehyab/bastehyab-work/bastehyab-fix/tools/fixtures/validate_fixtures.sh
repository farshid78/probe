#!/usr/bin/env bash
# Offline check: fixtures exist, are non-empty, and do not contain obvious PII markers.
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
count=0
for f in "$HERE"/*.txt; do
  [ -f "$f" ] || continue
  count=$((count+1))
  size=$(wc -c < "$f")
  if [ "$size" -lt 20 ]; then
    echo "FAIL: $f too small"
    exit 1
  fi
  if grep -Eiq '09[0-9]{9}|password|رمز|شماره موبایل' "$f"; then
    echo "FAIL: $f may contain PII — sanitize before commit"
    exit 1
  fi
  echo "OK: $(basename "$f") ($size bytes)"
done
if [ "$count" -eq 0 ]; then
  echo "FAIL: no fixtures"
  exit 1
fi
echo "PASS: $count fixture(s) validated"
