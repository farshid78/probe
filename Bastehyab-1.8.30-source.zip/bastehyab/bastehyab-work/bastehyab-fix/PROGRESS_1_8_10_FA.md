# پیشرفت ۱.۸.۱۰

## انجام‌شده
1. SettingsScreen تقریباً تمام اسکلت تنظیمات را می‌سازد
2. تاریخچه به SettingsScreen منتقل شد
3. fixture دوم (ایرانسل‌مانند)
4. مستندسازی aliasهای ScanService

## باقی‌مانده
- static aliasها هنوز برای سازگاری میانی هستند
- fixture واقعی از دستگاه
- chips/list اپراتور هنوز در MainActivity
- Compose / rule-pack کامل
