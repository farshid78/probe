# معماری بسته‌یاب (پس از refactor ۱.۸.x)

## لایه‌ها
1. **UI** — `MainActivity` orchestration؛ کارت‌ها در `Home*` / `Compare*` / `SettingsScreen` / `FormControls` / `ScreenChrome`
2. **وضعیت اسکن** — `ScanSession` + `ScanStatus`؛ helperهای dual-write در `ScanService`
3. **استخراج** — `Extractor` (pairing قیمت) + `ExtractRules` (الگوهای مشترک) + `OperatorRules` (پروفایل اپراتور)
4. **سیاست اسکرول** — `ScanStrategyPolicy` ← `OperatorRules`
5. **داده** — `Store` / `HistoryLog` / `CsvExport` / `LocalFileExport`
6. **تست** — parser smoke + fixtures synthetic + unit tests محدود

## آنچه عمداً انجام نشد
- حذف کامل staticهای `ScanService` (نیاز به تست OEM)
- مهاجرت Compose
- جابه‌جایی کامل PRICE pairing بدون fixture واقعی
