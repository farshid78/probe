# پیشرفت ۱.۸.۲۱

## انجام‌شده
1. helperهای اسکرول/probe با session
2. مستند fixtureها

## باقی‌مانده
- static mid-loop (با sync و helper)
- fixture واقعی
- Compose / rule-pack کامل
