# پیشرفت ۱.۸.۸

## انجام‌شده
1. setStatus / syncStepCountersToSession
2. بیشتر وضعیت‌های اسکن از مسیر session-aware
3. ExtractRules برای night/unlimited + تست
4. Settings: سیاست داده
5. smoke PASS

## باقی‌مانده
- حذف نهایی فیلدهای static (همه writes فقط روی session)
- fixture واقعی
- شکستن کامل MainActivity
- Compose / rule-pack per-operator
