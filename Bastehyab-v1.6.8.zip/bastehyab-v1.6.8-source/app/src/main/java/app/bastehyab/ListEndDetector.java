package app.bastehyab;

import java.util.HashSet;
import java.util.Set;

/** Conservative list-end detector. A stationary page alone can never mean completion. */
final class ListEndDetector {
    private static final int REQUIRED_INDEPENDENT_BOTTOM_CYCLES = 3;
    enum State { MORE_AVAILABLE, END_CONFIRMED, UNKNOWN }

    private State state = State.UNKNOWN;
    private final Set<Long> proofCycles = new HashSet<>();
    private int lastMax = -1;
    private int lastY = -1;

    synchronized State observe(int scrollY, int maxScrollY, boolean moreIndicator,
                               boolean forwardActionAccepted, long scanCycle) {
        if (maxScrollY <= 0 || scrollY < 0) {
            state = State.UNKNOWN;
            proofCycles.clear();
            lastMax = lastY = -1;
            return state;
        }
        int tolerance = Math.max(2, maxScrollY / 100);
        boolean atBottom = scrollY >= maxScrollY - tolerance;
        if (moreIndicator || !atBottom) {
            state = State.MORE_AVAILABLE;
            proofCycles.clear();
            lastMax = maxScrollY;
            lastY = scrollY;
            return state;
        }

        // Require the same range to be observed at the bottom in three separate scan cycles.
        // A provider may report ACTION_SCROLL_FORWARD as accepted even when it did not move.
        if (lastMax != maxScrollY || lastY < 0 || Math.abs(lastY - scrollY) > tolerance) {
            proofCycles.clear();
        }
        lastMax = maxScrollY;
        lastY = scrollY;
        proofCycles.add(scanCycle);
        if (proofCycles.size() >= REQUIRED_INDEPENDENT_BOTTOM_CYCLES) state = State.END_CONFIRMED;
        else state = State.UNKNOWN;
        return state;
    }

    synchronized State state() { return state; }

    synchronized void reset() {
        state = State.UNKNOWN;
        proofCycles.clear();
        lastMax = lastY = -1;
    }
}
