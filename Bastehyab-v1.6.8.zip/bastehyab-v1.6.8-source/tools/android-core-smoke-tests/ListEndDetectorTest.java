package app.bastehyab;

/** Regression coverage for conservative three-state end-of-list detection. */
public final class ListEndDetectorTest {
    private static void check(boolean ok, String message) {
        if (!ok) throw new AssertionError(message);
    }

    public static void main(String[] args) {
        ListEndDetector detector = new ListEndDetector();
        check(detector.state() == ListEndDetector.State.UNKNOWN, "initial state must be unknown");

        check(detector.observe(100, 1000, false, false, 1) == ListEndDetector.State.MORE_AVAILABLE,
                "not-at-bottom means more content may exist");
        check(detector.observe(1000, 1000, true, false, 2) == ListEndDetector.State.MORE_AVAILABLE,
                "load-more indicator prevents end confirmation");
        check(detector.observe(1000, 1000, false, true, 3) == ListEndDetector.State.UNKNOWN,
                "a consumed action at the bottom is not proof of more content");

        check(detector.observe(1000, 1000, false, false, 4) == ListEndDetector.State.UNKNOWN,
                "two bottom observations still need a third independent confirmation");
        check(detector.observe(1000, 1000, false, false, 4) == ListEndDetector.State.UNKNOWN,
                "duplicate cycle cannot satisfy the independent-observation requirement");
        check(detector.observe(1000, 1000, false, false, 5) == ListEndDetector.State.END_CONFIRMED,
                "three independent bottom observations confirm end");

        check(detector.observe(500, 1000, false, false, 6) == ListEndDetector.State.MORE_AVAILABLE,
                "moving away from bottom resets end proof");
        check(detector.observe(0, 0, false, false, 7) == ListEndDetector.State.UNKNOWN,
                "missing scroll range must remain unknown");
        detector.reset();
        check(detector.state() == ListEndDetector.State.UNKNOWN, "reset returns to unknown");
        System.out.println("ListEndDetectorTest: PASS");
    }
}
