package probe.app;

import android.accessibilityservice.AccessibilityService;
import android.content.Context;
import android.graphics.Rect;
import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import java.io.File;
import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class ScanService extends AccessibilityService {
    static File file(Context c) { return new File(c.getFilesDir(), "dump.txt"); }

    private final Handler h = new Handler(Looper.getMainLooper());
    private final Runnable job = this::dump;
    private String last = "", act = "";
    private int count;

    @Override public void onInterrupt() {}

    @Override public void onAccessibilityEvent(AccessibilityEvent e) {
        String p = String.valueOf(e.getPackageName());
        if (p.equals(getPackageName()) || p.equals("com.android.systemui")) return;
        int t = e.getEventType();
        if (t == AccessibilityEvent.TYPE_VIEW_CLICKED) {
            AccessibilityNodeInfo s = e.getSource();
            write("CLICK pkg=" + p + " " + (s == null ? "" : desc(s)) + " ev=" + e.getText() + "\n");
            return;
        }
        if (t == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED && e.getClassName() != null)
            act = e.getClassName().toString();
        h.removeCallbacks(job);
        h.postDelayed(job, 800);
    }

    private void dump() {
        AccessibilityNodeInfo r = getRootInActiveWindow();
        if (r == null) return;
        String p = String.valueOf(r.getPackageName());
        if (p.equals(getPackageName()) || p.equals("com.android.systemui")) return;
        count = 0;
        StringBuilder sb = new StringBuilder();
        walk(r, 0, sb);
        String body = sb.toString();
        String key = p + body.hashCode();
        if (key.equals(last)) return;
        last = key;
        write("=== " + new SimpleDateFormat("HH:mm:ss", Locale.US).format(new Date())
                + " pkg=" + p + " act=" + act + " nodes=" + count
                + (body.isEmpty() ? " EMPTY" : "") + "\n" + body);
    }

    private void walk(AccessibilityNodeInfo n, int d, StringBuilder sb) {
        if (n == null || d > 40 || !n.isVisibleToUser()) return;
        count++;
        if (n.getText() != null || n.getContentDescription() != null
                || n.getViewIdResourceName() != null || n.isClickable()) {
            for (int i = 0; i < Math.min(d, 20); i++) sb.append(' ');
            sb.append(desc(n)).append('\n');
        }
        for (int i = 0; i < n.getChildCount(); i++) walk(n.getChild(i), d + 1, sb);
    }

    private String desc(AccessibilityNodeInfo n) {
        Rect b = new Rect();
        n.getBoundsInScreen(b);
        String cn = String.valueOf(n.getClassName());
        cn = cn.substring(cn.lastIndexOf('.') + 1);
        return cn + " id=" + n.getViewIdResourceName()
                + " t=\"" + s(n.getText()) + "\" d=\"" + s(n.getContentDescription()) + "\" "
                + b.toShortString() + (n.isClickable() ? " CK" : "") + (n.isScrollable() ? " SC" : "");
    }

    private static String s(CharSequence c) {
        if (c == null) return "";
        String x = c.toString().replace("\n", "\\n");
        return x.length() > 200 ? x.substring(0, 200) : x;
    }

    private synchronized void write(String s) {
        File f = file(this);
        if (f.length() > 8_000_000) return;
        try (FileWriter w = new FileWriter(f, true)) { w.write(s); } catch (Exception ignored) {}
    }
}
