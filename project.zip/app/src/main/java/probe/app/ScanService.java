package probe.app;

import android.accessibilityservice.AccessibilityService;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Rect;
import android.hardware.HardwareBuffer;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.Display;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;
import android.widget.Toast;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Pattern;

public class ScanService extends AccessibilityService {
    static File file(Context c) { return new File(c.getFilesDir(), "dump.txt"); }
    static File shots(Context c) { File d = new File(c.getFilesDir(), "shots"); d.mkdirs(); return d; }

    // P = price, V = volume, D = duration (matched on digit-normalized text)
    private static final Pattern PP = Pattern.compile("(تومان|تومن|ریال|\\d+\\s*(هزار|میلیون)|\\d{1,3}([,.]\\d{3})+)");
    private static final Pattern VP = Pattern.compile("(\\d\\s*(گیگ|مگ|ترابایت|gb|mb|tb)|نامحدود)", Pattern.CASE_INSENSITIVE);
    private static final Pattern DP = Pattern.compile(
            "(\\d\\s*(روز|ماه|هفته|ساعت|شبانه|سال|day|month|week|hour)|روزه|ماهه|ماهانه|هفتگی|روزانه|سالانه|ساعته|ساعتی|شبانه)",
            Pattern.CASE_INSENSITIVE);

    private final Handler h = new Handler(Looper.getMainLooper());
    private final Runnable job = this::capture;
    private final Map<String, Integer> last = new HashMap<>();
    private String act = "";
    private long pending, lastToast;
    private int seq;

    @Override public void onInterrupt() {}

    @Override protected void onServiceConnected() {
        String[] l = shots(this).list();
        seq = l == null ? 0 : l.length;
        write("##### SERVICE CONNECTED sdk=" + Build.VERSION.SDK_INT + " device="
                + Build.MANUFACTURER + " " + Build.MODEL + "\n"
                + "##### columns(TAB): left,top,right,bottom | path | flags(S=selected,C=checked) | tags(P=price,V=volume,D=duration) | id | text\n");
        toast("Probe فعال شد");
    }

    private boolean pass(String p) {
        if (p.equals(getPackageName()) || p.equals("com.android.systemui")) return false;
        String f = getSharedPreferences("p", 0).getString("filter", "").trim();
        if (f.isEmpty()) return true;
        for (String t : f.split("[,\\s]+")) if (!t.isEmpty() && p.contains(t)) return true;
        return false;
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent e) {
        if (!pass(String.valueOf(e.getPackageName()))) return;
        if (e.getEventType() == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED && e.getClassName() != null)
            act = e.getClassName().toString();
        long now = System.currentTimeMillis();
        if (pending == 0) pending = now;
        h.removeCallbacks(job);
        h.postDelayed(job, now - pending > 2500 ? 0 : 800);
    }

    private void capture() {
        pending = 0;
        List<AccessibilityNodeInfo> roots = new ArrayList<>();
        List<AccessibilityWindowInfo> ws = getWindows();
        if (ws != null) {
            for (AccessibilityWindowInfo w : ws) {
                if (w.getType() == AccessibilityWindowInfo.TYPE_APPLICATION) {
                    AccessibilityNodeInfo r = w.getRoot();
                    if (r != null) roots.add(r);
                }
            }
        }
        if (roots.isEmpty()) {
            AccessibilityNodeInfo r = getRootInActiveWindow();
            if (r != null) roots.add(r);
        }
        SharedPreferences sp = getSharedPreferences("p", 0);
        boolean all = sp.getBoolean("shotAll", false), logAll = sp.getBoolean("logAll", false);
        int w = getResources().getDisplayMetrics().widthPixels, hh = getResources().getDisplayMetrics().heightPixels;
        String msg = null;
        int shotId = 0;
        for (AccessibilityNodeInfo r : roots) {
            String p = String.valueOf(r.getPackageName());
            if (!pass(p)) continue;
            int[] st = new int[4]; // texts, P, V, D
            StringBuilder sb = new StringBuilder();
            walk(r, "0", 0, sb, st);
            Integer key = sb.toString().hashCode();
            if (key.equals(last.get(p))) continue;
            last.put(p, key);
            int kinds = (st[1] > 0 ? 1 : 0) + (st[2] > 0 ? 1 : 0) + (st[3] > 0 ? 1 : 0);
            boolean sparse = st[0] < 4;
            if (!sparse && kinds < 2 && !logAll) {
                sp.edit().putInt("skipped", sp.getInt("skipped", 0) + 1).apply();
                msg = "صفحه‌ی بدون بسته (" + st[0] + " متن)";
                continue;
            }
            boolean needShot = sparse || all;
            if (needShot && shotId == 0) shotId = ++seq;
            write("=== " + new SimpleDateFormat("HH:mm:ss", Locale.US).format(new Date())
                    + " pkg=" + p + " screen=" + w + "x" + hh + " act=" + act
                    + " n=" + st[0] + " P=" + st[1] + " V=" + st[2] + " D=" + st[3]
                    + (st[0] == 0 ? " EMPTY" : sparse ? " SPARSE" : "")
                    + (needShot ? " shot=" + String.format(Locale.US, "%03d", shotId) : "")
                    + "\n" + sb);
            msg = sparse ? "⚠ کم‌متن (" + st[0] + ") • اسکرین‌شات گرفته شد"
                    : "✓ " + st[1] + " قیمت • " + st[2] + " حجم • " + st[3] + " مدت";
        }
        if (shotId != 0) shot(shotId);
        long now = System.currentTimeMillis();
        if (msg != null && now - lastToast > 1200) {
            lastToast = now;
            toast(msg);
        }
    }

    private void walk(AccessibilityNodeInfo n, String path, int d, StringBuilder sb, int[] st) {
        if (n == null || d > 50 || !n.isVisibleToUser()) return;
        CharSequence x = n.getText();
        if (x == null || x.length() == 0) x = n.getContentDescription();
        if (x != null && x.length() > 0) {
            String t = clean(x.toString());
            if (!t.trim().isEmpty()) {
                String tag = tags(t);
                st[0]++;
                if (tag.contains("P")) st[1]++;
                if (tag.contains("V")) st[2]++;
                if (tag.contains("D")) st[3]++;
                Rect b = new Rect();
                n.getBoundsInScreen(b);
                String id = n.getViewIdResourceName();
                sb.append(b.left).append(',').append(b.top).append(',').append(b.right).append(',').append(b.bottom)
                        .append('\t').append(path)
                        .append('\t').append(n.isSelected() ? "S" : "").append(n.isChecked() ? "C" : "")
                        .append('\t').append(tag)
                        .append('\t').append(id == null ? "" : id.substring(id.indexOf('/') + 1))
                        .append('\t').append(t).append('\n');
            }
        }
        for (int i = 0; i < n.getChildCount(); i++) walk(n.getChild(i), path + "." + i, d + 1, sb, st);
    }

    private static String tags(String t) {
        String s = norm(t);
        return (PP.matcher(s).find() ? "P" : "") + (VP.matcher(s).find() ? "V" : "") + (DP.matcher(s).find() ? "D" : "");
    }

    private static String norm(String s) {
        StringBuilder b = new StringBuilder(s.length());
        for (char c : s.toCharArray()) {
            if (c >= '\u06f0' && c <= '\u06f9') b.append((char) ('0' + c - '\u06f0'));
            else if (c >= '\u0660' && c <= '\u0669') b.append((char) ('0' + c - '\u0660'));
            else if (c == '\u066c' || c == '\u060c') b.append(',');
            else if (c == '\u066b') b.append('.');
            else if (c == '\u064a' || c == '\u0649') b.append('\u06cc');
            else if (c == '\u0643') b.append('\u06a9');
            else if (c == '\u200c') b.append(' ');
            else b.append(c);
        }
        return b.toString();
    }

    private static String clean(String x) {
        x = x.replaceAll("[\\u200e\\u200f\\u202a-\\u202e\\u2066-\\u2069]", "")
                .replace("\n", "\\n").replace("\t", " ");
        return x.length() > 300 ? x.substring(0, 300) : x;
    }

    private void shot(final int id) {
        if (Build.VERSION.SDK_INT < 30) return;
        File[] ex = shots(this).listFiles();
        if (ex != null && ex.length >= 60) return;
        takeScreenshot(Display.DEFAULT_DISPLAY, getMainExecutor(), new TakeScreenshotCallback() {
            @Override public void onSuccess(ScreenshotResult r) {
                HardwareBuffer hb = r.getHardwareBuffer();
                try {
                    Bitmap hw = Bitmap.wrapHardwareBuffer(hb, r.getColorSpace());
                    if (hw == null) return;
                    Bitmap b = hw.copy(Bitmap.Config.ARGB_8888, false);
                    File f = new File(shots(ScanService.this), String.format(Locale.US, "%03d.jpg", id));
                    try (FileOutputStream o = new FileOutputStream(f)) {
                        b.compress(Bitmap.CompressFormat.JPEG, 75, o);
                    }
                } catch (Exception ignored) {
                } finally {
                    hb.close();
                }
            }
            @Override public void onFailure(int code) {
                write("shot " + id + " failed code=" + code + "\n");
            }
        });
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    private synchronized void write(String s) {
        File f = file(this);
        if (f.length() > 8_000_000) return;
        try (Writer w = new OutputStreamWriter(new FileOutputStream(f, true), StandardCharsets.UTF_8)) {
            w.write(s);
        } catch (Exception ignored) {}
    }
}
