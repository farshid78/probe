package probe.app;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class MainActivity extends Activity {
    interface W { void w(OutputStream o) throws Exception; }

    TextView st, pv;
    EditText fl;
    CheckBox ca, la;

    SharedPreferences p() { return getSharedPreferences("p", 0); }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        ScrollView sv = new ScrollView(this);
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(40, 80, 40, 40);
        sv.addView(l);
        st = new TextView(this);
        st.setTextSize(15);
        l.addView(st);
        fl = new EditText(this);
        fl.setHint("فیلتر پکیج (اختیاری) مثال: mci,irancell");
        fl.setSingleLine();
        fl.setText(p().getString("filter", ""));
        l.addView(fl);
        ca = new CheckBox(this);
        ca.setText("اسکرین‌شات از هر ثبت");
        ca.setChecked(p().getBoolean("shotAll", false));
        l.addView(ca);
        la = new CheckBox(this);
        la.setText("ثبت همه‌ی صفحات (اشکال‌یابی)");
        la.setChecked(p().getBoolean("logAll", false));
        l.addView(la);
        add(l, "۱) فعال‌سازی سرویس", v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        add(l, "اگر سرویس خاکستری بود (Restricted settings)", v -> startActivity(
                new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName()))));
        add(l, "۲) خروجی به Downloads", v -> export());
        add(l, "پاک کردن لاگ", v -> clear());
        add(l, "بروزرسانی", v -> refresh());
        pv = new TextView(this);
        pv.setTypeface(Typeface.MONOSPACE);
        pv.setTextSize(10);
        l.addView(pv);
        setContentView(sv);
    }

    @Override protected void onResume() { super.onResume(); refresh(); }
    @Override protected void onPause() { super.onPause(); saveP(); }

    void saveP() {
        p().edit().putString("filter", fl.getText().toString()).putBoolean("shotAll", ca.isChecked()).putBoolean("logAll", la.isChecked()).apply();
    }

    void add(LinearLayout l, String t, View.OnClickListener c) {
        Button x = new Button(this);
        x.setText(t);
        x.setOnClickListener(c);
        l.addView(x);
    }

    void refresh() {
        saveP();
        String en = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        boolean on = en != null && en.contains(getPackageName());
        File f = ScanService.file(this);
        int snaps = 0, weak = 0;
        Map<String, Integer> pk = new TreeMap<>();
        try (BufferedReader r = new BufferedReader(new InputStreamReader(new FileInputStream(f), StandardCharsets.UTF_8))) {
            String ln;
            while ((ln = r.readLine()) != null) {
                if (!ln.startsWith("=== ")) continue;
                snaps++;
                if (ln.contains(" EMPTY") || ln.contains(" SPARSE")) weak++;
                int i = ln.indexOf("pkg=");
                if (i >= 0) pk.merge(ln.substring(i + 4).split(" ")[0], 1, Integer::sum);
            }
        } catch (Exception ignored) {}
        String[] sh = ScanService.shots(this).list();
        StringBuilder s = new StringBuilder();
        s.append("سرویس: ").append(on ? "روشن ✓" : "خاموش ✗")
                .append("\nثبت‌ها: ").append(snaps).append("  (کم‌متن: ").append(weak).append(")")
                .append("\nصفحه‌های بدون بسته (ثبت نشد): ").append(p().getInt("skipped", 0))
                .append("\nاسکرین‌شات: ").append(sh == null ? 0 : sh.length)
                .append("\nحجم لاگ: ").append(f.length() / 1024).append(" KB\n");
        for (Map.Entry<String, Integer> e : pk.entrySet())
            s.append("\n").append(e.getKey()).append("  ×").append(e.getValue());
        st.setText(s);
        pv.setText(tail(f));
    }

    String tail(File f) {
        try (RandomAccessFile r = new RandomAccessFile(f, "r")) {
            long n = Math.min(r.length(), 6000);
            r.seek(r.length() - n);
            byte[] b = new byte[(int) n];
            r.readFully(b);
            String s = new String(b, StandardCharsets.UTF_8);
            int i = s.indexOf('\n');
            return i >= 0 ? s.substring(i + 1) : s;
        } catch (Exception e) { return ""; }
    }

    void clear() {
        ScanService.file(this).delete();
        p().edit().putInt("skipped", 0).apply();
        File[] s = ScanService.shots(this).listFiles();
        if (s != null) for (File x : s) x.delete();
        refresh();
    }

    void export() {
        saveP();
        final File f = ScanService.file(this);
        if (!f.exists()) { toast("لاگ خالی است"); return; }
        String ts = new SimpleDateFormat("MMdd_HHmmss", Locale.US).format(new Date());
        try {
            save("probe_" + ts + ".zip", "application/zip", o -> {
                ZipOutputStream z = new ZipOutputStream(o);
                put(z, "dump.txt", f);
                File[] s = ScanService.shots(this).listFiles();
                if (s != null) {
                    Arrays.sort(s);
                    for (File x : s) put(z, "shots/" + x.getName(), x);
                }
                z.finish();
            });
            save("dump_" + ts + ".txt", "text/plain", o -> {
                try (InputStream i = new FileInputStream(f)) { copy(i, o); }
            });
            toast("ذخیره شد در Downloads: probe_" + ts + ".zip");
        } catch (Exception e) { toast(e.toString()); }
    }

    void save(String name, String mime, W w) throws Exception {
        ContentValues v = new ContentValues();
        v.put(MediaStore.Downloads.DISPLAY_NAME, name);
        v.put(MediaStore.Downloads.MIME_TYPE, mime);
        Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
        try (OutputStream o = getContentResolver().openOutputStream(u)) { w.w(o); }
    }

    void put(ZipOutputStream z, String name, File f) throws Exception {
        z.putNextEntry(new ZipEntry(name));
        try (InputStream i = new FileInputStream(f)) { copy(i, z); }
        z.closeEntry();
    }

    void copy(InputStream i, OutputStream o) throws Exception {
        byte[] buf = new byte[8192];
        int n;
        while ((n = i.read(buf)) > 0) o.write(buf, 0, n);
    }

    void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }
}
