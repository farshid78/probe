package probe.app;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;

public class MainActivity extends Activity {
    TextView st;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(48, 96, 48, 48);
        st = new TextView(this);
        st.setTextSize(16);
        l.addView(st);
        add(l, "1) Enable service", v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        add(l, "2) Export log to Downloads", v -> export());
        add(l, "Clear log", v -> { ScanService.file(this).delete(); refresh(); });
        add(l, "Refresh", v -> refresh());
        setContentView(l);
    }

    @Override protected void onResume() { super.onResume(); refresh(); }

    void add(LinearLayout l, String t, View.OnClickListener c) {
        Button x = new Button(this);
        x.setText(t);
        x.setOnClickListener(c);
        l.addView(x);
    }

    void refresh() {
        String en = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        boolean on = en != null && en.contains(getPackageName());
        st.setText("Service: " + (on ? "ON" : "OFF") + "\nLog size: " + ScanService.file(this).length() / 1024 + " KB");
    }

    void export() {
        File f = ScanService.file(this);
        if (!f.exists()) { toast("Log is empty"); return; }
        try {
            ContentValues v = new ContentValues();
            v.put(MediaStore.Downloads.DISPLAY_NAME, "dump_" + System.currentTimeMillis() / 1000 + ".txt");
            v.put(MediaStore.Downloads.MIME_TYPE, "text/plain");
            Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
            try (InputStream i = new FileInputStream(f); OutputStream o = getContentResolver().openOutputStream(u)) {
                byte[] buf = new byte[8192];
                int n;
                while ((n = i.read(buf)) > 0) o.write(buf, 0, n);
            }
            toast("Saved in Downloads");
        } catch (Exception e) { toast(e.toString()); }
    }

    void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }
}
