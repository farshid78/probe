package app.bastehyab;

import android.content.Context;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

final class Compare {
    static final class Result {
        final List<Pkg> ranked = new ArrayList<>();
        final Map<String, Double> val = new HashMap<>();
        final List<Pkg> ambig = new ArrayList<>(); // kept out of the ranking: price could not be trusted
        double median;
        int ops, metric;
        String label = "", unit = "";
        Pkg bestScreen;
        int rankScreen;
    }

    static double value(Pkg p, int metric, double usage) {
        switch (metric) {
            case Cfg.PER_GB_MONTH: return p.perGbMonth();
            case Cfg.MY_USAGE: return p.monthlyCost(usage);
            default: return p.perGb();
        }
    }

    static Result run(Context c, Set<String> onScreen) {
        final Result r = new Result();
        int metric = Cfg.metric(c);
        double usage = Cfg.usage(c);
        r.metric = metric;
        long minTs = System.currentTimeMillis() - Cfg.fresh(c) * 86400000L;
        Set<String> enabled = new HashSet<>();
        for (Op o : Cfg.ops(c)) if (o.cmp) enabled.add(o.id);
        Set<String> seen = new HashSet<>();
        float minGb = Cfg.minGb(c);
        int maxDays = Cfg.maxDays(c);
        boolean restricted = Cfg.restricted(c);
        for (Pkg p : Store.all(c)) {
            if (!enabled.contains(p.op) || p.ts < minTs || p.gb < minGb) continue;
            if (p.ambig && !Cfg.ambig(c)) {
                r.ambig.add(p);
                continue;
            }
            if (maxDays > 0 && p.days > maxDays) continue;
            if (p.restricted && !restricted) continue;
            double v = value(p, metric, usage);
            if (v >= Double.MAX_VALUE / 2) continue;
            r.val.put(p.key, v);
            r.ranked.add(p);
            seen.add(p.op);
        }
        Collections.sort(r.ranked, (a, b) -> Double.compare(r.val.get(a.key), r.val.get(b.key)));
        r.ops = seen.size();
        if (!r.ranked.isEmpty()) r.median = r.val.get(r.ranked.get(r.ranked.size() / 2).key);
        if (onScreen != null) {
            for (int i = 0; i < r.ranked.size(); i++) {
                if (onScreen.contains(r.ranked.get(i).key)) {
                    r.bestScreen = r.ranked.get(i);
                    r.rankScreen = i + 1;
                    break;
                }
            }
        }
        if (metric == Cfg.PER_GB_MONTH) {
            r.label = "قیمت هر گیگ در ماه";
            r.unit = "تومان/گیگ‌ماه";
        } else if (metric == Cfg.MY_USAGE) {
            r.label = "هزینه‌ی ماهانه برای " + Fmt.dec(usage) + " گیگ";
            r.unit = "تومان/ماه";
        } else {
            r.label = "قیمت هر گیگ";
            r.unit = "تومان/گیگ";
        }
        return r;
    }
}
