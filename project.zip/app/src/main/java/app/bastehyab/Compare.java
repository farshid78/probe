package app.bastehyab;

import android.content.Context;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

final class Compare {
    static final String[] BUCKETS = {"همه", "هفتگی", "ماهانه", "۳ ماهه", "بلندمدت"};

    static boolean inBucket(double days, int b) {
        if (b == 0) return true;
        if (days <= 0) return false;
        switch (b) {
            case 1: return days <= 7;
            case 2: return days > 7 && days <= 35;
            case 3: return days > 35 && days <= 100;
            default: return days > 100;
        }
    }

    static final class Result {
        final List<Pkg> ranked = new ArrayList<>();
        final Map<String, Double> val = new HashMap<>();
        final List<Pkg> ambig = new ArrayList<>(); // kept out of the ranking: price could not be trusted
        final Map<String, Integer> rank = new HashMap<>();
        final java.util.Set<String> cheap = new HashSet<>(); // far below the median: double-check
        final List<Pkg> screen = new ArrayList<>(); // ranked packages that are on the current screen
        int bucket;
        double median;
        int ops, metric;
        String label = "", unit = "";
        Pkg bestScreen;
        int rankScreen;
    }

    static double value(Pkg p, int metric, double usage) {
        switch (metric) {
            case Cfg.PER_GB_MONTH: return p.perGbMonth();
            case Cfg.MY_USAGE: return p.monthlyCost(usage);
            default: return p.perGb();
        }
    }

    static Result run(Context c, Set<String> onScreen) {
        final Result r = new Result();
        int metric = Cfg.metric(c);
        double usage = Cfg.usage(c);
        r.metric = metric;
        r.bucket = Cfg.bucket(c);
        long minTs = System.currentTimeMillis() - Cfg.fresh(c) * 86400000L;
        Set<String> enabled = new HashSet<>();
        for (Op o : Cfg.ops(c)) if (o.cmp) enabled.add(o.id);
        Set<String> seen = new HashSet<>();
        float minGb = Cfg.minGb(c);
        int maxDays = Cfg.maxDays(c);
        boolean restricted = Cfg.restricted(c);
        for (Pkg p : Store.all(c)) {
            if (!enabled.contains(p.op) || p.ts < minTs || p.gb < minGb) continue;
            if (p.ambig && !Cfg.ambig(c)) {
                r.ambig.add(p);
                continue;
            }
            if (maxDays > 0 && p.days > maxDays) continue;
            if (!inBucket(p.days, r.bucket)) continue;
            if (p.restricted && !restricted) continue;
            double v = value(p, metric, usage);
            if (v >= Double.MAX_VALUE / 2) continue;
            r.val.put(p.key, v);
            r.ranked.add(p);
            seen.add(p.op);
        }
        Collections.sort(r.ranked, (a, b) -> Double.compare(r.val.get(a.key), r.val.get(b.key)));
        r.ops = seen.size();
        if (!r.ranked.isEmpty()) r.median = r.val.get(r.ranked.get(r.ranked.size() / 2).key);
        for (int i = 0; i < r.ranked.size(); i++) {
            Pkg p = r.ranked.get(i);
            r.rank.put(p.key, i + 1);
            if (onScreen != null && onScreen.contains(p.key)) r.screen.add(p);
            if (r.ranked.size() >= 6 && r.val.get(p.key) < 0.6 * r.median) r.cheap.add(p.key);
        }
        if (!r.screen.isEmpty()) {
            r.bestScreen = r.screen.get(0);
            r.rankScreen = r.rank.get(r.bestScreen.key);
        }
        if (metric == Cfg.PER_GB_MONTH) {
            r.label = "قیمت هر گیگ در ماه";
            r.unit = "تومان/گیگ‌ماه";
        } else if (metric == Cfg.MY_USAGE) {
            r.label = "هزینه‌ی ماهانه برای " + Fmt.dec(usage) + " گیگ";
            r.unit = "تومان/ماه";
        } else {
            r.label = "قیمت هر گیگ";
            r.unit = "تومان/گیگ";
        }
        return r;
    }
}
