package app.bastehyab;

import android.content.Context;
import org.json.JSONArray;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

final class Store {
    private static final Map<String, Pkg> m = new LinkedHashMap<>();
    private static boolean loaded;
    private static long lastSave;

    private static File f(Context c) {
        return new File(c.getApplicationContext().getFilesDir(), "data.json");
    }

    private static void load(Context c) {
        if (loaded) return;
        loaded = true;
        try (BufferedReader r = new BufferedReader(new InputStreamReader(new FileInputStream(f(c)), StandardCharsets.UTF_8))) {
            StringBuilder sb = new StringBuilder();
            String ln;
            while ((ln = r.readLine()) != null) sb.append(ln);
            JSONArray a = new JSONArray(sb.toString());
            for (int i = 0; i < a.length(); i++) {
                Pkg p = Pkg.from(a.getJSONObject(i));
                String w = Extractor.restr(p.title + " " + p.raw);
                if (!w.isEmpty()) {
                    p.why = w;
                    p.restricted = true;
                }
                m.put(p.key, p);
            }
        } catch (Exception ignored) {}
    }

    private static void save(Context c) {
        lastSave = System.currentTimeMillis();
        JSONArray a = new JSONArray();
        for (Pkg p : m.values()) {
            try {
                a.put(p.json());
            } catch (Exception ignored) {}
        }
        try (Writer w = new OutputStreamWriter(new FileOutputStream(f(c)), StandardCharsets.UTF_8)) {
            w.write(a.toString());
        } catch (Exception ignored) {}
    }

    // returns number of new/changed packages
    static synchronized int upsert(Context c, List<Pkg> items) {
        load(c);
        int ch = 0;
        long now = System.currentTimeMillis();
        for (Pkg p : items) {
            Pkg o = m.get(p.key);
            if (o == null || o.toman != p.toman || Math.abs(o.gb - p.gb) > 1e-9
                    || o.days != p.days || o.restricted != p.restricted) ch++;
            p.ts = now;
            m.put(p.key, p);
        }
        if (ch > 0 || now - lastSave > 60000) save(c);
        return ch;
    }

    static synchronized List<Pkg> all(Context c) {
        load(c);
        return new ArrayList<>(m.values());
    }

    static synchronized void clearOp(Context c, String opId) {
        load(c);
        Iterator<Pkg> it = m.values().iterator();
        while (it.hasNext()) if (it.next().op.equals(opId)) it.remove();
        save(c);
    }

    static synchronized void reprice(Context c, String opId, int policy) {
        load(c);
        for (Pkg p : m.values()) {
            if (!p.op.equals(opId) || p.alts.length < 2 || policy == 0) continue;
            long best = p.alts[0];
            for (long a : p.alts) best = policy == 1 ? Math.max(best, a) : Math.min(best, a);
            p.toman = best;
            p.ambig = false;
        }
        save(c);
    }

    static synchronized void clearAll(Context c) {
        load(c);
        m.clear();
        save(c);
    }
}
