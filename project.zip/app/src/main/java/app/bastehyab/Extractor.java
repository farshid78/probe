package app.bastehyab;

import android.graphics.Rect;
import android.view.accessibility.AccessibilityNodeInfo;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Turns an accessibility tree into package offers (price / volume / duration), operator-agnostic. */
final class Extractor {
    static final class N {
        N parent;
        final List<N> kids = new ArrayList<>();
        String text, id;
        final Rect b = new Rect();
        List<N> lv = new ArrayList<>(); // text leaves in subtree
        boolean leaf, price, unitOnly;
        double amt;
        int unit; // 0 none, 1 rial, 2 toman

        int cx() { return b.centerX(); }
        int cy() { return b.centerY(); }
    }

    static final class Result {
        final List<Pkg> items = new ArrayList<>();
        final Set<String> keys = new HashSet<>();
        String dump = "";
        int leaves;
    }

    private static final int F = Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE;
    private static final Pattern VOL = Pattern.compile(
            "(\\d+(?:\\.\\d+)?)\\s*(گیگابایت|گیگا|گیگ|مگابایت|مگا|مگ|ترابایت|ترا|gb|mb|tb)", F);
    private static final Pattern DUR = Pattern.compile("(\\d+(?:\\.\\d+)?)\\s*(روز|ماه|هفته|ساعت|سال)");
    private static final Pattern DURW = Pattern.compile("(روزانه|هفتگی|ماهانه|سالانه)");
    private static final Pattern UNIT = Pattern.compile("تومان|تومن|ریال");
    private static final Pattern UNITONLY = Pattern.compile("^\\s*(تومان|تومن|ریال)\\s*$");
    private static final Pattern PRICE = Pattern.compile(
            "(\\d{1,3}(?:[,.]\\d{3})+|\\d+(?:\\.\\d+)?)(?:\\s*(میلیون|هزار))?\\s*(تومان|تومن|ریال)?");
    private static final Pattern SEP = Pattern.compile("\\d{1,3}(?:[,.]\\d{3})+");
    private static final Pattern CODE = Pattern.compile("offerPackage-([A-Za-z0-9]+)-");
    private static final Pattern R_TIME = Pattern.compile("شبانه|نیمه\\s?شب|بامداد|صبح|\\d\\s*(?:تا|الی)\\s*\\d");
    private static final Pattern R_APP = Pattern.compile("اپلیکیشن|اینستاگرام|تلگرام|واتس|یوتیوب|آپارات|بازی");
    private static final Pattern R_NET = Pattern.compile("رومینگ|بین\\s?الملل|داخلی|مخصوص");

    static Result extract(AccessibilityNodeInfo root, Op op, int screenH) {
        Result res = new Result();
        N tree = build(root, null, 0, new int[]{0});
        if (tree == null) return res;
        mark(tree);
        List<N> leaves = tree.lv;
        res.leaves = leaves.size();

        StringBuilder dump = new StringBuilder();
        int line = 0;
        for (N l : leaves) {
            double[] p = price(l.text);
            if (p != null) {
                l.price = true;
                l.amt = p[0];
                l.unit = (int) p[1];
            } else if (UNITONLY.matcher(Fmt.norm(l.text)).matches()) {
                l.unitOnly = true;
                l.unit = Fmt.norm(l.text).contains("ریال") ? 1 : 2;
            }
            if (line++ < 250) {
                dump.append(l.b.left).append(',').append(l.b.top).append(',').append(l.b.right).append(',')
                        .append(l.b.bottom).append('\t').append(l.id == null ? "" : l.id).append('\t')
                        .append(l.text).append('\n');
            }
        }

        // group leaves into cards: climb from each price leaf while the subtree still looks like one offer
        Set<N> cards = new LinkedHashSet<>();
        for (N pl : leaves) {
            if (!pl.price) continue;
            N node = pl, best = null;
            while (node != null) {
                int pc = 0;
                N first = null, second = null;
                for (N l : node.lv) {
                    if (l.price) {
                        pc++;
                        if (first == null) first = l;
                        else if (second == null) second = l;
                    }
                }
                if (pc > 2 || node.lv.size() > 16) break;
                if (pc == 2 && Math.hypot(first.cx() - second.cx(), first.cy() - second.cy()) > 0.06 * screenH) break;
                best = node;
                node = node.parent;
            }
            if (best != null) cards.add(best);
        }

        Map<String, Pkg> out = new LinkedHashMap<>();
        for (N card : cards) {
            Pkg p = make(card, op);
            if (p != null && !out.containsKey(p.key)) out.put(p.key, p);
        }

        // fallback: container nodes whose own text already holds the whole offer (e.g. price leaf scrolled off-screen)
        List<N> all = new ArrayList<>();
        flatten(tree, all);
        for (N x : all) {
            if (x.text == null || x.leaf || hasPrice(x)) continue;
            Pkg p = fromText(x, op);
            if (p != null && !out.containsKey(p.key)) out.put(p.key, p);
        }

        res.items.addAll(out.values());
        for (Pkg p : res.items) res.keys.add(p.key);
        res.dump = "pkg=" + root.getPackageName() + " leaves=" + res.leaves + " items=" + res.items.size() + "\n" + dump;
        return res;
    }

    private static N build(AccessibilityNodeInfo n, N parent, int d, int[] cnt) {
        if (n == null || d > 60 || cnt[0] > 4000 || !n.isVisibleToUser()) return null;
        cnt[0]++;
        N x = new N();
        x.parent = parent;
        n.getBoundsInScreen(x.b);
        CharSequence t = n.getText();
        if (t == null || t.length() == 0) t = n.getContentDescription();
        if (t != null) {
            String s = t.toString().replaceAll("[\\u200e\\u200f\\u202a-\\u202e\\u2066-\\u2069]", "")
                    .replace("\n", ", ").trim();
            if (!s.isEmpty()) x.text = s.length() > 300 ? s.substring(0, 300) : s;
        }
        String id = n.getViewIdResourceName();
        if (id != null) x.id = id.substring(id.indexOf('/') + 1);
        for (int i = 0; i < n.getChildCount(); i++) {
            N k = build(n.getChild(i), x, d + 1, cnt);
            if (k != null) x.kids.add(k);
        }
        return x;
    }

    private static boolean mark(N x) {
        boolean any = false;
        for (N k : x.kids) {
            if (mark(k)) any = true;
            x.lv.addAll(k.lv);
        }
        if (x.text != null) {
            if (!any) {
                x.leaf = true;
                x.lv.add(x);
            }
            return true;
        }
        return any;
    }

    private static void flatten(N x, List<N> out) {
        out.add(x);
        for (N k : x.kids) flatten(k, out);
    }

    private static boolean hasPrice(N x) {
        for (N l : x.lv) if (l.price) return true;
        return false;
    }

    /** returns {amount, unit} or null. unit: 0 none, 1 rial, 2 toman */
    private static double[] price(String t) {
        String s = Fmt.norm(t);
        if (s.contains("%") || s.contains("درصد")) return null;
        boolean hasUnit = UNIT.matcher(s).find();
        if (!hasUnit && (VOL.matcher(s).find() || DUR.matcher(s).find())) return null;
        Matcher m = PRICE.matcher(s);
        while (m.find()) {
            String num = m.group(1), mul = m.group(2), un = m.group(3);
            boolean sep = SEP.matcher(num).matches();
            boolean whole = s.trim().equals(m.group().trim());
            if (un == null && mul == null && !sep && !(whole && num.matches("\\d{4,}"))) continue;
            double v = sep ? Double.parseDouble(num.replace(",", "").replace(".", "")) : Double.parseDouble(num);
            if (mul != null) v *= mul.equals("میلیون") ? 1e6 : 1e3;
            if (v < 100) return null;
            int unit = un == null ? 0 : un.equals("ریال") ? 1 : 2;
            return new double[]{v, unit};
        }
        return null;
    }

    /** returns {firstGb, distinctCount} or null */
    private static double[] vol(String s) {
        Matcher m = VOL.matcher(Fmt.norm(s));
        double first = -1;
        Set<Double> seen = new HashSet<>();
        while (m.find()) {
            double n = Double.parseDouble(m.group(1));
            String u = m.group(2).toLowerCase(Locale.ROOT);
            double g = (u.startsWith("گیگ") || u.equals("gb")) ? n
                    : (u.startsWith("مگ") || u.equals("mb")) ? n / 1024.0 : n * 1024.0;
            if (first < 0) first = g;
            seen.add(g);
        }
        return first < 0 ? null : new double[]{first, seen.size()};
    }

    /** days, 0 if unknown */
    private static double dur(String s) {
        String n = Fmt.norm(s);
        Matcher m = DUR.matcher(n);
        if (m.find()) {
            double v = Double.parseDouble(m.group(1));
            String u = m.group(2);
            if (u.equals("روز")) return v;
            if (u.equals("هفته")) return v * 7;
            if (u.equals("ماه")) return v * 30;
            if (u.equals("سال")) return v * 365;
            return v / 24.0; // ساعت
        }
        Matcher w = DURW.matcher(n);
        if (w.find()) {
            String u = w.group(1);
            return u.equals("روزانه") ? 1 : u.equals("هفتگی") ? 7 : u.equals("ماهانه") ? 30 : 365;
        }
        return 0;
    }

    private static double toman(double amt, int unit, String cur) {
        if (unit == 1) return amt / 10.0;
        if (unit == 2) return amt;
        return "IRR".equals(cur) ? amt / 10.0 : amt;
    }

    private static String restr(String s) {
        String n = Fmt.norm(s);
        if (R_TIME.matcher(n).find()) return "ساعت خاص";
        if (R_APP.matcher(n).find()) return "ویژه‌ی اپلیکیشن";
        if (R_NET.matcher(n).find()) return "ترافیک خاص";
        return "";
    }

    private static String codeOf(N card) {
        for (N l : card.lv) {
            if (l.id == null) continue;
            Matcher m = CODE.matcher(l.id);
            if (m.find()) return m.group(1);
        }
        return "";
    }

    private static N nearest(N card, N anchor, boolean wantVol) {
        N best = null;
        double bd = Double.MAX_VALUE;
        for (N l : card.lv) {
            if (l.price || l.unitOnly) continue;
            boolean ok = wantVol ? vol(l.text) != null : dur(l.text) > 0;
            if (!ok) continue;
            double d = Math.hypot(l.cx() - anchor.cx(), l.cy() - anchor.cy());
            if (d < bd) {
                bd = d;
                best = l;
            }
        }
        return best;
    }

    private static Pkg make(N card, Op op) {
        N anchor = null;
        int cardUnit = 0;
        List<N> pls = new ArrayList<>();
        for (N l : card.lv) {
            if (l.price) {
                pls.add(l);
                if (anchor == null) anchor = l;
            } else if (l.unitOnly) {
                cardUnit = l.unit;
            }
        }
        if (anchor == null) return null;
        double tom = -1;
        for (N l : pls) {
            double t = toman(l.amt, l.unit != 0 ? l.unit : cardUnit, op.cur);
            if (tom < 0 || t < tom) tom = t;
        }
        N vl = nearest(card, anchor, true);
        if (vl == null) return null;
        double[] v = vol(vl.text);
        double days = dur(vl.text);
        if (days <= 0) {
            N dl = nearest(card, anchor, false);
            if (dl != null) days = dur(dl.text);
        }
        StringBuilder all = new StringBuilder();
        for (N l : card.lv) if (!l.price && !l.unitOnly) all.append(l.text).append(' ');
        String why = restr(all.toString());
        if (why.isEmpty() && v[1] > 1) why = "حجم ترکیبی";
        return mk(op, vl.text, v[0], days, Math.round(tom), why, codeOf(card));
    }

    private static Pkg fromText(N x, Op op) {
        String s = x.text;
        if (s.length() > 250 || x.lv.size() > 16) return null;
        double[] v = vol(s);
        if (v == null || v[1] > 1) return null;
        double[] pr = price(s);
        if (pr == null) return null;
        String n = Fmt.norm(s);
        int sepCount = 0;
        Matcher m = SEP.matcher(n);
        while (m.find()) sepCount++;
        if (sepCount > 2) return null;
        int unit = (int) pr[1];
        if (unit == 0) unit = n.contains("ریال") ? 1 : (n.contains("تومان") || n.contains("تومن")) ? 2 : 0;
        String title = null;
        for (N l : x.lv) {
            if (vol(l.text) != null) {
                title = l.text;
                break;
            }
        }
        if (title == null) title = s.split(", ")[0];
        double days = dur(title);
        if (days <= 0) days = dur(s);
        double[] tv = vol(title);
        if (tv == null) return null;
        long tom = Math.round(toman(pr[0], unit, op.cur));
        return mk(op, title, tv[0], days, tom, restr(s), codeOf(x));
    }

    private static Pkg mk(Op op, String title, double gb, double days, long toman, String why, String code) {
        if (gb < 0.05 || gb > 5000 || toman < 1000 || toman > 2000000000L) return null;
        Pkg p = new Pkg();
        p.op = op.id;
        p.title = title;
        p.gb = gb;
        p.days = days > 1000 ? 0 : days;
        p.toman = toman;
        p.why = why;
        p.restricted = !why.isEmpty();
        p.code = code;
        p.key = op.id + "|" + (code.isEmpty() ? Fmt.norm(title).replace(" ", "") : code);
        return p;
    }
}
