package app.bastehyab;

import android.graphics.Rect;
import android.view.accessibility.AccessibilityNodeInfo;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Turns an accessibility tree into package offers (price / volume / duration), operator-agnostic. */
final class Extractor {
    static final class N {
        N parent;
        final List<N> kids = new ArrayList<>();
        String text, id;
        final Rect b = new Rect();
        List<N> lv = new ArrayList<>(); // text leaves in subtree
        boolean leaf, price, unitOnly, isVol;
        double amt, mul;
        int unit, pc, vc; // unit: 0 none, 1 rial, 2 toman; pc/vc: price / volume leaves below

        int cx() { return b.centerX(); }
        int cy() { return b.centerY(); }
    }

    static final class Result {
        final List<Pkg> items = new ArrayList<>();
        final Set<String> keys = new HashSet<>();
        String dump = "";
        int leaves;
    }

    private static final class Cand {
        N leaf;
        long toman;
        int kind; // 0 normal, 1 unit price (monthly / per GB ...), 2 old price, 3 discount / credit amount, 4 labelled "price"
    }

    private static final class Pick {
        long toman;
        long[] alts = new long[0];
        String note = "";
        boolean ambig;
    }

    private static final int F = Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE;
    private static final Pattern VOL = Pattern.compile(
            "(\\d+(?:\\.\\d+)?)\\s*(گیگابایت|گیگا|گیگ|مگابایت|مگا|مگ|ترابایت|ترا|gb|mb|tb)", F);
    private static final Pattern DUR = Pattern.compile("(\\d+(?:\\.\\d+)?)\\s*(روز|ماه|هفته|ساعت|سال)");
    private static final Pattern DURN = Pattern.compile(
            "(یک|دو|سه|چهار|پنج|شش|هفت|هشت|نه|ده|دوازده|پانزده|بیست|سی|شصت|نود)\\s*(روزه|ماهه|هفته|ساله)");
    private static final Pattern DURW = Pattern.compile("(روزانه|هفتگی|ماهانه|سالانه)");
    private static final Pattern UNIT = Pattern.compile("تومان|تومن|ریال");
    private static final Pattern UNITONLY = Pattern.compile("^\\s*(میلیون|هزار)?\\s*(تومان|تومن|ریال)\\s*$");
    private static final Pattern NUMONLY = Pattern.compile("^\\d{1,4}(?:\\.\\d+)?$");
    private static final Pattern PRICE = Pattern.compile(
            "(\\d{1,3}(?:[,.]\\d{3})+|\\d+(?:\\.\\d+)?)(?:\\s*(میلیون|هزار))?\\s*(تومان|تومن|ریال)?");
    private static final Pattern SEP = Pattern.compile("\\d{1,3}(?:[,.]\\d{3})+");
    private static final Pattern CODE = Pattern.compile("offerPackage-([A-Za-z0-9]+)-");
    private static final Pattern R_TIME = Pattern.compile("شبانه|نیمه\\s?شب|بامداد|صبح|ظهر|\\d\\s*(?:تا|الی)\\s*\\d");
    private static final Pattern R_USER = Pattern.compile("مشترکین جدید|مشترک جدید|ثبت ?نام|ویژه مشترک|اولین خرید|دعوت");
    private static final Pattern R_NAT = Pattern.compile("آی ?نو|اینترنت ملی|ایرانی");
    private static final Pattern R_BUNDLE = Pattern.compile("پیامک|مکالمه|دقیقه");
    private static final Pattern R_SUB = Pattern.compile("اشتراک|سرویس دیجیتال|هدیه");
    private static final Pattern R_UNL = Pattern.compile("نامحدود|مصرف منصفانه");
    private static final Pattern R_APP = Pattern.compile("اپلیکیشن|اینستاگرام|تلگرام|واتس|یوتیوب|آپارات|بازی");
    private static final Pattern R_NET = Pattern.compile("رومینگ|بین\\s?الملل|داخلی|مخصوص");
    // labels around a price leaf
    private static final Pattern K_OLD = Pattern.compile("قبل از|پیش از|قیمت اصلی|قیمت پایه|بدون تخفیف|قیمت قبلی|قبلی");
    private static final Pattern K_UNIT = Pattern.compile(
            "ماهانه|ماهیانه|هر ?ماه|در ?ماه|ماهی|/ ?ماه|هر ?گیگ|به ?ازای|روزانه|هر ?روز|در ?روز|هفتگی|هر ?هفته|قسط|اقساط");
    private static final Pattern K_MAIN = Pattern.compile(
            "قیمت|مبلغ|با تخفیف|پس از تخفیف|نهایی|قابل ?پرداخت|با مالیات|شامل مالیات");
    private static final Pattern K_DISC = Pattern.compile(
            "تخفیف|هدیه|اعتبار هدیه|پاداش|جایزه|کش ?بک|بازگشت|مالیات|ارزش ?افزوده|صرفه ?جویی");

    static Result extract(AccessibilityNodeInfo root, Op op, int screenH) {
        Result res = new Result();
        N tree = build(root, null, 0, new int[]{0});
        if (tree == null) return res;
        mark(tree);
        List<N> leaves = tree.lv;
        res.leaves = leaves.size();

        StringBuilder dump = new StringBuilder();
        int line = 0;
        for (N l : leaves) {
            double[] p = price(l.text);
            if (p != null) {
                l.price = true;
                l.amt = p[0];
                l.unit = (int) p[1];
            } else {
                Matcher um = UNITONLY.matcher(Fmt.norm(l.text));
                if (um.matches()) {
                    l.unitOnly = true;
                    String mu = um.group(1);
                    l.mul = mu == null ? 0 : mu.equals("میلیون") ? 1e6 : 1e3;
                    l.unit = um.group(2).equals("ریال") ? 1 : 2;
                }
            }
            if (line++ < 250) {
                dump.append(l.b.left).append(',').append(l.b.top).append(',').append(l.b.right).append(',')
                        .append(l.b.bottom).append('\t').append(l.id == null ? "" : l.id).append('\t')
                        .append(l.text.replaceAll("[0-9\u06f0-\u06f9\u0660-\u0669]{10,}", "•••")).append('\n');
            }
        }
        // "120" + "هزار تومان" written as two separate leaves
        for (int i = 0; i < leaves.size(); i++) {
            N l = leaves.get(i);
            if (!l.unitOnly || l.mul == 0) continue;
            for (int d = -1; d <= 1; d += 2) {
                int j = i + d;
                if (j < 0 || j >= leaves.size()) continue;
                N o = leaves.get(j);
                if (o.price || o.unitOnly) continue;
                String n = Fmt.norm(o.text).trim();
                if (NUMONLY.matcher(n).matches()) {
                    o.price = true;
                    o.amt = Double.parseDouble(n) * l.mul;
                    o.unit = l.unit;
                    break;
                }
            }
        }
        for (N l : leaves) l.isVol = !l.price && !l.unitOnly && vol(l.text) != null;
        count(tree);

        List<N> cards = new ArrayList<>();
        findCards(tree, cards, 0);

        StringBuilder log = new StringBuilder();
        Map<String, Pkg> out = new LinkedHashMap<>();
        for (N card : cards) {
            Pkg p = make(card, op, log);
            if (p != null && !out.containsKey(p.key)) out.put(p.key, p);
        }

        // fallback: container nodes whose own text already holds the whole offer (price leaf scrolled off-screen)
        List<N> all = new ArrayList<>();
        flatten(tree, all);
        for (N x : all) {
            if (x.text == null || x.leaf || x.pc > 0) continue;
            Pkg p = fromText(x, op);
            if (p != null && !out.containsKey(p.key)) out.put(p.key, p);
        }

        res.items.addAll(out.values());
        for (Pkg p : res.items) res.keys.add(p.key);
        res.dump = "pkg=" + root.getPackageName() + " leaves=" + res.leaves + " cards=" + cards.size()
                + " items=" + res.items.size() + "\n" + log + "--- leaves ---\n" + dump;
        return res;
    }

    // ---------------------------------------------------------------- tree

    private static N build(AccessibilityNodeInfo n, N parent, int d, int[] cnt) {
        if (n == null || d > 60 || cnt[0] > 4000 || !n.isVisibleToUser()) return null;
        cnt[0]++;
        N x = new N();
        x.parent = parent;
        n.getBoundsInScreen(x.b);
        CharSequence t = n.getText();
        if (t == null || t.length() == 0) t = n.getContentDescription();
        if (t != null) {
            String s = t.toString().replaceAll("[\\u200e\\u200f\\u202a-\\u202e\\u2066-\\u2069]", "")
                    .replace("\n", ", ").trim();
            if (!s.isEmpty()) x.text = s.length() > 300 ? s.substring(0, 300) : s;
        }
        String id = n.getViewIdResourceName();
        if (id != null) x.id = id.substring(id.indexOf('/') + 1);
        for (int i = 0; i < n.getChildCount(); i++) {
            N k = build(n.getChild(i), x, d + 1, cnt);
            if (k != null) x.kids.add(k);
        }
        return x;
    }

    private static boolean mark(N x) {
        boolean any = false;
        for (N k : x.kids) {
            if (mark(k)) any = true;
            x.lv.addAll(k.lv);
        }
        if (x.text != null) {
            if (!any) {
                x.leaf = true;
                x.lv.add(x);
            }
            return true;
        }
        return any;
    }

    private static void count(N x) {
        x.pc = 0;
        x.vc = 0;
        if (x.leaf) {
            if (x.price) x.pc = 1;
            if (x.isVol) x.vc = 1;
        }
        for (N k : x.kids) {
            count(k);
            x.pc += k.pc;
            x.vc += k.vc;
        }
    }

    private static void flatten(N x, List<N> out) {
        out.add(x);
        for (N k : x.kids) flatten(k, out);
    }

    /** Cards = repeating sibling branches that each hold a price and a volume (works whatever the number of prices per card). */
    private static void findCards(N x, List<N> out, int depth) {
        if (depth > 70) return;
        List<N> ks = new ArrayList<>();
        for (N k : x.kids) if (k.pc > 0 && k.vc > 0) ks.add(k);
        if (ks.size() >= 2) {
            for (N k : ks) {
                int n = 0;
                for (N g : k.kids) if (g.pc > 0 && g.vc > 0) n++;
                if (n >= 2) findCards(k, out, depth + 1);
                else out.add(k);
            }
        } else if (ks.size() == 1) {
            findCards(ks.get(0), out, depth + 1);
        } else if (x.pc > 0 && x.vc > 0) {
            out.add(x);
        }
    }

    // ---------------------------------------------------------------- parsing

    /** returns {amount, unit} or null. unit: 0 none, 1 rial, 2 toman */
    private static double[] price(String t) {
        String s = Fmt.norm(t);
        if (s.contains("%") || s.contains("درصد")) return null;
        boolean hasUnit = UNIT.matcher(s).find();
        if (!hasUnit && (VOL.matcher(s).find() || DUR.matcher(s).find())) return null;
        Matcher m = PRICE.matcher(s);
        while (m.find()) {
            String num = m.group(1), mul = m.group(2), un = m.group(3);
            boolean sep = SEP.matcher(num).matches();
            boolean whole = s.trim().equals(m.group().trim());
            if (un == null && mul == null && !sep && !(whole && num.matches("\\d{4,}"))) continue;
            double v = sep ? Double.parseDouble(num.replace(",", "").replace(".", "")) : Double.parseDouble(num);
            if (mul != null) v *= mul.equals("میلیون") ? 1e6 : 1e3;
            if (v < 100) return null;
            int unit = un == null ? 0 : un.equals("ریال") ? 1 : 2;
            return new double[]{v, unit};
        }
        return null;
    }

    /** returns {firstGb, distinctCount} or null */
    private static double[] vol(String s) {
        Matcher m = VOL.matcher(Fmt.norm(s));
        double first = -1;
        Set<Double> seen = new HashSet<>();
        while (m.find()) {
            double n = Double.parseDouble(m.group(1));
            String u = m.group(2).toLowerCase(Locale.ROOT);
            double g = (u.startsWith("گیگ") || u.equals("gb")) ? n
                    : (u.startsWith("مگ") || u.equals("mb")) ? n / 1024.0 : n * 1024.0;
            if (first < 0) first = g;
            seen.add(g);
        }
        return first < 0 ? null : new double[]{first, seen.size()};
    }

    private static double word(String w) {
        switch (w) {
            case "یک": return 1;
            case "دو": return 2;
            case "سه": return 3;
            case "چهار": return 4;
            case "پنج": return 5;
            case "شش": return 6;
            case "هفت": return 7;
            case "هشت": return 8;
            case "نه": return 9;
            case "ده": return 10;
            case "پانزده": return 15;
            case "بیست": return 20;
            case "سی": return 30;
            case "شصت": return 60;
            case "نود": return 90;
            default: return 12;
        }
    }

    /** days, 0 if unknown */
    private static double dur(String s) {
        String n = Fmt.norm(s);
        Matcher m = DUR.matcher(n);
        if (m.find()) {
            double v = Double.parseDouble(m.group(1));
            String u = m.group(2);
            if (u.equals("روز")) return v;
            if (u.equals("هفته")) return v * 7;
            if (u.equals("ماه")) return v * 30;
            if (u.equals("سال")) return v * 365;
            return v / 24.0; // ساعت
        }
        Matcher w = DURN.matcher(n);
        if (w.find()) {
            double v = word(w.group(1));
            String u = w.group(2);
            return u.startsWith("روز") ? v : u.startsWith("هفته") ? v * 7 : u.startsWith("ماه") ? v * 30 : v * 365;
        }
        Matcher x = DURW.matcher(n);
        if (x.find()) {
            String u = x.group(1);
            return u.equals("روزانه") ? 1 : u.equals("هفتگی") ? 7 : u.equals("ماهانه") ? 30 : 365;
        }
        return 0;
    }

    private static double toman(double amt, int unit, String cur) {
        if (unit == 1) return amt / 10.0;
        if (unit == 2) return amt;
        return "IRR".equals(cur) ? amt / 10.0 : amt;
    }

    static String restr(String s) {
        String n = Fmt.norm(s);
        if (R_TIME.matcher(n).find()) return "ساعت خاص";
        if (R_USER.matcher(n).find()) return "ویژه‌ی مشترکین خاص";
        if (R_NAT.matcher(n).find()) return "ترافیک ملی";
        if (R_BUNDLE.matcher(n).find()) return "بسته‌ی ترکیبی";
        if (R_SUB.matcher(n).find()) return "همراه با اشتراک/هدیه";
        if (R_UNL.matcher(n).find()) return "نامحدود (حد منصفانه)";
        if (R_APP.matcher(n).find()) return "ویژه‌ی اپلیکیشن";
        if (R_NET.matcher(n).find()) return "ترافیک خاص";
        return "";
    }

    private static String codeOf(N card) {
        for (N l : card.lv) {
            if (l.id == null) continue;
            Matcher m = CODE.matcher(l.id);
            if (m.find()) return m.group(1);
        }
        return "";
    }

    // ---------------------------------------------------------------- price choice

    private static String near(List<N> lv, int i, int d) {
        for (int j = i + d; j >= 0 && j < lv.size(); j += d) {
            N o = lv.get(j);
            if (o.price || o.unitOnly) continue;
            String t = Fmt.norm(o.text);
            return t.length() <= 18 ? t : "";
        }
        return "";
    }

    private static int kind(List<N> lv, N leaf) {
        int i = lv.indexOf(leaf);
        String ctx = (Fmt.norm(leaf.text) + " " + near(lv, i, -1) + " " + near(lv, i, 1))
                .replace("پرداخت مستقیم", " ").replace("از اعتبار", " ").replace("خرید", " ");
        if (K_OLD.matcher(ctx).find()) return 2;
        if (K_UNIT.matcher(ctx).find()) return 1;
        if (K_MAIN.matcher(ctx).find()) return 4;
        if (K_DISC.matcher(ctx).find()) return 3;
        return 0;
    }

    /** is `small` just `large` split per month / week / day / GB ? */
    private static boolean explains(long small, long large, double gb, double days) {
        if (small <= 0) return false;
        double r = (double) large / small;
        double[] ds = {days / 30.0, days / 7.0, days, gb};
        for (double d : ds) if (d >= 1.8 && Math.abs(r - d) / d <= 0.07) return true;
        return false;
    }

    private static String kindName(int k) {
        switch (k) {
            case 1: return "مبلغ ماهانه/واحدی";
            case 2: return "قیمت قبلی";
            case 3: return "تخفیف/اعتبار";
            default: return "مبلغ دیگر";
        }
    }

    private static Pick pick(N card, List<N> pl, int cardUnit, Op op, double gb, double days) {
        List<Cand> cs = new ArrayList<>();
        boolean unitKnown = cardUnit != 0;
        for (N l : pl) {
            Cand c = new Cand();
            c.leaf = l;
            c.toman = Math.round(toman(l.amt, l.unit != 0 ? l.unit : cardUnit, op.cur));
            c.kind = kind(card.lv, l);
            if (l.unit != 0) unitKnown = true;
            cs.add(c);
        }
        Cand best = null;
        if (op.policy == 1 || op.policy == 2) {
            for (Cand c : cs) {
                if (best == null || (op.policy == 1 ? c.toman > best.toman : c.toman < best.toman)) best = c;
            }
        } else {
            List<Cand> f = new ArrayList<>();
            for (Cand c : cs) if (c.kind == 0 || c.kind == 4) f.add(c);
            if (f.isEmpty()) f.addAll(cs);
            if (f.size() > 1) {
                List<Cand> g = new ArrayList<>(f);
                for (Cand s : f) {
                    for (Cand big : f) if (big.toman > s.toman * 1.2 && explains(s.toman, big.toman, gb, days)) g.remove(s);
                }
                if (!g.isEmpty()) f = g;
            }
            if (f.size() > 1) {
                int maxH = 0;
                for (Cand c : f) maxH = Math.max(maxH, c.leaf.b.height());
                List<Cand> g = new ArrayList<>();
                for (Cand c : f) if (c.leaf.b.height() >= 0.88 * maxH) g.add(c);
                if (!g.isEmpty()) f = g;
            }
            if (f.size() > 1) {
                List<Cand> g = new ArrayList<>();
                for (Cand c : f) if (c.kind == 4) g.add(c);
                if (!g.isEmpty() && g.size() < f.size()) f = g;
            }
            for (Cand c : f) if (best == null || c.toman < best.toman) best = c;
        }
        Pick pk = new Pick();
        pk.toman = best.toman;
        Set<Long> distinct = new HashSet<>();
        for (Cand c : cs) distinct.add(c.toman);
        pk.alts = new long[distinct.size()];
        int i = 0;
        for (long v : distinct) pk.alts[i++] = v;
        // no currency word anywhere and an absurd price per GB: it was probably in rial
        if (!unitKnown && "AUTO".equals(op.cur) && gb > 0 && pk.toman / gb > 150000) {
            pk.toman = pk.toman / 10;
            for (int k = 0; k < pk.alts.length; k++) pk.alts[k] = pk.alts[k] / 10;
        }
        StringBuilder note = new StringBuilder();
        boolean other = false;
        for (Cand c : cs) {
            if (c.toman == best.toman) continue;
            other = true;
            String nm = explains(Math.min(c.toman, best.toman), Math.max(c.toman, best.toman), gb, days)
                    ? "مبلغ ماهانه/واحدی" : kindName(c.kind);
            if (note.length() > 0) note.append("، ");
            note.append(Fmt.num(c.toman)).append(" (").append(nm).append(')');
        }
        if (other) pk.note = "مبالغ دیگر در همین کارت: " + note;
        // ambiguous when the decision was not backed by a label / unit-price rule
        boolean unexplained = false;
        for (Cand c : cs) {
            if (c.toman != best.toman && c.kind == 0 && !explains(Math.min(c.toman, best.toman), Math.max(c.toman, best.toman), gb, days))
                unexplained = true;
        }
        pk.ambig = unexplained && op.policy == 0;
        return pk;
    }

    // ---------------------------------------------------------------- building packages

    private static N nearestDur(N card, N from) {
        N best = null;
        double bd = Double.MAX_VALUE;
        for (N l : card.lv) {
            if (l.price || l.unitOnly || dur(l.text) <= 0) continue;
            double d = Math.hypot(l.cx() - from.cx(), l.cy() - from.cy());
            if (d < bd) {
                bd = d;
                best = l;
            }
        }
        return best;
    }

    private static String rawOf(N card) {
        StringBuilder sb = new StringBuilder();
        for (N l : card.lv) {
            if (sb.length() > 0) sb.append(" | ");
            sb.append(l.text);
            if (sb.length() > 420) break;
        }
        return sb.length() > 420 ? sb.substring(0, 420) : sb.toString();
    }

    private static Pkg make(N card, Op op, StringBuilder log) {
        List<N> pl = new ArrayList<>();
        int cardUnit = 0;
        for (N l : card.lv) {
            if (l.price) pl.add(l);
            else if (l.unitOnly) cardUnit = l.unit;
        }
        if (pl.isEmpty()) return null;
        N tl = null;
        boolean tlDur = false;
        for (N l : card.lv) {
            if (!l.isVol) continue;
            boolean d = dur(l.text) > 0;
            if (tl == null || (d && !tlDur)) {
                tl = l;
                tlDur = d;
            }
        }
        if (tl == null) return null;
        double[] v = vol(tl.text);
        double days = dur(tl.text);
        if (days <= 0) {
            N dl = nearestDur(card, tl);
            if (dl != null) days = dur(dl.text);
        }
        Pick pk = pick(card, pl, cardUnit, op, v[0], days);
        StringBuilder all = new StringBuilder();
        for (N l : card.lv) if (!l.price && !l.unitOnly) all.append(l.text).append(' ');
        String why = restr(all.toString());
        if (why.isEmpty() && v[1] > 1) why = "حجم ترکیبی";
        String raw = rawOf(card);
        log.append("CARD ").append(tl.text).append(" -> ").append(pk.toman).append(" alts=");
        for (long a : pk.alts) log.append(a).append(' ');
        log.append("\n   raw: ").append(raw).append('\n');
        return mk(op, tl.text, v[0], days, pk.toman, why, codeOf(card), pk, raw);
    }

    private static Pkg fromText(N x, Op op) {
        String s = x.text;
        if (s.length() > 250 || x.lv.size() > 16) return null;
        double[] v = vol(s);
        if (v == null || v[1] > 1) return null;
        double[] pr = price(s);
        if (pr == null) return null;
        String n = Fmt.norm(s);
        int sepCount = 0;
        Matcher m = SEP.matcher(n);
        while (m.find()) sepCount++;
        if (sepCount > 2) return null;
        int unit = (int) pr[1];
        if (unit == 0) unit = n.contains("ریال") ? 1 : (n.contains("تومان") || n.contains("تومن")) ? 2 : 0;
        String title = null;
        for (N l : x.lv) {
            if (vol(l.text) != null) {
                title = l.text;
                break;
            }
        }
        if (title == null) title = s.split(", ")[0];
        double days = dur(title);
        if (days <= 0) days = dur(s);
        double[] tv = vol(title);
        if (tv == null) return null;
        long tom = Math.round(toman(pr[0], unit, op.cur));
        return mk(op, title, tv[0], days, tom, restr(s), codeOf(x), null, s);
    }

    private static Pkg mk(Op op, String title, double gb, double days, long toman, String why, String code, Pick pk, String raw) {
        if (gb < 0.05 || gb > 5000 || toman < 1000 || toman > 2000000000L) return null;
        Pkg p = new Pkg();
        p.op = op.id;
        p.title = title;
        p.gb = gb;
        p.days = days > 1000 ? 0 : days;
        p.toman = toman;
        p.why = why;
        p.restricted = !why.isEmpty();
        p.code = code;
        p.raw = raw;
        if (pk != null) {
            p.note = pk.note;
            p.ambig = pk.ambig;
            p.alts = pk.alts;
        } else {
            p.alts = new long[]{toman};
        }
        p.key = op.id + "|" + (code.isEmpty() ? Fmt.norm(title).replace(" ", "") : code);
        return p;
    }
}
