package app.bastehyab;

import android.content.Context;
import android.graphics.PixelFormat;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.HashSet;
import java.util.Set;

/** Floating comparison card drawn as an accessibility overlay (no extra permission needed). */
final class Popup {
    private final Context c;
    private final WindowManager wm;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final Runnable autoHide = this::hide;
    private LinearLayout root;
    private WindowManager.LayoutParams lp;
    private boolean attached, compact;
    private Runnable onClose;
    private Compare.Result last;
    private Set<String> screen;
    private String lastSig = "";

    Popup(Context c) {
        this.c = c;
        wm = (WindowManager) c.getSystemService(Context.WINDOW_SERVICE);
    }

    void onClose(Runnable r) { onClose = r; }

    void show(Compare.Result r, Set<String> onScreen) {
        last = r;
        screen = onScreen;
        String sig = sig(r);
        boolean changed = !attached || !sig.equals(lastSig);
        try {
            if (root == null) root = new LinearLayout(c);
            if (changed) {
                render();
                lastSig = sig;
            }
            if (!attached) {
                makeParams();
                wm.addView(root, lp);
                attached = true;
            } else if (changed) {
                wm.updateViewLayout(root, lp);
            }
        } catch (Exception e) {
            attached = false;
            root = null;
            lastSig = "";
        }
        h.removeCallbacks(autoHide);
        int s = Cfg.hideSec(c);
        if (s > 0) h.postDelayed(autoHide, s * 1000L);
    }

    void hide() {
        h.removeCallbacks(autoHide);
        if (attached && root != null) {
            try {
                wm.removeView(root);
            } catch (Exception ignored) {}
        }
        attached = false;
        lastSig = "";
    }

    private String sig(Compare.Result r) {
        StringBuilder b = new StringBuilder();
        b.append(Cfg.pmode(c)).append('|').append(Cfg.rows(c)).append('|').append(compact).append('|')
                .append(r.metric).append('|').append(r.bucket).append('|').append(r.ranked.size());
        int n = Math.min(12, r.ranked.size());
        for (int i = 0; i < n; i++) b.append(r.ranked.get(i).key).append(r.ranked.get(i).toman);
        for (Pkg p : r.screen) b.append('#').append(p.key).append(p.toman);
        for (Op o : Cfg.ops(c)) b.append(o.cmp ? '1' : '0');
        return b.toString();
    }

    private void makeParams() {
        DisplayMetrics dm = c.getResources().getDisplayMetrics();
        boolean bottom = Cfg.bottom(c);
        lp = new WindowManager.LayoutParams(
                dm.widthPixels - UI.dp(c, 20), WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        lp.gravity = (bottom ? Gravity.BOTTOM : Gravity.TOP) | Gravity.CENTER_HORIZONTAL;
        lp.y = UI.dp(c, bottom ? 90 : 48);
    }

    private TextView icon(String s) {
        TextView t = UI.tv(c, s, 16, UI.MUTED, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(UI.dp(c, 10), UI.dp(c, 4), UI.dp(c, 10), UI.dp(c, 4));
        return t;
    }

    private View ticks() {
        HorizontalScrollView hs = new HorizontalScrollView(c);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout r = UI.hbox(c);
        for (final Op o : Cfg.ops(c)) {
            TextView t = UI.tv(c, (o.cmp ? "✓ " : "") + o.name, 11, o.cmp ? 0xFF0B1220 : UI.TEXT, true);
            t.setPadding(UI.dp(c, 10), UI.dp(c, 4), UI.dp(c, 10), UI.dp(c, 4));
            t.setBackground(UI.rr(c, o.cmp ? o.color : UI.CARD2, 12));
            t.setOnClickListener(v -> {
                o.cmp = !o.cmp;
                Cfg.saveOps(c, Cfg.ops(c));
                last = Compare.run(c, screen);
                if (attached) render();
            });
            r.addView(t, UI.lp(c, -2, -2, 0, 0, 6, 0));
        }
        hs.addView(r);
        return hs;
    }

    private void render() {
        final Compare.Result r = last;
        int pad = UI.dp(c, 12);
        root.removeAllViews();
        root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setPadding(pad, pad, pad, pad);
        root.setBackground(UI.rr(c, 0xF2101828, 20, UI.STROKE));

        LinearLayout hd = UI.hbox(c);
        hd.addView(UI.tv(c, "⚡ مقایسه‌ی آنی", 15, UI.PRIMARY, true), UI.lpw(1f));
        TextView min = icon(compact ? "▴" : "▾");
        min.setOnClickListener(v -> {
            compact = !compact;
            lastSig = "";
            render();
        });
        TextView x = icon("✕");
        x.setOnClickListener(v -> {
            hide();
            if (onClose != null) onClose.run();
        });
        hd.addView(min);
        hd.addView(x);
        hd.setOnTouchListener(new View.OnTouchListener() {
            float sy;
            int oy;

            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        sy = e.getRawY();
                        oy = lp.y;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float d = e.getRawY() - sy;
                        boolean bottom = (lp.gravity & Gravity.BOTTOM) == Gravity.BOTTOM;
                        lp.y = oy + (int) (bottom ? -d : d);
                        try {
                            wm.updateViewLayout(root, lp);
                        } catch (Exception ignored) {}
                        return true;
                    default:
                        return false;
                }
            }
        });
        root.addView(hd);

        String sub = Fmt.fa(String.valueOf(r.ranked.size())) + " بسته از " + Fmt.fa(String.valueOf(r.ops))
                + " اپراتور • " + r.label + (r.bucket != 0 ? " • " + Compare.BUCKETS[r.bucket] : "");
        root.addView(UI.tv(c, sub, 11, UI.MUTED, false), UI.lp(c, -1, -2, 0, 0, 0, 6));
        if (!compact) root.addView(ticks(), UI.lp(c, -1, -2, 0, 0, 0, 6));

        int mode = Cfg.pmode(c);
        boolean showScreen = mode != 1, showAll = mode != 2;

        if (compact) {
            if (showAll && !r.ranked.isEmpty()) root.addView(mini("🏆 برترین کل", r, r.ranked.get(0)), UI.lp(c, -1, -2, 0, 3, 0, 3));
            if (showScreen && !r.screen.isEmpty()) root.addView(mini("✓ این صفحه", r, r.screen.get(0)), UI.lp(c, -1, -2, 0, 3, 0, 3));
            return;
        }

        Set<String> shown = new HashSet<>();
        if (showScreen && !r.screen.isEmpty()) {
            root.addView(UI.tv(c, "✓ بهترین‌های همین صفحه (از " + Fmt.fa(String.valueOf(r.screen.size())) + " بسته)", 11, UI.PRIMARY, true), UI.lp(c, -1, -2, 0, 4, 0, 2));
            int k = Math.min(3, r.screen.size());
            for (int i = 0; i < k; i++) {
                Pkg p = r.screen.get(i);
                shown.add(p.key);
                root.addView(row(r, p, i + 1, true), UI.lp(c, -1, -2, 0, 3, 0, 3));
            }
        }
        if (showAll && !r.ranked.isEmpty()) {
            root.addView(UI.tv(c, "🏆 برترین‌ها در همه‌ی اپراتورهای تیک‌خورده", 11, UI.ACCENT, true), UI.lp(c, -1, -2, 0, 6, 0, 2));
            int n = 0;
            for (Pkg p : r.ranked) {
                if (n >= Cfg.rows(c)) break;
                if (shown.contains(p.key)) continue;
                n++;
                root.addView(row(r, p, r.rank.get(p.key), false), UI.lp(c, -1, -2, 0, 3, 0, 3));
            }
        }

        String foot;
        if (r.ranked.isEmpty()) {
            foot = "هیچ اپراتوری تیک نخورده یا با فیلترهای شما بسته‌ای نمانده است.";
        } else if (r.screen.isEmpty() && screen != null && !screen.isEmpty()) {
            foot = "بسته‌های همین صفحه با فیلترها (حجم، مدت، ویژه‌ها) جور نیستند؛ بالا فقط برترین‌های اپراتورهای دیگر است.";
        } else if (r.ops < 2) {
            foot = "برای مقایسه‌ی بین اپراتورها، برنامه‌ی اپراتور دیگری را هم باز کنید.";
        } else if (r.bestScreen != null) {
            double best = r.val.get(r.ranked.get(0).key), mine = r.val.get(r.bestScreen.key);
            long pct = Math.round((mine - best) / best * 100);
            foot = r.rankScreen == 1 ? "🏆 بهترین بسته‌ی همین صفحه، برترین کل است."
                    : "بهترین بسته‌ی همین صفحه، رتبه‌ی " + Fmt.fa(String.valueOf(r.rankScreen)) + " کل است و "
                    + Fmt.fa(String.valueOf(pct)) + "٪ گران‌تر از برترین.";
        } else {
            foot = "برای دقت بیشتر، لیست بسته‌ها را تا آخر اسکرول کنید.";
        }
        root.addView(UI.tv(c, foot, 11, UI.MUTED, false), UI.lp(c, -1, -2, 0, 6, 0, 0));
    }

    private View mini(String label, Compare.Result r, Pkg p) {
        Op op = Cfg.opById(c, p.op);
        int col = op == null ? UI.MUTED : op.color;
        LinearLayout row = UI.hbox(c);
        int pd = UI.dp(c, 8);
        row.setPadding(pd, pd, pd, pd);
        row.setBackground(UI.rr(c, UI.CARD, 12, UI.STROKE));
        row.addView(UI.tv(c, label, 10, UI.MUTED, true));
        row.addView(UI.chip(c, op == null ? p.op : op.name, UI.tint(col), col), UI.lp(c, -2, -2, 6, 0, 0, 0));
        row.addView(UI.tv(c, p.label(), 13, UI.TEXT, true), UI.lp2(c, 8));
        row.addView(UI.tv(c, Fmt.num(Math.round(r.val.get(p.key))), 14, UI.PRIMARY, true));
        return row;
    }

    private View row(Compare.Result r, Pkg p, int badgeNo, boolean here) {
        Op op = Cfg.opById(c, p.op);
        int g = r.rank.get(p.key);
        LinearLayout row = UI.hbox(c);
        int pd = UI.dp(c, 8);
        row.setPadding(pd, pd, pd, pd);
        row.setBackground(UI.rr(c, g == 1 ? 0xFF16283A : UI.CARD, 12, here ? UI.PRIMARY : UI.STROKE));

        TextView badge = UI.tv(c, g == 1 ? "👑" : Fmt.fa(String.valueOf(badgeNo)), 12, g == 1 ? 0xFF0B1220 : UI.TEXT, true);
        badge.setGravity(Gravity.CENTER);
        badge.setBackground(UI.rr(c, g == 1 ? UI.ACCENT : UI.CARD2, 14));
        row.addView(badge, UI.lp(c, 28, 28, 0, 0, 8, 0));

        LinearLayout info = UI.vbox(c);
        LinearLayout l1 = UI.hbox(c);
        int col = op == null ? UI.MUTED : op.color;
        l1.addView(UI.chip(c, op == null ? p.op : op.name, UI.tint(col), col));
        if (p.restricted) l1.addView(UI.chip(c, "⚠ " + p.why, 0x33F5B84B, UI.ACCENT), UI.lp(c, -2, -2, 4, 0, 0, 0));
        if (p.ambig) l1.addView(UI.chip(c, "⚠ قیمت نامطمئن", 0x33FF6B6B, UI.DANGER), UI.lp(c, -2, -2, 4, 0, 0, 0));
        if (r.cheap.contains(p.key)) l1.addView(UI.chip(c, "⚠ خیلی ارزان؟", 0x33F5B84B, UI.ACCENT), UI.lp(c, -2, -2, 4, 0, 0, 0));
        info.addView(l1);
        info.addView(UI.tv(c, p.label(), 14, UI.TEXT, true), UI.lp(c, -2, -2, 0, 3, 0, 0));
        String line = Fmt.num(p.toman) + " تومان • " + (here
                ? "رتبه‌ی کل " + Fmt.fa(String.valueOf(g)) + " از " + Fmt.fa(String.valueOf(r.ranked.size()))
                : "در برنامه‌ی " + (op == null ? p.op : op.name) + " • " + Fmt.ago(p.ts));
        info.addView(UI.tv(c, line, 10, UI.MUTED, false));
        row.addView(info, UI.lpw(1f));

        LinearLayout m = UI.vbox(c);
        m.setGravity(Gravity.CENTER_HORIZONTAL);
        m.addView(UI.tv(c, Fmt.num(Math.round(r.val.get(p.key))), 15, g == 1 ? UI.PRIMARY : UI.TEXT, true));
        m.addView(UI.tv(c, r.unit, 9, UI.MUTED, false));
        row.addView(m);
        return row;
    }
}
