package app.bastehyab;

import org.json.JSONArray;
import org.json.JSONObject;

final class Pkg {
    String op, key, title, code = "", why = "";
    double gb, days;
    long toman, ts;
    boolean restricted, ambig;
    String note = "", raw = "";
    long[] alts = new long[0];

    double perGb() { return gb > 0 ? toman / gb : Double.MAX_VALUE; }

    double monthlyGb() { return days > 0 ? gb * 30.0 / days : 0; }

    double perGbMonth() { return days > 0 && gb > 0 ? toman / (gb * days / 30.0) : Double.MAX_VALUE; }

    double monthlyCost(double usage) {
        if (days <= 0 || gb <= 0) return Double.MAX_VALUE;
        double mg = monthlyGb();
        double n = usage <= mg ? 1 : Math.ceil(usage / mg);
        return n * toman * 30.0 / days;
    }

    String label() {
        return Fmt.dec(gb) + " گیگ" + (days > 0 ? " • " + Fmt.dec(days) + " روز" : "");
    }

    JSONObject json() throws Exception {
        JSONObject o = new JSONObject();
        o.put("op", op);
        o.put("key", key);
        o.put("title", title);
        o.put("code", code);
        o.put("why", why);
        o.put("gb", gb);
        o.put("days", days);
        o.put("toman", toman);
        o.put("ts", ts);
        o.put("r", restricted);
        o.put("am", ambig);
        o.put("note", note);
        o.put("raw", raw);
        JSONArray a = new JSONArray();
        for (long v : alts) a.put(v);
        o.put("alts", a);
        return o;
    }

    static Pkg from(JSONObject o) throws Exception {
        Pkg p = new Pkg();
        p.op = o.getString("op");
        p.key = o.getString("key");
        p.title = o.optString("title", "");
        p.code = o.optString("code", "");
        p.why = o.optString("why", "");
        p.gb = o.getDouble("gb");
        p.days = o.optDouble("days", 0);
        p.toman = o.getLong("toman");
        p.ts = o.optLong("ts", 0);
        p.restricted = o.optBoolean("r", false);
        p.ambig = o.optBoolean("am", false);
        p.note = o.optString("note", "");
        p.raw = o.optString("raw", "");
        JSONArray a = o.optJSONArray("alts");
        if (a != null) {
            p.alts = new long[a.length()];
            for (int i = 0; i < a.length(); i++) p.alts[i] = a.getLong(i);
        }
        return p;
    }
}
