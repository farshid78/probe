package app.bastehyab;

import org.json.JSONObject;

final class Pkg {
    String op, key, title, code = "", why = "";
    double gb, days;
    long toman, ts;
    boolean restricted;

    double perGb() { return gb > 0 ? toman / gb : Double.MAX_VALUE; }

    double monthlyGb() { return days > 0 ? gb * 30.0 / days : 0; }

    double perGbMonth() { return days > 0 && gb > 0 ? toman / (gb * days / 30.0) : Double.MAX_VALUE; }

    double monthlyCost(double usage) {
        if (days <= 0 || gb <= 0) return Double.MAX_VALUE;
        double mg = monthlyGb();
        double n = usage <= mg ? 1 : Math.ceil(usage / mg);
        return n * toman * 30.0 / days;
    }

    String label() {
        return Fmt.dec(gb) + " گیگ" + (days > 0 ? " • " + Fmt.dec(days) + " روز" : "");
    }

    JSONObject json() throws Exception {
        JSONObject o = new JSONObject();
        o.put("op", op);
        o.put("key", key);
        o.put("title", title);
        o.put("code", code);
        o.put("why", why);
        o.put("gb", gb);
        o.put("days", days);
        o.put("toman", toman);
        o.put("ts", ts);
        o.put("r", restricted);
        return o;
    }

    static Pkg from(JSONObject o) throws Exception {
        Pkg p = new Pkg();
        p.op = o.getString("op");
        p.key = o.getString("key");
        p.title = o.optString("title", "");
        p.code = o.optString("code", "");
        p.why = o.optString("why", "");
        p.gb = o.getDouble("gb");
        p.days = o.optDouble("days", 0);
        p.toman = o.getLong("toman");
        p.ts = o.optLong("ts", 0);
        p.restricted = o.optBoolean("r", false);
        return p;
    }
}
