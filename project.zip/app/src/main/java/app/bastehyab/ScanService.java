package app.bastehyab;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;
import android.widget.Toast;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

public class ScanService extends AccessibilityService {
    static volatile ScanService inst;

    private final Handler h = new Handler(Looper.getMainLooper());
    private final Runnable job = this::scan;
    private final Map<String, String> dumps = new HashMap<>();
    private Popup popup;
    private long pending, lastDiag;
    private int emptyStreak;
    private String fg = "", dismissed = "";

    @Override public void onInterrupt() {}

    @Override protected void onServiceConnected() {
        inst = this;
        popup = new Popup(this);
        popup.onClose(() -> dismissed = fg);
    }

    @Override public boolean onUnbind(Intent i) {
        inst = null;
        if (popup != null) popup.hide();
        return super.onUnbind(i);
    }

    private static boolean ignorable(String p) {
        String s = p.toLowerCase();
        return s.equals("com.android.systemui") || s.contains("inputmethod") || s.contains("keyboard") || s.contains("honeyboard");
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent e) {
        CharSequence cs = e.getPackageName();
        if (cs == null || popup == null) return;
        String p = cs.toString();
        if (p.equals(getPackageName())) return;
        if (e.getEventType() == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED && !ignorable(p) && !p.equals(fg)) {
            fg = p;
            if (!p.equals(dismissed)) dismissed = "";
            popup.hide();
            if (Cfg.opFor(this, p) == null) Cfg.addRecent(this, p);
        }
        Op op = Cfg.opFor(this, p);
        if (op == null || !op.enabled) return;
        long now = System.currentTimeMillis();
        if (pending == 0) pending = now;
        h.removeCallbacks(job);
        h.postDelayed(job, now - pending > 2500 ? 0 : 700);
    }

    private void scan() {
        pending = 0;
        List<AccessibilityNodeInfo> roots = new ArrayList<>();
        List<AccessibilityWindowInfo> ws = getWindows();
        if (ws != null) {
            for (AccessibilityWindowInfo w : ws) {
                if (w.getType() == AccessibilityWindowInfo.TYPE_APPLICATION) {
                    AccessibilityNodeInfo r = w.getRoot();
                    if (r != null) roots.add(r);
                }
            }
        }
        if (roots.isEmpty()) {
            AccessibilityNodeInfo r = getRootInActiveWindow();
            if (r != null) roots.add(r);
        }
        DisplayMetrics dm = getResources().getDisplayMetrics();
        for (AccessibilityNodeInfo r : roots) {
            String p = String.valueOf(r.getPackageName());
            Op op = Cfg.opFor(this, p);
            if (op == null || !op.enabled) continue;
            Extractor.Result res = Extractor.extract(r, op, dm.heightPixels);
            diag(p, res.dump);
            if (res.items.isEmpty()) {
                if (++emptyStreak >= 3) popup.hide();
                continue;
            }
            emptyStreak = 0;
            Store.upsert(this, res.items);
            Compare.Result cr = Compare.run(this, res.keys);
            if (!Cfg.popup(this) || p.equals(dismissed) || cr.ranked.isEmpty() || cr.ops < Cfg.minOps(this)) continue;
            popup.show(cr, res.keys);
        }
    }

    void showTest() {
        Compare.Result cr = Compare.run(this, new HashSet<String>());
        if (cr.ranked.isEmpty()) {
            Toast.makeText(this, "هنوز داده‌ای برای نمایش نیست", Toast.LENGTH_SHORT).show();
            return;
        }
        popup.show(cr, new HashSet<String>());
    }

    private void diag(String p, String dump) {
        dumps.put(p, dump);
        long now = System.currentTimeMillis();
        if (now - lastDiag < 3000) return;
        lastDiag = now;
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, String> en : dumps.entrySet()) sb.append("=== ").append(en.getValue()).append('\n');
        try (Writer w = new OutputStreamWriter(new FileOutputStream(new File(getFilesDir(), "diag.txt")), StandardCharsets.UTF_8)) {
            w.write(sb.toString());
        } catch (Exception ignored) {}
    }
}
