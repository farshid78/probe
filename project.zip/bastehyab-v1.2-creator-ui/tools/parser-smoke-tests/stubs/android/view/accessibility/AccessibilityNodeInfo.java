package android.view.accessibility;
import android.graphics.Rect;
import java.util.*;
public class AccessibilityNodeInfo {
 private String text, desc, id, pkg="test.operator"; private final List<AccessibilityNodeInfo> children=new ArrayList<>();
 private int top; private boolean visible=true, editable=false, password=false;
 public AccessibilityNodeInfo(String t,int y){text=t;top=y;}
 public AccessibilityNodeInfo add(AccessibilityNodeInfo n){children.add(n);return this;}
 public AccessibilityNodeInfo visible(boolean v){visible=v;return this;}
 public AccessibilityNodeInfo editable(boolean v){editable=v;return this;}
 public AccessibilityNodeInfo password(boolean v){password=v;return this;}
 public boolean isVisibleToUser(){return visible;} public boolean isEditable(){return editable;} public boolean isPassword(){return password;}
 public void getBoundsInScreen(Rect r){r.left=0;r.right=100;r.top=top;r.bottom=top+20;}
 public CharSequence getText(){return text;} public CharSequence getContentDescription(){return desc;}
 public String getViewIdResourceName(){return id;} public int getChildCount(){return children.size();}
 public AccessibilityNodeInfo getChild(int i){return children.get(i);} public CharSequence getPackageName(){return pkg;} public void recycle(){}
}
