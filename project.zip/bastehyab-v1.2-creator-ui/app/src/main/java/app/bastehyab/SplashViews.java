package app.bastehyab;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.view.View;

/** Custom drawing for the opening / creator screen. Purely visual; no touch handling. */
final class SplashViews {
    private SplashViews() { }

    static float dp(View v, float value) {
        return value * v.getResources().getDisplayMetrics().density;
    }

    /** Dark navy backdrop with a faint circuit grid and two soft light sources. */
    static final class Backdrop extends View {
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint node = new Paint(Paint.ANTI_ALIAS_FLAG);

        Backdrop(Context c) {
            super(c);
            line.setStyle(Paint.Style.STROKE);
            line.setStrokeWidth(dp(this, 1));
            line.setColor(0x1A22D3A5);
            node.setColor(0x5522D3A5);
        }

        @Override protected void onDraw(Canvas cv) {
            float w = getWidth(), h = getHeight();
            if (w <= 0 || h <= 0) return;
            fill.setShader(new LinearGradient(0, 0, w, h,
                    new int[]{0xFF060C18, 0xFF0A1830, 0xFF061224}, null, Shader.TileMode.CLAMP));
            cv.drawRect(0, 0, w, h, fill);

            fill.setShader(new RadialGradient(w * 0.88f, h * 0.10f, dp(this, 300),
                    new int[]{0x4022D3A5, 0x0022D3A5}, null, Shader.TileMode.CLAMP));
            cv.drawRect(0, 0, w, h, fill);
            fill.setShader(new RadialGradient(w * 0.08f, h * 0.92f, dp(this, 280),
                    new int[]{0x403B82F6, 0x003B82F6}, null, Shader.TileMode.CLAMP));
            cv.drawRect(0, 0, w, h, fill);

            float step = dp(this, 56);
            for (float x = step / 2; x < w; x += step) {
                for (float y = step / 2; y < h; y += step) {
                    int k = (int) ((x * 7 + y * 13) / step) % 5;
                    if (k == 0) cv.drawLine(x, y, x + step, y, line);
                    if (k == 1) cv.drawLine(x, y, x, y + step, line);
                    if (k <= 1) cv.drawCircle(x, y, dp(this, 1.6f), node);
                }
            }
        }
    }

    /** Hexagon ring with a gradient stroke, used behind the app logo. */
    static final class HexBadge extends View {
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);

        HexBadge(Context c) {
            super(c);
            stroke.setStyle(Paint.Style.STROKE);
            stroke.setStrokeWidth(dp(this, 2));
        }

        @Override protected void onDraw(Canvas cv) {
            float w = getWidth(), h = getHeight();
            float r = Math.min(w, h) / 2f - dp(this, 4);
            Path p = hex(w / 2f, h / 2f, r);
            fill.setShader(new LinearGradient(0, 0, w, h,
                    new int[]{0x3322D3A5, 0x203B82F6}, null, Shader.TileMode.CLAMP));
            cv.drawPath(p, fill);
            stroke.setShader(new LinearGradient(0, 0, w, h,
                    new int[]{0xFF22D3A5, 0xFF3B82F6}, null, Shader.TileMode.CLAMP));
            cv.drawPath(p, stroke);
        }

        static Path hex(float cx, float cy, float r) {
            Path p = new Path();
            for (int i = 0; i < 6; i++) {
                double a = Math.PI / 3 * i - Math.PI / 6;
                float x = (float) (cx + r * Math.cos(a));
                float y = (float) (cy + r * Math.sin(a));
                if (i == 0) p.moveTo(x, y); else p.lineTo(x, y);
            }
            p.close();
            return p;
        }
    }

    /** Accent circle with a paper-plane glyph (Telegram-style). */
    static final class PlaneIcon extends View {
        private final Paint circle = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint glyph = new Paint(Paint.ANTI_ALIAS_FLAG);

        PlaneIcon(Context c) {
            super(c);
            glyph.setColor(0xFF06241C);
        }

        @Override protected void onDraw(Canvas cv) {
            float w = getWidth(), h = getHeight();
            circle.setShader(new LinearGradient(0, 0, w, h,
                    new int[]{0xFF22D3A5, 0xFF3B82F6}, null, Shader.TileMode.CLAMP));
            cv.drawCircle(w / 2f, h / 2f, Math.min(w, h) / 2f, circle);
            Path p = new Path();
            p.moveTo(w * 0.24f, h * 0.48f);
            p.lineTo(w * 0.78f, h * 0.26f);
            p.lineTo(w * 0.62f, h * 0.76f);
            p.lineTo(w * 0.47f, h * 0.60f);
            p.close();
            cv.drawPath(p, glyph);
            Path fold = new Path();
            fold.moveTo(w * 0.47f, h * 0.60f);
            fold.lineTo(w * 0.78f, h * 0.26f);
            fold.lineTo(w * 0.50f, h * 0.66f);
            fold.close();
            cv.drawPath(fold, glyph);
        }
    }
}
