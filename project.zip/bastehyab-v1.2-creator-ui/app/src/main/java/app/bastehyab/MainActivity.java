package app.bastehyab;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.provider.Settings;
import android.text.Editable;
import android.text.InputType;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    interface IntCb { void on(int v); }
    interface StrCb { void on(String s); }
    interface W { void w(OutputStream o) throws Exception; }

    private static final int[] ICONS = {R.drawable.ic_home, R.drawable.ic_compare, R.drawable.ic_tune};
    private static final String[] NAMES = {"خانه", "مقایسه", "تنظیمات"};

    private FrameLayout body;
    private FrameLayout outer;
    private View splashView;
    private boolean splashShowing;
    private final Handler splashHandler = new Handler(Looper.getMainLooper());
    private LinearLayout nav;
    private ScrollView sv;
    private int tab;
    private final int[] scroll = new int[3];
    private String newName = "", newPkg = "";
    private int newCur;

    private int dp(float v) { return UI.dp(this, v); }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(UI.BG);
        getWindow().setNavigationBarColor(UI.CARD);
        LinearLayout root = UI.vbox(this);
        root.setBackgroundResource(R.drawable.bg_app);
        body = new FrameLayout(this);
        root.addView(body, new LinearLayout.LayoutParams(-1, 0, 1f));
        nav = UI.hbox(this);
        nav.setBackgroundColor(UI.CARD);
        nav.setPadding(0, dp(6), 0, dp(6));
        root.addView(nav, new LinearLayout.LayoutParams(-1, -2));
        outer = new FrameLayout(this);
        outer.addView(root, new FrameLayout.LayoutParams(-1, -1));
        setContentView(outer);
        if (b == null) showCreatorSplash();
    }

    private void showCreatorSplash() {
        splashShowing = true;

        // Scrollable shell keeps the creator card usable on compact screens and landscape.
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);
        scroll.setBackgroundResource(R.drawable.bg_app);

        FrameLayout center = new FrameLayout(this);
        center.setPadding(dp(18), dp(18), dp(18), dp(18));
        scroll.addView(center, new ScrollView.LayoutParams(-1, -1));

        LinearLayout panel = UI.vbox(this);
        panel.setGravity(Gravity.CENTER_HORIZONTAL);
        panel.setPadding(dp(24), dp(28), dp(24), dp(26));
        panel.setBackground(UI.grad(this, 0xF01B2B43, 0xF0123448, 26));
        panel.setElevation(dp(8));
        FrameLayout.LayoutParams cardParams = new FrameLayout.LayoutParams(-1, -2, Gravity.CENTER);
        center.addView(panel, cardParams);

        ImageView mark = new ImageView(this);
        mark.setImageResource(R.mipmap.ic_launcher);
        mark.setScaleType(ImageView.ScaleType.FIT_CENTER);
        mark.setElevation(dp(5));
        panel.addView(mark, new LinearLayout.LayoutParams(dp(88), dp(88)));

        TextView title = UI.tv(this, "بسته‌یاب", 29, 0xFFFFFFFF, true);
        title.setGravity(Gravity.CENTER);
        panel.addView(title, UI.lp(this, -1, -2, 0, 14, 0, 0));

        TextView subtitle = UI.tv(this, "مرکز هوشمند تحلیل و مقایسه‌ی بسته‌های اینترنت", 13, 0xFFCAD9E8, false);
        subtitle.setGravity(Gravity.CENTER);
        panel.addView(subtitle, UI.lp(this, -1, -2, 0, 5, 0, 18));

        View line = new View(this);
        line.setBackgroundColor(0x5579B8CC);
        panel.addView(line, new LinearLayout.LayoutParams(-1, dp(1)));

        TextView creator = UI.tv(this, "سازنده و برنامه‌نویسی‌شده توسط", 12, 0xFFB7C9D8, false);
        creator.setGravity(Gravity.CENTER);
        panel.addView(creator, UI.lp(this, -1, -2, 0, 16, 0, 3));

        TextView name = UI.tv(this, "فرشید نبی‌پور", 20, 0xFFFFFFFF, true);
        name.setGravity(Gravity.CENTER);
        panel.addView(name);

        TextView telegram = UI.tv(this, "t.me/Farshid_Np", 13, 0xFF5EEAD4, true);
        telegram.setGravity(Gravity.CENTER);
        telegram.setTextDirection(View.TEXT_DIRECTION_LTR);
        telegram.setPadding(dp(14), dp(9), dp(14), dp(9));
        telegram.setBackground(UI.rr(this, 0x2237E0C0, 14, 0x5546DCC1));
        telegram.setOnClickListener(v -> {
            try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/Farshid_Np"))); }
            catch (Exception e) { toast("امکان باز کردن تلگرام وجود ندارد"); }
        });
        panel.addView(telegram, UI.lp(this, -2, -2, 0, 10, 0, 16));

        TextView aboutTitle = UI.tv(this, "درباره‌ی برنامه", 13, UI.PRIMARY, true);
        aboutTitle.setGravity(Gravity.RIGHT);
        panel.addView(aboutTitle, UI.lp(this, -1, -2, 0, 0, 0, 5));

        TextView about = UI.tv(this,
                "بسته‌های اینترنت اپراتورها را از صفحه‌ی خرید شناسایی و یکپارچه می‌کند.\nبا مقایسه‌ی قیمت، حجم و اعتبار، انتخاب بسته‌ی اقتصادی‌تر را ساده‌تر می‌سازد.",
                12, 0xFFE1EDF5, false);
        about.setGravity(Gravity.RIGHT);
        about.setLineSpacing(dp(4), 1f);
        panel.addView(about, UI.lp(this, -1, -2, 0, 0, 0, 0));

        splashView = scroll;
        outer.addView(splashView, new FrameLayout.LayoutParams(-1, -1));
        splashView.setAlpha(1f);
        // Five seconds total, including a short fade-out at the end.
        splashHandler.postDelayed(() -> {
            if (splashView == null) return;
            View fading = splashView;
            fading.animate().alpha(0f).setDuration(350L).withEndAction(() -> {
                if (splashView == fading) {
                    outer.removeView(fading);
                    splashView = null;
                    splashShowing = false;
                    render();
                }
            }).start();
        }, 4650L);
    }

    @Override protected void onResume() {
        super.onResume();
        if (!splashShowing) render();
    }

    @Override protected void onDestroy() {
        splashHandler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }

    // ---------------------------------------------------------------- shell

    private void render() {
        if (sv != null) scroll[tab] = sv.getScrollY();
        body.removeAllViews();
        sv = new ScrollView(this);
        sv.setFillViewport(true);
        LinearLayout col = UI.vbox(this);
        col.setPadding(dp(16), dp(20), dp(16), dp(24));
        sv.addView(col, new FrameLayout.LayoutParams(-1, -2));
        body.addView(sv, new FrameLayout.LayoutParams(-1, -1));
        if (tab == 0) home(col);
        else if (tab == 1) compare(col);
        else settings(col);
        final int y = scroll[tab];
        sv.post(() -> sv.scrollTo(0, y));
        buildNav();
    }

    private void buildNav() {
        nav.removeAllViews();
        for (int i = 0; i < 3; i++) {
            final int idx = i;
            boolean on = i == tab;
            LinearLayout it = UI.vbox(this);
            it.setGravity(Gravity.CENTER);
            ImageView im = new ImageView(this);
            im.setImageResource(ICONS[i]);
            im.setColorFilter(on ? UI.PRIMARY : UI.MUTED);
            it.addView(im, new LinearLayout.LayoutParams(dp(24), dp(24)));
            it.addView(UI.tv(this, NAMES[i], 11, on ? UI.PRIMARY : UI.MUTED, on), UI.lp(this, -2, -2, 0, 2, 0, 0));
            it.setOnClickListener(v -> {
                scroll[tab] = sv.getScrollY();
                tab = idx;
                render();
            });
            nav.addView(it, new LinearLayout.LayoutParams(0, -2, 1f));
        }
    }

    private boolean serviceOn() {
        String en = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        return en != null && en.contains(getPackageName());
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }

    // ---------------------------------------------------------------- home

    private void home(LinearLayout col) {
        boolean on = serviceOn();
        LinearLayout hero = UI.vbox(this);
        hero.setPadding(dp(20), dp(20), dp(20), dp(20));
        hero.setBackground(UI.grad(this, 0xFF14B8A6, 0xFF2563EB, 22));
        hero.addView(UI.tv(this, "بسته‌یاب", 26, 0xFFFFFFFF, true));
        hero.addView(UI.tv(this, "مقایسه‌ی آنی بسته‌های اینترنت اپراتورها", 13, 0xCCFFFFFF, false), UI.lp(this, -2, -2, 0, 2, 0, 12));
        hero.addView(UI.chip(this, on ? "● سرویس فعال" : "● سرویس غیرفعال", on ? 0x3322D3A5 : 0x44FF6B6B, on ? 0xFFFFFFFF : 0xFFFFD6D6));
        col.addView(hero);

        if (!on) {
            LinearLayout c = UI.card(this);
            c.addView(UI.tv(this, "برای شروع، دسترسی را فعال کنید", 15, UI.TEXT, true));
            c.addView(UI.tv(this, "بسته‌یاب برای شناسایی و مقایسه بسته‌های اینترنتی، به اجازه خواندن محتوای قابل مشاهده صفحه برنامه اپراتور نیاز دارد. اطلاعات فقط برای تشخیص بسته‌ها روی همین گوشی پردازش می‌شوند؛ برنامه بدون اجازه شما خرید یا تغییری در اپراتور انجام نمی‌دهد و داده‌ای به سرور ارسال نمی‌کند.", 12, UI.MUTED, false), UI.lp(this, -1, -2, 0, 6, 0, 8));
            c.addView(UI.tv(this, "برای فعال‌سازی، تنظیمات دسترسی‌پذیری اندروید باز می‌شود و تأیید نهایی فقط توسط شما انجام می‌شود. اگر گزینه غیرفعال بود، محدودیت تنظیمات برنامه را از صفحه اطلاعات برنامه بررسی کنید.", 11, UI.MUTED, false), UI.lp(this, -1, -2, 0, 0, 0, 10));
            LinearLayout r = UI.hbox(this);
            r.addView(UI.btn(this, "فعال‌سازی دسترسی", UI.PRIMARY, 0xFF0B1220, v ->
                    new AlertDialog.Builder(this)
                            .setTitle("تأیید آگاهانه دسترسی")
                            .setMessage("با فعال‌کردن این سرویس، بسته‌یاب فقط محتوای قابل‌مشاهده صفحه‌های بسته اینترنت در برنامه‌های اپراتوری را که خودتان انتخاب کرده‌اید می‌خواند. فیلدهای قابل‌ویرایش و رمز عبور نادیده گرفته می‌شوند؛ متن خام صفحه ذخیره یا ارسال نمی‌شود و هیچ دکمه‌ای فشرده یا خریدی انجام نمی‌شود. ادامه می‌دهید؟")
                            .setNegativeButton("فعلاً نه", null)
                            .setPositiveButton("می‌پذیرم؛ تنظیمات را باز کن", (dialog, which) ->
                                    startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)))
                            .show()), UI.lpw(1f));
            r.addView(UI.btn(this, "اطلاعات برنامه", UI.CARD2, UI.TEXT,
                    v -> startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName())))),
                    UI.lp(this, -2, -2, 8, 0, 0, 0));
            c.addView(r);
            col.addView(c, UI.lp(this, -1, -2, 0, 12, 0, 0));
        }

        Compare.Result cr = Compare.run(this, new HashSet<String>());
        List<Op> ops = Cfg.ops(this);
        int active = 0;
        long latest = 0;
        for (Op o : ops) if (o.enabled) active++;
        for (Pkg p : Store.all(this)) if (p.ts > latest) latest = p.ts;

        LinearLayout st = UI.hbox(this);
        st.addView(stat(Fmt.fa(String.valueOf(active)), "اپراتور فعال"), UI.lpw(1f));
        st.addView(stat(Fmt.fa(String.valueOf(cr.ops)), "اپراتور دارای داده"), UI.lp2(this, 8));
        st.addView(stat(Fmt.fa(String.valueOf(cr.ranked.size())), "بسته‌ی قابل مقایسه"), UI.lp2(this, 8));
        col.addView(st, UI.lp(this, -1, -2, 0, 12, 0, 0));

        LinearLayout scanInfo = UI.card(this);
        scanInfo.addView(UI.tv(this, "وضعیت آخرین اسکن", 13, UI.TEXT, true));
        String scanAge = ScanService.lastCompletedScanAt > 0
                ? " • " + Fmt.ago(ScanService.lastCompletedScanAt) : "";
        scanInfo.addView(UI.tv(this, ScanService.lastScanStatus + scanAge, 12, UI.MUTED, false),
                UI.lp(this, -1, -2, 0, 4, 0, 0));
        if (ScanService.lastCompletedScanAt > 0) {
            scanInfo.addView(UI.tv(this, "زمان پردازش آخرین اسکن: "
                    + Fmt.fa(String.valueOf(ScanService.lastScanDurationMs)) + " میلی‌ثانیه",
                    10, UI.MUTED, false), UI.lp(this, -1, -2, 0, 3, 0, 0));
        }
        scanInfo.addView(UI.tv(this,
                "شناسایی‌شده: " + Fmt.fa(String.valueOf(ScanService.lastScannedPackages))
                        + "  • معتبر: " + Fmt.fa(String.valueOf(ScanService.lastValidPackages))
                        + "  • مشکوک: " + Fmt.fa(String.valueOf(ScanService.lastSuspiciousPackages))
                        + "  • تکراری: " + Fmt.fa(String.valueOf(ScanService.lastDuplicatePackages)),
                10, UI.MUTED, false), UI.lp(this, -1, -2, 0, 4, 0, 0));
        col.addView(scanInfo, UI.lp(this, -1, -2, 0, 10, 0, 0));

        LinearLayout best = UI.card(this);
        best.addView(UI.tv(this, "🏆 بهترین پیشنهاد فعلی", 13, UI.ACCENT, true));
        if (cr.ranked.isEmpty()) {
            best.addView(UI.tv(this, "هنوز بسته‌ای ثبت نشده. برنامه‌ی یک اپراتور را باز کنید و به صفحه‌ی «خرید بسته‌ی اینترنت» بروید؛ بقیه‌ی کار خودکار است.", 12, UI.MUTED, false), UI.lp(this, -1, -2, 0, 8, 0, 0));
        } else {
            Pkg p = cr.ranked.get(0);
            Op op = Cfg.opById(this, p.op);
            LinearLayout r = UI.hbox(this);
            LinearLayout info = UI.vbox(this);
            info.addView(UI.chip(this, op == null ? p.op : op.name, UI.tint(op == null ? UI.MUTED : op.color), op == null ? UI.MUTED : op.color));
            info.addView(UI.tv(this, p.label(), 18, UI.TEXT, true), UI.lp(this, -2, -2, 0, 6, 0, 0));
            info.addView(UI.tv(this, Fmt.num(p.toman) + " تومان", 12, UI.MUTED, false));
            r.addView(info, UI.lpw(1f));
            LinearLayout m = UI.vbox(this);
            m.setGravity(Gravity.CENTER_HORIZONTAL);
            m.addView(UI.tv(this, Fmt.num(Math.round(cr.val.get(p.key))), 22, UI.PRIMARY, true));
            m.addView(UI.tv(this, cr.unit, 10, UI.MUTED, false));
            r.addView(m);
            best.addView(r, UI.lp(this, -1, -2, 0, 8, 0, 0));
            double med = cr.median, v = cr.val.get(p.key);
            if (med > 0 && cr.ranked.size() > 2) {
                long pct = Math.round((med - v) / med * 100);
                if (pct >= 3)
                    best.addView(UI.chip(this, Fmt.fa(String.valueOf(pct)) + "٪ ارزان‌تر از بسته‌ی میانه", 0x3322D3A5, UI.PRIMARY), UI.lp(this, -2, -2, 0, 8, 0, 0));
            }
        }
        col.addView(best, UI.lp(this, -1, -2, 0, 12, 0, 0));

        LinearLayout oc = UI.card(this);
        oc.addView(UI.tv(this, "اپراتورها", 13, UI.MUTED, true));
        for (final Op o : ops) {
            int n = 0;
            long ts = 0;
            for (Pkg p : Store.all(this)) {
                if (p.op.equals(o.id)) {
                    n++;
                    if (p.ts > ts) ts = p.ts;
                }
            }
            LinearLayout r = UI.hbox(this);
            View dot = new View(this);
            dot.setBackground(UI.rr(this, o.color, 6));
            r.addView(dot, new LinearLayout.LayoutParams(dp(12), dp(12)));
            LinearLayout info = UI.vbox(this);
            info.addView(UI.tv(this, o.name + (o.enabled ? "" : " (خاموش)"), 14, o.enabled ? UI.TEXT : UI.MUTED, true));
            info.addView(UI.tv(this, n == 0 ? "هنوز داده‌ای نیست" : Fmt.fa(String.valueOf(n)) + " بسته • " + Fmt.ago(ts), 11, UI.MUTED, false));
            r.addView(info, UI.lp2(this, 10));
            r.addView(UI.btn(this, "باز کردن", UI.CARD2, UI.TEXT, v -> launch(o)));
            oc.addView(r, UI.lp(this, -1, -2, 0, 10, 0, 0));
        }
        col.addView(oc, UI.lp(this, -1, -2, 0, 12, 0, 0));

        LinearLayout g = UI.card(this);
        g.addView(UI.tv(this, "راهنمای سریع", 13, UI.MUTED, true));
        String[] steps = {
                "۱) برنامه‌ی اپراتور را باز کنید و به صفحه‌ی خرید بسته‌ی اینترنت بروید.",
                "۲) لیست را کمی اسکرول کنید تا همه‌ی بسته‌ها خوانده شوند.",
                "۳) به برنامه‌ی اپراتور بعدی بروید؛ کادر مقایسه خودکار باز می‌شود و عالی‌ترین بسته‌ها را نشان می‌دهد."};
        for (String s : steps) g.addView(UI.tv(this, s, 12, UI.TEXT, false), UI.lp(this, -1, -2, 0, 8, 0, 0));
        col.addView(g, UI.lp(this, -1, -2, 0, 12, 0, 0));
    }

    private View stat(String big, String small) {
        LinearLayout c = UI.vbox(this);
        c.setGravity(Gravity.CENTER);
        c.setPadding(dp(8), dp(14), dp(8), dp(14));
        c.setBackground(UI.rr(this, UI.CARD, 16, UI.STROKE));
        c.addView(UI.tv(this, big, 22, UI.PRIMARY, true));
        TextView t = UI.tv(this, small, 10, UI.MUTED, false);
        t.setGravity(Gravity.CENTER);
        c.addView(t);
        return c;
    }

    private void launch(Op o) {
        for (String p : o.pkgs) {
            Intent i = getPackageManager().getLaunchIntentForPackage(p);
            if (i != null) {
                startActivity(i);
                return;
            }
        }
        toast("برنامه‌ی " + o.name + " پیدا نشد؛ نام پکیج را در تنظیمات بررسی کنید.");
    }

    // ---------------------------------------------------------------- compare

    private void compare(LinearLayout col) {
        col.addView(UI.tv(this, "مقایسه‌ی بسته‌ها", 22, UI.TEXT, true));
        col.addView(UI.tv(this, "رتبه‌بندی زنده‌ی همه‌ی بسته‌هایی که تا الان خوانده شده", 12, UI.MUTED, false), UI.lp(this, -2, -2, 0, 2, 0, 12));

        chips(col, new String[]{"هر گیگ", "هر گیگ‌ماه", "مصرف من"}, Cfg.metric(this), i -> {
            Cfg.setInt(this, "metric", i);
            render();
        });
        col.addView(UI.tv(this, "مدت بسته (مقایسه‌ی هم‌رده)", 11, UI.MUTED, false), UI.lp(this, -1, -2, 0, 4, 0, 0));
        chips(col, Compare.BUCKETS, Cfg.bucket(this), i -> {
            Cfg.setInt(this, "bucket", i);
            render();
        });
        if (Cfg.metric(this) == Cfg.MY_USAGE) {
            stepRow(col, "مصرف ماهانه‌ی شما", null, (int) Cfg.usage(this), 5, 500, 5, " گیگ", v -> {
                Cfg.setFloat(this, "usage", v);
                render();
            });
        }

        col.addView(tickCard(), UI.lp(this, -1, -2, 0, 12, 0, 8));

        Compare.Result cr = Compare.run(this, new HashSet<String>());
        if (!cr.ambig.isEmpty()) col.addView(ambigCard(cr.ambig), UI.lp(this, -1, -2, 0, 0, 0, 8));
        if (cr.ranked.isEmpty()) {
            LinearLayout c = UI.card(this);
            c.addView(UI.tv(this, anyCmp() ? "بسته‌ای برای نمایش نیست" : "هیچ اپراتوری تیک نخورده", 14, UI.TEXT, true));
            c.addView(UI.tv(this, "برنامه‌ی اپراتور را باز کنید و صفحه‌ی بسته‌های اینترنت را ببینید. اگر داده دارید ولی چیزی نمی‌بینید، فیلترهای «تنظیمات ← مقایسه» (حداقل حجم، سقف مدت، بسته‌های ویژه) را بررسی کنید.", 12, UI.MUTED, false), UI.lp(this, -1, -2, 0, 6, 0, 0));
            col.addView(c);
            return;
        }
        int n = Math.min(60, cr.ranked.size());
        for (int i = 0; i < n; i++) col.addView(pkgRow(cr.ranked.get(i), i + 1, cr), UI.lp(this, -1, -2, 0, 4, 0, 4));
    }

    private View ambigCard(List<Pkg> list) {
        LinearLayout c = UI.card(this);
        c.setBackground(UI.rr(this, 0xFF2A1A22, 18, 0x66FF6B6B));
        c.addView(UI.tv(this, "⚠ " + Fmt.fa(String.valueOf(list.size())) + " بسته با قیمت نامطمئن (وارد رتبه‌بندی نشدند)", 13, UI.DANGER, true));
        c.addView(UI.tv(this, "روی هر بسته بزنید، مبلغ‌های دیده‌شده را ببینید و روش انتخاب قیمت را برای آن اپراتور اصلاح کنید.", 11, UI.MUTED, false), UI.lp(this, -1, -2, 0, 4, 0, 6));
        int n = Math.min(8, list.size());
        for (int i = 0; i < n; i++) {
            final Pkg p = list.get(i);
            Op op = Cfg.opById(this, p.op);
            LinearLayout r = UI.hbox(this);
            r.setPadding(0, dp(6), 0, dp(6));
            int col = op == null ? UI.MUTED : op.color;
            r.addView(UI.chip(this, op == null ? p.op : op.name, UI.tint(col), col));
            r.addView(UI.tv(this, p.label(), 13, UI.TEXT, true), UI.lp2(this, 8));
            r.addView(UI.tv(this, p.currencyKnown ? Fmt.num(p.toman) + " تومان" : "واحد پول نامشخص", 12, UI.MUTED, false));
            r.setOnClickListener(v4 -> showDetail(p));
            c.addView(r);
        }
        return c;
    }

    private boolean anyCmp() {
        for (Op o : Cfg.ops(this)) if (o.cmp) return true;
        return false;
    }

    private void setAllCmp(boolean on) {
        for (Op o : Cfg.ops(this)) o.cmp = on;
        Cfg.saveOps(this, Cfg.ops(this));
        render();
    }

    private View tickCard() {
        LinearLayout c = UI.card(this);
        List<Op> ops = Cfg.ops(this);
        int on = 0;
        StringBuilder names = new StringBuilder();
        for (Op o : ops) {
            if (o.cmp) {
                on++;
                if (names.length() > 0) names.append(" + ");
                names.append(o.name);
            }
        }
        LinearLayout hd = UI.hbox(this);
        hd.addView(UI.tv(this, "اپراتورهای مقایسه", 14, UI.TEXT, true), UI.lpw(1f));
        hd.addView(UI.btn(this, "همه", UI.CARD2, UI.TEXT, v -> setAllCmp(true)), UI.lp(this, -2, -2, 0, 0, 6, 0));
        hd.addView(UI.btn(this, "هیچ", UI.CARD2, UI.TEXT, v -> setAllCmp(false)));
        c.addView(hd);
        for (final Op o : ops) {
            int n = 0;
            long ts = 0;
            for (Pkg p : Store.all(this)) {
                if (p.op.equals(o.id)) {
                    n++;
                    if (p.ts > ts) ts = p.ts;
                }
            }
            LinearLayout r = UI.hbox(this);
            CheckBox cb = new CheckBox(this);
            cb.setChecked(o.cmp);
            cb.setButtonTintList(ColorStateList.valueOf(o.color));
            cb.setOnCheckedChangeListener((bv, ch) -> {
                o.cmp = ch;
                Cfg.saveOps(this, Cfg.ops(this));
                body.post(this::render);
            });
            r.addView(cb);
            LinearLayout t = UI.vbox(this);
            t.addView(UI.tv(this, o.name, 14, o.cmp ? UI.TEXT : UI.MUTED, true));
            t.addView(UI.tv(this, n == 0 ? "داده‌ای ندارد — برنامه‌اش را باز کنید" : Fmt.fa(String.valueOf(n)) + " بسته • " + Fmt.ago(ts), 11, UI.MUTED, false));
            r.addView(t, UI.lpw(1f));
            c.addView(r, UI.lp(this, -1, -2, 0, 8, 0, 0));
        }
        String sum = on == 0 ? "هیچ اپراتوری تیک نخورده"
                : on == ops.size() ? "قیمت همه‌ی اپراتورها جمع شد و با هم مقایسه می‌شود"
                : "مقایسه‌ی " + names;
        c.addView(UI.tv(this, sum, 12, UI.PRIMARY, true), UI.lp(this, -1, -2, 0, 10, 0, 0));
        return c;
    }

    private View pkgRow(Pkg p, int rank, Compare.Result cr) {
        Op op = Cfg.opById(this, p.op);
        LinearLayout row = UI.hbox(this);
        row.setPadding(dp(12), dp(12), dp(12), dp(12));
        row.setBackground(UI.rr(this, rank == 1 ? 0xFF16283A : UI.CARD, 16, rank == 1 ? UI.PRIMARY : UI.STROKE));

        TextView badge = UI.tv(this, rank == 1 ? "👑" : Fmt.fa(String.valueOf(rank)), 14, rank == 1 ? 0xFF0B1220 : UI.TEXT, true);
        badge.setGravity(Gravity.CENTER);
        badge.setBackground(UI.rr(this, rank == 1 ? UI.ACCENT : UI.CARD2, 16));
        row.addView(badge, UI.lp(this, 32, 32, 0, 0, 10, 0));

        LinearLayout info = UI.vbox(this);
        LinearLayout l1 = UI.hbox(this);
        int c = op == null ? UI.MUTED : op.color;
        l1.addView(UI.chip(this, op == null ? p.op : op.name, UI.tint(c), c));
        if (p.restricted) l1.addView(UI.chip(this, "⚠ " + p.why, 0x33F5B84B, UI.ACCENT), UI.lp(this, -2, -2, 6, 0, 0, 0));
        if (p.ambig) l1.addView(UI.chip(this, "⚠ قیمت نامطمئن", 0x33FF6B6B, UI.DANGER), UI.lp(this, -2, -2, 6, 0, 0, 0));
        if (cr.cheap.contains(p.key)) l1.addView(UI.chip(this, "⚠ خیلی ارزان؛ بررسی کنید", 0x33F5B84B, UI.ACCENT), UI.lp(this, -2, -2, 6, 0, 0, 0));
        info.addView(l1);
        info.addView(UI.tv(this, p.label(), 16, UI.TEXT, true), UI.lp(this, -2, -2, 0, 6, 0, 0));
        info.addView(UI.tv(this, (p.currencyKnown ? Fmt.num(p.toman) + " تومان" : "واحد پول نامشخص") + " • " + Fmt.ago(p.ts), 11, UI.MUTED, false), UI.lp(this, -2, -2, 0, 2, 0, 0));
        row.addView(info, UI.lpw(1f));

        double v = cr.val.get(p.key);
        LinearLayout m = UI.vbox(this);
        m.setGravity(Gravity.CENTER_HORIZONTAL);
        m.addView(UI.tv(this, Fmt.num(Math.round(v)), 17, rank == 1 ? UI.PRIMARY : UI.TEXT, true));
        m.addView(UI.tv(this, cr.unit, 9, UI.MUTED, false));
        if (cr.median > 0 && cr.ranked.size() > 2) {
            long pct = Math.round((cr.median - v) / cr.median * 100);
            if (pct >= 5) m.addView(UI.chip(this, Fmt.fa(String.valueOf(pct)) + "٪ ارزان‌تر", 0x3322D3A5, UI.PRIMARY), UI.lp(this, -2, -2, 0, 4, 0, 0));
            else if (pct <= -5) m.addView(UI.chip(this, Fmt.fa(String.valueOf(-pct)) + "٪ گران‌تر", 0x33FF6B6B, UI.DANGER), UI.lp(this, -2, -2, 0, 4, 0, 0));
        }
        row.addView(m);
        row.setOnClickListener(v2 -> showDetail(p));
        return row;
    }

    private void showDetail(final Pkg p) {
        final Op op = Cfg.opById(this, p.op);
        StringBuilder sb = new StringBuilder();
        sb.append("عنوان خوانده‌شده: ").append(p.title).append('\n');
        sb.append("حجم: ").append(Fmt.dec(p.gb)).append(" گیگ • مدت: ")
                .append(p.days > 0 ? Fmt.dec(p.days) + " روز" : "نامشخص").append('\n');
        if (p.currencyKnown) sb.append("قیمت در مقایسه: ").append(Fmt.num(p.toman)).append(" تومان\n");
        else sb.append("مبلغ خام: ").append(Fmt.num(p.toman)).append(" (واحد پول نامشخص؛ در رتبه‌بندی استفاده نمی‌شود)\n");
        if (!p.note.isEmpty()) sb.append(p.note).append('\n');
        if (p.alts.length > 1) {
            sb.append("همه‌ی مبلغ‌های دیده‌شده: ");
            for (int i = 0; i < p.alts.length; i++) sb.append(Fmt.num(p.alts[i])).append(i < p.alts.length - 1 ? "، " : "");
            sb.append('\n');
        }
        sb.append("\nبرای حفظ حریم خصوصی، متن خام صفحه ذخیره یا در جزئیات نمایش داده نمی‌شود.");
        LinearLayout box = UI.vbox(this);
        box.setPadding(dp(20), dp(8), dp(20), dp(8));
        ScrollView s = new ScrollView(this);
        s.addView(UI.tv(this, sb.toString(), 12, UI.TEXT, false));
        box.addView(s, new LinearLayout.LayoutParams(-1, dp(230)));
        String[] names = {"خودکار", "بزرگ‌ترین مبلغ کارت", "کوچک‌ترین مبلغ کارت"};
        int cur = op == null ? 0 : op.policy;
        box.addView(UI.tv(this, "اگر قیمت اشتباه است، روش انتخاب قیمت را برای این اپراتور عوض کنید (فعلی: " + names[cur] + ")", 11, UI.MUTED, false), UI.lp(this, -1, -2, 0, 10, 0, 6));
        final AlertDialog[] dd = new AlertDialog[1];
        for (int k = 0; k < 3; k++) {
            final int kk = k;
            box.addView(UI.btn(this, names[k], k == cur ? UI.PRIMARY : UI.CARD2, k == cur ? 0xFF0B1220 : UI.TEXT, v3 -> {
                setPolicy(op, kk);
                dd[0].dismiss();
            }), UI.lp(this, -1, -2, 0, 4, 0, 0));
        }
        dd[0] = new AlertDialog.Builder(this).setTitle(op == null ? p.op : op.name).setView(box).setNegativeButton("بستن", null).create();
        dd[0].show();
    }

    private void setPolicy(Op op, int k) {
        if (op == null) return;
        op.policy = k;
        Cfg.saveOps(this, Cfg.ops(this));
        Store.reprice(this, op.id, k);
        toast(k == 0 ? "با خواندن دوباره‌ی صفحه‌ی بسته‌ها اعمال می‌شود" : "اعمال شد");
        render();
    }

    // ---------------------------------------------------------------- settings

    private void settings(LinearLayout col) {
        col.addView(UI.tv(this, "تنظیمات", 22, UI.TEXT, true));
        col.addView(UI.tv(this, "همه‌چیز را می‌توانید خودتان تنظیم کنید", 12, UI.MUTED, false), UI.lp(this, -2, -2, 0, 2, 0, 4));

        // operators
        LinearLayout c = section(col, "اپراتورها (روشن = خواندن قیمت از صفحه‌ی برنامه‌ی آن)");
        List<Op> ops = Cfg.ops(this);
        for (final Op o : ops) {
            LinearLayout r = UI.hbox(this);
            LinearLayout t = UI.vbox(this);
            t.addView(UI.tv(this, o.name, 14, UI.TEXT, true));
            TextView pk = UI.tv(this, TextUtils.join("، ", o.pkgs) + " • " + (o.cur.equals("IRR") ? "ریال" : o.cur.equals("IRT") ? "تومان" : "واحد خودکار"), 10, UI.MUTED, false);
            pk.setTextDirection(View.TEXT_DIRECTION_LTR);
            t.addView(pk);
            r.addView(t, UI.lpw(1f));
            r.addView(UI.btn(this, "ویرایش", UI.CARD2, UI.TEXT, v -> editOp(o)), UI.lp(this, -2, -2, 0, 0, 6, 0));
            Switch s = new Switch(this);
            s.setChecked(o.enabled);
            s.setOnCheckedChangeListener((bv, on) -> {
                o.enabled = on;
                Cfg.saveOps(this, Cfg.ops(this));
            });
            r.addView(s);
            c.addView(r, UI.lp(this, -1, -2, 0, 6, 0, 6));
            if (!o.builtin) {
                c.addView(UI.btn(this, "حذف " + o.name, 0x33FF6B6B, UI.DANGER, v -> {
                    Cfg.ops(this).remove(o);
                    Cfg.saveOps(this, Cfg.ops(this));
                    Store.clearOp(this, o.id);
                    render();
                }), UI.lp(this, -2, -2, 0, 0, 0, 6));
            }
        }
        int enabledCount = 0;
        for (Op o : ops) if (o.cmp) enabledCount++;
        stepRow(c, "حداقل تعداد اپراتور برای نمایش کادر", "کادر فقط وقتی باز می‌شود که داده‌ی این تعداد اپراتور ثبت شده باشد",
                Cfg.minOps(this), 1, Math.max(1, enabledCount), 1, "", v -> {
                    Cfg.setInt(this, "minOps", v);
                    render();
                });

        LinearLayout a = section(col, "افزودن اپراتور یا برنامه‌ی دیگر");
        a.addView(input("نام اپراتور (مثلاً سامانتل)", newName, s -> newName = s), UI.lp(this, -1, -2, 0, 4, 0, 6));
        a.addView(input("نام پکیج برنامه (مثلاً ir.example.app)", newPkg, s -> newPkg = s), UI.lp(this, -1, -2, 0, 0, 0, 6));
        chips(a, new String[]{"واحد خودکار", "ریال", "تومان"}, newCur, i -> {
            newCur = i;
            render();
        });
        a.addView(UI.tv(this, "برای رعایت حریم خصوصی، بسته‌یاب فهرست برنامه‌های بازشده‌ی گوشی را جمع‌آوری نمی‌کند. نام پکیج اپراتور را فقط در صورت تمایل خودتان وارد کنید.", 11, UI.MUTED, false), UI.lp(this, -1, -2, 0, 10, 0, 0));
        a.addView(UI.btn(this, "افزودن", UI.PRIMARY, 0xFF0B1220, v -> addOp()), UI.lp(this, -1, -2, 0, 10, 0, 0));

        // comparison
        LinearLayout k = section(col, "مقایسه");
        k.addView(UI.tv(this, "معیار رتبه‌بندی", 13, UI.TEXT, false));
        chips(k, new String[]{"هر گیگ", "هر گیگ‌ماه", "مصرف من"}, Cfg.metric(this), i -> {
            Cfg.setInt(this, "metric", i);
            render();
        });
        numberRow(k, "حداقل حجم بسته (گیگ)", Fmt.dec(Cfg.minGb(this)), s -> Cfg.setFloat(this, "minGb", (float) Fmt.parse(s, 1)));
        numberRow(k, "حداکثر مدت بسته (روز، ۰ = بدون محدودیت)", Fmt.dec(Cfg.maxDays(this)), s -> Cfg.setInt(this, "maxDays", (int) Fmt.parse(s, 0)));
        numberRow(k, "مصرف ماهانه‌ی من (گیگ)", Fmt.dec(Cfg.usage(this)), s -> Cfg.setFloat(this, "usage", (float) Fmt.parse(s, 30)));
        k.addView(UI.tv(this, "بسته‌های دارای واحد پول نامشخص یا استخراج مبهم فقط در بخش هشدار نمایش داده می‌شوند و وارد رتبه‌بندی قطعی نمی‌شوند.", 11, UI.MUTED, false), UI.lp(this, -1, -2, 0, 8, 0, 0));
        swRow(k, "شامل بسته‌های ویژه", "شبانه، ساعت خاص، مخصوص اپلیکیشن و ترافیک خاص", Cfg.restricted(this),
                (bv, on) -> Cfg.setBool(this, "restricted", on));

        // popup
        LinearLayout pc = section(col, "کادر مقایسه‌ی آنی");
        swRow(pc, "نمایش خودکار کادر", "وقتی بسته‌های یک اپراتور شناسایی شد باز می‌شود", Cfg.popup(this),
                (bv, on) -> Cfg.setBool(this, "popup", on));
        pc.addView(UI.tv(this, "محتوای کادر", 13, UI.TEXT, false), UI.lp(this, -1, -2, 0, 8, 0, 0));
        chips(pc, new String[]{"هر دو", "برترین کل", "همین صفحه"}, Cfg.pmode(this), i -> {
            Cfg.setInt(this, "pmode", i);
            render();
        });
        stepRow(pc, "تعداد ردیف‌های کادر", null, Cfg.rows(this), 3, 8, 1, "", v -> {
            Cfg.setInt(this, "rows", v);
            render();
        });
        pc.addView(UI.tv(this, "بستن خودکار", 13, UI.TEXT, false), UI.lp(this, -1, -2, 0, 8, 0, 0));
        final int[] hv = {0, 8, 15, 30};
        int hsel = 0;
        for (int i = 0; i < hv.length; i++) if (hv[i] == Cfg.hideSec(this)) hsel = i;
        chips(pc, new String[]{"هرگز", "۸ ثانیه", "۱۵ ثانیه", "۳۰ ثانیه"}, hsel, i -> {
            Cfg.setInt(this, "hide", hv[i]);
            render();
        });
        pc.addView(UI.tv(this, "جای کادر", 13, UI.TEXT, false), UI.lp(this, -1, -2, 0, 8, 0, 0));
        chips(pc, new String[]{"بالا", "پایین"}, Cfg.bottom(this) ? 1 : 0, i -> {
            Cfg.setBool(this, "bottom", i == 1);
            render();
        });
        pc.addView(UI.btn(this, "آزمایش کادر", UI.CARD2, UI.TEXT, v -> {
            ScanService s = ScanService.inst;
            if (s == null) toast("اول سرویس دسترسی را روشن کنید");
            else s.showTest();
        }), UI.lp(this, -1, -2, 0, 10, 0, 0));

        // data
        LinearLayout d = section(col, "داده‌ها");
        d.addView(UI.tv(this, "اعتبار داده (بعد از این مدت نادیده گرفته می‌شود)", 13, UI.TEXT, false));
        final int[] fv = {3, 7, 14, 30};
        int fsel = 0;
        for (int i = 0; i < fv.length; i++) if (fv[i] == Cfg.fresh(this)) fsel = i;
        chips(d, new String[]{"۳ روز", "۷ روز", "۱۴ روز", "۳۰ روز"}, fsel, i -> {
            Cfg.setInt(this, "fresh", fv[i]);
            render();
        });
        d.addView(UI.btn(this, "خروجی CSV در Downloads", UI.CARD2, UI.TEXT, v -> exportCsv()), UI.lp(this, -1, -2, 0, 10, 0, 0));
        d.addView(UI.btn(this, "گزارش تشخیصی (برای رفع مشکل خواندن یک برنامه)", UI.CARD2, UI.TEXT, v -> exportDiag()), UI.lp(this, -1, -2, 0, 8, 0, 0));
        d.addView(UI.btn(this, "پاک‌کردن همه‌ی بسته‌های ذخیره‌شده", 0x33FF6B6B, UI.DANGER, v -> {
            Store.clearAll(this);
            toast("پاک شد");
            render();
        }), UI.lp(this, -1, -2, 0, 8, 0, 0));
        col.addView(UI.tv(this, "حریم خصوصی: این برنامه دسترسی به اینترنت ندارد و فقط متن صفحه‌ی برنامه‌های اپراتورهای انتخابی را روی همین گوشی می‌خواند.", 11, UI.MUTED, false), UI.lp(this, -1, -2, 0, 16, 0, 0));
    }

    private LinearLayout section(LinearLayout col, String title) {
        col.addView(UI.tv(this, title, 13, UI.MUTED, true), UI.lp(this, -1, -2, 0, 18, 0, 8));
        LinearLayout c = UI.card(this);
        col.addView(c);
        return c;
    }

    private void swRow(LinearLayout c, String title, String sub, boolean on, CompoundButton.OnCheckedChangeListener l) {
        LinearLayout r = UI.hbox(this);
        LinearLayout t = UI.vbox(this);
        t.addView(UI.tv(this, title, 14, UI.TEXT, false));
        if (sub != null) t.addView(UI.tv(this, sub, 11, UI.MUTED, false));
        r.addView(t, UI.lpw(1f));
        Switch s = new Switch(this);
        s.setChecked(on);
        s.setOnCheckedChangeListener(l);
        r.addView(s);
        c.addView(r, UI.lp(this, -1, -2, 0, 8, 0, 4));
    }

    private void chips(LinearLayout c, String[] labels, int sel, final IntCb cb) {
        LinearLayout r = UI.hbox(this);
        for (int i = 0; i < labels.length; i++) {
            final int idx = i;
            boolean on = i == sel;
            TextView t = UI.tv(this, labels[i], 12, on ? 0xFF0B1220 : UI.TEXT, on);
            t.setGravity(Gravity.CENTER);
            t.setPadding(dp(6), dp(9), dp(6), dp(9));
            t.setBackground(UI.rr(this, on ? UI.PRIMARY : UI.CARD2, 12));
            t.setOnClickListener(v -> cb.on(idx));
            r.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
            if (i < labels.length - 1) r.addView(new View(this), new LinearLayout.LayoutParams(dp(6), 1));
        }
        c.addView(r, UI.lp(this, -1, -2, 0, 6, 0, 6));
    }

    private void stepRow(LinearLayout c, String title, String sub, final int val, final int min, final int max, final int step, String suffix, final IntCb cb) {
        LinearLayout r = UI.hbox(this);
        LinearLayout t = UI.vbox(this);
        t.addView(UI.tv(this, title, 13, UI.TEXT, false));
        if (sub != null) t.addView(UI.tv(this, sub, 10, UI.MUTED, false));
        r.addView(t, UI.lpw(1f));
        r.addView(UI.btn(this, "−", UI.CARD2, UI.TEXT, v -> cb.on(Math.max(min, val - step))));
        TextView n = UI.tv(this, Fmt.fa(String.valueOf(val)) + suffix, 14, UI.PRIMARY, true);
        n.setGravity(Gravity.CENTER);
        n.setMinWidth(dp(56));
        r.addView(n);
        r.addView(UI.btn(this, "+", UI.CARD2, UI.TEXT, v -> cb.on(Math.min(max, val + step))));
        c.addView(r, UI.lp(this, -1, -2, 0, 6, 0, 6));
    }

    private EditText input(String hint, String text, final StrCb cb) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setHintTextColor(UI.MUTED);
        e.setTextColor(UI.TEXT);
        e.setTextSize(13);
        e.setSingleLine();
        e.setInputType(InputType.TYPE_CLASS_TEXT);
        e.setText(text);
        e.setBackground(UI.rr(this, UI.CARD2, 12));
        e.setPadding(dp(12), dp(10), dp(12), dp(10));
        e.setTextDirection(View.TEXT_DIRECTION_ANY_RTL);
        e.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void afterTextChanged(Editable s) { cb.on(s.toString()); }
        });
        return e;
    }

    private void numberRow(LinearLayout c, String label, String cur, StrCb cb) {
        c.addView(UI.tv(this, label, 13, UI.TEXT, false), UI.lp(this, -1, -2, 0, 10, 0, 4));
        c.addView(input("", cur, cb));
    }

    private void addOp() {
        if (newName.trim().isEmpty() || newPkg.trim().isEmpty()) {
            toast("نام و نام پکیج را وارد کنید");
            return;
        }
        List<Op> l = Cfg.ops(this);
        int[] pal = {0xFF8B5CF6, 0xFFEC4899, 0xFF22C55E, 0xFFF97316, 0xFF06B6D4};
        String[] cur = {"AUTO", "IRR", "IRT"};
        l.add(new Op("c" + System.currentTimeMillis(), newName.trim(), pal[l.size() % pal.length], cur[newCur], false, newPkg.trim()));
        Cfg.saveOps(this, l);
        newName = "";
        newPkg = "";
        render();
    }

    private void editOp(final Op o) {
        final EditText e = input("com.example.app, com.example.beta", TextUtils.join(", ", o.pkgs), s -> {});
        e.setTextDirection(View.TEXT_DIRECTION_LTR);
        FrameLayout f = new FrameLayout(this);
        f.setPadding(dp(20), dp(8), dp(20), 0);
        f.addView(e);
        new AlertDialog.Builder(this)
                .setTitle("پکیج‌های " + o.name)
                .setMessage("نام پکیج برنامه‌ها را با ویرگول جدا کنید.")
                .setView(f)
                .setPositiveButton("ذخیره", (dlg, w) -> {
                    o.pkgs.clear();
                    for (String s : e.getText().toString().split("[,\\s]+")) if (!s.trim().isEmpty()) o.pkgs.add(s.trim());
                    Cfg.saveOps(this, Cfg.ops(this));
                    render();
                })
                .setNegativeButton("لغو", null)
                .show();
    }

    // ---------------------------------------------------------------- export

    private static String csv(String value) {
        String safe = value == null ? "" : value.replace("\"", "\"\"");
        return "\"" + safe + "\"";
    }

    private void exportCsv() {
        final List<Pkg> all = Store.all(this);
        if (all.isEmpty()) {
            toast("داده‌ای برای خروجی نیست");
            return;
        }
        String ts = new SimpleDateFormat("MMdd_HHmmss", Locale.US).format(new Date());
        try {
            save("bastehyab_" + ts + ".csv", "text/csv", o -> {
                StringBuilder sb = new StringBuilder("\uFEFFoperator,title,gb,days,price_toman,currency_known,per_gb_toman,restricted,reason,captured\n");
                for (Pkg p : all) {
                    Op op = Cfg.opById(this, p.op);
                    sb.append(csv(op == null ? p.op : op.name)).append(',').append(csv(p.title)).append(',')
                            .append(p.gb).append(',').append(p.days).append(',')
                            .append(p.currencyKnown ? String.valueOf(p.toman) : "").append(',')
                            .append(p.currencyKnown).append(',')
                            .append(p.currencyKnown ? String.valueOf(Math.round(p.perGb())) : "").append(',')
                            .append(p.restricted).append(',').append(csv(p.why)).append(',')
                            .append(new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(new Date(p.ts))).append('\n');
                }
                o.write(sb.toString().getBytes(StandardCharsets.UTF_8));
            });
            toast("ذخیره شد در Downloads");
        } catch (Exception e) {
            toast(e.toString());
        }
    }

    private void exportDiag() {
        final File f = new File(getFilesDir(), "diag.txt");
        if (!f.exists()) {
            toast("هنوز گزارشی ساخته نشده؛ برنامه‌ی اپراتور را باز کنید و صفحه‌ی بسته‌ها را ببینید.");
            return;
        }
        String ts = new SimpleDateFormat("MMdd_HHmmss", Locale.US).format(new Date());
        try {
            save("diag_" + ts + ".txt", "text/plain", o -> {
                try (InputStream i = new FileInputStream(f)) {
                    byte[] buf = new byte[8192];
                    int n;
                    while ((n = i.read(buf)) > 0) o.write(buf, 0, n);
                }
            });
            toast("ذخیره شد در Downloads");
        } catch (Exception e) {
            toast(e.toString());
        }
    }

    private void save(String name, String mime, W w) throws Exception {
        ContentValues v = new ContentValues();
        v.put(MediaStore.Downloads.DISPLAY_NAME, name);
        v.put(MediaStore.Downloads.MIME_TYPE, mime);
        Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
        try (OutputStream o = getContentResolver().openOutputStream(u)) {
            w.w(o);
        }
    }
}
