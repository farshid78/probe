# بسته‌یاب (Bastehyab) — نسخه اصلاحی 1.2.5

**سازنده:** فرشید نبی‌پور  
**Application ID:** `app.bastehyab`  
**مبنای کار:** ZIP نسخه 1.2 ارسالی کاربر  
**زبان:** Java 17  
**minSdk / compileSdk / targetSdk فعلی:** 29 / 34 / 34

این تحویل یک اصلاح مهندسیِ مرحله‌ای روی سورس موجود است؛ نه ادعای تکمیل تمام قابلیت‌های نقشه راه. جزئیات ممیزی، تغییرات، تست‌ها و کارهای باقی‌مانده در فایل‌های زیر آمده است:

- `AUDIT_REPORT_FA.md`
- `IMPLEMENTATION_REPORT_FA.md`
- `TEST_REPORT_FA.md`
- `SECURITY_PLAY_PROTECT_FA.md`
- `INSTALL_AND_BUILD_FA.md`
- `CHANGELOG.md`

## اجرای تست‌های محلیِ مستقل از Android SDK

```bash
./tools/parser-smoke-tests/run.sh
./tools/android-core-smoke-tests/run.sh
```

این تست‌ها هسته Parser و برخی کلاس‌های پیکربندی/سرویس/ذخیره‌سازی را با test double بررسی می‌کنند؛ بیلد APK، اعتبارسنجی Android Lint، اجرای Emulator یا آزمایش دستگاه واقعی محسوب نمی‌شوند.

## ساخت Android

پروژه به Android Gradle Plugin `8.5.2` و SDK Platform 34 تنظیم شده است. ZIP تحویلی عمداً `gradlew` و `gradle-wrapper.jar` ساختگی ندارد؛ برای ساخت واقعی، پروژه را در Android Studio باز کنید و محیط Gradle و Android SDK سازگار را نصب کنید. راهنمای ساخت و امضای انتشار در `INSTALL_AND_BUILD_FA.md` است.

## وضعیت تحویل

- سورس اصلاح‌شده: موجود
- ZIP سورس نسخه 1.2.1: در کنار گزارش تحویل ارائه شده
- APK Debug: در این محیط ساخته نشد؛ Android SDK و Gradle نصب نیستند
- APK Release: ساخته نشد؛ کلید اختصاصی Release ارائه نشده است
- تأیید رفع هشدار Play Protect: انجام‌پذیر نیست بدون APK امضاشده و متن دقیق هشدار؛ هیچ تضمینی داده نمی‌شود
