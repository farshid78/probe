# گزارش تغییرات اعمال‌شده — بسته‌یاب 1.2.1

## فایل‌های تغییرکرده

- `app/src/main/java/app/bastehyab/Extractor.java`
- `app/src/main/java/app/bastehyab/ScanService.java`
- `app/src/main/java/app/bastehyab/Pkg.java`
- `app/src/main/java/app/bastehyab/Store.java`
- `app/src/main/java/app/bastehyab/Cfg.java`
- `app/src/main/java/app/bastehyab/Fmt.java`
- `app/src/main/java/app/bastehyab/Compare.java`
- `app/src/main/java/app/bastehyab/MainActivity.java`
- `app/src/main/AndroidManifest.xml`
- `app/src/main/res/xml/service_config.xml`
- `app/src/main/res/values/strings.xml`
- `app/build.gradle`
- `.gitignore`
- `tools/parser-smoke-tests/` و `tools/android-core-smoke-tests/`

## شرح پیاده‌سازی

### Scan / Accessibility
- رویدادها با debounce و حداقل فاصله 900ms زمان‌بندی می‌شوند.
- در زمان اجرا guard و درخواست اسکن مجدد کنترل‌شده وجود دارد.
- توقف/قطع سرویس callbackها را حذف و پنجره را پنهان می‌کند.
- پیمایش درخت فقط روی گره‌های visible و نه editable/password انجام می‌شود.
- فلگ IncludeNotImportantViews حذف شده؛ دریافت پنجره‌های تعاملی برای چندپنجره‌ای بودن حفظ شده است.
- عمل خودکار scroll/click/buy در سورس یافت نشد و اضافه نشده است.
- قطع پیمایش در حد 60 عمق یا 8000 گره صریح گزارش می‌شود؛ بسته‌های همان نتیجه مبهم علامت می‌خورند.
- وضعیت آخرین اسکن و تعداد شناسایی‌شده/معتبر/مشکوک/تکراری در UI موجود نشان داده می‌شود. این نمایش snapshot آخرین اسکن است، نه داشبورد زنده با به‌روزرسانی لحظه‌ای.

### پول و Parsing
- واحد ریال به تومان با تقسیم بر 10 تبدیل می‌شود؛ تومان دست‌نخورده می‌ماند.
- اگر مبلغ نه واحد صریح دارد و نه اپراتور واحد ثابت و تاییدشده، مبلغ قابل مقایسه نیست.
- اگر همان کارت مبلغ رقیبی بدون واحد داشته باشد، در انتخاب مقایسه‌ای دخالت نمی‌کند اما بسته مبهم می‌ماند.
- قیمت نامشخص و تمام بسته‌های مبهم در همه حالت‌ها از رتبه‌بندی قطعی خارج می‌شوند؛ گزینه قبلیِ ورود بسته مبهم به رتبه‌بندی حذف شد.
- تست‌ها تبدیل و تشخیص واحد را بررسی می‌کنند؛ این مجموعه برای ادعای دقت 99% کافی نیست.

### ذخیره و حریم خصوصی
- `currencyKnown` به مدل بسته و JSON اضافه شد.
- رکوردهای قدیمی بدون واحد قابل اثبات، به‌صورت محافظه‌کارانه مبهم می‌شوند.
- متن خام کارت در JSON جدید ذخیره نمی‌شود؛ متون خام قدیمی در بارگذاری scrub و دیتابیس بازنویسی می‌شود.
- تشخیص‌گر فقط اطلاعات ساختاری و شمارش‌ها را در `diag.txt` می‌نویسد.
- فایل `diag.txt` قدیمیِ احتمالا حاوی raw dump هنگام اتصال سرویس حذف می‌شود.
- برای اپراتور ناشناخته، نام پکیج برنامه‌های foreground ذخیره نمی‌شود؛ افزودن اپراتور دستی است.

### UI و خروجی
- متن Disclosure روشن و تأیید صریح قبل از بازکردن صفحه تنظیمات Accessibility اضافه شد.
- CSV ستون `currency_known` دارد و قیمت نامشخص را به‌عنوان تومان صادر نمی‌کند.
- معرفی سازنده، لینک تلگرام و زمان‌بندی 5 ثانیه/350ms بدون تغییر حفظ شده‌اند.

## عمداً تکمیل‌نشده

به‌دلیل نبود داده واقعی و محیط ساخت/تست Android، این قابلیت‌ها عمداً پیاده‌سازی نمایشی نشده‌اند: OperatorRegistry و parserهای مستقل واقعی، پشتیبانی کامل و اعتبارسنجی‌شده پنج اپراتور، confidence score صفر تا صد، SQLite/Room و price history، اعلان‌های پس‌زمینه، favorite/alerts، recommendation چندمعیاره کامل، PDF/XLSX، backup/restore کامل، UI چندصفحه‌ای نهایی، و release signing.
