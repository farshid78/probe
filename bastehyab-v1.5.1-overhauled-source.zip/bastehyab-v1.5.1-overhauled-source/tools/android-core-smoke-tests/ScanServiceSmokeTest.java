package app.bastehyab;

public final class ScanServiceSmokeTest {
    private static void ok(boolean value, String message) {
        if (!value) throw new AssertionError(message);
    }

    public static void main(String[] args) {
        ScanService.startFull("rightel", "ir.rightel.myrightel");
        ok(ScanService.fullMode, "auto extraction should start");
        ok(!ScanService.fullStartedScanning, "auto extraction should wait for the actual package page");
        ok(ScanService.fullStartedAt == 0L, "navigation time must not start the five-minute scan timeout");
        ok("rightel".equals(ScanService.fullTargetOpId), "operator target should be retained");
        ok(ScanService.isFullTarget("ir.rightel.myrightel"), "the selected operator package should match");
        ok(!ScanService.isFullTarget("com.android.launcher"), "other apps must not be auto-scrolled");
        ok(!ScanService.shouldStopFullForWindowChange("app.bastehyab"),
                "the launcher activity's transition must not cancel a scan before the operator opens");
        ScanService.fullTargetObservedOnce = true;
        ok(ScanService.shouldStopFullForWindowChange("app.bastehyab"),
                "leaving the operator after it was opened must stop the targeted scan");
        ScanService.stopFull("اسکرول متوقف شد؛ پایان فهرست یا محدودیت اپ قابل تأیید نیست");
        ok(!ScanService.fullMode, "stop should close the auto-extraction state");
        ok(!ScanService.fullFinished, "a stationary page must not be falsely reported as a confirmed end-of-list");
        ScanService.startFull("rightel", "ir.rightel.myrightel");
        ScanService.stopFull("فهرست تمام شد");
        ok(ScanService.fullFinished, "an explicit list-complete signal should be reported as completed");

        ScanService.startFull("rightel", "");
        ok(!ScanService.fullMode, "empty package target must not enable broad auto-scrolling");
        ok(!ScanService.isFullTarget("com.android.launcher"), "an empty target must never match every app");

        ok(Fmt.parse("NaN", 12.5) == 12.5, "NaN must not enter numeric settings");
        ok(Fmt.parse("Infinity", 7) == 7, "Infinity must not enter numeric settings");
        ok(Cfg.validPackageName("ir.example.operator"), "valid Android package name should pass");
        ok(!Cfg.validPackageName("ir..operator"), "empty package segments must fail");
        ok(!Cfg.validPackageName("operator"), "single-segment package name must fail");

        // Rank badges and visible row order must use the same metric ordering, even when
        // a restricted offer is cheaper than a general-purpose offer.
        Pkg costlyGeneral = new Pkg();
        costlyGeneral.key = "general"; costlyGeneral.op = "rightel"; costlyGeneral.restricted = false;
        Pkg cheapSpecial = new Pkg();
        cheapSpecial.key = "special"; cheapSpecial.op = "rightel"; cheapSpecial.restricted = true;
        Pkg middle = new Pkg();
        middle.key = "middle"; middle.op = "irancell"; middle.restricted = false;
        java.util.List<Pkg> ranked = new java.util.ArrayList<>();
        ranked.add(costlyGeneral); ranked.add(middle); ranked.add(cheapSpecial);
        java.util.Map<String, Double> values = new java.util.HashMap<>();
        values.put("general", 100.0); values.put("middle", 50.0); values.put("special", 10.0);
        Compare.sortRanked(ranked, values);
        ok("special".equals(ranked.get(0).key) && "middle".equals(ranked.get(1).key)
                        && "general".equals(ranked.get(2).key),
                "row order must exactly follow the comparison value, not a separate special-offer sort");

        Pkg intl = new Pkg();
        intl.why = "بین‌الملل و رومینگ";
        intl.restricted = true;
        ok(Compare.passesSpecialFilters(intl, false, true),
                "intl filter should work independently of domestic special bundles");
        ok(!Compare.passesSpecialFilters(intl, true, false), "intl offers must obey the intl toggle");
        Pkg night = new Pkg();
        night.why = "شبانه";
        night.restricted = true;
        ok(!Compare.passesSpecialFilters(night, false, true),
                "domestic night offers must obey the special-bundles toggle");
        ok(Compare.passesSpecialFilters(night, true, false),
                "domestic special offers must not require the intl toggle");

        android.view.accessibility.AccessibilityNodeInfo root =
                new android.view.accessibility.AccessibilityNodeInfo("root", 0).bounds(0, 0, 1080, 2200);
        android.view.accessibility.AccessibilityNodeInfo carousel =
                new android.view.accessibility.AccessibilityNodeInfo("carousel", 300)
                        .bounds(0, 300, 1080, 560).scrollable(true);
        android.view.accessibility.AccessibilityNodeInfo feed =
                new android.view.accessibility.AccessibilityNodeInfo("feed", 600)
                        .bounds(0, 600, 1080, 2100).scrollable(true);
        root.add(carousel).add(feed);
        ok(ScanService.findScrollable(root) == feed,
                "auto scroll should select the main tall list instead of a horizontal carousel");
        System.out.println("PASS: targeted auto extraction, target validation, vertical-list selection, metric-consistent ranking, finite numeric parsing, package validation, and independent special/intl filters.");
    }
}
