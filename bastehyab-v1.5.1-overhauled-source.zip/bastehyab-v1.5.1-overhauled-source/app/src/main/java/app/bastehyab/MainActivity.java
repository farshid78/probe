package app.bastehyab;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.provider.Settings;
import android.text.Editable;
import android.text.InputType;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.graphics.drawable.GradientDrawable;
import android.widget.Button;
import android.view.Gravity;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;

import android.widget.LinearLayout;
import android.widget.ProgressBar;

import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    interface IntCb { void on(int v); }
    interface StrCb { void on(String s); }
    interface W { void w(OutputStream o) throws Exception; }

    private static final int[] ICONS = {R.drawable.ic_home, R.drawable.ic_compare, R.drawable.ic_tune};
    private static final String[] NAMES = {"خانه", "مقایسه", "تنظیمات"};

    private FrameLayout body;
    private FrameLayout outer;
    private View splashView;
    private boolean splashShowing;
    private final Handler splashHandler = new Handler(Looper.getMainLooper());
    private final Handler liveHandler = new Handler(Looper.getMainLooper());
    private final Runnable liveRefresh = new Runnable() {
        @Override public void run() {
            if (isFinishing()) return;
            if (tab == 0 && !splashShowing) render();
            if (ScanService.fullMode) liveHandler.postDelayed(this, 700L);
        }
    };
    private LinearLayout nav;
    private ScrollView sv;
    private int tab;
    private final int[] scroll = new int[3];
    private String newName = "", newPkg = "";
    private int newCur;

    private int dp(float v) { return UI.dp(this, v); }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(UI.BG);
        getWindow().setNavigationBarColor(UI.CARD);
        getWindow().getDecorView().setSystemUiVisibility(0);
        LinearLayout root = UI.vbox(this);
        root.setBackgroundResource(R.drawable.bg_app);
        body = new FrameLayout(this);
        root.addView(body, new LinearLayout.LayoutParams(-1, 0, 1f));
        nav = UI.hbox(this);
        nav.setBackground(UI.grad(this, 0xFF0B1730, 0xFF070E20, 0));
        nav.setElevation(dp(10));
        nav.setPadding(0, dp(7), 0, dp(7));
        root.addView(nav, new LinearLayout.LayoutParams(-1, -2));
        outer = new FrameLayout(this);
        outer.addView(root, new FrameLayout.LayoutParams(-1, -1));
        setContentView(outer);
        if (b == null) showCreatorSplash();
        else render(); // Rebuild the visible screen after Android restores the Activity.
    }

    private void showCreatorSplash() {
        splashShowing = true;
        FrameLayout shell = new FrameLayout(this);
        shell.setBackground(UI.grad(this, 0xFF071226, 0xFF0B2540, 24));

        ScrollView scrollView = new ScrollView(this);
        scrollView.setFillViewport(true);
        scrollView.setVerticalScrollBarEnabled(false);
        shell.addView(scrollView, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout col = UI.vbox(this);
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        col.setPadding(dp(24), dp(24), dp(24), dp(22));
        scrollView.addView(col, new ScrollView.LayoutParams(-1, -2));

        FrameLayout logo = new FrameLayout(this);
        logo.addView(new SplashViews.HexBadge(this),
                new FrameLayout.LayoutParams(dp(94), dp(94), Gravity.CENTER));
        logo.addView(new SplashViews.PackageWifiLogo(this),
                new FrameLayout.LayoutParams(dp(82), dp(82), Gravity.CENTER));
        col.addView(logo, UI.lp(this, 104, 104, 0, 0, 0, 10));

        TextView version = UI.tv(this, "نسخه ۱.۵.۱  •  تحلیل‌گر آفلاین", 10, UI.PRIMARY, true);
        version.setGravity(Gravity.CENTER);
        version.setPadding(dp(12), dp(6), dp(12), dp(6));
        version.setBackground(UI.rr(this, 0x2235D9F5, 20));
        col.addView(version, UI.lp(this, -2, -2, 0, 0, 0, 10));

        TextView title = UI.tv(this, "بسته‌یاب", 30, UI.TEXT, true);
        title.setGravity(Gravity.CENTER);
        col.addView(title, UI.lp(this, -1, -2, 0, 0, 0, 3));
        TextView subtitle = UI.tv(this, "مقایسه‌ی دقیق بسته‌های اینترنت؛ بدون حدس‌زدن قیمت", 13, UI.PRIMARY, true);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setMaxLines(2);
        col.addView(subtitle, UI.lp(this, -1, -2, 0, 0, 0, 18));

        LinearLayout steps = UI.card(this);
        steps.setPadding(dp(16), dp(15), dp(16), dp(15));
        steps.addView(UI.tv(this, "شروع کار در سه مرحله", 14, UI.TEXT, true));
        String[] stepText = {
                "برنامه‌ی اپراتور را از داخل بسته‌یاب باز کنید.",
                "در اپراتور وارد صفحه‌ی بسته‌های اینترنت شوید.",
                "بسته‌یاب فهرست را می‌خواند، اسکرول می‌کند و قیمت‌ها را مقایسه می‌کند."
        };
        for (int i = 0; i < stepText.length; i++) {
            LinearLayout item = UI.hbox(this);
            item.setGravity(Gravity.CENTER_VERTICAL);
            TextView number = UI.tv(this, Fmt.fa(String.valueOf(i + 1)), 12, UI.TEXT, true);
            number.setGravity(Gravity.CENTER);
            number.setIncludeFontPadding(false);
            number.setBackground(UI.rr(this, 0x3335D9F5, 10));
            item.addView(number, UI.lp(this, 28, 28, 0, 0, 9, 0));
            TextView instruction = UI.tv(this, stepText[i], 11, UI.MUTED, false);
            instruction.setGravity(Gravity.CENTER_VERTICAL | Gravity.RIGHT);
            instruction.setMaxLines(2);
            item.addView(instruction, UI.lpw(1f));
            steps.addView(item, UI.lp(this, -1, -2, 0, i == 0 ? 10 : 8, 0, 0));
        }
        col.addView(steps, UI.lp(this, -1, -2, 0, 0, 0, 14));

        TextView enter = UI.btn(this, "ورود به برنامه", UI.PRIMARY, 0xFF071226, v -> enterApp());
        col.addView(enter, UI.lp(this, -1, -2, 0, 0, 0, 14));

        LinearLayout creator = UI.hbox(this);
        creator.setGravity(Gravity.CENTER_VERTICAL);
        creator.setPadding(dp(14), dp(12), dp(14), dp(12));
        creator.setBackground(UI.rr(this, 0xCC101D34, 14, 0x664B648C));
        LinearLayout creatorText = UI.vbox(this);
        creatorText.addView(UI.tv(this, "طراحی و توسعه", 10, UI.MUTED, false));
        creatorText.addView(UI.tv(this, "فرشید نبی‌پور", 14, UI.TEXT, true),
                UI.lp(this, -1, -2, 0, 2, 0, 0));
        creator.addView(creatorText, UI.lpw(1f));
        TextView contact = UI.tv(this, "@Farshid_Np", 12, UI.PRIMARY, true);
        contact.setTextDirection(View.TEXT_DIRECTION_LTR);
        contact.setGravity(Gravity.CENTER);
        contact.setPadding(dp(10), dp(8), dp(10), dp(8));
        contact.setBackground(UI.rr(this, 0x2235D9F5, 10));
        contact.setOnClickListener(v -> {
            try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/Farshid_Np"))); }
            catch (Exception e) { toast("امکان باز کردن پیوند ارتباطی وجود ندارد"); }
        });
        creator.addView(contact);
        col.addView(creator, UI.lp(this, -1, -2, 0, 0, 0, 7));

        TextView privacy = UI.tv(this, "تمام پردازش‌ها روی همین گوشی انجام می‌شود؛ اطلاعات صفحه به سرور ارسال نمی‌شود.", 10, UI.MUTED, false);
        privacy.setGravity(Gravity.CENTER);
        privacy.setMaxLines(2);
        col.addView(privacy, UI.lp(this, -1, -2, 0, 3, 0, 0));

        splashView = shell;
        outer.addView(splashView, new FrameLayout.LayoutParams(-1, -1));
    }

    private void enterApp() {
        if (!splashShowing) return;
        View fading = splashView;
        if (fading == null) {
            splashShowing = false;
            render();
            return;
        }
        fading.animate().alpha(0f).setDuration(180L).withEndAction(() -> {
            if (splashView == fading) {
                outer.removeView(fading);
                splashView = null;
                splashShowing = false;
                render();
            }
        }).start();
    }

    @Override protected void onResume() {
        super.onResume();
        if (!splashShowing) render();
        if (ScanService.fullMode) liveHandler.post(liveRefresh);
    }

    @Override protected void onPause() {
        liveHandler.removeCallbacks(liveRefresh);
        super.onPause();
    }

    @Override protected void onDestroy() {
        splashHandler.removeCallbacksAndMessages(null);
        liveHandler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }

    // ---------------------------------------------------------------- shell

    private void render() {
        if (sv != null) scroll[tab] = sv.getScrollY();
        body.removeAllViews();
        sv = new ScrollView(this);
        sv.setFillViewport(true);
        LinearLayout col = UI.vbox(this);
        col.setPadding(dp(16), dp(20), dp(16), dp(24));
        sv.addView(col, new FrameLayout.LayoutParams(-1, -2));
        body.addView(sv, new FrameLayout.LayoutParams(-1, -1));
        if (tab == 0) home(col);
        else if (tab == 1) compare(col);
        else settings(col);
        final int y = scroll[tab];
        sv.post(() -> sv.scrollTo(0, y));
        buildNav();
    }

    private void buildNav() {
        nav.removeAllViews();
        for (int i = 0; i < 3; i++) {
            final int idx = i;
            boolean on = i == tab;
            LinearLayout it = UI.vbox(this);
            it.setGravity(Gravity.CENTER);
            View indicator = new View(this);
            indicator.setBackground(UI.rr(this, on ? UI.PRIMARY : 0x00000000, 3));
            it.addView(indicator, new LinearLayout.LayoutParams(dp(on ? 28 : 12), dp(3)));
            ImageView im = new ImageView(this);
            im.setImageResource(ICONS[i]);
            im.setColorFilter(on ? UI.PRIMARY : UI.MUTED);
            it.addView(im, UI.lp(this, 24, 24, 0, 4, 0, 0));
            it.addView(UI.tv(this, NAMES[i], 11, on ? UI.PRIMARY : UI.MUTED, on), UI.lp(this, -2, -2, 0, 3, 0, 0));
            it.setOnClickListener(v -> {
                scroll[tab] = sv.getScrollY();
                tab = idx;
                render();
            });
            nav.addView(it, new LinearLayout.LayoutParams(0, -2, 1f));
        }
    }

    private boolean serviceOn() {
        String en = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        return en != null && en.contains(getPackageName());
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }

    // ---------------------------------------------------------------- home

    private void home(LinearLayout col) {
        boolean on = serviceOn();
        LinearLayout hero = UI.vbox(this);
        hero.setPadding(dp(20), dp(20), dp(20), dp(20));
        GradientDrawable heroBg = UI.grad(this, 0xFF241B50, 0xFF0A3550, 22);
        heroBg.setStroke(dp(1), 0xAA4E73C7);
        hero.setBackground(heroBg);
        hero.addView(UI.tv(this, "بسته‌یاب", 26, 0xFFFFFFFF, true));
        hero.addView(UI.tv(this, "تحلیل هوشمند • استخراج قیمت • مقایسه‌ی چنداپراتوری", 12, 0xFFB5C9DD, false), UI.lp(this, -2, -2, 0, 4, 0, 12));
        hero.addView(UI.chip(this, on ? "● سرویس فعال" : "● سرویس غیرفعال", on ? 0x334AD8D0 : 0x44FF7185, on ? 0xFFFFFFFF : UI.DANGER));
        col.addView(hero);

        if (!on) {
            LinearLayout c = UI.card(this);
            c.addView(UI.tv(this, "برای شروع، دسترسی را فعال کنید", 15, UI.TEXT, true));
            c.addView(UI.tv(this, "بسته‌یاب برای شناسایی و مقایسه بسته‌های اینترنتی، به اجازه خواندن محتوای قابل مشاهده صفحه برنامه اپراتور نیاز دارد. اطلاعات فقط برای تشخیص بسته‌ها روی همین گوشی پردازش می‌شوند؛ برنامه بدون اجازه شما خرید یا تغییری در اپراتور انجام نمی‌دهد و داده‌ای به سرور ارسال نمی‌کند.", 12, UI.MUTED, false), UI.lp(this, -1, -2, 0, 6, 0, 8));
            c.addView(UI.tv(this, "برای فعال‌سازی، تنظیمات دسترسی‌پذیری اندروید باز می‌شود و تأیید نهایی فقط توسط شما انجام می‌شود. اگر گزینه غیرفعال بود، محدودیت تنظیمات برنامه را از صفحه اطلاعات برنامه بررسی کنید.", 11, UI.MUTED, false), UI.lp(this, -1, -2, 0, 0, 0, 10));
            LinearLayout r = UI.hbox(this);
            r.addView(UI.btn(this, "فعال‌سازی دسترسی", UI.PRIMARY, 0xFF0B1220, v ->
                    new AlertDialog.Builder(this)
                            .setTitle("تأیید آگاهانه دسترسی")
                            .setMessage("با فعال‌کردن این سرویس، بسته‌یاب فقط محتوای قابل‌مشاهده صفحه‌های بسته اینترنت در برنامه‌های اپراتوری را که خودتان انتخاب کرده‌اید می‌خواند. فیلدهای قابل‌ویرایش و رمز عبور نادیده گرفته می‌شوند؛ متن خام صفحه ذخیره یا ارسال نمی‌شود و هیچ دکمه‌ای فشرده یا خریدی انجام نمی‌شود. ادامه می‌دهید؟")
                            .setNegativeButton("فعلاً نه", null)
                            .setPositiveButton("می‌پذیرم؛ تنظیمات را باز کن", (dialog, which) ->
                                    startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)))
                            .show()), UI.lpw(1f));
            r.addView(UI.btn(this, "اطلاعات برنامه", UI.CARD2, UI.TEXT,
                    v -> startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName())))),
                    UI.lp(this, -2, -2, 8, 0, 0, 0));
            c.addView(r);
            col.addView(c, UI.lp(this, -1, -2, 0, 12, 0, 0));
        }

        Compare.Result cr = Compare.run(this, new HashSet<String>());
        List<Op> ops = Cfg.ops(this);
        int active = 0;
        long latest = 0;
        for (Op o : ops) if (o.enabled) active++;
        for (Pkg p : Store.all(this)) if (p.ts > latest) latest = p.ts;

        LinearLayout st = UI.hbox(this);
        st.addView(stat(Fmt.fa(String.valueOf(active)), "اپراتور فعال"), UI.lpw(1f));
        st.addView(stat(Fmt.fa(String.valueOf(cr.ops)), "اپراتور دارای داده"), UI.lp2(this, 8));
        st.addView(stat(Fmt.fa(String.valueOf(cr.ranked.size())), "بسته‌ی قابل مقایسه"), UI.lp2(this, 8));
        col.addView(st, UI.lp(this, -1, -2, 0, 12, 0, 0));

        LinearLayout scanInfo = UI.card(this);
        scanInfo.addView(UI.tv(this, "وضعیت آخرین اسکن", 13, UI.TEXT, true));
        String scanAge = ScanService.lastCompletedScanAt > 0
                ? " • " + Fmt.ago(ScanService.lastCompletedScanAt) : "";
        scanInfo.addView(UI.tv(this, ScanService.lastScanStatus + scanAge, 12, UI.MUTED, false),
                UI.lp(this, -1, -2, 0, 4, 0, 0));
        if (ScanService.lastCompletedScanAt > 0) {
            scanInfo.addView(UI.tv(this, "زمان پردازش آخرین اسکن: "
                    + Fmt.fa(String.valueOf(ScanService.lastScanDurationMs)) + " میلی‌ثانیه",
                    10, UI.MUTED, false), UI.lp(this, -1, -2, 0, 3, 0, 0));
        }
        scanInfo.addView(UI.tv(this,
                "شناسایی‌شده: " + Fmt.fa(String.valueOf(ScanService.lastScannedPackages))
                        + "  • معتبر: " + Fmt.fa(String.valueOf(ScanService.lastValidPackages))
                        + "  • مشکوک: " + Fmt.fa(String.valueOf(ScanService.lastSuspiciousPackages))
                        + "  • تکراری: " + Fmt.fa(String.valueOf(ScanService.lastDuplicatePackages)),
                10, UI.MUTED, false), UI.lp(this, -1, -2, 0, 4, 0, 0));
        {
            // Per-scan counts only describe the current screen; show what the store holds for this operator.
            String opId = ScanService.lastOpId;
            HashSet<String> uniqueSigs = new HashSet<>();
            for (Pkg p : Store.all(this)) if (opId.isEmpty() || p.op.equals(opId)) uniqueSigs.add(p.sig());
            int rankedHere = 0;
            for (Pkg p : cr.ranked) if (opId.isEmpty() || p.op.equals(opId)) rankedHere++;
            scanInfo.addView(UI.tv(this,
                    "ذخیره‌شده‌ی یکتا برای این اپراتور: " + Fmt.fa(String.valueOf(uniqueSigs.size()))
                            + "  • در رتبه‌بندی: " + Fmt.fa(String.valueOf(rankedHere))
                            + "  • در بررسی دستی: " + Fmt.fa(String.valueOf(cr.ambig.size())),
                    10, UI.PRIMARY, true), UI.lp(this, -1, -2, 0, 4, 0, 0));
        }
        if (ScanService.fullMode || ScanService.fullSteps > 0) {
            int pct = ScanService.fullFinished ? 100
                    : Math.min(95, Math.max(1, ScanService.fullSteps * 100 / ScanService.FULL_MAX_STEPS));
            Op targetOp = Cfg.opById(this, ScanService.fullTargetOpId);
            String phase = ScanService.fullMode
                    ? (ScanService.fullStartedScanning ? "در حال استخراج خودکار" : "در انتظار صفحه‌ی بسته‌ها")
                    : (ScanService.fullFinished ? "استخراج به پایان رسید" : "استخراج متوقف شد");
            scanInfo.addView(UI.tv(this, phase + (targetOp == null ? "" : " • " + targetOp.name),
                    11, UI.PRIMARY, true), UI.lp(this, -1, -2, 0, 8, 0, 2));
            scanInfo.addView(UI.tv(this, "پیشرفت تقریبی: " + Fmt.fa(String.valueOf(pct))
                    + "٪  •  " + Fmt.fa(String.valueOf(ScanService.fullSeen.size())) + " بسته‌ی یکتا",
                    10, UI.MUTED, false), UI.lp(this, -1, -2, 0, 2, 0, 3));
            if (!ScanService.lastPackageStatus.isEmpty()) {
                scanInfo.addView(UI.tv(this, ScanService.lastPackageStatus, 10, UI.PRIMARY, false),
                        UI.lp(this, -1, -2, 0, 3, 0, 0));
            }
            ProgressBar pb = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
            pb.setMax(100); pb.setProgress(pct);
            scanInfo.addView(pb, UI.lp(this, -1, 6, 0, 2, 0, 0));
        }
        col.addView(scanInfo, UI.lp(this, -1, -2, 0, 10, 0, 0));

        LinearLayout best = UI.card(this);
        best.addView(UI.tv(this, "بهترین پیشنهاد فعلی", 13, UI.ACCENT, true));
        if (cr.ranked.isEmpty()) {
            best.addView(UI.tv(this, "هنوز بسته‌ی معتبر برای مقایسه ثبت نشده است. برنامه‌ی اپراتور را باز کنید و وارد صفحه‌ی بسته‌های اینترنت شوید.", 12, UI.MUTED, false), UI.lp(this, -1, -2, 0, 8, 0, 0));
        } else {
            Pkg p = cr.ranked.get(0);
            Op op = Cfg.opById(this, p.op);
            LinearLayout r = UI.hbox(this);
            LinearLayout info = UI.vbox(this);
            info.addView(UI.chip(this, op == null ? p.op : op.name, UI.tint(op == null ? UI.MUTED : op.color), op == null ? UI.MUTED : op.color));
            info.addView(UI.tv(this, "رتبه ۱ در مقایسه", 10, UI.PRIMARY, true), UI.lp(this, -1, -2, 0, 5, 0, 0));
            info.addView(UI.tv(this, p.label(), 18, UI.TEXT, true), UI.lp(this, -2, -2, 0, 3, 0, 0));
            info.addView(UI.tv(this, Fmt.num(Cfg.finalPrice(this, p)) + " تومان (با ارزش افزوده)", 12, UI.MUTED, false));
            r.addView(info, UI.lpw(1f));
            LinearLayout m = UI.vbox(this);
            m.setGravity(Gravity.CENTER_HORIZONTAL);
            m.addView(UI.tv(this, Fmt.num(Math.round(cr.val.get(p.key))), 22, UI.PRIMARY, true));
            m.addView(UI.tv(this, cr.unit, 10, UI.MUTED, false));
            r.addView(m);
            best.addView(r, UI.lp(this, -1, -2, 0, 8, 0, 0));
            double med = cr.median, v = cr.val.get(p.key);
            if (med > 0 && cr.ranked.size() > 2) {
                long pct = Math.round((med - v) / med * 100);
                if (pct >= 3)
                    best.addView(UI.chip(this, Fmt.fa(String.valueOf(pct)) + "٪ ارزان‌تر از بسته‌ی میانه", 0x334AD8D0, UI.PRIMARY), UI.lp(this, -2, -2, 0, 8, 0, 0));
            }
        }
        col.addView(best, UI.lp(this, -1, -2, 0, 12, 0, 0));

        // بسته‌های با قیمت مبهم در رتبه‌بندی و رابط اصلی نمایش داده نمی‌شوند.

        if (!cr.ranked.isEmpty()) {
            Pkg low = cr.ranked.get(0), volume = cr.ranked.get(0), duration = cr.ranked.get(0);
            for (Pkg candidate : cr.ranked) {
                if (candidate.toman < low.toman) low = candidate;
                if (candidate.gb > volume.gb) volume = candidate;
                if (candidate.days > duration.days) duration = candidate;
            }
            LinearLayout picks = UI.hbox(this);
            picks.addView(bestMini("کمترین قیمت", low), UI.lpw(1f));
            picks.addView(bestMini("بیشترین حجم", volume), UI.lp2(this, 6));
            picks.addView(bestMini("بیشترین مدت", duration), UI.lp2(this, 6));
            col.addView(picks, UI.lp(this, -1, -2, 0, 8, 0, 0));
        }

        LinearLayout oc = UI.card(this);
        oc.addView(UI.tv(this, "اپراتورها", 13, UI.MUTED, true));
        for (final Op o : ops) {
            int n = 0;
            long ts = 0;
            for (Pkg p : Store.all(this)) {
                if (p.op.equals(o.id)) {
                    n++;
                    if (p.ts > ts) ts = p.ts;
                }
            }
            LinearLayout r = UI.hbox(this);
            View dot = new View(this);
            dot.setBackground(UI.rr(this, o.color, 6));
            r.addView(dot, new LinearLayout.LayoutParams(dp(12), dp(12)));
            LinearLayout info = UI.vbox(this);
            info.addView(UI.tv(this, o.name + (o.enabled ? "" : " (خاموش)"), 14, o.enabled ? UI.TEXT : UI.MUTED, true));
            info.addView(UI.tv(this, n == 0 ? "هنوز داده‌ای نیست" : Fmt.fa(String.valueOf(n)) + " بسته • " + Fmt.ago(ts), 11, UI.MUTED, false));
            r.addView(info, UI.lp2(this, 10));
            String actionLabel = o.enabled ? "باز کردن و استخراج" : "باز کردن";
            r.addView(UI.btn(this, actionLabel, UI.CARD2, UI.PRIMARY, v -> launch(o)));
            oc.addView(r, UI.lp(this, -1, -2, 0, 10, 0, 0));
        }
        col.addView(oc, UI.lp(this, -1, -2, 0, 12, 0, 0));

        LinearLayout g = UI.card(this);
        g.addView(UI.tv(this, "راهنمای سریع", 13, UI.MUTED, true));
        String[] steps = {
                "۱) روی «باز کردن و استخراج» اپراتور بزنید؛ برنامه باز می‌شود و استخراج خودکار آماده می‌ماند.",
                "۲) وارد صفحه‌ی خرید بسته‌های اینترنت شوید؛ پس از شناسایی بسته‌ها، پیمایش فهرست خودکار انجام می‌شود.",
                "۳) برای اپراتور بعدی همین کار را تکرار کنید؛ نتیجه‌ها در مقایسه‌ی چنداپراتوری نمایش داده می‌شوند."};
        for (String s : steps) g.addView(UI.tv(this, s, 12, UI.TEXT, false), UI.lp(this, -1, -2, 0, 8, 0, 0));
        col.addView(g, UI.lp(this, -1, -2, 0, 12, 0, 0));
    }

    private View bestMini(String heading, Pkg p) {
        LinearLayout c = UI.vbox(this);
        c.setPadding(dp(9), dp(10), dp(9), dp(10));
        c.setBackground(UI.rr(this, UI.CARD, 14, UI.STROKE));
        c.addView(UI.tv(this, heading, 10, UI.ACCENT, true));
        c.addView(UI.tv(this, p.label(), 11, UI.TEXT, true), UI.lp(this, -1, -2, 0, 5, 0, 0));
        c.addView(UI.tv(this, Fmt.num(Cfg.finalPrice(this, p)) + " تومان", 10, UI.MUTED, false));
        return c;
    }

    private View stat(String big, String small) {
        LinearLayout c = UI.vbox(this);
        c.setGravity(Gravity.CENTER);
        c.setPadding(dp(8), dp(14), dp(8), dp(14));
        c.setBackground(UI.rr(this, UI.CARD, 16, UI.STROKE));
        c.addView(UI.tv(this, big, 22, UI.PRIMARY, true));
        TextView t = UI.tv(this, small, 10, UI.MUTED, false);
        t.setGravity(Gravity.CENTER);
        c.addView(t);
        return c;
    }

    private void launch(Op o) {
        String targetPackage = null;
        Intent launchIntent = null;
        for (String p : o.pkgs) {
            Intent candidate = getPackageManager().getLaunchIntentForPackage(p);
            if (candidate != null) {
                targetPackage = p;
                launchIntent = candidate;
                break;
            }
        }
        if (launchIntent == null || targetPackage == null) {
            toast("برنامه‌ی " + o.name + " پیدا نشد؛ نصب بودن برنامه و نام پکیج را بررسی کنید.");
            return;
        }

        boolean auto = ScanService.inst != null && o.enabled;
        if (auto) ScanService.startFull(o.id, targetPackage);
        try {
            startActivity(launchIntent);
            if (auto) {
                liveHandler.removeCallbacks(liveRefresh);
                liveHandler.post(liveRefresh);
                toast("استخراج خودکار " + o.name + " آماده شد؛ وارد صفحه‌ی بسته‌های اینترنت شوید.");
            } else if (!o.enabled) {
                toast("برنامه باز شد؛ این اپراتور در تنظیمات غیرفعال است و استخراج انجام نمی‌شود.");
            } else {
                toast("برنامه باز شد؛ برای استخراج خودکار، ابتدا سرویس دسترسی بسته‌یاب را فعال کنید.");
            }
        } catch (RuntimeException e) {
            if (auto) ScanService.stopFull("باز کردن برنامه‌ی اپراتور ناموفق بود");
            toast("باز کردن برنامه‌ی " + o.name + " ناموفق بود: " + e.getClass().getSimpleName());
        }
    }

    // ---------------------------------------------------------------- compare

    private void compare(LinearLayout col) {
        col.addView(UI.tv(this, "مقایسه‌ی بسته‌ها", 22, UI.TEXT, true));
        col.addView(UI.tv(this, "رتبه‌بندی زنده‌ی همه‌ی بسته‌هایی که تا الان خوانده شده", 12, UI.MUTED, false), UI.lp(this, -2, -2, 0, 2, 0, 12));

        chips(col, new String[]{"هر گیگ", "هر گیگ‌ماه", "مصرف من"}, Cfg.metric(this), i -> {
            Cfg.setInt(this, "metric", i);
            render();
        });
        col.addView(UI.tv(this, "مدت بسته (مقایسه‌ی هم‌رده)", 11, UI.MUTED, false), UI.lp(this, -1, -2, 0, 4, 0, 0));
        chips(col, Compare.BUCKETS, Cfg.bucket(this), i -> {
            Cfg.setInt(this, "bucket", i);
            render();
        });
        if (Cfg.metric(this) == Cfg.MY_USAGE) {
            stepRow(col, "مصرف ماهانه‌ی شما", null, (int) Cfg.usage(this), 5, 500, 5, " گیگ", v -> {
                Cfg.setFloat(this, "usage", v);
                render();
            });
        }

        col.addView(tickCard(), UI.lp(this, -1, -2, 0, 12, 0, 8));

        Compare.Result cr = Compare.run(this, new HashSet<String>());
        if (cr.ranked.isEmpty()) {
            LinearLayout c = UI.card(this);
            c.addView(UI.tv(this, anyCmp() ? "بسته‌ای برای نمایش نیست" : "هیچ اپراتوری تیک نخورده", 14, UI.TEXT, true));
            c.addView(UI.tv(this, "برنامه‌ی اپراتور را باز کنید و صفحه‌ی بسته‌های اینترنت را ببینید. اگر داده دارید ولی چیزی نمی‌بینید، فیلترهای «تنظیمات ← مقایسه» (حداقل حجم، سقف مدت، بسته‌های ویژه) را بررسی کنید.", 12, UI.MUTED, false), UI.lp(this, -1, -2, 0, 6, 0, 0));
            col.addView(c);
            return;
        }
        int n = Math.min(60, cr.ranked.size());
        for (int i = 0; i < n; i++) col.addView(pkgRow(cr.ranked.get(i), i + 1, cr), UI.lp(this, -1, -2, 0, 4, 0, 4));
    }

    private boolean anyCmp() {
        for (Op o : Cfg.ops(this)) if (o.cmp) return true;
        return false;
    }

    private void setAllCmp(boolean on) {
        for (Op o : Cfg.ops(this)) o.cmp = on;
        Cfg.saveOps(this, Cfg.ops(this));
        render();
    }

    private View tickCard() {
        LinearLayout c = UI.card(this);
        List<Op> ops = Cfg.ops(this);
        int on = 0;
        StringBuilder names = new StringBuilder();
        for (Op o : ops) {
            if (o.cmp) {
                on++;
                if (names.length() > 0) names.append(" + ");
                names.append(o.name);
            }
        }
        LinearLayout hd = UI.hbox(this);
        hd.addView(UI.tv(this, "اپراتورهای مقایسه", 14, UI.TEXT, true), UI.lpw(1f));
        hd.addView(UI.btn(this, "همه", UI.CARD2, UI.TEXT, v -> setAllCmp(true)), UI.lp(this, -2, -2, 0, 0, 6, 0));
        hd.addView(UI.btn(this, "هیچ", UI.CARD2, UI.TEXT, v -> setAllCmp(false)));
        c.addView(hd);
        for (final Op o : ops) {
            int n = 0;
            long ts = 0;
            for (Pkg p : Store.all(this)) {
                if (p.op.equals(o.id)) {
                    n++;
                    if (p.ts > ts) ts = p.ts;
                }
            }
            LinearLayout r = UI.hbox(this);
            CheckBox cb = new CheckBox(this);
            cb.setChecked(o.cmp);
            cb.setButtonTintList(ColorStateList.valueOf(o.color));
            cb.setOnCheckedChangeListener((bv, ch) -> {
                o.cmp = ch;
                Cfg.saveOps(this, Cfg.ops(this));
                body.post(this::render);
            });
            r.addView(cb);
            LinearLayout t = UI.vbox(this);
            t.addView(UI.tv(this, o.name, 14, o.cmp ? UI.TEXT : UI.MUTED, true));
            t.addView(UI.tv(this, n == 0 ? "داده‌ای ندارد — برنامه‌اش را باز کنید" : Fmt.fa(String.valueOf(n)) + " بسته • " + Fmt.ago(ts), 11, UI.MUTED, false));
            r.addView(t, UI.lpw(1f));
            c.addView(r, UI.lp(this, -1, -2, 0, 8, 0, 0));
        }
        String sum = on == 0 ? "هیچ اپراتوری تیک نخورده"
                : on == ops.size() ? "قیمت همه‌ی اپراتورها جمع شد و با هم مقایسه می‌شود"
                : "مقایسه‌ی " + names;
        c.addView(UI.tv(this, sum, 12, UI.PRIMARY, true), UI.lp(this, -1, -2, 0, 10, 0, 0));
        return c;
    }

    private View pkgRow(Pkg p, int rank, Compare.Result cr) {
        Op op = Cfg.opById(this, p.op);
        int actualRank = cr.rank.containsKey(p.key) ? cr.rank.get(p.key) : rank;
        int opColor = op == null ? UI.MUTED : op.color;

        LinearLayout card = UI.vbox(this);
        card.setPadding(dp(12), dp(11), dp(12), dp(11));
        card.setBackground(UI.rr(this, actualRank == 1 ? 0xFF16283A : UI.CARD,
                15, actualRank == 1 ? UI.PRIMARY : UI.STROKE));

        LinearLayout head = UI.hbox(this);
        TextView badge = UI.tv(this, Fmt.fa(String.valueOf(actualRank)), 13, UI.TEXT, true);
        badge.setGravity(Gravity.CENTER);
        badge.setIncludeFontPadding(false);
        badge.setBackground(UI.rr(this, actualRank == 1 ? UI.ACCENT : UI.CARD2, 11));
        head.addView(badge, UI.lp(this, 34, 34, 0, 0, 9, 0));
        head.addView(UI.chip(this, op == null ? p.op : op.name, UI.tint(opColor), opColor));
        if (p.restricted) head.addView(UI.chip(this, "ویژه", 0x33F5B84B, UI.ACCENT),
                UI.lp(this, -2, -2, 6, 0, 0, 0));
        if (cr.cheap.contains(p.key)) head.addView(UI.chip(this, "بررسی قیمت", 0x33F5B84B, UI.ACCENT),
                UI.lp(this, -2, -2, 6, 0, 0, 0));
        card.addView(head);

        TextView label = UI.tv(this, p.label(), 15, UI.TEXT, true);
        label.setMaxLines(2);
        label.setEllipsize(android.text.TextUtils.TruncateAt.END);
        label.setGravity(Gravity.CENTER_VERTICAL | Gravity.RIGHT);
        card.addView(label, UI.lp(this, -1, -2, 0, 7, 0, 7));

        LinearLayout foot = UI.hbox(this);
        LinearLayout total = UI.vbox(this);
        total.addView(UI.tv(this, "قیمت نهایی", 9, UI.MUTED, false));
        total.addView(UI.tv(this, Fmt.num(Cfg.finalPrice(this, p)) + " تومان", 12, UI.TEXT, true));
        foot.addView(total, UI.lpw(1f));

        LinearLayout metric = UI.vbox(this);
        metric.setGravity(Gravity.CENTER_HORIZONTAL);
        metric.addView(UI.tv(this, "معیار مقایسه", 9, UI.MUTED, false));
        metric.addView(UI.tv(this, Fmt.num(Math.round(cr.val.get(p.key))) + " " + cr.unit,
                12, actualRank == 1 ? UI.PRIMARY : UI.TEXT, true));
        foot.addView(metric, UI.lpw(1f));
        card.addView(foot);
        card.setOnClickListener(v -> showDetail(p));
        return card;
    }

    private void showDetail(final Pkg p) {
        final Op op = Cfg.opById(this, p.op);
        String operator = op == null ? p.op : op.name;
        StringBuilder sb = new StringBuilder();
        sb.append(operator).append("\n");
        sb.append(p.label()).append("\n");
        if (p.currencyKnown && !p.ambig) {
            sb.append("قیمت پایه: ").append(Fmt.num(p.toman)).append(" تومان\n");
            sb.append("با ارزش افزوده: ").append(Fmt.num(Cfg.finalPrice(this, p))).append(" تومان\n");
        } else {
            // Never display a candidate number as the package price when the parser could not
            // verify which amount belongs to this offer.
            sb.append("قیمت این بسته به‌صورت قطعی شناسایی نشد.\n");
            sb.append("تا بررسی دوباره، در رتبه‌بندی و مقایسه استفاده نمی‌شود.");
        }
        if (p.restricted && !p.ambig) {
            sb.append("\nمحدودیت: ").append(p.why);
        }
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("جزئیات بسته")
                .setMessage(sb.toString())
                .setPositiveButton("بستن", null)
                .create();
        dialog.show();
    }

    // ---------------------------------------------------------------- settings

    private void settings(LinearLayout col) {
        col.addView(UI.tv(this, "تنظیمات", 22, UI.TEXT, true));
        col.addView(UI.tv(this, "همه‌چیز را می‌توانید خودتان تنظیم کنید", 12, UI.MUTED, false), UI.lp(this, -2, -2, 0, 2, 0, 4));

        // operators
        LinearLayout c = section(col, "اپراتورها (روشن = خواندن قیمت از صفحه‌ی برنامه‌ی آن)");
        List<Op> ops = Cfg.ops(this);
        for (final Op o : ops) {
            LinearLayout r = UI.hbox(this);
            LinearLayout t = UI.vbox(this);
            t.addView(UI.tv(this, o.name, 14, UI.TEXT, true));
            TextView pk = UI.tv(this, TextUtils.join("، ", o.pkgs) + " • " + (o.cur.equals("IRR") ? "ریال" : o.cur.equals("IRT") ? "تومان" : "واحد خودکار"), 10, UI.MUTED, false);
            pk.setTextDirection(View.TEXT_DIRECTION_LTR);
            t.addView(pk);
            r.addView(t, UI.lpw(1f));
            r.addView(UI.btn(this, "ویرایش", UI.CARD2, UI.TEXT, v -> editOp(o)), UI.lp(this, -2, -2, 0, 0, 6, 0));
            Switch s = new Switch(this);
            s.setChecked(o.enabled);
            s.setOnCheckedChangeListener((bv, on) -> {
                o.enabled = on;
                Cfg.saveOps(this, Cfg.ops(this));
            });
            r.addView(s);
            c.addView(r, UI.lp(this, -1, -2, 0, 6, 0, 6));
            if (!o.builtin) {
                c.addView(UI.btn(this, "حذف " + o.name, 0x33FF6B6B, UI.DANGER, v -> {
                    Cfg.ops(this).remove(o);
                    Cfg.saveOps(this, Cfg.ops(this));
                    Store.clearOp(this, o.id);
                    render();
                }), UI.lp(this, -2, -2, 0, 0, 0, 6));
            }
        }
        int enabledCount = 0;
        for (Op o : ops) if (o.cmp) enabledCount++;
        stepRow(c, "حداقل تعداد اپراتور برای نمایش کادر", "کادر فقط وقتی باز می‌شود که داده‌ی این تعداد اپراتور ثبت شده باشد",
                Cfg.minOps(this), 1, Math.max(1, enabledCount), 1, "", v -> {
                    Cfg.setInt(this, "minOps", v);
                    render();
                });

        LinearLayout a = section(col, "افزودن اپراتور یا برنامه‌ی دیگر");
        a.addView(input("نام اپراتور (مثلاً سامانتل)", newName, s -> newName = s), UI.lp(this, -1, -2, 0, 4, 0, 6));
        a.addView(input("نام پکیج برنامه (مثلاً ir.example.app)", newPkg, s -> newPkg = s), UI.lp(this, -1, -2, 0, 0, 0, 6));
        chips(a, new String[]{"واحد خودکار", "ریال", "تومان"}, newCur, i -> {
            newCur = i;
            render();
        });
        a.addView(UI.tv(this, "برای رعایت حریم خصوصی، بسته‌یاب فهرست برنامه‌های بازشده‌ی گوشی را جمع‌آوری نمی‌کند. نام پکیج اپراتور را فقط در صورت تمایل خودتان وارد کنید.", 11, UI.MUTED, false), UI.lp(this, -1, -2, 0, 10, 0, 0));
        a.addView(UI.btn(this, "افزودن", UI.PRIMARY, 0xFF0B1220, v -> addOp()), UI.lp(this, -1, -2, 0, 10, 0, 0));

        // comparison
        LinearLayout k = section(col, "مقایسه");
        k.addView(UI.tv(this, "معیار رتبه‌بندی", 13, UI.TEXT, false));
        chips(k, new String[]{"هر گیگ", "هر گیگ‌ماه", "مصرف من"}, Cfg.metric(this), i -> {
            Cfg.setInt(this, "metric", i);
            render();
        });
        numberRow(k, "حداقل حجم بسته (مگابایت، ۰ = همه)", Fmt.num(Math.round(Cfg.minGb(this) * 1024)),
                s -> Cfg.setFloat(this, "minGb", Math.max(0f, Math.min(5120000f, (float) (Fmt.parse(s, 0) / 1024.0)))));
        numberRow(k, "حداکثر مدت بسته (روز، ۰ = بدون محدودیت)", Fmt.dec(Cfg.maxDays(this)),
                s -> Cfg.setInt(this, "maxDays", Cfg.clamp((int) Fmt.parse(s, 0), 0, 36500)));
        numberRow(k, "مصرف ماهانه‌ی من (گیگ)", Fmt.dec(Cfg.usage(this)),
                s -> Cfg.setFloat(this, "usage", Cfg.finiteClamp((float) Fmt.parse(s, 30), 0.1f, 5000f, 30f)));
        numberRow(k, "ارزش افزوده (درصد، ۰ تا ۱۰۰)", Fmt.num(Cfg.vat(this)), s -> {
            int v = (int) Fmt.parse(s, Cfg.vat(this));
            Cfg.setInt(this, "vat", Math.max(0, Math.min(100, v)));
        });
        k.addView(UI.tv(this, "مالیات فقط هنگام نمایش و مقایسه روی قیمت پایه اعمال می‌شود؛ قیمت اصلی ذخیره‌شده تغییر نمی‌کند.",
                11, UI.MUTED, false), UI.lp(this, -1, -2, 0, 5, 0, 0));
        k.addView(UI.tv(this, "بسته‌های دارای واحد پول نامشخص یا استخراج مبهم فقط در بخش هشدار نمایش داده می‌شوند و وارد رتبه‌بندی قطعی نمی‌شوند.", 11, UI.MUTED, false), UI.lp(this, -1, -2, 0, 8, 0, 0));
        swRow(k, "شامل بسته‌های ویژه", "شبانه، ساعت خاص، اپلیکیشن، ترکیبی، هدیه و ترافیک محدود؛ پایین‌تر از بسته‌های عمومی", Cfg.restricted(this),
                (bv, on) -> Cfg.setBool(this, "restricted", on));
        swRow(k, "شامل بسته‌های بین‌الملل و رومینگ", "جدا از رتبه‌بندی داخلی؛ برای مقایسه‌ی داخلی توصیه نمی‌شود", Cfg.intl(this),
                (bv, on) -> Cfg.setBool(this, "intl", on));

        // popup
        LinearLayout pc = section(col, "کادر مقایسه‌ی آنی");
        swRow(pc, "نمایش خودکار کادر", "وقتی بسته‌های یک اپراتور شناسایی شد باز می‌شود", Cfg.popup(this),
                (bv, on) -> Cfg.setBool(this, "popup", on));
        pc.addView(UI.tv(this, "محتوای کادر", 13, UI.TEXT, false), UI.lp(this, -1, -2, 0, 8, 0, 0));
        chips(pc, new String[]{"هر دو", "برترین کل", "همین صفحه"}, Cfg.pmode(this), i -> {
            Cfg.setInt(this, "pmode", i);
            render();
        });
        stepRow(pc, "تعداد ردیف‌های کادر", null, Cfg.rows(this), 3, 8, 1, "", v -> {
            Cfg.setInt(this, "rows", v);
            render();
        });
        pc.addView(UI.tv(this, "بستن خودکار", 13, UI.TEXT, false), UI.lp(this, -1, -2, 0, 8, 0, 0));
        final int[] hv = {0, 8, 15, 30};
        int hsel = 0;
        for (int i = 0; i < hv.length; i++) if (hv[i] == Cfg.hideSec(this)) hsel = i;
        chips(pc, new String[]{"هرگز", "۸ ثانیه", "۱۵ ثانیه", "۳۰ ثانیه"}, hsel, i -> {
            Cfg.setInt(this, "hide", hv[i]);
            render();
        });
        pc.addView(UI.tv(this, "جای کادر", 13, UI.TEXT, false), UI.lp(this, -1, -2, 0, 8, 0, 0));
        chips(pc, new String[]{"بالا", "پایین"}, Cfg.bottom(this) ? 1 : 0, i -> {
            Cfg.setBool(this, "bottom", i == 1);
            render();
        });
        pc.addView(UI.btn(this, "آزمایش کادر", UI.CARD2, UI.TEXT, v -> {
            ScanService s = ScanService.inst;
            if (s == null) toast("اول سرویس دسترسی را روشن کنید");
            else s.showTest();
        }), UI.lp(this, -1, -2, 0, 10, 0, 0));

        // data
        LinearLayout d = section(col, "داده‌ها");
        d.addView(UI.tv(this, "اعتبار داده (بعد از این مدت نادیده گرفته می‌شود)", 13, UI.TEXT, false));
        final int[] fv = {3, 7, 14, 30};
        int fsel = 0;
        for (int i = 0; i < fv.length; i++) if (fv[i] == Cfg.fresh(this)) fsel = i;
        chips(d, new String[]{"۳ روز", "۷ روز", "۱۴ روز", "۳۰ روز"}, fsel, i -> {
            Cfg.setInt(this, "fresh", fv[i]);
            render();
        });
        d.addView(UI.btn(this, "خروجی CSV در Downloads", UI.CARD2, UI.TEXT, v -> exportCsv()), UI.lp(this, -1, -2, 0, 10, 0, 0));
        d.addView(UI.btn(this, "گزارش تشخیصی (برای رفع مشکل خواندن یک برنامه)", UI.CARD2, UI.TEXT, v -> exportDiag()), UI.lp(this, -1, -2, 0, 8, 0, 0));
        LinearLayout hist = UI.card(this);
        hist.addView(UI.tv(this, "تاریخچه‌ی تغییرات بسته‌ها", 13, UI.TEXT, true));
        List<HistoryLog.Entry> changes = HistoryLog.recent(this, 8);
        if (changes.isEmpty()) hist.addView(UI.tv(this, "هنوز تغییری بین دو اسکن ثبت نشده است.", 11, UI.MUTED, false),
                UI.lp(this, -1, -2, 0, 6, 0, 0));
        for (HistoryLog.Entry ch : changes) {
            boolean priceChange = "price".equals(ch.field);
            String fieldLabel = priceChange ? "قیمت" : ("gb".equals(ch.field) ? "حجم" : "مدت");
            String before = priceChange ? Fmt.num((long) ch.before) + " تومان"
                    : Fmt.dec(ch.before) + ("gb".equals(ch.field) ? " گیگ" : " روز");
            String after = priceChange ? Fmt.num((long) ch.after) + " تومان"
                    : Fmt.dec(ch.after) + ("gb".equals(ch.field) ? " گیگ" : " روز");
            hist.addView(UI.tv(this, fieldLabel + ": " + ch.title + " | " + before + " ← " + after
                    + " • " + Fmt.ago(ch.ts), 10, priceChange ? UI.ACCENT : UI.MUTED, false),
                    UI.lp(this, -1, -2, 0, 6, 0, 0));
        }
        d.addView(hist, UI.lp(this, -1, -2, 0, 10, 0, 0));
        d.addView(UI.btn(this, "پاک‌کردن همه‌ی بسته‌های ذخیره‌شده", 0x33FF6B6B, UI.DANGER, v -> {
            Store.clearAll(this);
            HistoryLog.clear(this);
            toast("پاک شد");
            render();
        }), UI.lp(this, -1, -2, 0, 8, 0, 0));
        col.addView(UI.tv(this, "حریم خصوصی: این برنامه دسترسی به اینترنت ندارد و فقط متن صفحه‌ی برنامه‌های اپراتورهای انتخابی را روی همین گوشی می‌خواند.", 11, UI.MUTED, false), UI.lp(this, -1, -2, 0, 16, 0, 0));
    }

    private LinearLayout section(LinearLayout col, String title) {
        col.addView(UI.tv(this, title, 13, UI.MUTED, true), UI.lp(this, -1, -2, 0, 18, 0, 8));
        LinearLayout c = UI.card(this);
        col.addView(c);
        return c;
    }

    private void swRow(LinearLayout c, String title, String sub, boolean on, CompoundButton.OnCheckedChangeListener l) {
        LinearLayout r = UI.hbox(this);
        LinearLayout t = UI.vbox(this);
        t.addView(UI.tv(this, title, 14, UI.TEXT, false));
        if (sub != null) t.addView(UI.tv(this, sub, 11, UI.MUTED, false));
        r.addView(t, UI.lpw(1f));
        Switch s = new Switch(this);
        s.setChecked(on);
        s.setOnCheckedChangeListener(l);
        r.addView(s);
        c.addView(r, UI.lp(this, -1, -2, 0, 8, 0, 4));
    }

    private void chips(LinearLayout c, String[] labels, int sel, final IntCb cb) {
        LinearLayout r = UI.hbox(this);
        for (int i = 0; i < labels.length; i++) {
            final int idx = i;
            boolean on = i == sel;
            TextView t = UI.tv(this, labels[i], 12, on ? 0xFF0B1220 : UI.TEXT, on);
            t.setGravity(Gravity.CENTER);
            t.setPadding(dp(6), dp(9), dp(6), dp(9));
            t.setBackground(UI.rr(this, on ? UI.PRIMARY : UI.CARD2, 12));
            t.setOnClickListener(v -> cb.on(idx));
            r.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
            if (i < labels.length - 1) r.addView(new View(this), new LinearLayout.LayoutParams(dp(6), 1));
        }
        c.addView(r, UI.lp(this, -1, -2, 0, 6, 0, 6));
    }

    private void stepRow(LinearLayout c, String title, String sub, final int val, final int min, final int max, final int step, String suffix, final IntCb cb) {
        LinearLayout r = UI.hbox(this);
        LinearLayout t = UI.vbox(this);
        t.addView(UI.tv(this, title, 13, UI.TEXT, false));
        if (sub != null) t.addView(UI.tv(this, sub, 10, UI.MUTED, false));
        r.addView(t, UI.lpw(1f));
        r.addView(UI.btn(this, "−", UI.CARD2, UI.TEXT, v -> cb.on(Math.max(min, val - step))));
        TextView n = UI.tv(this, Fmt.fa(String.valueOf(val)) + suffix, 14, UI.PRIMARY, true);
        n.setGravity(Gravity.CENTER);
        n.setMinWidth(dp(56));
        r.addView(n);
        r.addView(UI.btn(this, "+", UI.CARD2, UI.TEXT, v -> cb.on(Math.min(max, val + step))));
        c.addView(r, UI.lp(this, -1, -2, 0, 6, 0, 6));
    }

    private EditText input(String hint, String text, final StrCb cb) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setHintTextColor(UI.MUTED);
        e.setTextColor(UI.TEXT);
        e.setTextSize(13);
        e.setSingleLine();
        e.setInputType(InputType.TYPE_CLASS_TEXT);
        e.setText(text);
        e.setBackground(UI.rr(this, UI.CARD2, 12));
        e.setPadding(dp(12), dp(10), dp(12), dp(10));
        e.setTextDirection(View.TEXT_DIRECTION_ANY_RTL);
        e.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void afterTextChanged(Editable s) { cb.on(s.toString()); }
        });
        return e;
    }

    private void numberRow(LinearLayout c, String label, String cur, StrCb cb) {
        c.addView(UI.tv(this, label, 13, UI.TEXT, false), UI.lp(this, -1, -2, 0, 10, 0, 4));
        c.addView(input("", cur, cb));
    }

    private void addOp() {
        String name = newName == null ? "" : newName.trim();
        String pkg = newPkg == null ? "" : newPkg.trim();
        if (name.isEmpty() || pkg.isEmpty() || name.length() > 40) {
            toast("نام اپراتور و نام پکیج معتبر (حداکثر ۴۰ نویسه برای نام) وارد کنید");
            return;
        }
        if (!Cfg.validPackageName(pkg)) {
            toast("نام پکیج معتبر نیست؛ نمونه: ir.example.app");
            return;
        }
        List<Op> l = Cfg.ops(this);
        for (Op existing : l) if (existing.pkgs.contains(pkg)) {
            toast("این پکیج قبلاً به «" + existing.name + "» اختصاص داده شده است");
            return;
        }
        int[] pal = {0xFF8B5CF6, 0xFFEC4899, 0xFF22C55E, 0xFFF97316, 0xFF06B6D4};
        String[] cur = {"AUTO", "IRR", "IRT"};
        l.add(new Op("c" + System.currentTimeMillis(), name, pal[l.size() % pal.length], cur[Math.max(0, Math.min(2, newCur))], false, pkg));
        Cfg.saveOps(this, l);
        newName = "";
        newPkg = "";
        render();
    }

    private void editOp(final Op o) {
        final EditText e = input("com.example.app, com.example.beta", TextUtils.join(", ", o.pkgs), s -> {});
        e.setTextDirection(View.TEXT_DIRECTION_LTR);
        FrameLayout f = new FrameLayout(this);
        f.setPadding(dp(20), dp(8), dp(20), 0);
        f.addView(e);
        final AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("پکیج‌های " + o.name)
                .setMessage("نام پکیج برنامه‌ها را با ویرگول جدا کنید.")
                .setView(f)
                .setPositiveButton("ذخیره", (dlg, w) -> {})
                .setNegativeButton("لغو", null)
                .create();
        dialog.setOnShowListener(v -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(button -> {
            List<String> proposed = new ArrayList<>();
            for (String raw : e.getText().toString().split("[,\\s]+")) {
                String value = raw.trim();
                if (value.isEmpty()) continue;
                if (!Cfg.validPackageName(value)) {
                    toast("نام پکیج نامعتبر است: " + value);
                    return;
                }
                if (proposed.contains(value)) {
                    toast("پکیج تکراری وارد شده است: " + value);
                    return;
                }
                for (Op other : Cfg.ops(this)) {
                    if (other != o && other.pkgs.contains(value)) {
                        toast("این پکیج به «" + other.name + "» اختصاص دارد: " + value);
                        return;
                    }
                }
                proposed.add(value);
            }
            if (proposed.isEmpty()) {
                toast("حداقل یک نام پکیج معتبر وارد کنید");
                return;
            }
            o.pkgs.clear();
            o.pkgs.addAll(proposed);
            Cfg.saveOps(this, Cfg.ops(this));
            dialog.dismiss();
            render();
        }));
        dialog.show();
    }

    // ---------------------------------------------------------------- export

    private static String csv(String value) {
        String safe = value == null ? "" : value.replace("\"", "\"\"");
        return "\"" + safe + "\"";
    }

    private void exportCsv() {
        final List<Pkg> all = Store.all(this);
        if (all.isEmpty()) {
            toast("داده‌ای برای خروجی نیست");
            return;
        }
        String ts = new SimpleDateFormat("MMdd_HHmmss", Locale.US).format(new Date());
        try {
            save("bastehyab_" + ts + ".csv", "text/csv", o -> {
                StringBuilder sb = new StringBuilder("\uFEFFoperator,title,gb,days,price_toman,price_with_vat_toman,vat_percent,currency_known,ambiguous,per_gb_toman,restricted,reason,review_note,captured\n");
                // one row per real package (operator + volume + duration + price), newest observation kept
                Map<String, Pkg> uniqueRows = new LinkedHashMap<>();
                for (Pkg p : all) {
                    if (p.op == null || p.op.isEmpty()) continue;
                    Pkg prev = uniqueRows.get(p.sig());
                    if (prev == null || p.ts > prev.ts) uniqueRows.put(p.sig(), p);
                }
                for (Pkg p : uniqueRows.values()) {
                    Op op = Cfg.opById(this, p.op);
                    sb.append(csv(op == null ? p.op : op.name)).append(',').append(csv(p.title)).append(',')
                            .append(p.gb).append(',').append(p.days).append(',')
                             .append(p.currencyKnown ? String.valueOf(p.toman) : "").append(',')
                            .append(p.currencyKnown ? String.valueOf(Cfg.finalPrice(this, p)) : "").append(',')
                            .append(Cfg.vat(this)).append(',')
                            .append(p.currencyKnown).append(',')
                            .append(p.ambig).append(',')
                            .append(p.currencyKnown && !p.ambig ? String.valueOf(Math.round(p.perGb())) : "").append(',')
                            .append(p.restricted).append(',').append(csv(p.why)).append(',')
                            .append(csv(p.note)).append(',')
                            .append(new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(new Date(p.ts))).append('\n');
                }
                o.write(sb.toString().getBytes(StandardCharsets.UTF_8));
            });
            toast("ذخیره شد در Downloads");
        } catch (Exception e) {
            toast(e.toString());
        }
    }

    private void exportDiag() {
        final File f = new File(getFilesDir(), "diag.txt");
        if (!f.exists()) {
            toast("هنوز گزارشی ساخته نشده؛ برنامه‌ی اپراتور را باز کنید و صفحه‌ی بسته‌ها را ببینید.");
            return;
        }
        ScanService.flushDiagnostics();
        String ts = new SimpleDateFormat("MMdd_HHmmss", Locale.US).format(new Date());
        try {
            save("diag_" + ts + ".txt", "text/plain", o -> {
                try (InputStream i = new FileInputStream(f)) {
                    byte[] buf = new byte[8192];
                    int n;
                    while ((n = i.read(buf)) > 0) o.write(buf, 0, n);
                }
            });
            toast("ذخیره شد در Downloads");
        } catch (Exception e) {
            toast(e.toString());
        }
    }

    private void save(String name, String mime, W w) throws Exception {
        ContentValues v = new ContentValues();
        v.put(MediaStore.Downloads.DISPLAY_NAME, name);
        v.put(MediaStore.Downloads.MIME_TYPE, mime);
        Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
        if (u == null) throw new java.io.IOException("ساخت فایل در Downloads ناموفق بود");
        try (OutputStream o = getContentResolver().openOutputStream(u)) {
            if (o == null) throw new java.io.IOException("دسترسی نوشتن به فایل خروجی برقرار نشد");
            w.w(o);
        } catch (Exception e) {
            getContentResolver().delete(u, null, null);
            throw e;
        }
    }
}
