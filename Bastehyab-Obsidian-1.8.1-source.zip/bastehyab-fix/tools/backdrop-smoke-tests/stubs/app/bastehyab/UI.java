package app.bastehyab; final class UI { static boolean light=false,mono=false; static int PRIMARY=0, BLUE=0, ACCENT=0; }
