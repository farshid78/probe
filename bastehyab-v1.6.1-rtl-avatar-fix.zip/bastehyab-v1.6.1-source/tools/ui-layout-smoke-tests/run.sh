#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
UI="$ROOT/app/src/main/java/app/bastehyab/UI.java"
MAIN="$ROOT/app/src/main/java/app/bastehyab/MainActivity.java"
SPLASH="$ROOT/app/src/main/java/app/bastehyab/SplashViews.java"
BUILD="$ROOT/app/build.gradle"
ASSET="$ROOT/app/src/main/res/drawable-nodpi/creator_avatar.jpg"

grep -q 'TEXT_ALIGNMENT_GRAVITY' "$UI"
! grep -q 'TEXT_ALIGNMENT_VIEW_START' "$UI"
grep -q 'pk.setTextDirection(View.TEXT_DIRECTION_RTL)' "$MAIN"
grep -q 'pkgInput.setTextDirection(View.TEXT_DIRECTION_LTR)' "$MAIN"
grep -q 'BitmapShader' "$SPLASH"
grep -q 'R.drawable.creator_avatar' "$SPLASH"
grep -q 'PersonAvatar(this), UI.lp(this, 66, 66' "$MAIN"
grep -q "versionName '1.6.1'" "$BUILD"
test -s "$ASSET"
echo 'PASS: RTL text alignment, mixed Persian/Latin direction, circular creator avatar, and version metadata.'
