# گزارش آزمون — بسته‌یاب 1.4.0

## آزمون‌های اجراشده

| تست | نتیجه | پوشش |
|---|---|---|
| `bash tools/parser-smoke-tests/run.sh` | PASS | نرمال‌سازی فارسی/عربی، null، ریال/تومان، واحد نامشخص، مبلغ رقیب، فیلتر editable/password/invisible، سقف درخت، کارت ناقص، تکراری، متن خام، فهرست تخت، ساعت خاص، رومینگ، حجم MB، VAT، تاریخچه، تشخیص چندعلتی و امضای بسته |
| `bash tools/android-core-smoke-tests/run.sh` | PASS | کامپایل هسته‌ی واقعی شامل Parser، Op، Cfg، Compare، ScanService و Store با test double؛ استخراج هدفمند، انتخاب فهرست عمودی، رد NaN/Infinity، اعتبارسنجی نام پکیج و استقلال فیلتر رومینگ از بسته‌های ویژه‌ی داخلی |
| XML parse | پیش‌تر PASS | ساختار XML منابع و Manifest |
| بررسی نسخه | PASS | `versionCode=14` و `versionName=1.4.0` |
| جست‌وجوی دکمه‌ی مستقل | PASS | عبارت دکمه‌ی قدیمی در کد اجرایی MainActivity وجود ندارد؛ عبارت تاریخی فقط در changelog باقی مانده است |

تست `tools/dump-replay/run.sh` بدون آرگومان اجرا نمی‌شود و برای اجرا به مسیر dump، شناسه‌ی پکیج و واحد پول نیاز دارد؛ در ZIP ورودی dump خام قابل replay همراه فایل‌ها نبود، بنابراین آن را به‌عنوان تست موفق گزارش نمی‌کنیم.

## مواردی که اجرا نشده‌اند

- `assembleDebug`, `assembleRelease`, `lint`, Android Studio Sync و `gradle test`.
- Emulator، Android instrumentation، Espresso و تست روی گوشی واقعی.
- تست عملی ورود به اپ‌های رسمی ایرانسل، همراه اول، رایتل و سامانتل با نسخه‌های منتشرشده فعلی.
- بررسی رفتار انواع WebView، صفحه‌های چندپنجره‌ای، محتوای lazy-load و carousel در Accessibility واقعی.
- اندازه‌گیری CPU، حافظه، مصرف باتری و دوام طولانی‌مدت.
- محاسبه precision/recall و ارائه‌ی ادعای دقت عددی.
- Play Protect و امضای Release.

## علت عدم ساخت APK

در محیط حاضر `gradle`، `adb` و `sdkmanager` موجود نیستند؛ `ANDROID_HOME` هم تنظیم نشده و Gradle Wrapper در سورس ورودی قرار ندارد. بدون Gradle و Android SDK نمی‌توان خروجی APK را معتبر ساخت یا از صحت نصب/اجرا اطمینان داد. Java 21 نصب است، ولی این جایگزین زنجیره‌ی ساخت Android نیست.
