package app.bastehyab;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.view.View;

/** Custom drawing for the opening / creator screen. Purely visual; no touch handling. */
final class SplashViews {
    private SplashViews() { }

    static float dp(View v, float value) {
        return value * v.getResources().getDisplayMetrics().density;
    }

    /** Deep cyber-network backdrop: fine grid, connected nodes and restrained data glows. */
    static final class Backdrop extends View {
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint grid = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint links = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint nodes = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint rings = new Paint(Paint.ANTI_ALIAS_FLAG);

        private final float[][] points = {
                {0.06f,0.19f},{0.18f,0.10f},{0.31f,0.20f},{0.46f,0.08f},{0.61f,0.18f},
                {0.78f,0.09f},{0.93f,0.22f},{0.10f,0.43f},{0.25f,0.37f},{0.42f,0.49f},
                {0.62f,0.39f},{0.83f,0.48f},{0.96f,0.40f},{0.06f,0.69f},{0.23f,0.79f},
                {0.39f,0.67f},{0.58f,0.82f},{0.75f,0.69f},{0.93f,0.82f},{0.48f,0.94f}
        };
        private final int[][] edges = {
                {0,1},{1,2},{2,3},{3,4},{4,5},{5,6},{0,7},{7,8},{8,2},{8,9},
                {9,10},{10,4},{10,11},{11,12},{7,13},{13,14},{14,15},{15,9},{15,16},
                {16,17},{17,11},{17,18},{16,19}
        };

        Backdrop(Context c) {
            super(c);
            grid.setStyle(Paint.Style.STROKE);
            grid.setStrokeWidth(dp(this, 0.7f));
            grid.setColor(0x142D9DB0);
            links.setStyle(Paint.Style.STROKE);
            links.setStrokeWidth(dp(this, 1.0f));
            links.setColor(0x3541AFC2);
            nodes.setColor(0x8864DCEB);
            rings.setStyle(Paint.Style.STROKE);
            rings.setStrokeWidth(dp(this, 1.1f));
            rings.setColor(0x224E98D8);
        }

        @Override protected void onDraw(Canvas cv) {
            float w = getWidth(), h = getHeight();
            if (w <= 0 || h <= 0) return;
            fill.setShader(new LinearGradient(0, 0, w, h,
                    new int[]{0xFF050B16, 0xFF0B1A30, 0xFF070F20}, null, Shader.TileMode.CLAMP));
            cv.drawRect(0, 0, w, h, fill);
            fill.setShader(new RadialGradient(w * 0.82f, h * 0.18f, dp(this, 330),
                    new int[]{0x453B75C7, 0x003B75C7}, null, Shader.TileMode.CLAMP));
            cv.drawRect(0, 0, w, h, fill);
            fill.setShader(new RadialGradient(w * 0.12f, h * 0.78f, dp(this, 300),
                    new int[]{0x3823BEBB, 0x0023BEBB}, null, Shader.TileMode.CLAMP));
            cv.drawRect(0, 0, w, h, fill);

            float step = dp(this, 44);
            for (float x = 0; x < w; x += step) cv.drawLine(x, 0, x, h, grid);
            for (float y = 0; y < h; y += step) cv.drawLine(0, y, w, y, grid);

            for (int[] edge : edges) {
                float x1 = points[edge[0]][0] * w, y1 = points[edge[0]][1] * h;
                float x2 = points[edge[1]][0] * w, y2 = points[edge[1]][1] * h;
                cv.drawLine(x1, y1, x2, y2, links);
            }
            for (int i = 0; i < points.length; i++) {
                float x = points[i][0] * w, y = points[i][1] * h;
                cv.drawCircle(x, y, dp(this, i % 4 == 0 ? 2.4f : 1.5f), nodes);
            }

            float cx = w * 0.5f, cy = h * 0.35f;
            cv.drawCircle(cx, cy, dp(this, 112), rings);
            cv.drawCircle(cx, cy, dp(this, 126), rings);
            cv.drawCircle(cx, cy, dp(this, 140), rings);
            rings.setColor(0x164AD8D0);
            cv.drawArc(cx - dp(this, 158), cy - dp(this, 158), cx + dp(this, 158), cy + dp(this, 158),
                    208, 112, false, rings);
        }
    }

    /** Hexagon ring with a gradient stroke, used behind the app logo. */
    static final class HexBadge extends View {
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);

        HexBadge(Context c) {
            super(c);
            stroke.setStyle(Paint.Style.STROKE);
            stroke.setStrokeWidth(dp(this, 2));
        }

        @Override protected void onDraw(Canvas cv) {
            float w = getWidth(), h = getHeight();
            float r = Math.min(w, h) / 2f - dp(this, 4);
            Path p = hex(w / 2f, h / 2f, r);
            fill.setShader(new LinearGradient(0, 0, w, h,
                    new int[]{0x334AD8D0, 0x203D65C5}, null, Shader.TileMode.CLAMP));
            cv.drawPath(p, fill);
            stroke.setShader(new LinearGradient(0, 0, w, h,
                    new int[]{0xFF4AD8D0, 0xFF668BFF}, null, Shader.TileMode.CLAMP));
            cv.drawPath(p, stroke);
        }

        static Path hex(float cx, float cy, float r) {
            Path p = new Path();
            for (int i = 0; i < 6; i++) {
                double a = Math.PI / 3 * i - Math.PI / 6;
                float x = (float) (cx + r * Math.cos(a));
                float y = (float) (cy + r * Math.sin(a));
                if (i == 0) p.moveTo(x, y); else p.lineTo(x, y);
            }
            p.close();
            return p;
        }
    }

    /** Accent circle with a paper-plane glyph (Telegram-style). */
    static final class PlaneIcon extends View {
        private final Paint circle = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint glyph = new Paint(Paint.ANTI_ALIAS_FLAG);

        PlaneIcon(Context c) {
            super(c);
            glyph.setColor(0xFF06241C);
        }

        @Override protected void onDraw(Canvas cv) {
            float w = getWidth(), h = getHeight();
            circle.setShader(new LinearGradient(0, 0, w, h,
                    new int[]{0xFF4AD8D0, 0xFF668BFF}, null, Shader.TileMode.CLAMP));
            cv.drawCircle(w / 2f, h / 2f, Math.min(w, h) / 2f, circle);
            Path p = new Path();
            p.moveTo(w * 0.24f, h * 0.48f);
            p.lineTo(w * 0.78f, h * 0.26f);
            p.lineTo(w * 0.62f, h * 0.76f);
            p.lineTo(w * 0.47f, h * 0.60f);
            p.close();
            cv.drawPath(p, glyph);
            Path fold = new Path();
            fold.moveTo(w * 0.47f, h * 0.60f);
            fold.lineTo(w * 0.78f, h * 0.26f);
            fold.lineTo(w * 0.50f, h * 0.66f);
            fold.close();
            cv.drawPath(fold, glyph);
        }
    }

    /** Creator avatar: gradient disc with a person silhouette and a thin accent ring. */
    static final class PersonAvatar extends View {
        private final Paint disc = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint figure = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);

        PersonAvatar(Context c) {
            super(c);
            figure.setColor(0xFFF0F6FF);
            ring.setStyle(Paint.Style.STROKE);
            ring.setStrokeWidth(dp(this, 1.5f));
            ring.setColor(0x9964DCEB);
        }

        @Override protected void onDraw(Canvas cv) {
            float w = getWidth(), h = getHeight();
            float r = Math.min(w, h) / 2f;
            disc.setShader(new LinearGradient(0, 0, w, h,
                    new int[]{0xFF1B4D6B, 0xFF0F2A44}, null, Shader.TileMode.CLAMP));
            cv.drawCircle(w / 2f, h / 2f, r, disc);
            cv.drawCircle(w / 2f, h / 2f, r - dp(this, 3), ring);
            // head
            cv.drawCircle(w / 2f, h * 0.38f, w * 0.17f, figure);
            // shoulders (upper half-ellipse)
            android.graphics.RectF body = new android.graphics.RectF(w * 0.22f, h * 0.58f, w * 0.78f, h * 1.12f);
            Path shoulders = new Path();
            shoulders.addArc(body, 180, 180);
            shoulders.close();
            cv.drawPath(shoulders, figure);
        }
    }
}
