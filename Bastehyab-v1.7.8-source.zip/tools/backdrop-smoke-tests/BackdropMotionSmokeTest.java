package app.bastehyab;

import android.content.Context;
import android.graphics.Canvas;
import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.List;

/** JVM smoke test for the background particle field; no Android SDK or device is required. */
public final class BackdropMotionSmokeTest {
    private static void check(boolean value, String message) {
        if (!value) throw new AssertionError(message);
    }

    private static final class Probe extends SplashViews.AppBackdrop {
        Probe(Context context) { super(context); }
        void sizeScene() { onSizeChanged(1080, 2340, 0, 0); }
        void drawFrame(Canvas canvas) { onDraw(canvas); }
    }

    private static Field findField(Class<?> type, String name) throws NoSuchFieldException {
        for (Class<?> current = type; current != null; current = current.getSuperclass()) {
            try { return current.getDeclaredField(name); }
            catch (NoSuchFieldException ignored) { /* inspect parent */ }
        }
        throw new NoSuchFieldException(name);
    }

    private static Method findMethod(Class<?> type, String name, Class<?>... parameters)
            throws NoSuchMethodException {
        for (Class<?> current = type; current != null; current = current.getSuperclass()) {
            try { return current.getDeclaredMethod(name, parameters); }
            catch (NoSuchMethodException ignored) { /* inspect parent */ }
        }
        throw new NoSuchMethodException(name);
    }

    private static Object field(Object target, String name) throws Exception {
        Field f = findField(target.getClass(), name);
        f.setAccessible(true);
        return f.get(target);
    }

    private static float position(Object target, String method, Object particle,
                                  float phase, float extent) throws Exception {
        Method m = findMethod(target.getClass(), method,
                particle.getClass(), float.class, float.class);
        m.setAccessible(true);
        return ((Number)m.invoke(target, particle, phase, extent)).floatValue();
    }

    public static void main(String[] args) throws Exception {
        Probe view = new Probe(new Context());
        view.sizeScene();

        Object snow = field(view, "snow");
        Object fire = field(view, "fire");
        check(Array.getLength(snow) == 24, "the scene should contain 24 independently moving snowflakes");
        check(Array.getLength(fire) == 20, "the scene should contain 20 independently moving flames");

        @SuppressWarnings("unchecked")
        List<Object> impacts = (List<Object>)field(view, "impacts");
        check(impacts.size() >= 8 && impacts.size() <= 18,
                "the loop should contain a controlled number of separated collision events");

        Object firstSnow = Array.get(snow, 0);
        float x0 = position(view, "particleX", firstSnow, 0f, 1080f);
        float y0 = position(view, "particleY", firstSnow, 0f, 2340f);
        float xQuarter = position(view, "particleX", firstSnow, .25f, 1080f);
        float yQuarter = position(view, "particleY", firstSnow, .25f, 2340f);
        float xLoop = position(view, "particleX", firstSnow, 1f, 1080f);
        float yLoop = position(view, "particleY", firstSnow, 1f, 2340f);
        check(Math.abs(xQuarter - x0) > 3f, "particles must move horizontally rather than follow one vertical lane");
        check(Math.abs(yQuarter - y0) > 3f, "particles must move vertically on an independent axis");
        check(Math.abs(xLoop - x0) < .01f && Math.abs(yLoop - y0) < .01f,
                "the particle paths must close cleanly at the loop seam");

        view.startAnimation();
        view.drawFrame(new Canvas());
        view.stopAnimation();
        System.out.println("BackdropMotionSmokeTest: PASS (44 particles, "
                + impacts.size() + " randomized 2D collision events, seamless loop)");
    }
}
