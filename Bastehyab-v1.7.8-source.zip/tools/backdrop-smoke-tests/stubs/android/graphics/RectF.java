package android.graphics; public class RectF { public RectF(float a,float b,float c,float d){} public RectF(RectF r){} public void offset(float x,float y){} public void inset(float x,float y){} }
