package app.bastehyab; final class R { static final class drawable { static final int brand_mark=1,creator_avatar=2; } }
