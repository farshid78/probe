package app.bastehyab; final class UI { static boolean light=false,mono=false; static int ICE=0, FIRE=0, PRIMARY=0, BLUE=0; }
