package app.bastehyab;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapShader;
import android.graphics.Matrix;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.view.View;

/** Custom drawing for the opening / creator screen. Purely visual; no touch handling. */
final class SplashViews {
    private SplashViews() { }

    static float dp(View v, float value) {
        return value * v.getResources().getDisplayMetrics().density;
    }

    /** Backward-compatible splash background; shares the live ice/fire scene. */
    static final class Backdrop extends AppBackdrop {
        Backdrop(Context c) { super(c); }
    }

    /**
     * Lightweight animated wallpaper. Snowflakes and sculpted flames float freely on
     * independent two-dimensional paths. Organic close encounters trigger brief glints,
     * ice splinters and tapered embers that fall behind the UI. The view uses display
     * vsync for frame scheduling and a deterministic, seam-free motion cycle.
     */
    static class AppBackdrop extends View {
        private static final long LOOP_MS = 18000L;
        private static final int PAIRED_COUNT = 12;
        private static final int SNOW_COUNT = 24;
        private static final int FIRE_COUNT = 20;
        private static final int MAX_IMPACTS = 18;
        private static final long MIN_IMPACT_GAP_MS = 780L;
        private static final long SHARD_LIFE_MS = 1650L;
        private static final int COLLISION_SAMPLES = 600;

        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint detail = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint shardPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path wave = new Path();
        private final Path flamePath = new Path();
        private final Path coreFlamePath = new Path();
        private final Path shardPath = new Path();
        private Shader backgroundShader, iceGlowShader, fireGlowShader;
        private boolean animationRunning;
        private long animationOrigin;
        private float density;
        private Particle[] snow = new Particle[0];
        private Particle[] fire = new Particle[0];
        private final java.util.ArrayList<Impact> impacts = new java.util.ArrayList<>();

        private static final class Particle {
            final float cx, cy, ax, ay, wobbleX, wobbleY;
            final float phaseX, phaseY, phaseAlpha, size, spin;
            final int fx, fy;
            float x, y, angle;
            Particle(float cx, float cy, float ax, float ay,
                     float wobbleX, float wobbleY, float phaseX, float phaseY,
                     float phaseAlpha, float size, float spin, int fx, int fy) {
                this.cx = cx; this.cy = cy; this.ax = ax; this.ay = ay;
                this.wobbleX = wobbleX; this.wobbleY = wobbleY;
                this.phaseX = phaseX; this.phaseY = phaseY; this.phaseAlpha = phaseAlpha;
                this.size = size; this.spin = spin; this.fx = fx; this.fy = fy;
            }
        }

        private static final class Shard {
            final float vx, vy, gravity, size, rotation, rotationSpeed, delay;
            final boolean icy;
            Shard(float vx, float vy, float gravity, float size, float rotation,
                  float rotationSpeed, float delay, boolean icy) {
                this.vx = vx; this.vy = vy; this.gravity = gravity; this.size = size;
                this.rotation = rotation; this.rotationSpeed = rotationSpeed;
                this.delay = delay; this.icy = icy;
            }
        }

        private static final class Impact {
            final long atMs;
            final float x, y;
            final Shard[] shards;
            final float flashPhase;
            Impact(long atMs, float x, float y, Shard[] shards, float flashPhase) {
                this.atMs = atMs; this.x = x; this.y = y;
                this.shards = shards; this.flashPhase = flashPhase;
            }
        }

        AppBackdrop(Context c) {
            super(c);
            density = getResources().getDisplayMetrics().density;
            setWillNotDraw(false);
            setLayerType(View.LAYER_TYPE_HARDWARE, null);
            detail.setStyle(Paint.Style.STROKE);
            detail.setStrokeCap(Paint.Cap.ROUND);
            detail.setStrokeJoin(Paint.Join.ROUND);
            shardPaint.setStyle(Paint.Style.FILL);
        }

        @Override protected void onSizeChanged(int width, int height, int oldWidth, int oldHeight) {
            super.onSizeChanged(width, height, oldWidth, oldHeight);
            rebuildShaders(width, height);
            buildParticleField(width, height);
        }

        void refreshTheme() {
            rebuildShaders(getWidth(), getHeight());
            invalidate();
        }

        private void rebuildShaders(int width, int height) {
            if (width <= 0 || height <= 0) return;
            backgroundShader = new LinearGradient(0, 0, width, height,
                    UI.light ? new int[]{0xFFF1F6F9, 0xFFE6EEF3, 0xFFDDE7ED}
                            : UI.mono ? new int[]{0xFF090A0C, 0xFF17191D, 0xFF25282E}
                            : new int[]{0xFF071521, 0xFF0D1D2A, 0xFF1B1C20},
                    null, Shader.TileMode.CLAMP);
            iceGlowShader = new RadialGradient(width * .09f, height * .17f, dp(this, 390),
                    UI.mono ? new int[]{0x329CA8B5, 0x009CA8B5}
                            : new int[]{0x4855B9E7, 0x0055B9E7}, null, Shader.TileMode.CLAMP);
            fireGlowShader = new RadialGradient(width * .91f, height * .79f, dp(this, 420),
                    UI.mono ? new int[]{0x26858B95, 0x00858B95}
                            : new int[]{0x43F07B45, 0x00F07B45}, null, Shader.TileMode.CLAMP);
        }

        private void buildParticleField(int width, int height) {
            java.util.Random random = new java.util.Random(0xBA57E7A5L + width * 31L + height);
            snow = new Particle[SNOW_COUNT];
            fire = new Particle[FIRE_COUNT];
            float[] pairedX = new float[PAIRED_COUNT];
            float[] pairedY = new float[PAIRED_COUNT];
            for (int i = 0; i < PAIRED_COUNT; i++) {
                pairedX[i] = between(random, .10f, .90f);
                pairedY[i] = between(random, .10f, .90f);
            }
            for (int i = 0; i < SNOW_COUNT; i++) {
                float cx = i < PAIRED_COUNT ? pairedX[i] : between(random, .07f, .93f);
                float cy = i < PAIRED_COUNT ? pairedY[i] : between(random, .07f, .93f);
                snow[i] = makeParticle(random, cx, cy, true, i >= PAIRED_COUNT);
            }
            for (int i = 0; i < FIRE_COUNT; i++) {
                float cx = i < PAIRED_COUNT ? pairedX[i] + between(random, -.012f, .012f)
                        : between(random, .07f, .93f);
                float cy = i < PAIRED_COUNT ? pairedY[i] + between(random, -.012f, .012f)
                        : between(random, .07f, .93f);
                fire[i] = makeParticle(random, cx, cy, false, i >= PAIRED_COUNT);
            }
            buildImpactTimeline(width, height, random);
        }

        private Particle makeParticle(java.util.Random random, float cx, float cy,
                                      boolean icy, boolean freeFloating) {
            float spread = freeFloating ? 1.0f : .82f;
            float ax = between(random, .025f, .078f) * spread;
            float ay = between(random, .022f, .075f) * spread;
            return new Particle(cx, cy, ax, ay,
                    between(random, .003f, .019f), between(random, .003f, .018f),
                    between(random, 0f, (float)(Math.PI * 2)),
                    between(random, 0f, (float)(Math.PI * 2)),
                    between(random, 0f, (float)(Math.PI * 2)),
                    icy ? between(random, 3.2f, 5.2f) : between(random, 4.6f, 7.0f),
                    between(random, -.9f, .9f), 1 + random.nextInt(4), 1 + random.nextInt(4));
        }

        private static float between(java.util.Random r, float min, float max) {
            return min + r.nextFloat() * (max - min);
        }

        private float particleX(Particle item, float phase, float width) {
            double a = phase * Math.PI * 2.0;
            return item.cx * width
                    + item.ax * width * (float)Math.sin(a * item.fx + item.phaseX)
                    + item.wobbleX * width * (float)Math.sin(a * (item.fx + item.fy) + item.phaseY * .71f);
        }

        private float particleY(Particle item, float phase, float height) {
            double a = phase * Math.PI * 2.0;
            return item.cy * height
                    + item.ay * height * (float)Math.cos(a * item.fy + item.phaseY)
                    + item.wobbleY * height * (float)Math.sin(a * (item.fx + item.fy) + item.phaseX * .83f);
        }

        private void buildImpactTimeline(int width, int height, java.util.Random random) {
            impacts.clear();
            if (width <= 0 || height <= 0) return;
            java.util.ArrayList<Impact> candidates = new java.util.ArrayList<>();
            float contactDistance = dp(this, 11.5f);
            float contactSquared = contactDistance * contactDistance;
            for (int pair = 0; pair < PAIRED_COUNT; pair++) {
                Particle ice = snow[pair];
                Particle ember = fire[pair];
                float previous = Float.MAX_VALUE;
                for (int sample = 0; sample <= COLLISION_SAMPLES; sample++) {
                    float phase = sample / (float) COLLISION_SAMPLES;
                    float dx = particleX(ice, phase, width) - particleX(ember, phase, width);
                    float dy = particleY(ice, phase, height) - particleY(ember, phase, height);
                    float distanceSquared = dx * dx + dy * dy;
                    if (sample > 0 && sample < COLLISION_SAMPLES && distanceSquared <= contactSquared) {
                        float nextPhase = (sample + 1) / (float) COLLISION_SAMPLES;
                        float ndx = particleX(ice, nextPhase, width) - particleX(ember, nextPhase, width);
                        float ndy = particleY(ice, nextPhase, height) - particleY(ember, nextPhase, height);
                        float nextDistanceSquared = ndx * ndx + ndy * ndy;
                        if (distanceSquared <= previous && distanceSquared <= nextDistanceSquared) {
                            float x = (particleX(ice, phase, width) + particleX(ember, phase, width)) * .5f;
                            float y = (particleY(ice, phase, height) + particleY(ember, phase, height)) * .5f;
                            long at = Math.round(phase * LOOP_MS);
                            candidates.add(makeImpact(random, at, x, y));
                        }
                    }
                    previous = distanceSquared;
                }
            }
            java.util.Collections.sort(candidates, (a, b) -> Long.compare(a.atMs, b.atMs));
            long lastAt = -MIN_IMPACT_GAP_MS;
            for (Impact event : candidates) {
                if (event.atMs - lastAt < MIN_IMPACT_GAP_MS) continue;
                impacts.add(event);
                lastAt = event.atMs;
                if (impacts.size() >= MAX_IMPACTS) break;
            }
        }

        private Impact makeImpact(java.util.Random random, long at, float x, float y) {
            Shard[] pieces = new Shard[10];
            for (int i = 0; i < pieces.length; i++) {
                boolean icy = (i & 1) == 0;
                pieces[i] = new Shard(
                        between(random, -72f, 72f), between(random, -38f, 32f),
                        between(random, 92f, 158f), between(random, 1.8f, 3.8f),
                        between(random, 0f, (float)(Math.PI * 2)),
                        between(random, -8f, 8f), between(random, 0f, .12f), icy);
            }
            return new Impact(at, x, y, pieces, between(random, 0f, (float)(Math.PI * 2)));
        }

        void startAnimation() {
            if (animationRunning) return;
            animationRunning = true;
            animationOrigin = android.os.SystemClock.uptimeMillis();
            postInvalidateOnAnimation();
        }

        void stopAnimation() {
            animationRunning = false;
        }

        @Override protected void onDetachedFromWindow() {
            stopAnimation();
            super.onDetachedFromWindow();
        }

        @Override protected void onDraw(Canvas cv) {
            super.onDraw(cv);
            float w = getWidth(), h = getHeight();
            if (w <= 0 || h <= 0) return;
            p.setShader(backgroundShader);
            cv.drawRect(0, 0, w, h, p);
            p.setShader(iceGlowShader);
            cv.drawRect(0, 0, w, h, p);
            p.setShader(fireGlowShader);
            cv.drawRect(0, 0, w, h, p);
            p.setShader(null);

            // Gentle ambient ribbons keep the icy/ember atmosphere without competing with cards.
            detail.setStrokeWidth(dp(this, .9f));
            detail.setColor(UI.mono ? 0x174B525C : 0x1B77BBD7);
            wave.reset(); wave.moveTo(-w*.08f, h*.27f);
            wave.cubicTo(w*.24f, h*.12f, w*.60f, h*.39f, w*1.08f, h*.20f);
            cv.drawPath(wave, detail);
            detail.setColor(UI.mono ? 0x153F454E : 0x19F18455);
            wave.reset(); wave.moveTo(-w*.08f, h*.73f);
            wave.cubicTo(w*.34f, h*.88f, w*.69f, h*.61f, w*1.08f, h*.80f);
            cv.drawPath(wave, detail);

            long elapsed = animationRunning
                    ? Math.max(0L, android.os.SystemClock.uptimeMillis() - animationOrigin) : 0L;
            float phase = (elapsed % LOOP_MS) / (float) LOOP_MS;
            for (Particle item : snow) drawSnowflake(cv, item, phase, w, h, elapsed);
            for (Particle item : fire) drawFlame(cv, item, phase, w, h, elapsed);
            drawImpacts(cv, elapsed, w, h);

            if (animationRunning && isShown() && getWindowVisibility() == View.VISIBLE) {
                // Android schedules this on the next display vsync, avoiding timer jitter.
                postInvalidateOnAnimation();
            }
        }

        private int iceColor() {
            return UI.mono ? 0xFFD6DCE4 : UI.light ? 0xFF78BBD6 : 0xFF8BE3FA;
        }

        private int fireColor() {
            return UI.mono ? 0xFFADB5C0 : UI.light ? 0xFFE09A70 : 0xFFFF925F;
        }

        private void drawSnowflake(Canvas cv, Particle item, float phase, float w, float h, long elapsed) {
            float x = particleX(item, phase, w);
            float y = particleY(item, phase, h);
            float next = (phase + .0015f) % 1f;
            float nx = particleX(item, next, w), ny = particleY(item, next, h);
            float motionAngle = (float)Math.toDegrees(Math.atan2(ny - y, nx - x));
            float r = dp(this, item.size) * (1f + .07f * (float)Math.sin(elapsed * .0013 + item.phaseAlpha));
            int color = iceColor();
            int alpha = UI.mono ? 86 : 104 + Math.round(38f * (.5f + .5f * (float)Math.sin(elapsed * .0011 + item.phaseAlpha)));

            glow.setStyle(Paint.Style.FILL);
            glow.setColor(withAlpha(color, alpha / 7));
            cv.drawCircle(x, y, r * 2.0f, glow);
            detail.setStyle(Paint.Style.STROKE);
            detail.setStrokeWidth(dp(this, .85f));
            detail.setColor(withAlpha(color, alpha));
            cv.save();
            cv.rotate(motionAngle + item.spin * (float)(elapsed * .00005), x, y);
            for (int arm = 0; arm < 6; arm++) {
                float a = (float)(Math.PI * arm / 3.0);
                float ex = x + (float)Math.cos(a) * r;
                float ey = y + (float)Math.sin(a) * r;
                cv.drawLine(x, y, ex, ey, detail);
                float bx = x + (float)Math.cos(a) * r * .63f;
                float by = y + (float)Math.sin(a) * r * .63f;
                float branch = r * .31f;
                float left = a - .72f, right = a + .72f;
                cv.drawLine(bx, by, bx - (float)Math.cos(left) * branch, by - (float)Math.sin(left) * branch, detail);
                cv.drawLine(bx, by, bx - (float)Math.cos(right) * branch, by - (float)Math.sin(right) * branch, detail);
            }
            detail.setStyle(Paint.Style.FILL);
            cv.drawCircle(x, y, Math.max(dp(this, .55f), r * .12f), detail);
            cv.restore();
        }

        private void drawFlame(Canvas cv, Particle item, float phase, float w, float h, long elapsed) {
            float x = particleX(item, phase, w);
            float y = particleY(item, phase, h);
            float next = (phase + .0018f) % 1f;
            float nx = particleX(item, next, w), ny = particleY(item, next, h);
            float direction = (float)Math.toDegrees(Math.atan2(ny - y, nx - x));
            float flicker = 1f + .12f * (float)Math.sin(elapsed * .009f + item.phaseAlpha);
            float r = dp(this, item.size) * flicker;
            int color = fireColor();
            int alpha = UI.mono ? 76 : 88 + Math.round(34f * (.5f + .5f * (float)Math.sin(elapsed * .008f + item.phaseAlpha)));
            glow.setStyle(Paint.Style.FILL);
            glow.setColor(withAlpha(color, alpha / 7));
            cv.drawCircle(x, y, r * 2.4f, glow);

            cv.save();
            cv.rotate(direction * .22f + item.spin * 12f, x, y);
            flamePath.reset();
            flamePath.moveTo(x, y + r * 1.02f);
            flamePath.cubicTo(x - r * 1.22f, y + r * .45f, x - r * .60f, y - r * .52f,
                    x - r * .03f, y - r * 1.12f);
            flamePath.cubicTo(x + r * .04f, y - r * .63f, x + r * 1.02f, y - r * .35f,
                    x + r * .83f, y + r * .38f);
            flamePath.cubicTo(x + r * .75f, y + r * .92f, x + r * .25f, y + r * 1.04f,
                    x, y + r * 1.02f);
            flamePath.close();
            p.setStyle(Paint.Style.FILL);
            p.setColor(withAlpha(color, alpha));
            cv.drawPath(flamePath, p);

            coreFlamePath.reset();
            coreFlamePath.moveTo(x + r * .02f, y + r * .70f);
            coreFlamePath.cubicTo(x - r * .42f, y + r * .28f, x - r * .16f, y - r * .28f,
                    x + r * .18f, y - r * .62f);
            coreFlamePath.cubicTo(x + r * .17f, y - r * .20f, x + r * .55f, y + r * .18f,
                    x + r * .02f, y + r * .70f);
            coreFlamePath.close();
            p.setColor(withAlpha(UI.mono ? 0xFFE6E8EC : 0xFFFFD18A, Math.max(20, alpha - 25)));
            cv.drawPath(coreFlamePath, p);
            cv.restore();
        }

        private void drawImpacts(Canvas cv, long elapsed, float w, float h) {
            int ice = iceColor(), fireColor = fireColor();
            for (Impact event : impacts) {
                long ageMs = (elapsed - event.atMs + LOOP_MS) % LOOP_MS;
                if (ageMs >= SHARD_LIFE_MS) continue;
                float age = ageMs / 1000f;
                float flash = Math.max(0f, 1f - ageMs / 190f);
                if (flash > 0f) {
                    glow.setStyle(Paint.Style.FILL);
                    glow.setColor(withAlpha(UI.mono ? 0xFFE7EBF0 : 0xFFFFD8B0, Math.round(80f * flash)));
                    cv.drawCircle(event.x, event.y, dp(this, 3f + 14f * (1f - flash)), glow);
                    detail.setStyle(Paint.Style.STROKE);
                    detail.setStrokeWidth(dp(this, .8f));
                    detail.setColor(withAlpha(ice, Math.round(145f * flash)));
                    for (int ray = 0; ray < 7; ray++) {
                        float a = ray * 2.3999632f + event.flashPhase;
                        float inner = dp(this, 5f + ray % 3);
                        float outer = inner + dp(this, 3f + ray % 4);
                        cv.drawLine(event.x + (float)Math.cos(a) * inner,
                                event.y + (float)Math.sin(a) * inner,
                                event.x + (float)Math.cos(a) * outer,
                                event.y + (float)Math.sin(a) * outer, detail);
                    }
                }
                for (Shard piece : event.shards) {
                    float t = age - piece.delay;
                    if (t < 0f) continue;
                    float x = event.x + dp(this, piece.vx * t)
                            + dp(this, 2.5f) * (float)Math.sin(t * 8f + piece.rotation);
                    float y = event.y + dp(this, piece.vy * t + .5f * piece.gravity * t * t);
                    if (x < -dp(this, 20) || x > w + dp(this, 20) || y < -dp(this, 20) || y > h + dp(this, 12)) continue;
                    float fade = Math.max(0f, 1f - t / (SHARD_LIFE_MS / 1000f));
                    float groundFade = Math.min(1f, Math.max(0f, (h - y) / dp(this, 28f)));
                    int color = piece.icy ? ice : fireColor;
                    shardPaint.setColor(withAlpha(color, Math.round((piece.icy ? 145f : 170f) * fade * groundFade)));
                    float rotation = piece.rotation + piece.rotationSpeed * t
                            + (float)Math.toDegrees(Math.atan2(piece.vy + piece.gravity * t, piece.vx));
                    cv.save();
                    cv.rotate(rotation, x, y);
                    if (piece.icy) {
                        float size = dp(this, piece.size);
                        shardPath.reset();
                        shardPath.moveTo(0, -size * 1.35f);
                        shardPath.lineTo(size * .42f, size * .25f);
                        shardPath.lineTo(0, size * .78f);
                        shardPath.lineTo(-size * .34f, size * .22f);
                        shardPath.close();
                        cv.drawPath(shardPath, shardPaint);
                    } else {
                        float size = dp(this, piece.size);
                        flamePath.reset();
                        flamePath.moveTo(0, -size * 1.35f);
                        flamePath.cubicTo(size * .90f, -size * .35f, size * .58f, size * .72f,
                                0, size * .82f);
                        flamePath.cubicTo(-size * .56f, size * .62f, -size * .88f, -size * .25f,
                                0, -size * 1.35f);
                        flamePath.close();
                        cv.drawPath(flamePath, shardPaint);
                    }
                    cv.restore();
                }
            }
        }

        private static int withAlpha(int color, int alpha) {
            return (Math.max(0, Math.min(255, alpha)) << 24) | (color & 0x00FFFFFF);
        }
    }

    /** Original Bastehyab brand mark, shared with the launcher icon. */
    static final class BrandMark extends View {
        private final Paint imagePaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        private final Paint shadowPaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        private final Bitmap mark;
        BrandMark(Context c) {
            super(c);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
            shadowPaint.setColor(0xFFFFFFFF);
            shadowPaint.setShadowLayer(dp(this, 10), 0, dp(this, 5), UI.mono ? 0xAA000000 : 0xAA050B18);
            Bitmap decoded = BitmapFactory.decodeResource(c.getResources(), R.drawable.brand_mark);
            mark = decoded;
        }
        @Override protected void onDraw(Canvas c) {
            if (mark == null || getWidth() <= 0 || getHeight() <= 0) return;
            float side = Math.min(getWidth(), getHeight()) * .94f;
            android.graphics.RectF dst = new android.graphics.RectF(
                    (getWidth() - side) * .5f, (getHeight() - side) * .5f,
                    (getWidth() + side) * .5f, (getHeight() + side) * .5f);
            android.graphics.RectF shadow = new android.graphics.RectF(dst);
            shadow.offset(0, dp(this, 2.5f));
            c.drawBitmap(mark, null, shadow, shadowPaint);
            c.drawBitmap(mark, null, dst, imagePaint);
        }
    }

    /** Soft rounded logo halo with a ice-blue and ember edge light. */
    static final class LogoHalo extends View {
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);

        LogoHalo(Context c) {
            super(c);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
            stroke.setStyle(Paint.Style.STROKE);
            stroke.setStrokeWidth(dp(this, 2));
        }

        @Override protected void onDraw(Canvas cv) {
            float w = getWidth(), h = getHeight();
            float inset = dp(this, 2);
            android.graphics.RectF bounds = new android.graphics.RectF(inset, inset, w-inset, h-inset);
            fill.setColor(UI.mono ? 0x553A3E46 : 0x554CB6D9);
            android.graphics.RectF shadowBounds = new android.graphics.RectF(bounds);
            shadowBounds.offset(0, dp(this, 4));
            cv.drawRoundRect(shadowBounds, dp(this, 34), dp(this, 34), fill);
            fill.setShader(new LinearGradient(0, 0, w, h,
                    UI.light ? new int[]{0xAAFFFFFF, 0x556BADC7, 0x33D58B69}
                            : UI.mono ? new int[]{0x88666D78, 0x44252A31}
                            : new int[]{0x8879D9F4, 0x553C769A, 0x66FF895B},
                    null, Shader.TileMode.CLAMP));
            fill.setShadowLayer(dp(this, 12), 0, dp(this, 5), UI.mono ? 0x99000000 : 0xAA55BFEA);
            cv.drawRoundRect(bounds, dp(this, 34), dp(this, 34), fill);
            fill.clearShadowLayer();
            stroke.setStrokeWidth(dp(this, 2.1f));
            stroke.setShader(new LinearGradient(0, 0, w, h,
                    UI.mono ? new int[]{0xFFF5F6F8, 0xFF858D99, 0xFFFFFFFF}
                            : new int[]{0xFFE3FBFF, UI.ICE, UI.FIRE, 0xFFFFD2B5},
                    null, Shader.TileMode.CLAMP));
            cv.drawRoundRect(bounds, dp(this, 34), dp(this, 34), stroke);
            stroke.setStrokeWidth(dp(this, .8f));
            stroke.setColor(UI.mono ? 0x66868D98 : 0x667FE0F5);
            android.graphics.RectF inner = new android.graphics.RectF(bounds);
            inner.inset(dp(this, 4), dp(this, 4));
            cv.drawRoundRect(inner, dp(this, 30), dp(this, 30), stroke);
        }

        static Path hex(float cx, float cy, float r) {
            Path p = new Path();
            for (int i = 0; i < 6; i++) {
                double a = Math.PI / 3 * i - Math.PI / 6;
                float x = (float) (cx + r * Math.cos(a));
                float y = (float) (cy + r * Math.sin(a));
                if (i == 0) p.moveTo(x, y); else p.lineTo(x, y);
            }
            p.close();
            return p;
        }
    }

    /** Accent circle with a paper-plane glyph (Telegram-style). */
    static final class PlaneIcon extends View {
        private final Paint circle = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint glyph = new Paint(Paint.ANTI_ALIAS_FLAG);

        PlaneIcon(Context c) {
            super(c);
            glyph.setColor(0xFFFFFFFF);
        }

        @Override protected void onDraw(Canvas cv) {
            float w = getWidth(), h = getHeight();
            if (w <= 0 || h <= 0) return;
            circle.setShader(new LinearGradient(0, 0, w, h,
                    new int[]{UI.PRIMARY, UI.BLUE}, null, Shader.TileMode.CLAMP));
            cv.drawCircle(w / 2f, h / 2f, Math.min(w, h) / 2f, circle);
            Path p = new Path();
            p.moveTo(w * 0.24f, h * 0.48f);
            p.lineTo(w * 0.78f, h * 0.26f);
            p.lineTo(w * 0.62f, h * 0.76f);
            p.lineTo(w * 0.47f, h * 0.60f);
            p.close();
            cv.drawPath(p, glyph);
            Path fold = new Path();
            fold.moveTo(w * 0.47f, h * 0.60f);
            fold.lineTo(w * 0.78f, h * 0.26f);
            fold.lineTo(w * 0.50f, h * 0.66f);
            fold.close();
            cv.drawPath(fold, glyph);
        }
    }

    /** Creator portrait cropped into a consistent circular frame for compact profile cards. */
    static final class PersonAvatar extends View {
        private final Paint fallback = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint photo = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        private final Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint innerRing = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Matrix shaderMatrix = new Matrix();
        private final Bitmap portrait;
        private final BitmapShader shader;

        PersonAvatar(Context c) {
            super(c);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
            Bitmap loaded;
            try {
                loaded = BitmapFactory.decodeResource(c.getResources(), R.drawable.creator_avatar);
            } catch (RuntimeException ex) {
                loaded = null;
            }
            portrait = loaded;
            shader = portrait == null ? null : new BitmapShader(portrait,
                    Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
            photo.setDither(true);
            if (shader != null) photo.setShader(shader);

            fallback.setColor(UI.light ? 0xFF397F9D : UI.mono ? 0xFF34383F : 0xFF18354A);
            glow.setColor(UI.light ? 0x225AAACB : UI.mono ? 0x224D535D : 0x2279D9F4);
            glow.setStyle(Paint.Style.FILL);
            glow.setShadowLayer(dp(this, 4), 0, 0,
                    UI.light ? 0x335AAACB : UI.mono ? 0x334D535D : 0x4479D9F4);
            ring.setStyle(Paint.Style.STROKE);
            ring.setStrokeWidth(dp(this, 2.2f));
            ring.setShader(new LinearGradient(0, 0, dp(this, 66), dp(this, 66),
                    UI.mono ? new int[]{0xFFE8EBF0, 0xFF9299A3, 0xFFF4F5F7}
                            : new int[]{UI.ICE, UI.BLUE, UI.FIRE}, null, Shader.TileMode.CLAMP));
            innerRing.setStyle(Paint.Style.STROKE);
            innerRing.setStrokeWidth(dp(this, 0.8f));
            innerRing.setColor(UI.mono ? 0x667A828E : 0x6679BBD2);
        }

        @Override protected void onDraw(Canvas cv) {
            super.onDraw(cv);
            float w = getWidth(), h = getHeight();
            if (w <= 0 || h <= 0) return;
            float cx = w * .5f, cy = h * .5f;
            float radius = Math.min(w, h) * .5f - dp(this, 4);
            if (radius <= 0) return;

            cv.drawCircle(cx, cy, radius + dp(this, 1), glow);
            if (shader != null && portrait != null) {
                float diameter = (radius - dp(this, 2)) * 2f;
                float scale = diameter / Math.min(portrait.getWidth(), portrait.getHeight());
                float left = cx - portrait.getWidth() * scale * .5f;
                float top = cy - portrait.getHeight() * scale * .5f;
                shaderMatrix.setScale(scale, scale);
                shaderMatrix.postTranslate(left, top);
                shader.setLocalMatrix(shaderMatrix);
                cv.drawCircle(cx, cy, radius - dp(this, 2), photo);
            } else {
                cv.drawCircle(cx, cy, radius - dp(this, 2), fallback);
                Paint figure = new Paint(Paint.ANTI_ALIAS_FLAG);
                figure.setColor(0xFFF0F6FF);
                cv.drawCircle(cx, cy - radius * .20f, radius * .22f, figure);
                cv.drawOval(cx - radius * .48f, cy + radius * .05f,
                        cx + radius * .48f, cy + radius * .83f, figure);
            }
            cv.drawCircle(cx, cy, radius - dp(this, 1), ring);
            cv.drawCircle(cx, cy, radius - dp(this, 4), innerRing);
            Paint status = new Paint(Paint.ANTI_ALIAS_FLAG);
            status.setColor(0xFF63DDAA);
            cv.drawCircle(cx + radius * .68f, cy + radius * .68f, dp(this, 5.5f), status);
            status.setColor(UI.mono ? 0xFF101114 : UI.light ? 0xFFFFFFFF : 0xFF0A121C);
            cv.drawCircle(cx + radius * .68f, cy + radius * .68f, dp(this, 2.2f), status);
        }
    }
}
