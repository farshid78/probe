#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
OUT="$(mktemp -d)"
trap 'rm -rf "$OUT"' EXIT
STUBS="$ROOT/tools/android-core-smoke-tests/stubs"
PARSER_STUBS="$ROOT/tools/parser-smoke-tests/stubs"
find "$STUBS/android" -name '*.java' -print > "$OUT/sources.txt"
find "$STUBS/appstub" -name '*.java' -print >> "$OUT/sources.txt"
printf '%s\n' \
  "$PARSER_STUBS/android/graphics/Rect.java" \
  "$PARSER_STUBS/android/view/accessibility/AccessibilityNodeInfo.java" \
  "$PARSER_STUBS/org/json/JSONArray.java" \
  "$PARSER_STUBS/org/json/JSONObject.java" \
  "$ROOT/app/src/main/java/app/bastehyab/Pkg.java" \
  "$ROOT/app/src/main/java/app/bastehyab/Op.java" \
  "$ROOT/app/src/main/java/app/bastehyab/Cfg.java" \
  "$ROOT/app/src/main/java/app/bastehyab/Fmt.java" \
  "$ROOT/app/src/main/java/app/bastehyab/Extractor.java" \
  "$ROOT/app/src/main/java/app/bastehyab/Compare.java" \
  "$ROOT/app/src/main/java/app/bastehyab/ScanService.java" \
  "$ROOT/app/src/main/java/app/bastehyab/Store.java" >> "$OUT/sources.txt"
javac -Xlint:all -d "$OUT/classes" @"$OUT/sources.txt"
echo 'PASS: parser, operator configuration, scan service, and JSON store compile against minimal test doubles.'
