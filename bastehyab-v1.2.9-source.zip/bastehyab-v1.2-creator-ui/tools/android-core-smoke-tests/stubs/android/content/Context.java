package android.content;
import java.io.File; import android.content.res.Resources;
public class Context { public Context getApplicationContext(){return this;} public File getFilesDir(){return new File(".");} public Resources getResources(){return new Resources();} public SharedPreferences getSharedPreferences(String name,int mode){return null;} public String getPackageName(){return "app.bastehyab";} }
