package android.accessibilityservice;
import android.content.Context; import android.content.Intent; import android.view.accessibility.*; import java.util.*;
public class AccessibilityService extends Context { public void onInterrupt(){} protected void onServiceConnected(){} public boolean onUnbind(Intent i){return false;} public List<AccessibilityWindowInfo> getWindows(){return null;} public AccessibilityNodeInfo getRootInActiveWindow(){return null;} public void onAccessibilityEvent(AccessibilityEvent e){} }
