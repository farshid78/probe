package org.json;
import java.util.HashMap;
import java.util.Map;
public class JSONObject {
 private final Map<String,Object> values=new HashMap<>();
 public JSONObject(){} public JSONObject put(String k,Object v){values.put(k,v);return this;}
 public boolean has(String k){return values.containsKey(k);}
 public String getString(String k){return "";} public double getDouble(String k){return 0;} public long getLong(String k){return 0;}
 public String optString(String k,String d){return d;} public double optDouble(String k,double d){return d;} public long optLong(String k,long d){return d;}
 public boolean optBoolean(String k,boolean d){return d;} public int optInt(String k,int d){return d;} public JSONArray optJSONArray(String k){return null;}
}
