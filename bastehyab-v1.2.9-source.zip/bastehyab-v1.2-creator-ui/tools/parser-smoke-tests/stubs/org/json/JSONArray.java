package org.json;
public class JSONArray {
 public JSONArray(){} public JSONArray(String s){} public JSONArray(Object o){} public JSONArray put(Object o){return this;} public int length(){return 0;}
 public long getLong(int i){return 0;} public JSONObject getJSONObject(int i){return new JSONObject();} public String getString(int i){return "";}
}
