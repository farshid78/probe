# گزارش تست واقعی — بسته‌یاب 1.2.1

## تست‌های اجراشده

| تست | فرمان/روش | نتیجه | محدوده |
|---|---|---|---|
| Parser smoke | `./tools/parser-smoke-tests/run.sh` | PASS | کلاس‌های واقعی Fmt/Pkg/Op/Extractor با node/JSON test doubles |
| Android core compile smoke | `./tools/android-core-smoke-tests/run.sh` | PASS | کامپایل واقعی Cfg/Extractor/ScanService/Store و مدل‌ها با stubهای حداقلی |
| XML well-formedness | Python `xml.etree.ElementTree` روی Manifest/service config/strings | PASS | فقط syntax XML |
| Manifest assertions | بررسی مجوزها، cleartext و backup | PASS | صفر `uses-permission`؛ cleartext=false و backup=false |
| ZIP ورودی | `unzip -t` | PASS | آرشیو مبنا سالم بود |
| جست‌وجوی کد برای اقدام خودکار | جست‌وجوی `performAction`، `ACTION_SCROLL`، `ACTION_CLICK` | PASS | در سورس فعلی چنین فراخوانی‌ای پیدا نشد |
| جست‌وجوی فایل کلید | جست‌وجوی `.jks/.keystore/.pem/.p12` | PASS | کلید Debug مبنا حذف شد؛ کلید Release ساخته نشده |

### سناریوهای Parser پوشش داده‌شده

- ارقام فارسی و عربی و نرمال‌سازی حروف ی/ک، کشیده و کنترل‌های جهت.
- ورودی null و فاصله‌های Unicode.
- مبلغ صریح ریال و تومان و تبدیل صحیح ریال به تومان.
- واحد پول نامشخص در پروفایل AUTO و عدم حدس.
- وجود مبلغ رقیب بدون واحد در کنار مبلغ ریالی؛ خروجی مبهم و بدون مقایسه ناهم‌واحد.
- پروفایل با واحد ثابت IRR.
- عبور از سقف 8000 گره و اعلام incomplete.
- بسته استخراج‌شده از درخت ناقص و علامت ambiguity.
- حذف کارت‌های تکراری و شمارش آن‌ها.
- حذف گره‌های editable/password/not-visible.
- عدم ذخیره متن خام در JSON و عدم وجود متن/قیمت خام در diagnostics.

## تست‌هایی که انجام نشده‌اند

- `gradle test`, `assembleDebug`, `assembleRelease`, `lint` و build کامل Android.
- Android Studio Sync و Android SDK platform build.
- APK Analyzer، `apksigner verify` و استخراج SHA-256 گواهی/فایل.
- instrumentation / Espresso / Emulator / گوشی واقعی.
- تست نسخه‌های Android و lifecycle واقعی AccessibilityService.
- اسکن زنده روی ایرانسل، همراه اول، سامانتل، رایتل و شاتل موبایل با نسخه فعلی اپ‌های منتشرشده.
- دقت روی dataset برچسب‌گذاری‌شده و محاسبه precision/recall؛ بنابراین عدد 99% گزارش نمی‌شود.
- مصرف CPU/RAM/battery و مدت کار چندساعته.
- Play Protect scan و درخواست اعتراض.

## دلیل عدم ساخت APK

در محیط اجرا `gradle`, `adb` و `sdkmanager` در PATH موجود نبودند، `ANDROID_HOME` تنظیم نشده بود و Android SDK Platform/`android.jar` و Gradle Wrapper داخل ZIP نبود. به همین دلیل ساخت APK یا امضا را نمی‌توانستیم به‌طور واقعی اجرا یا تأیید کنیم. کلید Release هم ارائه نشده بود و عمداً تولید یا داخل پروژه قرار داده نشد.
