package app.bastehyab;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;
import android.widget.Toast;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class ScanService extends AccessibilityService {
    static volatile ScanService inst;
    static volatile String lastScanStatus = "هنوز اسکن انجام نشده است";
    static volatile int lastScannedPackages, lastValidPackages, lastSuspiciousPackages, lastDuplicatePackages;
    static volatile long lastCompletedScanAt;
    static volatile long lastScanDurationMs;
    static volatile String lastOpId = "";
    static volatile String lastEmptyReason = "";

    // ---- user-started full extraction: the app scrolls the operator list ONLY after an explicit user request
    static volatile boolean fullMode;
    static volatile long fullStartedAt;
    static volatile long fullLastStepAt;
    static volatile int fullSteps, fullNoNew;
    static final java.util.Set<String> fullSeen = new HashSet<>();
    static final int FULL_MAX_STEPS = 80;
    static final long FULL_MAX_MS = 180000L;

    /** Called from the UI when the user presses the full-extraction button. */
    static void startFull() {
        fullSeen.clear();
        fullSteps = 0;
        fullNoNew = 0;
        fullStartedAt = System.currentTimeMillis();
        fullLastStepAt = 0L;
        fullMode = true;
        lastScanStatus = "استخراج کامل آغاز شد؛ صفحه‌ی اپراتور را باز کنید";
    }

    static void stopFull(String reason) {
        fullMode = false;
        lastScanStatus = reason + " • " + fullSeen.size() + " بسته‌ی یکتا";
    }

    private final Handler h = new Handler(Looper.getMainLooper());
    private final Runnable job = this::scan;
    private final Map<String, String> dumps = new HashMap<>();
    private Popup popup;
    private long lastDiag, lastScanAt;
    private int emptyStreak;
    private boolean scanning, scanAgain;
    private String fg = "", dismissed = "";

    @Override public void onInterrupt() {
        h.removeCallbacks(job);
        pendingReset();
        if (popup != null) popup.hide();
    }

    private void pendingReset() {
        scanAgain = false;
        scanning = false;
    }

    @Override protected void onServiceConnected() {
        inst = this;
        // Remove a possible raw diagnostic file left by versions before the privacy fix.
        File legacyDiagnostic = new File(getFilesDir(), "diag.txt");
        if (legacyDiagnostic.exists()) legacyDiagnostic.delete();
        dumps.clear();
        popup = new Popup(this);
        popup.onClose(() -> dismissed = fg);
    }

    @Override public boolean onUnbind(Intent i) {
        h.removeCallbacksAndMessages(null);
        pendingReset();
        inst = null;
        dumps.clear();
        if (popup != null) popup.hide();
        return super.onUnbind(i);
    }

    private static boolean ignorable(String p) {
        String s = p.toLowerCase();
        return s.equals("com.android.systemui") || s.contains("inputmethod") || s.contains("keyboard") || s.contains("honeyboard");
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent e) {
        CharSequence cs = e.getPackageName();
        if (cs == null || popup == null) return;
        String p = cs.toString();
        if (p.equals(getPackageName())) return;
        if (e.getEventType() == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED && !ignorable(p) && !p.equals(fg)) {
            fg = p;
            if (!p.equals(dismissed)) dismissed = "";
            popup.hide();
        }
        Op op = Cfg.opFor(this, p);
        if (op == null || !op.enabled) return;
        long now = System.currentTimeMillis();
        // Debounce noisy accessibility events, but keep scrolling responsive.
        // A 450 ms floor prevents repeated full-tree walks while avoiding the old 900 ms lag.
        long earliest = lastScanAt + 450L;
        long delay = Math.max(180L, earliest - now);
        h.removeCallbacks(job);
        h.postDelayed(job, delay);
    }

    private void scan() {
        if (scanning) {
            scanAgain = true;
            return;
        }
        scanning = true;
        final long scanStartedAt = android.os.SystemClock.elapsedRealtime();
        lastScanAt = System.currentTimeMillis();
        int scanned = 0, valid = 0, suspicious = 0, duplicates = 0, fullNew = 0;
        Set<String> scanKeys = new HashSet<>();
        boolean incomplete = false;
        String operatorLabel = "";
        try {
        List<AccessibilityNodeInfo> roots = new ArrayList<>();
        List<AccessibilityWindowInfo> ws = getWindows();
        if (ws != null) {
            for (AccessibilityWindowInfo w : ws) {
                if (w.getType() == AccessibilityWindowInfo.TYPE_APPLICATION) {
                    AccessibilityNodeInfo r = w.getRoot();
                    if (r != null) roots.add(r);
                }
            }
        }
        if (roots.isEmpty()) {
            AccessibilityNodeInfo r = getRootInActiveWindow();
            if (r != null) roots.add(r);
        }
        DisplayMetrics dm = getResources().getDisplayMetrics();
        for (AccessibilityNodeInfo r : roots) {
            String p = String.valueOf(r.getPackageName());
            Op op = Cfg.opFor(this, p);
            if (op == null || !op.enabled) continue;
            Extractor.Result res = Extractor.extract(r, op, dm.heightPixels);
            r.recycle(); // root is no longer needed; release the pooled node (no-op on API 33+)
            operatorLabel = op.name;
            lastOpId = op.id;
            incomplete |= res.incomplete;
            duplicates += res.duplicates;
            diag(p, res.dump);
            for (Pkg item : res.items) {
                if (!scanKeys.add(item.key)) {
                    duplicates++;
                    continue;
                }
                scanned++;
                if (item.currencyKnown && !item.ambig) valid++;
                else suspicious++;
            }
            if (res.items.isEmpty()) {
                lastEmptyReason = "گره‌ها: " + res.nodes + "، متن‌های قابل‌مشاهده: " + res.leaves
                        + (res.fullTraversal ? "، پیمایش کامل" : "");
                if (++emptyStreak >= 3) popup.hide();
                continue;
            }
            emptyStreak = 0;
            Store.upsert(this, res.items);
            if (fullMode) for (Pkg item : res.items) if (fullSeen.add(item.sig())) fullNew++;
            Compare.Result cr = Compare.run(this, res.keys);
            if (!Cfg.popup(this) || p.equals(dismissed) || cr.ranked.isEmpty() || cr.ops < Cfg.minOps(this)) continue;
            popup.show(cr, res.keys);
        }
        lastScannedPackages = scanned;
        lastValidPackages = valid;
        lastSuspiciousPackages = suspicious;
        lastDuplicatePackages = duplicates;
        lastCompletedScanAt = System.currentTimeMillis();
        lastScanStatus = (incomplete ? "استخراج ناقص؛ بخشی از درخت صفحه در دسترس نبود"
                : scanned == 0 ? "در صفحه‌ی فعلی بسته‌ای شناسایی نشد (" + lastEmptyReason + ")" : "اسکن کامل شد")
                + (operatorLabel.isEmpty() ? "" : " • " + operatorLabel);
            if (fullMode && !operatorLabel.isEmpty()) advanceFull(fullNew);
        } catch (RuntimeException scanError) {
            lastCompletedScanAt = System.currentTimeMillis();
            lastScanStatus = "خطا در اسکن: " + scanError.getClass().getSimpleName();
            android.util.Log.w("BastehyabScan", "Accessibility scan failed: " + scanError.getClass().getSimpleName());
        } finally {
            lastScanDurationMs = Math.max(0L, android.os.SystemClock.elapsedRealtime() - scanStartedAt);
            scanning = false;
            if (scanAgain) {
                scanAgain = false;
                h.removeCallbacks(job);
                h.postDelayed(job, 180L);
            }
        }
    }

    /** One step of the user-started full extraction: count progress, then scroll the list once. */
    private void advanceFull(int newThisScan) {
        long now = System.currentTimeMillis();
        if (now - fullLastStepAt < 800L) return; // ignore event bursts; one step per settled screen
        fullLastStepAt = now;
        fullSteps++;
        fullNoNew = newThisScan == 0 ? fullNoNew + 1 : 0;
        lastScanStatus = "استخراج کامل: مرحله " + fullSteps + "، " + fullSeen.size() + " بسته‌ی یکتا";
        if (fullNoNew >= 3) { stopFull("پایان لیست"); return; }
        if (fullSteps >= FULL_MAX_STEPS || now - fullStartedAt > FULL_MAX_MS) { stopFull("توقف: حد مجاز رسید"); return; }

        AccessibilityNodeInfo root = getRootInActiveWindow();
        AccessibilityNodeInfo list = findScrollable(root);
        if (root != null) root.recycle();
        if (list == null) { stopFull("لیست قابل اسکرول پیدا نشد"); return; }
        boolean moved = list.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD);
        list.recycle();
        if (!moved) { stopFull("پایان لیست"); return; }
        h.removeCallbacks(job);
        h.postDelayed(job, 900L);
    }

    /** Breadth-first search for the first visible scrollable node; never clicks or changes anything. */
    private static AccessibilityNodeInfo findScrollable(AccessibilityNodeInfo root) {
        if (root == null) return null;
        java.util.ArrayDeque<AccessibilityNodeInfo> queue = new java.util.ArrayDeque<>();
        java.util.List<AccessibilityNodeInfo> owned = new ArrayList<>();
        queue.add(root);
        AccessibilityNodeInfo found = null;
        int visited = 0;
        while (!queue.isEmpty() && visited++ < 600 && found == null) {
            AccessibilityNodeInfo n = queue.poll();
            if (n != root && n.isScrollable() && n.isVisibleToUser()) { found = n; break; }
            for (int i = 0; i < n.getChildCount(); i++) {
                AccessibilityNodeInfo c = n.getChild(i);
                if (c != null) { owned.add(c); queue.add(c); }
            }
        }
        for (AccessibilityNodeInfo c : owned) if (c != found) c.recycle();
        return found;
    }

    void showTest() {
        Compare.Result cr = Compare.run(this, new HashSet<String>());
        if (cr.ranked.isEmpty()) {
            Toast.makeText(this, "هنوز داده‌ای برای نمایش نیست", Toast.LENGTH_SHORT).show();
            return;
        }
        popup.show(cr, new HashSet<String>());
    }

    private void diag(String p, String dump) {
        dumps.put(p, dump);
        long now = System.currentTimeMillis();
        if (now - lastDiag < 3000) return;
        lastDiag = now;
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, String> en : dumps.entrySet()) sb.append("=== ").append(en.getValue()).append('\n');
        try (Writer w = new OutputStreamWriter(new FileOutputStream(new File(getFilesDir(), "diag.txt")), StandardCharsets.UTF_8)) {
            w.write(sb.toString());
        } catch (Exception ignored) {}
    }
}
