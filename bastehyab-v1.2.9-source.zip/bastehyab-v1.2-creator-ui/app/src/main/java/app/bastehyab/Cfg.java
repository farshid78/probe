package app.bastehyab;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import java.util.ArrayList;
import java.util.List;

final class Cfg {
    static final int PER_GB = 0, PER_GB_MONTH = 1, MY_USAGE = 2;
    private static List<Op> cache;

    static SharedPreferences sp(Context c) {
        return c.getApplicationContext().getSharedPreferences("cfg", 0);
    }

    private static List<Op> defaults() {
        List<Op> d = new ArrayList<>();
        d.add(new Op("irancell", "ایرانسل", 0xFFFFCB05, "IRR", true, "com.myirancell"));
        d.add(new Op("mci", "همراه اول", 0xFF1EA7E1, "AUTO", true, "ir.mci.ecareapp"));
        d.add(new Op("rightel", "رایتل", 0xFFD81B60, "AUTO", true, "ir.rightel.myrightel"));
        d.add(new Op("samantel", "سامانتل", 0xFFFF7043, "IRR", true, "com.mysamantel"));
        d.add(new Op("shatel", "شاتل", 0xFF26A69A, "AUTO", true, "com.shmapp"));
        return d;
    }

    static synchronized List<Op> ops(Context c) {
        if (cache != null) return cache;
        // The previous build recorded package names of every foreground app to suggest
        // possible operators. This is unnecessary usage metadata; clear it during migration.
        sp(c).edit().remove("recent").remove("ambig").apply();
        List<Op> l = new ArrayList<>();
        String s = sp(c).getString("ops", null);
        if (s != null) {
            try {
                JSONArray a = new JSONArray(s);
                for (int i = 0; i < a.length(); i++) l.add(Op.from(a.getJSONObject(i)));
            } catch (Exception e) {
                l.clear();
            }
        }
        if (sp(c).getInt("defv", 0) < 3 || l.isEmpty()) {
            for (Op d : defaults()) {
                Op ex = null;
                for (Op o : l) if (o.id.equals(d.id)) ex = o;
                if (ex == null) {
                    l.add(d);
                } else if (ex.builtin) {
                    ex.pkgs.clear();
                    ex.pkgs.addAll(d.pkgs);
                    // Samantel's accessibility screen exposes rial amounts; migrate old AUTO configs.
                    if ("samantel".equals(ex.id)) ex.cur = "IRR";
                }
            }
            sp(c).edit().putInt("defv", 3).apply();
            saveOps(c, l);
        }
        cache = l;
        return l;
    }

    static synchronized void saveOps(Context c, List<Op> l) {
        cache = l;
        JSONArray a = new JSONArray();
        for (Op o : l) {
            try {
                a.put(o.json());
            } catch (Exception ignored) {}
        }
        sp(c).edit().putString("ops", a.toString()).apply();
    }

    static Op opFor(Context c, String pkg) {
        for (Op o : ops(c)) if (o.pkgs.contains(pkg)) return o;
        return null;
    }

    static Op opById(Context c, String id) {
        for (Op o : ops(c)) if (o.id.equals(id)) return o;
        return null;
    }

    static int metric(Context c) { return sp(c).getInt("metric", PER_GB); }
    // درصد ارزش افزوده؛ پیش‌فرض ۱۰ و محدود به بازه‌ی صفر تا صد
    static int vat(Context c) { return Math.max(0, Math.min(100, sp(c).getInt("vat", 10))); }
    static void setVat(Context c, int value) { setInt(c, "vat", Math.max(0, Math.min(100, value))); }
    static float minGb(Context c) { return sp(c).getFloat("minGb", 0f); }
    static int maxDays(Context c) { return sp(c).getInt("maxDays", 0); }
    static boolean restricted(Context c) { return sp(c).getBoolean("restricted", true); }
    static boolean intl(Context c) { return sp(c).getBoolean("intl", false); }
    static float usage(Context c) { return sp(c).getFloat("usage", 30f); }
    static boolean popup(Context c) { return sp(c).getBoolean("popup", true); }
    static int rows(Context c) { return sp(c).getInt("rows", 3); }
    static int hideSec(Context c) { return sp(c).getInt("hide", 0); }
    static boolean bottom(Context c) { return sp(c).getBoolean("bottom", false); }
    static int fresh(Context c) { return sp(c).getInt("fresh", 3); }
    static int minOps(Context c) { return sp(c).getInt("minOps", 1); }
    static int pmode(Context c) { return sp(c).getInt("pmode", 0); } // 0 screen + overall, 1 overall, 2 screen
    static int bucket(Context c) { return sp(c).getInt("bucket", 0); }

    static void setInt(Context c, String k, int v) { sp(c).edit().putInt(k, v).apply(); }
    static void setFloat(Context c, String k, float v) { sp(c).edit().putFloat(k, v).apply(); }
    static void setBool(Context c, String k, boolean v) { sp(c).edit().putBoolean(k, v).apply(); }

}
