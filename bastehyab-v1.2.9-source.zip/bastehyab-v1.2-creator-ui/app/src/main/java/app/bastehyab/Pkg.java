package app.bastehyab;

import org.json.JSONArray;
import org.json.JSONObject;

final class Pkg {
    String op, key, title, code = "", why = "";
    double gb, days;
    long toman, ts;
    boolean restricted, ambig, currencyKnown = true;
    String note = "", raw = "";
    long[] alts = new long[0];

    double perGb() { return gb > 0 && toman > 0 ? toman / gb : Double.MAX_VALUE; }

    /** قیمت نهایی با ارزش افزوده، با گرد کردن به تومان صحیح */
    long finalToman(int vatPercent) {
        int rate = Math.max(0, Math.min(100, vatPercent));
        return Math.round(toman * (100.0 + rate) / 100.0);
    }

    /** volume this package would give per 30 days if renewed back to back */
    double monthlyGb() { return days > 0 ? gb * 30.0 / days : 0; }

    /** price per GB for each month of validity (1 GB kept for 30 days = 1 GB-month) */
    double perGbMonth() { return days > 0 && gb > 0 && toman > 0 ? toman / (gb * days / 30.0) : Double.MAX_VALUE; }

    /**
     * Cost of getting `usage` GB in a 30-day month with this package.
     *  - 30 days or longer: the price is spread over the months it lasts (toman * 30 / days),
     *    and extra packages are added when one package per month is not enough.
     *  - shorter than 30 days: include both the packages required by volume and the minimum
     *    renewals required to keep the offer available throughout the 30-day comparison window.
     */
    double monthlyCost(double usage) {
        if (days <= 0 || gb <= 0 || toman <= 0) return Double.MAX_VALUE;
        if (days >= 30) {
            double mg = monthlyGb();
            double n = Math.max(1, Math.ceil(usage / mg - 1e-9));
            return n * toman * 30.0 / days;
        }
        double byVolume = Math.max(1, Math.ceil(usage / gb - 1e-9));
        double byCoverage = Math.max(1, Math.ceil(30.0 / days - 1e-9));
        return Math.max(byVolume, byCoverage) * toman;
    }

    /** identity of what the buyer really gets: same operator, volume, duration and price = same package */
    String sig() {
        return op + "|" + Math.round(gb * 1024) + "|" + Math.round(days * 24) + "|" + toman;
    }

    boolean isIntl() { return why != null && why.startsWith("بین‌الملل"); }

    String label() {
        String v = gb < 1 ? Fmt.num(Math.round(gb * 1024)) + " مگ" : Fmt.dec(gb) + " گیگ";
        String d = "";
        if (days > 0 && days < 1) d = " • " + Fmt.num(Math.max(1, Math.round(days * 24))) + " ساعت";
        else if (days > 0) d = " • " + Fmt.dec(days) + " روز";
        return v + d;
    }

    JSONObject json() throws Exception {
        JSONObject o = new JSONObject();
        o.put("op", op);
        o.put("key", key);
        o.put("title", title);
        o.put("code", code);
        o.put("why", why);
        o.put("gb", gb);
        o.put("days", days);
        o.put("toman", toman);
        o.put("ts", ts);
        o.put("r", restricted);
        o.put("am", ambig);
        o.put("ck", currencyKnown);
        o.put("note", note);
        JSONArray a = new JSONArray();
        for (long v : alts) a.put(v);
        o.put("alts", a);
        return o;
    }

    static Pkg from(JSONObject o) throws Exception {
        Pkg p = new Pkg();
        p.op = o.getString("op");
        p.key = o.getString("key");
        p.title = o.optString("title", "");
        p.code = o.optString("code", "");
        p.why = o.optString("why", "");
        p.gb = o.getDouble("gb");
        p.days = o.optDouble("days", 0);
        p.toman = o.getLong("toman");
        p.ts = o.optLong("ts", 0);
        p.restricted = o.optBoolean("r", false);
        p.ambig = o.optBoolean("am", false);
        p.currencyKnown = o.optBoolean("ck", false);
        p.note = o.optString("note", "");
        p.raw = o.optString("raw", "");
        JSONArray a = o.optJSONArray("alts");
        if (a != null) {
            p.alts = new long[a.length()];
            for (int i = 0; i < a.length(); i++) p.alts[i] = a.getLong(i);
        }
        return p;
    }
}
