#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
J="$ROOT/app/src/main/java/app/bastehyab"
UI="$J/UI.java"; MAIN="$J/MainActivity.java"; POPUP="$J/Popup.java"; NEU="$J/NeuDrawable.java"
# RTL / text rules
grep -q 'TEXT_ALIGNMENT_GRAVITY' "$UI"
grep -q 'Gravity.TOP | Gravity.START' "$UI"
grep -q 'Math.max(10.5f, sp)' "$UI"
grep -q 'pk.setTextDirection(View.TEXT_DIRECTION_RTL)' "$MAIN"
grep -q 'pkgInput.setTextDirection(View.TEXT_DIRECTION_LTR)' "$MAIN"
# state restore
grep -q 'state.tab' "$MAIN"; grep -q 'state.scroll.' "$MAIN"
# soft-UI design system contract
grep -q 'final class NeuDrawable' "$NEU"
grep -q 'static Drawable raised(' "$UI"; grep -q 'static Drawable inset(' "$UI"
grep -q 'static void unclip(' "$UI"; grep -q 'UI.unclip(col)' "$MAIN"
grep -q 'static final class Dlg' "$UI"
! grep -q 'AlertDialog' "$MAIN"            # all dialogs use the themed UI.Dlg
! grep -q 'setElevation' "$MAIN"           # system elevation shadows clash with soft-UI
! grep -q 'setElevation' "$POPUP"
! grep -q 'BlurMaskFilter\|setShadowLayer' "$NEU"   # unreliable on HW canvas < API 28
# brand / assets / fonts
for f in app/src/main/res/drawable-nodpi/brand_mark.png app/src/main/assets/fonts/NotoSansArabic-Regular.ttf \
         app/src/main/assets/fonts/NotoSansArabic-Medium.ttf app/src/main/assets/fonts/NotoSansArabic-Bold.ttf; do test -s "$ROOT/$f"; done
# Popup <-> ScanService contract
grep -q 'void show(Compare.Result result, Set<String> onScreen)' "$POPUP"
grep -q 'boolean showConfirm(' "$POPUP"
grep -q 'TYPE_ACCESSIBILITY_OVERLAY' "$POPUP"
python3 "$ROOT/tools/ui-layout-smoke-tests/palette-contrast.py"
echo 'PASS: RTL rules, soft-UI contract, palette contrast, assets, Popup/ScanService API contract.'
