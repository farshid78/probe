package app.bastehyab;

import android.content.Context;
import android.animation.ValueAnimator;
import android.os.Build;
import android.view.animation.LinearInterpolator;
import android.graphics.Canvas;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapShader;
import android.graphics.Matrix;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.view.View;

/** Custom drawing for the opening / creator screen. Purely visual; no touch handling. */
final class SplashViews {
    private SplashViews() { }

    static float dp(View v, float value) {
        return value * v.getResources().getDisplayMetrics().density;
    }

    /** Backward-compatible background class; the scene is deliberately static and stable. */
    static final class Backdrop extends AppBackdrop {
        Backdrop(Context c) { super(c); }
    }

    /**
     * Calm cyber/network wallpaper with a restrained, lifecycle-bound loop: data packets travel
     * along fixed circuit routes, hub nodes pulse gently, and a faint scanline moves slowly.
     * The base palette never flashes or changes, and the animator is stopped when detached.
     */
    static class AppBackdrop extends View {
        private static final int NODE_COUNT = 30;
        private static final int TRACE_COUNT = 36;
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint nodePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint tracePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private Shader backgroundShader, ambientShader;
        private float density;
        private float loopPhase;
        private ValueAnimator loopAnimator;
        private Node[] nodes = new Node[0];
        private Trace[] traces = new Trace[0];

        private static final class Node {
            final float x, y, radius;
            final boolean hub;
            Node(float x, float y, float radius, boolean hub) {
                this.x = x; this.y = y; this.radius = radius; this.hub = hub;
            }
        }
        private static final class Trace {
            final int from, to;
            final float bend;
            Trace(int from, int to, float bend) {
                this.from = from; this.to = to; this.bend = bend;
            }
        }

        AppBackdrop(Context c) {
            super(c);
            density = getResources().getDisplayMetrics().density;
            setWillNotDraw(false);
            tracePaint.setStyle(Paint.Style.STROKE);
            tracePaint.setStrokeCap(Paint.Cap.ROUND);
            tracePaint.setStrokeJoin(Paint.Join.ROUND);
            nodePaint.setStyle(Paint.Style.FILL);
            setLayerType(View.LAYER_TYPE_HARDWARE, null);
        }

        @Override protected void onAttachedToWindow() {
            super.onAttachedToWindow();
            startLoop();
        }

        @Override protected void onDetachedFromWindow() {
            stopLoop();
            super.onDetachedFromWindow();
        }

        @Override protected void onVisibilityChanged(View changedView, int visibility) {
            super.onVisibilityChanged(changedView, visibility);
            if (visibility == VISIBLE) startLoop(); else stopLoop();
        }

        void resumeLoop() { startLoop(); }
        void pauseLoop() { stopLoop(); }

        private void startLoop() {
            if (Build.VERSION.SDK_INT >= 26 && !ValueAnimator.areAnimatorsEnabled()) return;
            if (loopAnimator == null) {
                loopAnimator = ValueAnimator.ofFloat(0f, 1f);
                loopAnimator.setDuration(15000L);
                loopAnimator.setRepeatCount(ValueAnimator.INFINITE);
                loopAnimator.setInterpolator(new LinearInterpolator());
                loopAnimator.addUpdateListener(a -> {
                    loopPhase = (Float) a.getAnimatedValue();
                    invalidate();
                });
            }
            if (!loopAnimator.isStarted()) loopAnimator.start();
        }

        private void stopLoop() {
            if (loopAnimator != null) loopAnimator.cancel();
        }

        @Override protected void onSizeChanged(int width, int height, int oldWidth, int oldHeight) {
            super.onSizeChanged(width, height, oldWidth, oldHeight);
            rebuildShaders(width, height);
            if (nodes.length == 0 || width != oldWidth || height != oldHeight) buildNetwork(width, height);
        }

        void refreshTheme() {
            rebuildShaders(getWidth(), getHeight());
            invalidate();
        }

        private void rebuildShaders(int width, int height) {
            if (width <= 0 || height <= 0) return;
            int[] base = UI.light
                    ? new int[]{0xFFEBEDFB, 0xFFE6E8F7, 0xFFE0E3F5}
                    : UI.mono
                    ? new int[]{0xFF0A0E14, 0xFF111923, 0xFF18212C}
                    : new int[]{0xFF0E1222, 0xFF121729, 0xFF171C33};
            backgroundShader = new LinearGradient(0, 0, width, height, base, null, Shader.TileMode.CLAMP);
            int glow = UI.light ? 0x187B4DFF : UI.mono ? 0x183D5265 : 0x2E7B4DFF;
            int clear = glow & 0x00FFFFFF;
            ambientShader = new RadialGradient(width * .17f, height * .12f,
                    Math.max(width, height) * .58f,
                    new int[]{glow, clear}, null, Shader.TileMode.CLAMP);
        }

        private void buildNetwork(int width, int height) {
            if (width <= 0 || height <= 0) return;
            java.util.Random random = new java.util.Random(0xBA57E7A5L + width * 31L + height * 17L);
            nodes = new Node[NODE_COUNT];
            traces = new Trace[TRACE_COUNT];
            for (int i = 0; i < NODE_COUNT; i++) {
                float x = .035f + random.nextFloat() * .93f;
                float y = .045f + random.nextFloat() * .91f;
                boolean hub = i == 4 || i == 13 || i == 22;
                float radius = hub ? 2.0f + random.nextFloat() : .8f + random.nextFloat() * .85f;
                nodes[i] = new Node(x, y, radius, hub);
            }
            for (int i = 0; i < TRACE_COUNT; i++) {
                int from = i % NODE_COUNT;
                int to = (from + 1 + random.nextInt(7)) % NODE_COUNT;
                if (to == from) to = (to + 1) % NODE_COUNT;
                traces[i] = new Trace(from, to, .28f + random.nextFloat() * .44f);
            }
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float width = getWidth(), height = getHeight();
            if (width <= 0 || height <= 0 || backgroundShader == null) return;
            paint.setStyle(Paint.Style.FILL);
            paint.setShader(backgroundShader);
            canvas.drawRect(0, 0, width, height, paint);
            paint.setShader(ambientShader);
            canvas.drawRect(0, 0, width, height, paint);
            paint.setShader(null);

            // A very low-contrast drafting grid provides structure without visual noise.
            tracePaint.setStrokeWidth(Math.max(1f, density * .55f));
            tracePaint.setColor(UI.light ? 0x0D5B3BE0 : UI.mono ? 0x125F7185 : 0x167B6CFF);
            float step = 38f * density;
            for (float x = 0; x <= width; x += step) canvas.drawLine(x, 0, x, height, tracePaint);
            for (float y = 0; y <= height; y += step) canvas.drawLine(0, y, width, y, tracePaint);

            int traceColor = UI.light ? 0x205B3BE0 : UI.mono ? 0x285F7489 : 0x307B6CFF;
            tracePaint.setColor(traceColor);
            tracePaint.setStrokeWidth(Math.max(1f, density * 1.05f));
            for (Trace trace : traces) {
                Node a = nodes[trace.from], b = nodes[trace.to];
                float ax = a.x * width, ay = a.y * height;
                float bx = b.x * width, by = b.y * height;
                float midX = ax + (bx - ax) * trace.bend;
                // Orthogonal circuit paths give the scene a technical, calm visual rhythm.
                canvas.drawLine(ax, ay, midX, ay, tracePaint);
                canvas.drawLine(midX, ay, midX, by, tracePaint);
                canvas.drawLine(midX, by, bx, by, tracePaint);
            }

            // Static micro-labels add a restrained code/security atmosphere without motion.
            paint.setShader(null);
            paint.setTypeface(android.graphics.Typeface.create("monospace", android.graphics.Typeface.NORMAL));
            paint.setTextSize(9f * density);
            paint.setColor(UI.light ? 0x265B3BE0 : UI.mono ? 0x2C8A9AAC : 0x3C9A86FF);
            String[] marks = {"</>", "0x7F", "SHA-256", "{ }", "AES", "TLS 1.3", "0101", "chmod"};
            float[][] anchors = {{.06f,.18f},{.83f,.12f},{.08f,.74f},{.82f,.83f},
                    {.68f,.32f},{.13f,.48f},{.86f,.57f},{.39f,.91f}};
            for (int i = 0; i < marks.length; i++)
                canvas.drawText(marks[i], anchors[i][0] * width, anchors[i][1] * height, paint);

            int nodeColor = UI.light ? 0x775B3BE0 : UI.mono ? 0x887A8EA1 : 0x992BE4F5;
            int nodeIndex = 0;
            for (Node node : nodes) {
                float x = node.x * width, y = node.y * height;
                float r = node.radius * density;
                nodePaint.setColor((nodeColor & 0x00FFFFFF) | (node.hub ? 0x44000000 : 0x22000000));
                if (node.hub) {
                    float pulse = (float) (0.5 + 0.5 * Math.sin(loopPhase * Math.PI * 2.0 + nodeIndex * 1.7));
                    nodePaint.setColor(UI.light ? 0x22518AA6 : 0x3355D9E8);
                    canvas.drawCircle(x, y, r * (2.5f + pulse * 1.5f), nodePaint);
                }
                nodePaint.setColor(nodeColor);
                canvas.drawCircle(x, y, r, nodePaint);
                if (node.hub) {
                    nodePaint.setStyle(Paint.Style.STROKE);
                    nodePaint.setStrokeWidth(Math.max(1f, density * .8f));
                    nodePaint.setColor(UI.light ? 0x77518AA6 : 0x9970D8E8);
                    canvas.drawCircle(x, y, r * (1.8f + (float)Math.sin(loopPhase * Math.PI * 2.0 + nodeIndex) * .18f), nodePaint);
                    nodePaint.setStyle(Paint.Style.FILL);
                }
                nodeIndex++;
            }

            // A handful of small packets travel along deterministic circuit paths; no random
            // particles, full-screen color flashes, or moving background gradients are used.
            paint.setShader(null);
            for (int packet = 0; packet < 5 && traces.length > 0; packet++) {
                Trace trace = traces[(packet * 7 + 3) % traces.length];
                Node a = nodes[trace.from], b = nodes[trace.to];
                float ax = a.x * width, ay = a.y * height;
                float bx = b.x * width, by = b.y * height;
                float mx = ax + (bx - ax) * trace.bend;
                float my = ay;
                float progress = (loopPhase + packet * .197f) % 1f;
                float x, y;
                if (progress < .34f) {
                    float t = progress / .34f; x = ax + (mx - ax) * t; y = ay;
                } else if (progress < .68f) {
                    float t = (progress - .34f) / .34f; x = mx; y = my + (by - my) * t;
                } else {
                    float t = (progress - .68f) / .32f; x = mx + (bx - mx) * t; y = by;
                }
                paint.setColor(UI.light ? 0x22518AA6 : 0x3355D9E8);
                paint.setStyle(Paint.Style.STROKE);
                paint.setStrokeWidth(dpSafe(7f));
                canvas.drawCircle(x, y, dpSafe(3.2f), paint);
                paint.setStyle(Paint.Style.FILL);
                paint.setColor(UI.light ? 0xCC3D91AE : 0xE655D9E8);
                canvas.drawCircle(x, y, dpSafe(1.65f), paint);
            }

            // Slow, low-opacity scanline: it gives a security-console feel without affecting
            // card colors or causing any visible hue/brightness flicker.
            float scanY = ((loopPhase * 1.18f) % 1f) * height;
            tracePaint.setColor(UI.light ? 0x12518AA6 : 0x1855D9E8);
            tracePaint.setStrokeWidth(Math.max(1f, density * .8f));
            canvas.drawLine(width * .08f, scanY, width * .92f, scanY, tracePaint);
        }

        private float dpSafe(float value) { return value * density; }
    }

    /** Original Bastehyab brand mark, shared with the launcher icon. */
    static final class BrandMark extends View {
        private final Paint imagePaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        private final Paint shadowPaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        private final Bitmap mark;
        BrandMark(Context c) {
            super(c);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
            shadowPaint.setColor(0xFFFFFFFF);
            shadowPaint.setShadowLayer(dp(this, 10), 0, dp(this, 5), UI.mono ? 0xAA000000 : 0xAA050B18);
            Bitmap decoded = BitmapFactory.decodeResource(c.getResources(), R.drawable.brand_mark);
            mark = decoded;
        }
        @Override protected void onDraw(Canvas c) {
            if (mark == null || getWidth() <= 0 || getHeight() <= 0) return;
            float side = Math.min(getWidth(), getHeight()) * .94f;
            android.graphics.RectF dst = new android.graphics.RectF(
                    (getWidth() - side) * .5f, (getHeight() - side) * .5f,
                    (getWidth() + side) * .5f, (getHeight() + side) * .5f);
            android.graphics.RectF shadow = new android.graphics.RectF(dst);
            shadow.offset(0, dp(this, 2.5f));
            c.drawBitmap(mark, null, shadow, shadowPaint);
            c.drawBitmap(mark, null, dst, imagePaint);
        }
    }

    /** Soft rounded logo halo with a restrained cool edge light. */
    static final class LogoHalo extends View {
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);

        LogoHalo(Context c) {
            super(c);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
            stroke.setStyle(Paint.Style.STROKE);
            stroke.setStrokeWidth(dp(this, 2));
        }

        @Override protected void onDraw(Canvas cv) {
            float w = getWidth(), h = getHeight();
            float inset = dp(this, 2);
            android.graphics.RectF bounds = new android.graphics.RectF(inset, inset, w-inset, h-inset);
            fill.setColor(UI.mono ? 0x553A3E46 : 0x557B4DFF);
            android.graphics.RectF shadowBounds = new android.graphics.RectF(bounds);
            shadowBounds.offset(0, dp(this, 4));
            cv.drawRoundRect(shadowBounds, dp(this, 34), dp(this, 34), fill);
            fill.setShader(new LinearGradient(0, 0, w, h,
                    UI.light ? new int[]{0xAAFFFFFF, 0x556BADC7, 0x33DDE8F0}
                            : UI.mono ? new int[]{0x88666D78, 0x44252A31}
                            : new int[]{0x88A58CFF, 0x555E3BF2, 0x662BE4F5},
                    null, Shader.TileMode.CLAMP));
            fill.setShadowLayer(dp(this, 12), 0, dp(this, 5), UI.mono ? 0x99000000 : 0xAA7B4DFF);
            cv.drawRoundRect(bounds, dp(this, 34), dp(this, 34), fill);
            fill.clearShadowLayer();
            stroke.setStrokeWidth(dp(this, 2.1f));
            stroke.setShader(new LinearGradient(0, 0, w, h,
                    UI.mono ? new int[]{0xFFF5F6F8, 0xFF858D99, 0xFFFFFFFF}
                            : new int[]{0xFFE3FBFF, UI.PRIMARY, UI.ACCENT, 0xFFB7C9FF},
                    null, Shader.TileMode.CLAMP));
            cv.drawRoundRect(bounds, dp(this, 34), dp(this, 34), stroke);
            stroke.setStrokeWidth(dp(this, .8f));
            stroke.setColor(UI.mono ? 0x66868D98 : 0x667FE0F5);
            android.graphics.RectF inner = new android.graphics.RectF(bounds);
            inner.inset(dp(this, 4), dp(this, 4));
            cv.drawRoundRect(inner, dp(this, 30), dp(this, 30), stroke);
        }

        static Path hex(float cx, float cy, float r) {
            Path p = new Path();
            for (int i = 0; i < 6; i++) {
                double a = Math.PI / 3 * i - Math.PI / 6;
                float x = (float) (cx + r * Math.cos(a));
                float y = (float) (cy + r * Math.sin(a));
                if (i == 0) p.moveTo(x, y); else p.lineTo(x, y);
            }
            p.close();
            return p;
        }
    }

    /** Accent circle with a paper-plane glyph (Telegram-style). */
    static final class PlaneIcon extends View {
        private final Paint circle = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint glyph = new Paint(Paint.ANTI_ALIAS_FLAG);

        PlaneIcon(Context c) {
            super(c);
            glyph.setColor(0xFFFFFFFF);
        }

        @Override protected void onDraw(Canvas cv) {
            float w = getWidth(), h = getHeight();
            if (w <= 0 || h <= 0) return;
            circle.setShader(new LinearGradient(0, 0, w, h,
                    new int[]{UI.PRIMARY, UI.BLUE}, null, Shader.TileMode.CLAMP));
            cv.drawCircle(w / 2f, h / 2f, Math.min(w, h) / 2f, circle);
            Path p = new Path();
            p.moveTo(w * 0.24f, h * 0.48f);
            p.lineTo(w * 0.78f, h * 0.26f);
            p.lineTo(w * 0.62f, h * 0.76f);
            p.lineTo(w * 0.47f, h * 0.60f);
            p.close();
            cv.drawPath(p, glyph);
            Path fold = new Path();
            fold.moveTo(w * 0.47f, h * 0.60f);
            fold.lineTo(w * 0.78f, h * 0.26f);
            fold.lineTo(w * 0.50f, h * 0.66f);
            fold.close();
            cv.drawPath(fold, glyph);
        }
    }

    /** Creator portrait cropped into a consistent circular frame for compact profile cards. */
    static final class PersonAvatar extends View {
        private final Paint fallback = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint photo = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        private final Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint innerRing = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Matrix shaderMatrix = new Matrix();
        private final Bitmap portrait;
        private final BitmapShader shader;

        PersonAvatar(Context c) {
            super(c);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
            Bitmap loaded;
            try {
                loaded = BitmapFactory.decodeResource(c.getResources(), R.drawable.creator_avatar);
            } catch (RuntimeException ex) {
                loaded = null;
            }
            portrait = loaded;
            shader = portrait == null ? null : new BitmapShader(portrait,
                    Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
            photo.setDither(true);
            if (shader != null) photo.setShader(shader);

            fallback.setColor(UI.light ? 0xFF397F9D : UI.mono ? 0xFF34383F : 0xFF18354A);
            glow.setColor(UI.light ? 0x225AAACB : UI.mono ? 0x224D535D : 0x2270CDE0);
            glow.setStyle(Paint.Style.FILL);
            glow.setShadowLayer(dp(this, 4), 0, 0,
                    UI.light ? 0x335AAACB : UI.mono ? 0x334D535D : 0x4470CDE0);
            ring.setStyle(Paint.Style.STROKE);
            ring.setStrokeWidth(dp(this, 2.2f));
            ring.setShader(new LinearGradient(0, 0, dp(this, 66), dp(this, 66),
                    UI.mono ? new int[]{0xFFE8EBF0, 0xFF9299A3, 0xFFF4F5F7}
                            : new int[]{UI.PRIMARY, UI.BLUE, UI.ACCENT}, null, Shader.TileMode.CLAMP));
            innerRing.setStyle(Paint.Style.STROKE);
            innerRing.setStrokeWidth(dp(this, 0.8f));
            innerRing.setColor(UI.mono ? 0x667A828E : 0x6679BBD2);
        }

        @Override protected void onDraw(Canvas cv) {
            super.onDraw(cv);
            float w = getWidth(), h = getHeight();
            if (w <= 0 || h <= 0) return;
            float cx = w * .5f, cy = h * .5f;
            float radius = Math.min(w, h) * .5f - dp(this, 4);
            if (radius <= 0) return;

            cv.drawCircle(cx, cy, radius + dp(this, 1), glow);
            if (shader != null && portrait != null) {
                float diameter = (radius - dp(this, 2)) * 2f;
                float scale = diameter / Math.min(portrait.getWidth(), portrait.getHeight());
                float left = cx - portrait.getWidth() * scale * .5f;
                float top = cy - portrait.getHeight() * scale * .5f;
                shaderMatrix.setScale(scale, scale);
                shaderMatrix.postTranslate(left, top);
                shader.setLocalMatrix(shaderMatrix);
                cv.drawCircle(cx, cy, radius - dp(this, 2), photo);
            } else {
                cv.drawCircle(cx, cy, radius - dp(this, 2), fallback);
                Paint figure = new Paint(Paint.ANTI_ALIAS_FLAG);
                figure.setColor(0xFFF0F6FF);
                cv.drawCircle(cx, cy - radius * .20f, radius * .22f, figure);
                cv.drawOval(cx - radius * .48f, cy + radius * .05f,
                        cx + radius * .48f, cy + radius * .83f, figure);
            }
            cv.drawCircle(cx, cy, radius - dp(this, 1), ring);
            cv.drawCircle(cx, cy, radius - dp(this, 4), innerRing);
            Paint status = new Paint(Paint.ANTI_ALIAS_FLAG);
            status.setColor(0xFF63DDAA);
            cv.drawCircle(cx + radius * .68f, cy + radius * .68f, dp(this, 5.5f), status);
            status.setColor(UI.mono ? 0xFF101114 : UI.light ? 0xFFFFFFFF : 0xFF0A121C);
            cv.drawCircle(cx + radius * .68f, cy + radius * .68f, dp(this, 2.2f), status);
        }
    }
}
