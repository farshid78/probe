package app.bastehyab;

import android.app.Activity;
import android.app.Dialog;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.Trace;
import android.provider.MediaStore;
import android.provider.Settings;
import android.text.Editable;
import android.text.InputType;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.graphics.drawable.GradientDrawable;
import android.widget.Button;
import android.view.Gravity;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;

import android.widget.LinearLayout;
import android.widget.ProgressBar;

import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    interface IntCb { void on(int v); }
    interface StrCb { void on(String s); }
    interface W { void w(OutputStream o) throws Exception; }

    private static final int[] ICONS = {R.drawable.ic_home, R.drawable.ic_compare, R.drawable.ic_tune};
    private static final String[] NAMES = {"خانه", "مقایسه", "تنظیمات"};

    private FrameLayout body;
    private FrameLayout outer;
    private SplashViews.AppBackdrop appBackdrop;
    private View splashView;
    private boolean splashShowing;
    private boolean storeLoadRefreshAttached;
    private final Handler splashHandler = new Handler(Looper.getMainLooper());
    private final Handler liveHandler = new Handler(Looper.getMainLooper());
    private final ExecutorService uiDataExecutor = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "Bastehyab-UiData");
        t.setDaemon(true);
        return t;
    });
    private boolean activityResumed;
    private boolean homeTickerScheduled;
    private boolean homeDataInFlight;
    private boolean homeRefreshPending;
    private boolean compareDataInFlight;
    private boolean compareRefreshPending;
    private long homeAppliedVersion = -1L;
    private long compareAppliedVersion = -1L;
    private int homeRequestToken;
    private int compareRequestToken;
    private HomeLiveViews homeLive;
    private TextView compareCountChip;
    private TextView compareSummaryText;
    private TextView compareEmptyText;
    private LinearLayout compareResultsList;
    private final Map<String, View> compareRowViews = new LinkedHashMap<>();
    private final Map<String, String> compareRowSignatures = new LinkedHashMap<>();
    private final Runnable liveRefresh = new Runnable() {
        @Override public void run() {
            homeTickerScheduled = false;
            if (!isHomeVisibleForLive()) return;
            updateHomeScanUi();
            requestHomeData(false);
            if (ScanService.fullMode) scheduleHomeTicker();
        }
    };
    private LinearLayout nav;
    private ScrollView sv;
    private int tab;
    private final int[] scroll = new int[3];
    private String newName = "", newPkg = "";
    private int newCur;

    private int dp(float v) { return UI.dp(this, v); }

    private void applySystemBars() {
        getWindow().setStatusBarColor(UI.BG);
        getWindow().setNavigationBarColor(UI.BG);
        int flags = UI.light ? (View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR) : 0;
        getWindow().getDecorView().setSystemUiVisibility(flags);
    }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        UI.applyTheme(this);
        applySystemBars();
        LinearLayout root = UI.vbox(this);
        root.setBackgroundColor(0x00000000);
        body = new FrameLayout(this);
        root.addView(body, new LinearLayout.LayoutParams(-1, 0, 1f));
        nav = UI.hbox(this);
        nav.setBackground(UI.raised(this, 26, 9, true));
        nav.setPadding(dp(8), dp(8), dp(8), dp(8));
        root.setClipChildren(false);
        LinearLayout.LayoutParams navParams = new LinearLayout.LayoutParams(-1, -2);
        navParams.setMargins(dp(18), dp(8), dp(18), dp(16));
        root.addView(nav, navParams);
        outer = new FrameLayout(this);
        appBackdrop = new SplashViews.AppBackdrop(this);
        outer.addView(appBackdrop, new FrameLayout.LayoutParams(-1, -1));
        outer.addView(root, new FrameLayout.LayoutParams(-1, -1));
        setContentView(outer);
        if (b == null) showCreatorSplash();
        else {
            tab = Cfg.clamp(b.getInt("state.tab", 0), 0, 2);
            for (int i = 0; i < scroll.length; i++) scroll[i] = Math.max(0, b.getInt("state.scroll." + i, 0));
            render(); // Rebuild the visible screen and restore the selected tab/scroll position.
        }
    }

    private void showCreatorSplash() {
        splashShowing = true;
        FrameLayout shell = new FrameLayout(this);
        // Reuse the activity's static cyber wallpaper: one compositor, no stacked animation layers.
        shell.setBackgroundColor(0x00000000);
        View veil = new View(this);
        veil.setBackground(UI.grad(this, UI.light ? 0x22FFFFFF : UI.tint(UI.PRIMARY),
                UI.light ? 0x11EAF0FA : UI.tint(UI.ACCENT), 0));
        shell.addView(veil, new FrameLayout.LayoutParams(-1, -1));

        ScrollView scrollView = new ScrollView(this);
        scrollView.setFillViewport(true);
        scrollView.setVerticalScrollBarEnabled(false);
        shell.addView(scrollView, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout col = UI.vbox(this);
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        col.setPadding(dp(26), dp(30), dp(26), dp(24));
        scrollView.addView(col, new ScrollView.LayoutParams(-1, -2));

        FrameLayout logo = new FrameLayout(this);
        logo.addView(new SplashViews.LogoHalo(this),
                new FrameLayout.LayoutParams(dp(128), dp(128), Gravity.CENTER));
        SplashViews.BrandMark brandMark = new SplashViews.BrandMark(this);
        logo.addView(brandMark,
                new FrameLayout.LayoutParams(dp(120), dp(120), Gravity.CENTER));
        col.addView(logo, UI.lp(this, 140, 140, 0, 0, 0, 12));

        TextView title = UI.tv(this, "بسته‌یاب", 34, UI.TEXT, true);
        title.setGravity(Gravity.CENTER);
        col.addView(title, UI.lp(this, -1, -2, 0, 0, 0, 2));
        TextView latin = UI.mono(this, "[ BASTEHYAB // SECURE SCAN ]", 11, UI.ACCENT);
        latin.setLetterSpacing(0.14f);
        latin.setTextDirection(View.TEXT_DIRECTION_LTR);
        latin.setGravity(Gravity.CENTER);
        col.addView(latin, UI.lp(this, -1, -2, 0, 0, 0, 5));
        TextView subtitle = UI.tv(this, "مقایسه‌ی هوشمند بسته‌های اینترنت", 14, UI.ACCENT, true);
        subtitle.setGravity(Gravity.CENTER);
        col.addView(subtitle, UI.lp(this, -1, -2, 0, 0, 0, 20));

        LinearLayout features = UI.hbox(this);
        features.setGravity(Gravity.CENTER);
        String[] featureNames = {"اسکن محلی", "مقایسه قیمت", "بدون ارسال داده"};
        for (int i=0;i<featureNames.length;i++) {
            TextView f = UI.chip(this, featureNames[i], UI.tint(UI.ACCENT), UI.ACCENT);
            features.addView(f, UI.lp(this, -2, -2, i==0?0:5, 0, 0, 0));
        }
        col.addView(features, UI.lp(this, -1, -2, 0, 0, 0, 18));

        LinearLayout how = UI.card(this);
        how.setPadding(dp(16), dp(15), dp(16), dp(15));
        how.addView(UI.tv(this, "سه گام تا مقایسه", 14, UI.TEXT, true));
        LinearLayout steps = UI.hbox(this);
        String[] stepsText = {"بازکردن اپراتور", "ورود به بسته‌ها", "مقایسه خودکار"};
        for (int i=0;i<stepsText.length;i++) {
            LinearLayout step = UI.vbox(this);
            step.setGravity(Gravity.CENTER);
            TextView n = UI.tv(this, Fmt.fa(String.valueOf(i+1)), 12, UI.TEXT, true);
            n.setGravity(Gravity.CENTER);
            n.setBackground(UI.inset(this, 15, UI.ACCENT));
            step.addView(n, UI.lp(this, 30, 30, 0, 0, 0, 5));
            TextView label = UI.tv(this, stepsText[i], 10, UI.MUTED, true);
            label.setGravity(Gravity.CENTER);
            label.setMaxLines(2);
            step.addView(label);
            steps.addView(step, new LinearLayout.LayoutParams(0, -2, 1f));
        }
        how.addView(steps, UI.lp(this, -1, -2, 0, 12, 0, 0));
        col.addView(how, UI.lp(this, -1, -2, 0, 0, 0, 14));

        TextView enter = UI.btn(this, "ورود به برنامه", UI.PRIMARY, 0xFF061326, v -> enterApp());
        col.addView(enter, UI.lp(this, -1, -2, 0, 0, 0, 14));

        LinearLayout creator = UI.hbox(this);
        creator.setGravity(Gravity.CENTER_VERTICAL);
        creator.setPadding(dp(14), dp(13), dp(14), dp(13));
        creator.setBackground(UI.raised(this, 20));
        creator.addView(new SplashViews.PersonAvatar(this), UI.lp(this, 66, 66, 0, 0, 12, 0));
        LinearLayout creatorText = UI.vbox(this);
        creatorText.addView(UI.tv(this, "طراحی و توسعه", 10, UI.MUTED, false));
        creatorText.addView(UI.tv(this, "فرشید نبی‌پور", 16, UI.TEXT, true),
                UI.lp(this, -1, -2, 0, 3, 0, 0));
        creator.addView(creatorText, UI.lpw(1f));
        TextView contact = UI.tv(this, "ارتباط با سازنده  ↗", 10, UI.PRIMARY, true);
        contact.setGravity(Gravity.CENTER);
        contact.setPadding(dp(10), dp(10), dp(10), dp(10));
        contact.setBackground(UI.raisedSmall(this, 12));
        contact.setOnClickListener(v -> {
            try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/Farshid_Np"))); }
            catch (Exception e) { toast("امکان باز کردن پیوند ارتباطی وجود ندارد"); }
        });
        creator.addView(contact, UI.lp(this, -2, -2, 8, 0, 0, 0));
        col.addView(creator, UI.lp(this, -1, -2, 0, 0, 0, 8));

        TextView privacy = UI.tv(this, "پردازش روی همین گوشی انجام می‌شود؛ اطلاعات صفحه به سرور ارسال نمی‌شود.\nنسخه ۱.۹.۰  •  © ۲۰۲۶", 10, UI.MUTED, false);
        privacy.setGravity(Gravity.CENTER);
        privacy.setMaxLines(3);
        col.addView(privacy, UI.lp(this, -1, -2, 0, 0, 0, 0));

        UI.applyTypefaceTree(shell);
        UI.unclip(shell);
        splashView = shell;
        outer.addView(splashView, new FrameLayout.LayoutParams(-1, -1));
    }

    private void enterApp() {
        if (!splashShowing) return;
        View fading = splashView;
        if (fading == null) {
            splashShowing = false;
            render();
            return;
        }
        fading.animate().alpha(0f).setDuration(180L).withEndAction(() -> {
            if (splashView == fading) {
                outer.removeView(fading);
                splashView = null;
                splashShowing = false;
                render();
            }
        }).start();
    }

    @Override protected void onSaveInstanceState(Bundle out) {
        out.putInt("state.tab", tab);
        for (int i = 0; i < scroll.length; i++) out.putInt("state.scroll." + i, scroll[i]);
        super.onSaveInstanceState(out);
    }

    @Override protected void onResume() {
        super.onResume();
        activityResumed = true;
        if (appBackdrop != null) appBackdrop.resumeLoop();
        if (!splashShowing) {
            if (body == null || body.getChildCount() == 0) {
                render();
            } else if (tab == 0) {
                // Keep the existing Home hierarchy, scroll, focus and dialogs intact on return.
                updateHomeScanUi();
                requestHomeData(true);
            } else if (tab == 1) {
                requestCompareData(true);
            }
        }
        if (!storeLoadRefreshAttached) {
            storeLoadRefreshAttached = true;
            Store.whenLoaded(this, () -> {
                if (!isFinishing() && !splashShowing) {
                    if (tab == 0) requestHomeData(true);
                    else if (tab == 1) requestCompareData(true);
                }
            });
        }
        if (tab == 0) {
            updateHomeScanUi();
            requestHomeData(false);
            if (ScanService.fullMode) scheduleHomeTicker();
        }
    }

    @Override protected void onPause() {
        activityResumed = false;
        stopHomeTicker();
        if (appBackdrop != null) appBackdrop.pauseLoop();
        Store.flush(this);
        super.onPause();
    }

    @Override protected void onStop() {
        stopHomeTicker();
        super.onStop();
    }

    @Override protected void onDestroy() {
        activityResumed = false;
        stopHomeTicker();
        splashHandler.removeCallbacksAndMessages(null);
        liveHandler.removeCallbacksAndMessages(null);
        uiDataExecutor.shutdown(); // queued snapshots finish; callbacks self-discard after destruction
        super.onDestroy();
    }

    // ---------------------------------------------------------------- shell

    private void render() { render(true); }

    private void render(boolean captureCurrentScroll) {
        if (captureCurrentScroll && sv != null) scroll[tab] = sv.getScrollY();
        body.removeAllViews();
        final ScrollView screenScroll = new ScrollView(this);
        screenScroll.setFillViewport(true);
        screenScroll.setVerticalScrollBarEnabled(false);
        screenScroll.setOverScrollMode(View.OVER_SCROLL_NEVER);
        screenScroll.setClipToPadding(false);
        screenScroll.setClipChildren(false);
        sv = screenScroll;
        LinearLayout col = UI.vbox(this);
        col.setClipChildren(false);
        col.setPadding(dp(20), dp(18), dp(20), dp(30));
        screenScroll.addView(col, new FrameLayout.LayoutParams(-1, -2));
        body.addView(screenScroll, new FrameLayout.LayoutParams(-1, -1));
        if (tab == 0) home(col);
        else if (tab == 1) compare(col);
        else settings(col);
        UI.applyTypefaceTree(col);
        UI.unclip(col);
        final int y = scroll[tab];
        screenScroll.post(() -> screenScroll.scrollTo(0, y));
        buildNav();
        if (tab == 0) {
            updateHomeScanUi();
            requestHomeData(true);
            if (activityResumed && ScanService.fullMode) scheduleHomeTicker();
        } else {
            stopHomeTicker();
            if (tab == 1) requestCompareData(true);
        }
    }

    private void buildNav() {
        nav.removeAllViews();
        nav.setPadding(dp(8), dp(8), dp(8), dp(8));
        nav.setBackground(UI.raised(this, 26, 9, true));
        nav.setClipChildren(false);
        for (int i = 0; i < 3; i++) {
            final int idx = i;
            boolean on = i == tab;
            LinearLayout it = UI.vbox(this);
            it.setGravity(Gravity.CENTER);
            it.setPadding(dp(6), dp(8), dp(6), dp(8));
            // Active item: sunken key with a neon rim; inactive: flat.
            if (on) it.setBackground(UI.inset(this, 20, UI.PRIMARY));
            ImageView im = new ImageView(this);
            im.setImageResource(ICONS[i]);
            im.setColorFilter(on ? UI.ACCENT : UI.MUTED);
            it.addView(im, UI.lp(this, 22, 22, 0, 1, 0, 0));
            TextView label = UI.tv(this, NAMES[i], 10, on ? UI.TEXT : UI.MUTED, on);
            label.setGravity(Gravity.CENTER);
            it.addView(label, UI.lp(this, -2, -2, 0, 4, 0, 0));
            it.setContentDescription(NAMES[i] + (on ? "، صفحه فعلی" : "، رفتن به صفحه"));
            it.setSelected(on);
            it.setOnClickListener(v -> {
                // Re-tapping the active destination is intentionally a no-op.
                // Rebuilding the same screen used to reset focus/layout and cause a visible jump.
                if (idx == tab) return;
                if (sv != null) scroll[tab] = sv.getScrollY();
                tab = idx;
                // The target tab already owns its own saved scroll position; do not
                // overwrite it with the outgoing tab's scroll offset during render.
                render(false);
            });
            LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(0, -2, 1f);
            ip.setMarginStart(i == 0 ? 0 : dp(6));
            nav.addView(it, ip);
        }
    }

    private boolean serviceOn() {
        String en = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        return en != null && en.contains(getPackageName());
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }

    // ---------------------------------------------------------------- home

    private static final class HomeStat {
        final TextView value;
        HomeStat(TextView value) { this.value = value; }
    }

    private static final class HomeLiveViews {
        TextView shieldChip, accessTitle;
        HomeStat rankedCount, operatorsWithData, activeOperators, latest;
        TextView scanChip, scanStatus, scanDuration, scanCounts, scanPhase, scanUpdatedAt;
        ProgressBar progress;
        TextView bestEmpty, bestOperator, bestTitle, bestDays, bestPrice, bestMetric, bestMetricUnit;
        LinearLayout bestOffer;
        View bestButton;
        final Map<String, TextView> operatorStatuses = new LinkedHashMap<>();
        String bestSignature = "";
        Boolean lastPermission;
        int lastScanColor = Integer.MIN_VALUE;
        int lastProgress = Integer.MIN_VALUE;
    }

    private static final class HomeData {
        long version;
        List<Pkg> records;
        Compare.Result comparison;
        int activeOperators, operatorsWithData;
        long latestAt;
        String error = "";
        final Map<String, Integer> operatorCounts = new LinkedHashMap<>();
        final Map<String, Long> operatorLatest = new LinkedHashMap<>();
    }

    private void home(LinearLayout col) {
        final HomeLiveViews h = new HomeLiveViews();
        homeLive = h;
        List<Op> ops = Cfg.ops(this);
        LinearLayout hero = UI.hbox(this);
        hero.setPadding(dp(18), dp(18), dp(18), dp(18));
        hero.setBackground(UI.raised(this, 26, 9, true));
        ImageView mark = new ImageView(this);
        mark.setImageResource(R.mipmap.ic_launcher);
        mark.setScaleType(ImageView.ScaleType.FIT_CENTER);
        hero.addView(mark, UI.lp(this, 70, 70, 0, 0, 14, 0));
        LinearLayout brand = UI.vbox(this);
        brand.addView(UI.tv(this, "پردازش محلی و آفلاین", 12, UI.MUTED, true));
        brand.addView(UI.tv(this, "بسته‌یاب", 24, UI.TEXT, true), UI.lp(this, -1, -2, 0, 3, 0, 0));
        brand.addView(UI.tv(this, "مقایسه‌ی هوشمند بسته‌های اینترنت", 11, UI.MUTED, false), UI.lp(this, -1, -2, 0, 3, 0, 6));
        h.shieldChip = UI.chip(this, "● در حال بررسی دسترسی", UI.tint(UI.MUTED), UI.MUTED);
        brand.addView(h.shieldChip);
        hero.addView(brand, UI.lpw(1f));
        col.addView(hero, UI.lp(this, -1, -2, 0, 4, 0, 0));

        LinearLayout access = UI.card(this);
        h.accessTitle = UI.tv(this, "در حال بررسی وضعیت دسترسی…", 14, UI.TEXT, true);
        access.addView(h.accessTitle);
        access.addView(UI.tv(this, "این دسترسی اختیاری است. اگر نپذیرید، صفحه‌های خانه، مقایسه، فیلترها و داده‌های ذخیره‌شده همچنان قابل استفاده‌اند.", 11, UI.MUTED, false), UI.lp(this, -1, -2, 0, 5, 0, 9));
        access.addView(UI.btn(this, "مشاهدهٔ توضیحات و انتخاب آگاهانه", UI.PRIMARY, 0xFF061326, v -> showAccessibilityDisclosure()), UI.lp(this, -1, -2, 0, 0, 0, 0));
        col.addView(access, UI.lp(this, -1, -2, 0, 16, 0, 0));

        col.addView(UI.sectionHeader(this, "OVERVIEW", "نمای کلی", "آمار ذخیره‌شده روی این گوشی"), UI.lp(this, -1, -2, 0, 20, 0, 12));
        LinearLayout stats1 = UI.hbox(this);
        h.rankedCount = addHomeStat(stats1, "—", "بسته‌ی معتبر");
        addHomeStatSpacer(stats1);
        h.operatorsWithData = addHomeStat(stats1, "—", "اپراتور دارای داده");
        LinearLayout stats2 = UI.hbox(this);
        h.activeOperators = addHomeStat(stats2, "—", "اپراتور فعال");
        addHomeStatSpacer(stats2);
        h.latest = addHomeStat(stats2, "—", "آخرین دریافت");
        col.addView(stats1, UI.lp(this, -1, -2, 0, 0, 0, 14));
        col.addView(stats2, UI.lp(this, -1, -2, 0, 0, 0, 0));

        LinearLayout scan = UI.card(this);
        LinearLayout scanHead = UI.hbox(this);
        scanHead.addView(UI.tv(this, "وضعیت آخرین اسکن", 14, UI.TEXT, true), UI.lpw(1f));
        h.scanChip = UI.chip(this, "آماده", UI.tint(UI.ACCENT), UI.MUTED);
        scanHead.addView(h.scanChip);
        scan.addView(scanHead);
        h.scanStatus = UI.tv(this, "در انتظار دریافت وضعیت اسکن…", 12, UI.MUTED, false);
        scan.addView(h.scanStatus, UI.lp(this, -1, -2, 0, 7, 0, 0));
        h.scanDuration = UI.tv(this, "", 9, UI.MUTED, false);
        h.scanDuration.setVisibility(View.GONE);
        scan.addView(h.scanDuration, UI.lp(this, -1, -2, 0, 4, 0, 0));
        h.scanCounts = UI.tv(this, "شناسایی ۰  |  معتبر ۰  |  مشکوک ۰  |  تکراری ۰", 10, UI.MUTED, false);
        scan.addView(h.scanCounts, UI.lp(this, -1, -2, 0, 5, 0, 0));
        h.scanPhase = UI.tv(this, "", 10, UI.PRIMARY, true);
        h.scanPhase.setVisibility(View.GONE);
        scan.addView(h.scanPhase, UI.lp(this, -1, -2, 0, 7, 0, 3));
        h.progress = UI.progress(this);
        h.progress.setMax(100);
        h.progress.setVisibility(View.GONE);
        scan.addView(h.progress, UI.lp(this, -1, 8, 0, 2, 0, 0));
        h.scanUpdatedAt = UI.tv(this, "", 9, UI.MUTED, false);
        h.scanUpdatedAt.setFocusable(false);
        h.scanUpdatedAt.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        scan.addView(h.scanUpdatedAt, UI.lp(this, -1, -2, 0, 6, 0, 0));
        col.addView(scan, UI.lp(this, -1, -2, 0, 16, 0, 0));

        LinearLayout best = UI.card(this);
        LinearLayout bh = UI.hbox(this);
        bh.addView(UI.tv(this, "بهترین پیشنهاد فعلی", 14, UI.TEXT, true), UI.lpw(1f));
        bh.addView(UI.chip(this, "پیشنهاد هوشمند", UI.tint(UI.ACCENT), UI.ACCENT));
        best.addView(bh);
        h.bestEmpty = UI.tv(this, "در حال دریافت داده‌های مقایسه…", 11, UI.MUTED, false);
        best.addView(h.bestEmpty, UI.lp(this, -1, -2, 0, 8, 0, 0));
        h.bestOffer = UI.hbox(this);
        h.bestOffer.setVisibility(View.GONE);
        LinearLayout bestDetails = UI.vbox(this);
        h.bestOperator = UI.chip(this, "اپراتور", UI.tint(UI.MUTED), UI.MUTED);
        bestDetails.addView(h.bestOperator);
        h.bestTitle = UI.tv(this, "", 17, UI.TEXT, true);
        bestDetails.addView(h.bestTitle, UI.lp(this, -1, -2, 0, 7, 0, 3));
        h.bestDays = UI.tv(this, "", 10, UI.MUTED, false);
        bestDetails.addView(h.bestDays);
        h.bestPrice = UI.tv(this, "", 11, UI.MUTED, false);
        bestDetails.addView(h.bestPrice, UI.lp(this, -1, -2, 0, 5, 0, 0));
        h.bestOffer.addView(bestDetails, UI.lpw(1f));
        LinearLayout bestMetric = UI.vbox(this);
        bestMetric.setGravity(Gravity.CENTER);
        h.bestMetric = UI.tv(this, "—", 22, UI.PRIMARY, true);
        bestMetric.addView(h.bestMetric);
        h.bestMetricUnit = UI.tv(this, "", 9, UI.MUTED, false);
        bestMetric.addView(h.bestMetricUnit);
        h.bestOffer.addView(bestMetric);
        best.addView(h.bestOffer, UI.lp(this, -1, -2, 0, 10, 0, 0));
        h.bestButton = UI.btn(this, "مشاهده‌ی رتبه‌بندی بسته‌ها", UI.CARD2, UI.PRIMARY, v -> { tab = 1; render(); });
        h.bestButton.setVisibility(View.GONE);
        best.addView(h.bestButton, UI.lp(this, -1, -2, 0, 12, 0, 0));
        col.addView(best, UI.lp(this, -1, -2, 0, 16, 0, 0));

        col.addView(UI.sectionHeader(this, "OPERATORS", "اپراتورها", "وضعیت داده و شروع اسکن هر اپراتور"), UI.lp(this, -1, -2, 0, 22, 0, 12));
        for (final Op o : ops) {
            LinearLayout row = UI.hbox(this);
            row.setPadding(dp(14), dp(12), dp(14), dp(12));
            row.setMinimumHeight(dp(72));
            row.setBackground(UI.raised(this, 20));
            row.addView(new OperatorLogo(this, o.id), UI.lp(this, 42, 34, 0, 0, 10, 0));
            LinearLayout info = UI.vbox(this);
            info.addView(UI.tv(this, o.name, 13, UI.TEXT, true));
            TextView status = UI.tv(this, o.enabled ? "در حال دریافت اطلاعات…" : "اسکن غیرفعال", 10, UI.MUTED, false);
            info.addView(status, UI.lp(this, -1, -2, 0, 2, 0, 0));
            h.operatorStatuses.put(o.id, status);
            row.addView(info, UI.lpw(1f));
            row.addView(UI.btn(this, o.enabled ? "اسکن" : "بازکردن", UI.CARD2, UI.PRIMARY, v -> launch(o)));
            col.addView(row, UI.lp(this, -1, -2, 0, 0, 0, 14));
        }
        LinearLayout privacy = UI.hbox(this);
        privacy.setPadding(dp(12), dp(10), dp(12), dp(10));
        privacy.setBackground(UI.inset(this, 14));
        privacy.addView(UI.mono(this, "🛡 LOCAL ONLY", 10, UI.SUCCESS), UI.lp(this, -2, -2, 0, 0, 10, 0));
        privacy.addView(UI.tv(this, "پردازش آفلاین روی همین گوشی", 10, UI.TEXT, true), UI.lpw(1f));
        privacy.addView(UI.tv(this, "بدون ارسال اطلاعات", 9, UI.MUTED, false));
        col.addView(privacy, UI.lp(this, -1, -2, 0, 6, 0, 0));

        updateHomeScanUi();
    }

    private HomeStat addHomeStat(LinearLayout parent, String value, String small) {
        LinearLayout c = UI.vbox(this);
        c.setGravity(Gravity.CENTER);
        c.setPadding(dp(8), dp(12), dp(8), dp(12));
        c.setMinimumHeight(dp(96));
        c.setBackground(UI.raised(this, 20));
        TextView number = UI.tv(this, value, 23, UI.ACCENT, true);
        number.setGravity(Gravity.CENTER);
        number.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        c.addView(number);
        TextView caption = UI.tv(this, small, 10, UI.MUTED, false);
        caption.setGravity(Gravity.CENTER);
        caption.setMaxLines(2);
        caption.setGravity(Gravity.CENTER);
        caption.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        c.addView(caption);
        parent.addView(c, UI.lpw(1f));
        return new HomeStat(number);
    }

    private void addHomeStatSpacer(LinearLayout parent) {
        parent.addView(new View(this), UI.lp(this, 14, 1, 0, 0, 0, 0));
    }

    private boolean isHomeVisibleForLive() {
        return activityResumed && !isFinishing() && !splashShowing && tab == 0 && homeLive != null;
    }

    private void scheduleHomeTicker() {
        if (!isHomeVisibleForLive() || homeTickerScheduled) return;
        homeTickerScheduled = true;
        liveHandler.postDelayed(liveRefresh, 1500L);
    }

    private void stopHomeTicker() {
        homeTickerScheduled = false;
        liveHandler.removeCallbacks(liveRefresh);
    }

    private void updateHomeScanUi() {
        HomeLiveViews h = homeLive;
        if (h == null) return;
        Trace.beginSection("BY.Home.LiveRefresh");
        boolean permission = serviceOn();
        boolean consent = Cfg.sp(this).getBoolean("accessibility_disclosure_accepted", false);
        if (h.lastPermission == null || h.lastPermission.booleanValue() != permission) {
            setTextIfChanged(h.shieldChip, permission ? "● سپر فعال" : "● سپر غیرفعال");
            h.shieldChip.setTextColor(permission ? UI.SUCCESS : UI.WARN);
            h.shieldChip.setBackground(UI.tint(permission ? UI.SUCCESS : UI.WARN));
            h.lastPermission = permission;
        }
        setTextIfChanged(h.accessTitle, permission
                ? (consent ? "توضیحات و رضایت دسترسی فعال است" : "پیش از اسکن، توضیحات و رضایت را تکمیل کنید")
                : "دسترسی اسکن غیرفعال است؛ سایر بخش‌ها همچنان در دسترس‌اند");
        h.accessTitle.setTextColor(permission && consent ? UI.SUCCESS : UI.WARN);

        String badge, phase;
        int color;
        if (!permission) {
            badge = "دسترسی خاموش"; phase = "برای اسکن، دسترسی اختیاری را فعال کنید"; color = UI.WARN;
        } else if (!consent) {
            badge = "رضایت لازم"; phase = "ابتدا توضیحات مستقل را بخوانید و رضایت دهید"; color = UI.WARN;
        } else if (ScanService.fullMode && ScanService.fullPaused) {
            badge = "مکث"; phase = "اسکن موقتاً متوقف شده؛ بسته‌های ثبت‌شده حفظ شده‌اند"; color = UI.WARN;
        } else if (ScanService.fullMode && !ScanService.fullStartedScanning) {
            badge = "در انتظار"; phase = ScanService.fullConfirmed ? "در انتظار اتصال به صفحه‌ی بسته‌ها" : "در انتظار تأیید شما در صفحه‌ی بسته‌ها"; color = UI.INFO;
        } else if (ScanService.fullMode) {
            badge = "در حال اجرا"; phase = "استخراج خودکار"; color = UI.INFO;
        } else if (ScanService.fullFinished) {
            badge = "کامل شد"; phase = "استخراج پایان یافت"; color = UI.SUCCESS;
        } else if (ScanService.lastScanStatus != null && (ScanService.lastScanStatus.contains("خطا")
                || ScanService.lastScanStatus.contains("ناموفق") || ScanService.lastScanStatus.contains("نشد"))) {
            badge = "خطا"; phase = "اسکن با خطا یا وقفه روبه‌رو شد؛ جزئیات در پیام وضعیت آمده است"; color = UI.DANGER;
        } else if (ScanService.fullSteps > 0) {
            badge = "متوقف"; phase = "اسکن متوقف شده؛ اطلاعات قبلی حفظ شده‌اند"; color = UI.WARN;
        } else if (ScanService.lastCompletedScanAt <= 0) {
            badge = "بدون داده"; phase = "هنوز اسکن تکمیل‌شده‌ای ثبت نشده است"; color = UI.MUTED;
        } else {
            badge = "آماده"; phase = "آخرین اسکن تکمیل شده است"; color = UI.SUCCESS;
        }
        setTextIfChanged(h.scanChip, badge);
        if (h.lastScanColor != color) {
            h.scanChip.setTextColor(color);
            h.scanChip.setBackground(UI.tint(color));
            h.lastScanColor = color;
        }
        long completed = ScanService.lastCompletedScanAt;
        String status = ScanService.lastScanStatus == null ? "وضعیت اسکن در دسترس نیست" : ScanService.lastScanStatus;
        if (completed > 0) status += " • " + Fmt.ago(completed);
        setTextIfChanged(h.scanStatus, status);
        h.scanStatus.setTextColor(color);
        setTextIfChanged(h.scanCounts, "شناسایی " + Fmt.fa(String.valueOf(ScanService.lastScannedPackages))
                + "  |  معتبر " + Fmt.fa(String.valueOf(ScanService.lastValidPackages))
                + "  |  مشکوک " + Fmt.fa(String.valueOf(ScanService.lastSuspiciousPackages))
                + "  |  تکراری " + Fmt.fa(String.valueOf(ScanService.lastDuplicatePackages)));
        setVisibilityIfChanged(h.scanDuration, completed > 0 ? View.VISIBLE : View.GONE);
        if (completed > 0) setTextIfChanged(h.scanDuration, "مدت پردازش: " + Fmt.fa(String.valueOf(ScanService.lastScanDurationMs)) + " میلی‌ثانیه");
        boolean showProgress = ScanService.fullMode || ScanService.fullSteps > 0;
        setVisibilityIfChanged(h.scanPhase, showProgress ? View.VISIBLE : View.GONE);
        setVisibilityIfChanged(h.progress, showProgress ? View.VISIBLE : View.GONE);
        if (showProgress) {
            int pct = ScanService.fullFinished ? 100 : Math.min(95, Math.max(1,
                    ScanService.fullProgressPercent()));
            Op target = Cfg.opById(this, ScanService.fullTargetOpId);
            setTextIfChanged(h.scanPhase, phase + (target == null ? "" : " • " + target.name) + " • " + Fmt.fa(String.valueOf(pct)) + "٪");
            h.scanPhase.setTextColor(color);
            if (h.lastProgress != pct) { h.progress.setProgress(pct); h.lastProgress = pct; }
        } else {
            setTextIfChanged(h.scanPhase, phase);
            h.scanPhase.setTextColor(color);
        }
        String stamp = new SimpleDateFormat("HH:mm:ss", Locale.US).format(new Date());
        setTextIfChanged(h.scanUpdatedAt, "به‌روزرسانی صفحه: " + Fmt.fa(stamp));
        Trace.endSection();
    }

    private void setTextIfChanged(TextView view, String value) {
        if (view != null && !TextUtils.equals(view.getText(), value)) view.setText(value);
    }

    private void setVisibilityIfChanged(View view, int visibility) {
        if (view != null && view.getVisibility() != visibility) view.setVisibility(visibility);
    }

    private void requestHomeData(boolean force) {
        if (homeLive == null || tab != 0 || isFinishing()) return;
        if (!force && Store.version() == homeAppliedVersion) return;
        if (homeDataInFlight) { if (force) homeRefreshPending = true; return; }
        final Context app = getApplicationContext();
        final int token = ++homeRequestToken;
        homeDataInFlight = true;
        uiDataExecutor.execute(() -> {
            Trace.beginSection("BY.Home.SnapshotCompare");
            HomeData data = new HomeData();
            try {
                Store.Snapshot snapshot = Store.snapshotState(app);
                data.version = snapshot.version;
                data.records = snapshot.records;
                data.comparison = Compare.run(app, snapshot.records, new HashSet<String>());
                List<Op> ops = Cfg.ops(app);
                for (Op op : ops) if (op.enabled) data.activeOperators++;
                for (Pkg p : data.records) {
                    if (p.ts > data.latestAt) data.latestAt = p.ts;
                    Integer count = data.operatorCounts.get(p.op);
                    data.operatorCounts.put(p.op, count == null ? 1 : count + 1);
                    Long latest = data.operatorLatest.get(p.op);
                    if (latest == null || p.ts > latest) data.operatorLatest.put(p.op, p.ts);
                }
                for (Op op : ops) if (data.operatorCounts.containsKey(op.id)) data.operatorsWithData++;
            } catch (RuntimeException failure) {
                data.error = "HOME_DATA_UNAVAILABLE";
            }
            Trace.endSection();
            runOnUiThread(() -> {
                if (isFinishing() || isDestroyed() || token != homeRequestToken) return;
                homeDataInFlight = false;
                homeAppliedVersion = data.version;
                if (homeLive != null && tab == 0) applyHomeData(data);
                boolean rerun = homeRefreshPending || (data.error.isEmpty() && Store.version() != data.version);
                homeRefreshPending = false;
                if (rerun && isHomeVisibleForLive()) requestHomeData(true);
            });
        });
    }

    private void applyHomeData(HomeData data) {
        HomeLiveViews h = homeLive;
        if (h == null) return;
        if (!data.error.isEmpty() || data.comparison == null || data.records == null) {
            h.rankedCount.value.setText("—");
            h.operatorsWithData.value.setText("—");
            h.activeOperators.value.setText("—");
            h.latest.value.setText("—");
            h.bestEmpty.setText("بارگذاری داده‌ها ناموفق بود؛ برای تازه‌سازی دوباره وارد صفحه‌ی خانه شوید.");
            h.bestEmpty.setVisibility(View.VISIBLE);
            h.bestOffer.setVisibility(View.GONE);
            h.bestButton.setVisibility(View.GONE);
            return;
        }
        h.rankedCount.value.setText(Fmt.fa(String.valueOf(data.comparison.ranked.size())));
        h.operatorsWithData.value.setText(Fmt.fa(String.valueOf(data.operatorsWithData)));
        h.activeOperators.value.setText(Fmt.fa(String.valueOf(data.activeOperators)));
        h.latest.value.setText(data.latestAt <= 0 ? "—" : Fmt.ago(data.latestAt));
        for (Map.Entry<String, TextView> entry : h.operatorStatuses.entrySet()) {
            Op op = Cfg.opById(this, entry.getKey());
            int count = data.operatorCounts.containsKey(entry.getKey()) ? data.operatorCounts.get(entry.getKey()) : 0;
            long latest = data.operatorLatest.containsKey(entry.getKey()) ? data.operatorLatest.get(entry.getKey()) : 0L;
            String status = op == null || !op.enabled ? "اسکن غیرفعال"
                    : count > 0 ? Fmt.fa(String.valueOf(count)) + " بسته • " + Fmt.ago(latest)
                    : "آماده‌ی اسکن • هنوز داده‌ای نیست";
            entry.getValue().setText(status);
            entry.getValue().setTextColor(count > 0 ? UI.PRIMARY : UI.MUTED);
        }
        updateHomeBest(data.comparison);
        updateHomeScanUi();
    }

    private void updateHomeBest(Compare.Result result) {
        HomeLiveViews h = homeLive;
        if (h == null) return;
        if (result == null || result.ranked.isEmpty()) {
            h.bestSignature = "empty";
            h.bestEmpty.setText("هنوز بسته‌ی معتبر برای مقایسه ثبت نشده است. یکی از اپراتورها را باز کنید و وارد صفحه‌ی بسته‌ها شوید.");
            h.bestEmpty.setVisibility(View.VISIBLE);
            h.bestOffer.setVisibility(View.GONE);
            h.bestButton.setVisibility(View.GONE);
            return;
        }
        Pkg p = result.ranked.get(0);
        Double rawValue = result.val.get(p.key);
        String signature = p.key + "|" + p.ts + "|" + p.title + "|" + p.normalizedToman + "|"
                + p.finalToman + "|" + p.days + "|" + p.gb + "|" + Cfg.packagePriceLabel(this, p)
                + "|" + result.metric + "|" + rawValue;
        if (signature.equals(h.bestSignature)) return;
        h.bestSignature = signature;
        Op op = Cfg.opById(this, p.op);
        h.bestOperator.setText(op == null ? p.op : op.name);
        h.bestOperator.setTextColor(op == null ? UI.MUTED : op.color);
        h.bestOperator.setBackground(UI.tint(op == null ? UI.MUTED : op.color));
        h.bestTitle.setText(p.label());
        h.bestDays.setText("اعتبار " + Fmt.dec(p.days) + " روز");
        h.bestPrice.setText("قیمت نهایی: " + Cfg.packagePriceLabel(this, p));
        String metricValue = result.metric == Cfg.DURATION ? Fmt.dec(p.days)
                : Fmt.num(Math.round(Cfg.displayMetric(this, rawValue == null ? 0.0 : rawValue)));
        h.bestMetric.setText(metricValue);
        h.bestMetricUnit.setText(Cfg.metricUnit(this, result.unit));
        h.bestEmpty.setVisibility(View.GONE);
        h.bestOffer.setVisibility(View.VISIBLE);
        h.bestButton.setVisibility(View.VISIBLE);
    }

    /** Uses the installed operator application's real launcher identity (offline, no remote logo fetch). */
    private static final class OperatorLogo extends View {
        private final String id;
        private final android.graphics.Paint paint = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
        private final android.graphics.drawable.Drawable operatorIcon;
        private final int brandColor;

        OperatorLogo(Context c, String id) {
            super(c);
            this.id = id == null ? "" : id;
            Op op = Cfg.opById(c, this.id);
            brandColor = op == null ? 0xFF9C72E8 : op.color;
            android.graphics.drawable.Drawable found = null;
            if (op != null && op.pkgs != null) {
                for (String pkg : op.pkgs) {
                    try {
                        found = c.getPackageManager().getApplicationIcon(pkg);
                        break;
                    } catch (android.content.pm.PackageManager.NameNotFoundException ignored) { }
                }
            }
            operatorIcon = found == null ? null : found.getConstantState() == null
                    ? found : found.getConstantState().newDrawable(c.getResources()).mutate();
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
            setContentDescription(op == null ? "نشان اپراتور" : "نشان برنامه‌ی " + op.name);
        }

        @Override protected void onDraw(android.graphics.Canvas c) {
            float w = getWidth(), h = getHeight();
            if (w <= 0 || h <= 0) return;
            float side = Math.min(w, h) * .90f;
            float left = (w - side) * .5f, top = (h - side) * .5f;
            paint.setStyle(android.graphics.Paint.Style.FILL);
            paint.setColor(0x22FFFFFF);
            c.drawRoundRect(left - UI.dp(getContext(), 2), top - UI.dp(getContext(), 2),
                    left + side + UI.dp(getContext(), 2), top + side + UI.dp(getContext(), 2),
                    UI.dp(getContext(), 11), UI.dp(getContext(), 11), paint);
            if (operatorIcon != null) {
                operatorIcon.setBounds(Math.round(left), Math.round(top), Math.round(left + side), Math.round(top + side));
                operatorIcon.draw(c);
            } else {
                paint.setColor((brandColor & 0x00FFFFFF) | 0xFF000000);
                c.drawRoundRect(left, top, left + side, top + side, UI.dp(getContext(), 12), UI.dp(getContext(), 12), paint);
                paint.setColor(0xFFFFFFFF);
                paint.setTextAlign(android.graphics.Paint.Align.CENTER);
                paint.setTypeface(android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.BOLD));
                paint.setTextSize(side * .40f);
                String mark = id.equals("irancell") ? "I" : id.equals("mci") ? "M"
                        : id.equals("rightel") ? "R" : id.equals("samantel") ? "S" : "SM";
                c.drawText(mark, w * .5f, h * .5f + side * .14f, paint);
            }
        }
    }

    private void showAccessibilityDisclosure() {
        String disclosure = "بسته‌یاب فقط برای استخراج بسته‌های اینترنت از برنامهٔ اپراتوری که خودتان انتخاب و باز می‌کنید، از سرویس Accessibility استفاده می‌کند.\n\n"
                + "چه چیزی خوانده می‌شود؟ ساختار و متن قابل‌دسترسیِ پنجرهٔ فعال همان برنامهٔ انتخاب‌شده برای پیدا کردن کارت‌های بسته؛ مانند عنوان، شناسهٔ عمومی، قیمت، حجم و مدت. برچسب‌های دیگرِ قابل‌مشاهده در همان صفحه ممکن است موقتاً در حافظهٔ پردازش دیده شوند، اما فیلدهای قابل‌ویرایش و رمزدار اصلاً خوانده نمی‌شوند و فقط فیلدهای ساختاریافتهٔ بسته ذخیره می‌شوند. صفحه‌های سایر برنامه‌ها، اعلان‌ها، پیام‌ها و مخاطبان هدف نیستند.\n\n"
                + "چرا؟ برای تبدیل اطلاعات قابل‌مشاهدهٔ بسته‌ها به فهرست قابل‌مقایسه.\n\n"
                + "چه چیزی ذخیره می‌شود؟ مشخصات ساختاریافتهٔ بسته‌های معتبر مانند عنوان/شناسهٔ عمومی بسته، قیمت، حجم، مدت، دسته‌بندی و وضعیت بازبینی، به‌علاوهٔ تاریخچهٔ تغییرات و شمارنده‌های محدود اسکن؛ همه فقط در حافظهٔ محلی برنامه. متن خام صفحه، رمزها، فیلدهای ورود و اطلاعات حساب ذخیره نمی‌شود. داده‌ها را می‌توانید از بخش پاک‌کردن اطلاعات حذف کنید.\n\n"
                + "ارسال به سرور؟ کد این پروژه برای ارسال محتوای صفحه یا دادهٔ بسته‌ها به سرور بسته‌یاب مسیر شبکه‌ای ندارد؛ پردازش و ذخیره‌سازی محلی است. خود برنامهٔ اپراتور ممکن است برای بارگیری محتوای خودش به اینترنت متصل شود.\n\n"
                + "حرکت خودکار؟ فقط پس از انتخاب اپراتور و تأیید جداگانهٔ «تأیید و شروع» روی صفحهٔ بسته‌ها، ممکن است فرمان اسکرول یا swipe عمودی برای پیمایش فهرست انجام شود. خرید، پرداخت، فعال‌سازی بسته یا لمس دکمه‌های خرید انجام نمی‌شود. با «خروج/توقف اسکن» یا غیرفعال‌کردن سرویس، نشست متوقف می‌شود.\n\n"
                + "برنامه‌های مجاز: پنج اپراتور داخلیِ از پیش تعریف‌شده (ایرانسل، همراه اول، رایتل، سامانتل و شاتل)؛ برای اپراتور سفارشی فقط همان بستهٔ برنامه‌ای که خودتان در تنظیمات اپراتورها اضافه و سپس برای یک نشست انتخاب می‌کنید به فهرست موقت افزوده می‌شود. برنامه‌های بانکی، پیام‌رسان و سایر برنامه‌ها اسکن نمی‌شوند.\n\n"
                + "فعال‌کردن سرویس Accessibility به‌تنهایی اسکن را شروع نمی‌کند. ابتدا باید این توضیح را بپذیرید، سپس اپراتور را انتخاب کنید و در صفحهٔ بسته‌ها برای همان نشست «تأیید و شروع» را بزنید. رد این درخواست هیچ بخشی از برنامه را قفل نمی‌کند.";
        new AlertDialog.Builder(this)
                .setTitle("توضیح مستقل دسترسی و حریم خصوصی")
                .setMessage(disclosure)
                .setCancelable(true)
                .setNegativeButton("نمی‌پذیرم؛ ادامه بدون اسکن", (d, w) -> {
                    ScanService.revokeDisclosureConsent(this);
                    d.dismiss();
                    toast("رضایت لغو شد؛ اسکن انجام نمی‌شود و سایر بخش‌ها در دسترس‌اند.");
                    render();
                })
                .setPositiveButton("می‌پذیرم؛ بازکردن تنظیمات اندروید", (d, w) -> {
                    Cfg.sp(this).edit().putBoolean("accessibility_disclosure_accepted", true).apply();
                    startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
                }).show();
    }

    private void launch(Op o) {
        String targetPackage = null;
        Intent launchIntent = null;
        for (String p : o.pkgs) {
            Intent candidate = getPackageManager().getLaunchIntentForPackage(p);
            if (candidate != null) {
                targetPackage = p;
                launchIntent = candidate;
                break;
            }
        }
        if (launchIntent == null || targetPackage == null) {
            toast("برنامه‌ی " + o.name + " پیدا نشد؛ نصب بودن برنامه و نام پکیج را بررسی کنید.");
            return;
        }

        boolean auto = ScanService.inst != null && o.enabled;
        if (auto) {
            ScanService.startFull(o.id, targetPackage);
            auto = ScanService.fullMode;
        }
        try {
            startActivity(launchIntent);
            if (auto) {
                scheduleHomeTicker();
                toast("برنامه‌ی " + o.name + " باز شد؛ پس از ورود به بخش بسته‌های اینترنت، در پنجره‌ی شناور «تایید و شروع» را بزنید. برای مکث از «توقف اسکن» استفاده کنید.");
            } else if (!o.enabled) {
                toast("برنامه باز شد؛ این اپراتور در تنظیمات غیرفعال است و استخراج انجام نمی‌شود.");
            } else if (ScanService.inst != null && !ScanService.fullMode) {
                toast("برنامه باز شد؛ اسکن آغاز نشد. ابتدا توضیحات و رضایت را تکمیل کنید و دوباره اپراتور را انتخاب کنید.");
            } else {
                toast("برنامه باز شد؛ برای استخراج خودکار، ابتدا سرویس دسترسی بسته‌یاب را فعال کنید.");
            }
        } catch (RuntimeException e) {
            if (auto) ScanService.stopFull("باز کردن برنامه‌ی اپراتور ناموفق بود");
            toast("باز کردن برنامه‌ی " + o.name + " ناموفق بود: " + e.getClass().getSimpleName());
        }
    }

    // ---------------------------------------------------------------- compare

    private void compare(LinearLayout col) {
        LinearLayout header = UI.compact(this) ? UI.vbox(this) : UI.hbox(this);
        LinearLayout titles = UI.vbox(this);
        titles.addView(UI.tv(this, "رتبه‌بندی و بررسی بسته‌ها", 12, UI.MUTED, true));
        titles.addView(UI.tv(this, "مقایسه‌ی بسته‌ها", 22, UI.TEXT, true), UI.lp(this, -1, -2, 0, 3, 0, 0));
        titles.addView(UI.tv(this, "قیمت نهایی، حجم، اعتبار و هزینه‌ی هر گیگ", 13, UI.MUTED, false), UI.lp(this, -1, -2, 0, 3, 0, 0));
        header.addView(titles, UI.lpw(1f));
        compareCountChip = UI.chip(this, "در حال محاسبه…", UI.tint(UI.ACCENT), UI.PRIMARY);
        header.addView(compareCountChip, UI.lp(this, -2, -2, 0, UI.compact(this) ? 8 : 0, 0, 0));
        col.addView(header);

        LinearLayout filter = UI.card(this);
        filter.addView(UI.tv(this, "معیار رتبه‌بندی", 13, UI.TEXT, true));
        chips(filter, new String[]{"ارزان‌ترین هر گیگ", "بیشترین اعتبار", "هزینه مصرف من"}, Cfg.metric(this), i -> {
            Cfg.setInt(this, "metric", i); scroll[1] = 0; render();
        });
        filter.addView(UI.tv(this, "مقایسه‌ی بسته‌های هم‌اعتبار", 11, UI.MUTED, false), UI.lp(this, -1, -2, 0, 5, 0, 0));
        chips(filter, Compare.BUCKETS, Cfg.bucket(this), i -> {
            Cfg.setInt(this, "bucket", i); scroll[1] = 0; render();
        });
        if (Cfg.metric(this) == Cfg.MY_USAGE) {
            stepRow(filter, "مصرف ماهانه‌ی شما", "برآورد برای محاسبه‌ی هزینه‌ی مصرف", (int) Cfg.usage(this), 5, 500, 5, " گیگ", v -> {
                Cfg.setFloat(this, "usage", v); render();
            });
        }
        col.addView(filter, UI.lp(this, -1, -2, 0, 16, 0, 0));
        col.addView(tickCard(), UI.lp(this, -1, -2, 0, 16, 0, 8));

        compareSummaryText = UI.tv(this, "در حال محاسبه‌ی رتبه‌بندی…", 13, UI.MUTED, false);
        compareSummaryText.setPadding(dp(12), dp(10), dp(12), dp(10));
        compareSummaryText.setBackground(UI.inset(this, 14));
        col.addView(compareSummaryText, UI.lp(this, -1, -2, 0, 8, 0, 14));
        compareEmptyText = UI.tv(this, "هنوز بسته‌ی قابل مقایسه‌ای ثبت نشده است.", 14, UI.MUTED, false);
        compareEmptyText.setGravity(Gravity.CENTER);
        compareEmptyText.setVisibility(View.GONE);
        col.addView(compareEmptyText, UI.lp(this, -1, -2, 0, 8, 0, 12));
        compareResultsList = UI.vbox(this);
        compareResultsList.setClipChildren(false);
        col.addView(compareResultsList, UI.lp(this, -1, -2, 0, 0, 0, 0));
        compareRowViews.clear();
        compareRowSignatures.clear();
    }

    private void requestCompareData(boolean force) {
        if (compareResultsList == null || tab != 1 || isFinishing()) return;
        if (!force && Store.version() == compareAppliedVersion) return;
        if (compareDataInFlight) { if (force) compareRefreshPending = true; return; }
        final Context app = getApplicationContext();
        final int token = ++compareRequestToken;
        compareDataInFlight = true;
        uiDataExecutor.execute(() -> {
            Trace.beginSection("BY.Compare.SnapshotRank");
            Store.Snapshot snapshot;
            Compare.Result result;
            try {
                snapshot = Store.snapshotState(app);
                result = Compare.run(app, snapshot.records, new HashSet<String>());
            } catch (RuntimeException failure) {
                Trace.endSection();
                runOnUiThread(() -> {
                    if (isFinishing() || isDestroyed()) return;
                    compareDataInFlight = false;
                    if (tab == 1 && compareResultsList != null) {
                        compareCountChip.setText("خطا در دریافت");
                        compareSummaryText.setText("محاسبه‌ی رتبه‌بندی موقتاً ناموفق بود.");
                        compareEmptyText.setText("داده‌های ذخیره‌شده حذف نشده‌اند؛ دوباره وارد صفحه‌ی مقایسه شوید.");
                        compareEmptyText.setVisibility(View.VISIBLE);
                    }
                    boolean rerun = compareRefreshPending;
                    compareRefreshPending = false;
                    if (rerun && tab == 1) requestCompareData(true);
                });
                return;
            }
            Trace.endSection();
            final int recordCount = snapshot.records.size();
            final Store.Snapshot stableSnapshot = snapshot;
            final Compare.Result stableResult = result;
            runOnUiThread(() -> {
                if (isFinishing() || isDestroyed() || token != compareRequestToken) return;
                compareDataInFlight = false;
                compareAppliedVersion = stableSnapshot.version;
                if (tab == 1 && compareResultsList != null) applyCompareData(stableResult, recordCount);
                boolean rerun = compareRefreshPending || Store.version() != stableSnapshot.version;
                compareRefreshPending = false;
                if (rerun && tab == 1) requestCompareData(true);
            });
        });
    }

    private void applyCompareData(Compare.Result result, int recordCount) {
        if (compareResultsList == null) return;
        compareCountChip.setText(Fmt.fa(String.valueOf(recordCount)) + " ثبت‌شده");
        compareSummaryText.setText(Fmt.fa(String.valueOf(result.ranked.size())) + " بسته‌ی قطعی  •  " + result.label);
        boolean empty = result.ranked.isEmpty();
        compareEmptyText.setVisibility(empty ? View.VISIBLE : View.GONE);
        if (empty) compareEmptyText.setText(anyCmp()
                ? "هنوز بسته‌ی قابل مقایسه‌ای نیست. ممکن است قیمت یا وضعیت واحد/مالیات نیازمند بازبینی باشد."
                : "اپراتوری برای مقایسه انتخاب نشده است.");

        int limit = Math.min(80, result.ranked.size());
        Set<String> active = new HashSet<>();
        for (int i = 0; i < limit; i++) active.add(result.ranked.get(i).key);
        List<String> remove = new ArrayList<>();
        for (Map.Entry<String, View> e : compareRowViews.entrySet()) {
            if (!active.contains(e.getKey())) {
                compareResultsList.removeView(e.getValue());
                remove.add(e.getKey());
            }
        }
        for (String key : remove) {
            compareRowViews.remove(key);
            compareRowSignatures.remove(key);
        }

        for (int i = 0; i < limit; i++) {
            Pkg p = result.ranked.get(i);
            String key = p.key;
            Double value = result.val.get(key);
            String signature = p.ts + "|" + p.title + "|" + p.label() + "|" + p.gb + "|" + p.days + "|"
                    + p.normalizedToman + "|" + p.finalToman + "|" + Cfg.packagePriceLabel(this, p)
                    + "|" + p.restricted + "|" + p.ambig + "|" + p.currencyKnown + "|" + p.taxKnown
                    + "|" + p.taxIncluded + "|" + p.classificationConflict + "|" + p.identityConflict
                    + "|" + p.reviewStatus + "|" + result.metric + "|" + value + "|" + result.rank.get(key);
            View row = compareRowViews.get(key);
            if (row == null || !signature.equals(compareRowSignatures.get(key))) {
                if (row != null) compareResultsList.removeView(row);
                row = pkgRow(p, i + 1, result);
                compareRowViews.put(key, row);
                compareRowSignatures.put(key, signature);
            }
            int current = compareResultsList.indexOfChild(row);
            if (current != i) {
                if (current >= 0) compareResultsList.removeView(row);
                compareResultsList.addView(row, Math.min(i, compareResultsList.getChildCount()),
                        UI.lp(this, -1, -2, 0, 0, 0, 14));
            }
        }
        if (result.ranked.size() > limit) {
            // One stable note view; only its visibility changes.
            if (compareResultsList.getChildCount() == limit) {
                TextView note = UI.tv(this, "برای سبک ماندن صفحه، ۸۰ نتیجه‌ی نخست نمایش داده می‌شود.", 10, UI.MUTED, false);
                note.setTag("compare.limit.note");
                compareResultsList.addView(note, UI.lp(this, -1, -2, 0, 4, 0, 0));
            }
        } else {
            for (int i = compareResultsList.getChildCount() - 1; i >= 0; i--) {
                View child = compareResultsList.getChildAt(i);
                if ("compare.limit.note".equals(child.getTag())) compareResultsList.removeViewAt(i);
            }
        }
    }

    private boolean anyCmp() {
        for (Op o : Cfg.ops(this)) if (o.cmp) return true;
        return false;
    }

    private void setAllCmp(boolean on) {
        List<Op> ops = Cfg.ops(this);
        for (Op o : ops) o.cmp = on;
        Cfg.saveOps(this, ops);
        render();
    }

    private View tickCard() {
        LinearLayout c = UI.card(this);
        List<Op> ops = Cfg.ops(this);
        LinearLayout hd = UI.hbox(this);
        hd.addView(UI.tv(this, "انتخاب اپراتورها", 13, UI.TEXT, true), UI.lpw(1f));
        hd.addView(UI.btn(this, "همه", UI.CARD2, UI.PRIMARY, v -> setAllCmp(true)), UI.lp(this, -2, -2, 0, 0, 5, 0));
        hd.addView(UI.btn(this, "هیچ‌کدام", UI.CARD2, UI.MUTED, v -> setAllCmp(false)));
        c.addView(hd);
        LinearLayout pills = UI.vbox(this);
        for (int i = 0; i < ops.size(); i += 2) {
            LinearLayout row = UI.hbox(this);
            for (int j = i; j < Math.min(i + 2, ops.size()); j++) {
                final Op o = ops.get(j);
                TextView pill = UI.choice(this, (o.cmp ? "✓  " : "○  ") + o.name, o.cmp);
                pill.setOnClickListener(v -> {
                    o.cmp = !o.cmp;
                    Cfg.saveOps(this, ops);
                    render();
                });
                LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(0, -2, 1f);
                pp.setMargins(dp(4), dp(12), dp(4), 4);
                row.addView(pill, pp);
            }
            if (ops.size() % 2 == 1 && i + 1 == ops.size() - 1) {
                row.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1f));
            }
            pills.addView(row);
        }
        c.addView(pills);
        int selected = 0;
        for (Op o : ops) if (o.cmp) selected++;
        c.addView(UI.tv(this, selected == 0 ? "برای نمایش نتیجه، یک اپراتور را انتخاب کنید." :
                Fmt.fa(String.valueOf(selected)) + " اپراتور در مقایسه شرکت می‌کنند.", 10, UI.MUTED, false), UI.lp(this, -1, -2, 0, 7, 0, 0));
        return c;
    }

    private View pkgRow(Pkg p, int rank, Compare.Result cr) {
        Op op = Cfg.opById(this, p.op);
        int actualRank = cr.rank.containsKey(p.key) ? cr.rank.get(p.key) : rank;
        int opColor = op == null ? UI.MUTED : op.color;
        double metric = cr.val.containsKey(p.key) ? cr.val.get(p.key) : 0d;
        double med = cr.median;
        long discount = cr.metric != Cfg.DURATION && med > 0 && metric < med
                ? Math.round((med - metric) * 100d / med) : 0;

        LinearLayout card = UI.vbox(this);
        card.setPadding(dp(14), dp(14), dp(14), dp(14));
        card.setBackground(actualRank == 1
                ? new NeuDrawable(NeuDrawable.RAISED, dp(22), dp(7), UI.CARD2, UI.CARD, UI.LSH, UI.DSH,
                        (UI.PRIMARY & 0x00FFFFFF) | 0x88000000, dp(1.2f), 0)
                : UI.raised(this, 22, 5, true));

        LinearLayout top = UI.hbox(this);
        TextView badge = UI.tv(this, Fmt.fa(String.valueOf(actualRank)), 14, actualRank == 1 ? UI.ACCENT : UI.TEXT, true);
        badge.setGravity(Gravity.CENTER);
        badge.setBackground(actualRank == 1 ? UI.inset(this, 12, UI.ACCENT) : UI.inset(this, 12));
        top.addView(badge, UI.lp(this, 36, 36, 0, 0, 8, 0));
        top.addView(new OperatorLogo(this, op == null ? p.op : op.id), UI.lp(this, 36, 32, 0, 0, 8, 0));
        TextView operatorChip = UI.chip(this, op == null ? p.op : op.name, UI.tint(opColor), opColor);
        top.addView(operatorChip, new LinearLayout.LayoutParams(0, -2, 1f));
        card.addView(top);

        LinearLayout flags = UI.vbox(this);
        if (p.restricted) flags.addView(UI.chip(this, "بسته‌ی محدود/ویژه", UI.tint(UI.DANGER), UI.DANGER), UI.lp(this, -2, -2, 0, 8, 0, 0));
        if (isInternationalPackage(p)) flags.addView(UI.chip(this, "بین‌الملل / رومینگ", UI.tint(UI.INFO), UI.INFO), UI.lp(this, -2, -2, 0, 6, 0, 0));
        if (discount > 0) flags.addView(UI.chip(this, Fmt.fa(String.valueOf(discount)) + "٪ زیر میانه", UI.tint(UI.SUCCESS), UI.SUCCESS), UI.lp(this, -2, -2, 0, 6, 0, 0));
        if (flags.getChildCount() > 0) card.addView(flags);

        TextView label = UI.tv(this, p.title == null || p.title.trim().isEmpty() ? "بسته‌ی اینترنت" : p.title, 16, UI.TEXT, true);
        label.setMaxLines(Integer.MAX_VALUE);
        label.setEllipsize(null);
        label.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
        label.setTextAlignment(View.TEXT_ALIGNMENT_GRAVITY);
        card.addView(label, UI.lp(this, -1, -2, 0, 10, 0, 5));

        String volume = p.gb > 0 && p.gb < 1
                ? Fmt.num(Math.round(p.gb * 1024d)) + " مگابایت"
                : p.gb > 0 ? Fmt.dec(p.gb) + " گیگابایت" : "نامشخص";
        String validity = p.days > 0 ? Fmt.dec(p.days) + " روز" : "نامشخص";
        String kind = "COMBO".equals(p.identityKind) ? "اینترنت، مکالمه و پیامک"
                : "DATA".equals(p.identityKind) ? "اینترنت" : "نوع بسته نامشخص";
        card.addView(metricLine("حجم بسته", volume), UI.lp(this, -1, -2, 0, 5, 0, 0));
        card.addView(metricLine("اعتبار", validity), UI.lp(this, -1, -2, 0, 5, 0, 0));
        card.addView(metricLine("نوع بسته", kind), UI.lp(this, -1, -2, 0, 5, 0, 0));

        LinearLayout priceBlock = UI.vbox(this);
        priceBlock.setPadding(dp(12), dp(10), dp(12), dp(10));
        priceBlock.setBackground(UI.inset(this, 14));
        priceBlock.addView(UI.tv(this, "قیمت نهایی با واحد نمایش انتخاب‌شده", 12, UI.MUTED, false));
        TextView priceValue = UI.tv(this, Cfg.packagePriceLabel(this, p), 15, UI.TEXT, true);
        priceValue.setMaxLines(3);
        priceBlock.addView(priceValue, UI.lp(this, -1, -2, 0, 3, 0, 0));
        card.addView(priceBlock, UI.lp(this, -1, -2, 0, 10, 0, 0));

        double perGbToman = p.gb > 0 ? Cfg.finalPrice(this, p) / p.gb : 0;
        LinearLayout perBlock = UI.vbox(this);
        perBlock.setPadding(dp(12), dp(10), dp(12), dp(10));
        perBlock.setBackground(UI.raisedSmall(this, 14));
        perBlock.addView(UI.tv(this, "هزینه‌ی هر گیگ", 12, UI.MUTED, false));
        String perText = p.gb > 0 ? Cfg.priceLabel(this, Math.round(perGbToman)) + " / گیگابایت" : "برای این بسته محاسبه نمی‌شود";
        perBlock.addView(UI.tv(this, perText, 14, actualRank == 1 ? UI.ACCENT : UI.TEXT, true), UI.lp(this, -1, -2, 0, 3, 0, 0));
        card.addView(perBlock, UI.lp(this, -1, -2, 0, 7, 0, 0));
        card.setOnClickListener(v -> showDetail(p));
        card.setFocusable(true);
        card.setContentDescription("رتبه " + Fmt.fa(String.valueOf(actualRank)) + "، " + (op == null ? p.op : op.name)
                + "، " + volume + "، اعتبار " + validity + "، قیمت " + Cfg.packagePriceLabel(this, p) + "، برای جزئیات لمس کنید");
        return card;
    }

    private View metricLine(String label, String value) {
        LinearLayout line = UI.hbox(this);
        TextView name = UI.tv(this, label, 12, UI.MUTED, false);
        line.addView(name, new LinearLayout.LayoutParams(0, -2, 0.8f));
        TextView data = UI.tv(this, value, 13, UI.TEXT, true);
        data.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
        data.setTextAlignment(View.TEXT_ALIGNMENT_GRAVITY);
        line.addView(data, new LinearLayout.LayoutParams(0, -2, 1.2f));
        return line;
    }

    private boolean isInternationalPackage(Pkg p) {
        String evidence = ((p.why == null ? "" : p.why) + " " + (p.identityTitle == null ? "" : p.identityTitle)
                + " " + (p.title == null ? "" : p.title));
        String normalized = Fmt.norm(evidence);
        return normalized.contains("بین الملل") || normalized.contains("رومینگ")
                || normalized.contains("خارج از کشور") || normalized.toLowerCase(Locale.ROOT).contains("international");
    }

    private void showDetail(final Pkg p) {
        final Op op = Cfg.opById(this, p.op);
        String operator = op == null ? p.op : op.name;
        StringBuilder sb = new StringBuilder();
        sb.append(operator).append("\n");
        sb.append(p.label()).append("\n");
        if (p.currencyKnown && !p.ambig) {
            sb.append("قیمت پایه: ").append(Cfg.priceLabel(this, p.toman)) .append("\n");
            sb.append("با ارزش افزوده: ").append(Cfg.packagePriceLabel(this, p)).append("\n");
        } else {
            // Never display a candidate number as the package price when the parser could not
            // verify which amount belongs to this offer.
            sb.append("قیمت این بسته به‌صورت قطعی شناسایی نشد.\n");
            sb.append("تا بررسی دوباره، در رتبه‌بندی و مقایسه استفاده نمی‌شود.");
        }
        if (p.restricted && !p.ambig) {
            sb.append("\nمحدودیت: ").append(p.why);
        }
        if (isInternationalPackage(p)) sb.append("\nنوع تعرفه: بین‌الملل / رومینگ");
        sb.append("\nحجم: ").append(p.gb > 0 ? Fmt.dec(p.gb) + " گیگابایت" : "نامشخص");
        sb.append("\nاعتبار: ").append(p.days > 0 ? Fmt.dec(p.days) + " روز" : "نامشخص");
        new UI.Dlg(this).title("جزئیات بسته").message(sb.toString()).button("بستن", 0, null).show();
    }

    // ---------------------------------------------------------------- settings

    private void settings(LinearLayout col) {
        LinearLayout heading = UI.compact(this) ? UI.vbox(this) : UI.hbox(this);
        LinearLayout title = UI.vbox(this);
        title.addView(UI.tv(this, "تنظیم ظاهر و رفتار برنامه", 12, UI.MUTED, true));
        title.addView(UI.tv(this, "تنظیمات", 22, UI.TEXT, true), UI.lp(this, -1, -2, 0, 3, 0, 0));
        title.addView(UI.tv(this, "ظاهر، اپراتورها، فیلترها، پنجره‌ی شناور و داده‌ها", 13, UI.MUTED, false), UI.lp(this, -1, -2, 0, 3, 0, 0));
        heading.addView(title, UI.lpw(1f));
        heading.addView(UI.chip(this, "ذخیره‌ی خودکار", UI.tint(UI.ACCENT), UI.PRIMARY), UI.lp(this, -2, -2, 0, UI.compact(this) ? 8 : 0, 0, 0));
        col.addView(heading);

        LinearLayout display = section(col, "ظاهر و نمایش");
        display.addView(UI.tv(this, "حالت رنگی برنامه", 12, UI.TEXT, true));
        int activeTheme = UI.mono ? 1 : UI.light ? 2 : 0;
        chips(display, new String[]{"سایبری", "تک‌رنگ", "روشن"},
                activeTheme, i -> {
                    String selected = i == 1 ? "mono" : i == 2 ? "light" : "dark";
                    Cfg.sp(this).edit().putString("appearance", selected).apply();
                    UI.applyTheme(this);
                    applySystemBars();
                    if (appBackdrop != null) appBackdrop.refreshTheme();
                    render();
                });
        display.addView(UI.tv(this,
                "سایبری: سرمه‌ای عمیق با شبکه‌ی مدارهای زنده با پالس‌های آرام و تأکید فیروزه‌ای؛ تک‌رنگ: مینیمال؛ روشن: زمینه‌ی روشن و کم‌کنتراست.",
                10, UI.MUTED, false), UI.lp(this, -1, -2, 0, 0, 0, 12));
        display.addView(UI.tv(this, "واحد نمایش قیمت‌ها", 12, UI.TEXT, true));
        chips(display, new String[]{"تومان", "ریال"}, "IRR".equals(Cfg.displayCurrency(this)) ? 1 : 0, i -> {
            Cfg.setDisplayCurrency(this, i == 1 ? "IRR" : "IRT");
            if (ScanService.inst != null) ScanService.inst.hideComparisonPopup();
            render();
        });
        display.addView(UI.tv(this, "قیمت‌ها در حافظه بر اساس تومان نگهداری می‌شوند؛ تغییر این گزینه فقط واحد نمایش را عوض می‌کند.", 10, UI.MUTED, false), UI.lp(this, -1, -2, 0, 2, 0, 0));

        LinearLayout c = section(col, "اسکن اپراتورها");
        c.addView(UI.tv(this, "اسکن فقط برای اپراتورهای روشن انجام می‌شود.", 10, UI.MUTED, false));
        List<Op> ops = Cfg.ops(this);
        for (final Op o : ops) {
            LinearLayout r = UI.vbox(this);
            LinearLayout mainRow = UI.hbox(this);
            LinearLayout t = UI.vbox(this);
            mainRow.addView(new OperatorLogo(this, o.id), UI.lp(this, 42, 34, 0, 0, 10, 0));
            t.addView(UI.tv(this, o.name, 14, UI.TEXT, true));
            StringBuilder packageNamesBuilder = new StringBuilder();
            for (String packageName : o.pkgs) {
                if (packageNamesBuilder.length() > 0) packageNamesBuilder.append("، ");
                packageNamesBuilder.append(android.text.BidiFormatter.getInstance().unicodeWrap(packageName));
            }
            String packageNames = packageNamesBuilder.toString();
            TextView pk = UI.tv(this, packageNames + " • " + (o.cur.equals("IRR") ? "ریال" : o.cur.equals("IRT") ? "تومان" : "واحد خودکار"), 12, UI.MUTED, false);
            pk.setTextDirection(View.TEXT_DIRECTION_RTL);
            pk.setMaxLines(3);
            t.addView(pk, UI.lp(this, -1, -2, 0, 3, 0, 0));
            mainRow.addView(t, UI.lpw(1f));
            r.addView(mainRow);
            LinearLayout actions = UI.hbox(this);
            actions.addView(UI.btn(this, "پیکربندی", UI.CARD2, UI.PRIMARY, v -> editOp(o)), new LinearLayout.LayoutParams(0, -2, 1f));
            Switch sw = new Switch(this);
            styleSwitch(sw);
            sw.setChecked(o.enabled);
            sw.setContentDescription("فعال‌سازی اسکن " + o.name);
            sw.setOnCheckedChangeListener((bv, enabled) -> { o.enabled = enabled; Cfg.saveOps(this, ops); });
            actions.addView(sw, UI.lp(this, -2, -2, 10, 0, 0, 0));
            r.addView(actions, UI.lp(this, -1, -2, 0, 8, 0, 0));
            c.addView(r, UI.lp(this, -1, -2, 0, 10, 0, 10));
            if (!o.builtin) c.addView(UI.btn(this, "حذف اپراتور سفارشی: " + o.name, UI.tint(UI.DANGER), UI.DANGER, v -> new UI.Dlg(this)
                    .title("حذف اپراتور سفارشی")
                    .message("«" + o.name + "» از فهرست حذف شود؟ بسته‌های ذخیره‌شده‌ی همین اپراتور نیز پاک خواهند شد.")
                    .button("حذف اپراتور و داده‌ها", 2, dialog -> {
                        dialog.dismiss(); ops.remove(o); Cfg.saveOps(this, ops); Store.clearOp(this, o.id);
                        toast("اپراتور و داده‌های وابسته حذف شدند"); render();
                    })
                    .button("انصراف", 1, null).show()), UI.lp(this, -1, -2, 0, 0, 0, 5));
        }
        int enabledCount = 0;
        for (Op o : ops) if (o.cmp) enabledCount++;
        stepRow(c, "حداقل تعداد اپراتور برای مقایسه", "برای نمایش کادر مقایسه‌ی چنداپراتوری", Cfg.minOps(this), 1, Math.max(1, enabledCount), 1, "", v -> {
            Cfg.setInt(this, "minOps", v); render();
        });

        LinearLayout custom = section(col, "افزودن اپراتور سفارشی");
        custom.addView(input("نام اپراتور", newName, s -> newName = s), UI.lp(this, -1, -2, 0, 3, 0, 6));
        EditText pkgInput = input("نام بسته‌ی برنامه؛ مانند ir.example.app", newPkg, s -> newPkg = s);
        pkgInput.setTextDirection(View.TEXT_DIRECTION_LTR);
        custom.addView(pkgInput, UI.lp(this, -1, -2, 0, 0, 0, 6));
        chips(custom, new String[]{"واحد خودکار", "ریال", "تومان"}, newCur, i -> { newCur = i; render(); });
        custom.addView(UI.btn(this, "افزودن اپراتور", UI.PRIMARY, 0xFF061326, v -> addOp()), UI.lp(this, -1, -2, 0, 8, 0, 0));

        LinearLayout comparison = section(col, "فیلترهای مقایسه");
        comparison.addView(UI.tv(this, "معیار رتبه‌بندی", 12, UI.TEXT, true));
        chips(comparison, new String[]{"ارزان‌ترین هر گیگ", "بیشترین اعتبار", "هزینه مصرف من"}, Cfg.metric(this), i -> { Cfg.setInt(this, "metric", i); render(); });
        numberRow(comparison, "حداقل حجم بسته (مگابایت؛ صفر = همه)", Fmt.num(Math.round(Cfg.minGb(this) * 1024)),
                s -> Cfg.setFloat(this, "minGb", Math.max(0f, Math.min(5120000f, (float) (Fmt.parse(s, 0) / 1024.0)))));
        numberRow(comparison, "حداکثر اعتبار (روز؛ صفر = بدون محدودیت)", Fmt.dec(Cfg.maxDays(this)),
                s -> Cfg.setInt(this, "maxDays", Cfg.clamp((int) Fmt.parse(s, 0), 0, 36500)));
        numberRow(comparison, "مصرف ماهانه‌ی من (گیگ)", Fmt.dec(Cfg.usage(this)),
                s -> Cfg.setFloat(this, "usage", Cfg.finiteClamp((float) Fmt.parse(s, 30), 0.1f, 5000f, 30f)));
        numberRow(comparison, "ارزش افزوده (درصد)", Fmt.num(Cfg.vat(this)), s -> Cfg.setInt(this, "vat", Math.max(0, Math.min(100, (int) Fmt.parse(s, Cfg.vat(this))))));
        swRow(comparison, "نمایش بسته‌های ویژه", "شبانه، هدیه، اپلیکیشن و محدود", Cfg.restricted(this), (bv, on) -> Cfg.setBool(this, "restricted", on));
        swRow(comparison, "نمایش بسته‌های بین‌الملل و رومینگ", "جدا از مقایسه‌ی بسته‌های داخلی", Cfg.intl(this), (bv, on) -> Cfg.setBool(this, "intl", on));

        LinearLayout popup = section(col, "پنجره‌ی شناور و اعلان‌ها");
        swRow(popup, "نمایش خودکار پنجره‌ی مقایسه", "پس از شناسایی بسته‌ها نمایش داده شود", Cfg.popup(this), (bv, on) -> Cfg.setBool(this, "popup", on));
        popup.addView(UI.tv(this, "محتوای پنجره", 12, UI.TEXT, true), UI.lp(this, -1, -2, 0, 8, 0, 0));
        chips(popup, new String[]{"هر دو", "برترین کل", "همین صفحه"}, Cfg.pmode(this), i -> { Cfg.setInt(this, "pmode", i); render(); });
        stepRow(popup, "تعداد ردیف‌های پنجره", null, Cfg.rows(this), 3, 8, 1, "", v -> { Cfg.setInt(this, "rows", v); render(); });
        int[] hv = {0, 8, 15, 30}; int hsel = 0;
        for (int i=0;i<hv.length;i++) if (hv[i] == Cfg.hideSec(this)) hsel = i;
        chips(popup, new String[]{"بدون بستن خودکار", "۸ ثانیه", "۱۵ ثانیه", "۳۰ ثانیه"}, hsel, i -> { Cfg.setInt(this, "hide", hv[i]); render(); });
        chips(popup, new String[]{"بالای صفحه", "پایین صفحه"}, Cfg.bottom(this) ? 1 : 0, i -> { Cfg.setBool(this, "bottom", i == 1); render(); });
        popup.addView(UI.btn(this, "آزمایش پنجره‌ی شناور", UI.CARD2, UI.PRIMARY, v -> {
            ScanService service = ScanService.inst;
            if (service == null) toast("ابتدا دسترسی اسکن را فعال کنید"); else service.showTest();
        }), UI.lp(this, -1, -2, 0, 8, 0, 0));

        LinearLayout data = section(col, "اعتبار داده و خروجی");
        data.addView(UI.tv(this, "داده‌های قدیمی‌تر از این مدت از مقایسه کنار گذاشته می‌شوند.", 10, UI.MUTED, false));
        int[] fresh = {3, 7, 14, 30}; int sel = 0;
        for (int i=0;i<fresh.length;i++) if (fresh[i] == Cfg.fresh(this)) sel = i;
        chips(data, new String[]{"۳ روز", "۷ روز", "۱۴ روز", "۳۰ روز"}, sel, i -> { Cfg.setInt(this, "fresh", fresh[i]); render(); });
        List<Pkg> pendingReview = Store.reviewQueue(this);
        data.addView(UI.tv(this, "بسته‌های مبهم تا زمان تأیید دستی وارد رتبه‌بندی قطعی نمی‌شوند.", 10, UI.MUTED, false), UI.lp(this, -1, -2, 0, 8, 0, 0));
        data.addView(UI.btn(this, "بازبینی بسته‌های نیازمند تأیید  •  " + Fmt.fa(String.valueOf(pendingReview.size())),
                UI.CARD2, UI.PRIMARY, v -> showReviewQueue()), UI.lp(this, -1, -2, 0, 7, 0, 0));
        if (HistoryLog.hasError(this)) {
            LinearLayout historyWarning = UI.vbox(this);
            historyWarning.setPadding(dp(14), dp(14), dp(14), dp(14));
            historyWarning.setBackground(UI.inset(this, 18, UI.DANGER));
            historyWarning.addView(UI.tv(this, HistoryLog.errorSummary(this), 10, UI.DANGER, false));
            historyWarning.addView(UI.btn(this, "پاک‌کردن هشدار پس از بررسی", UI.CARD2, UI.TEXT, v -> {
                HistoryLog.clearError(this); render();
            }), UI.lp(this, -1, -2, 0, 6, 0, 0));
            data.addView(historyWarning, UI.lp(this, -1, -2, 0, 8, 0, 0));
        }
        data.addView(UI.btn(this, "خروجی بسته‌ها (CSV / Excel)", UI.CARD2, UI.PRIMARY, v -> exportCsv()), UI.lp(this, -1, -2, 0, 10, 0, 0));
        data.addView(UI.btn(this, "خروجی گزارش خطا (TXT)", UI.CARD2, UI.TEXT, v -> exportDiag()), UI.lp(this, -1, -2, 0, 7, 0, 0));
        LinearLayout history = UI.vbox(this);
        history.setPadding(dp(14), dp(14), dp(14), dp(14));
        history.setBackground(UI.inset(this, 18));
        history.addView(UI.tv(this, "گزارش تغییرات", 11, UI.MUTED, true));
        history.addView(UI.tv(this, "تاریخچه‌ی تغییرات بسته‌ها", 13, UI.TEXT, true), UI.lp(this, -1, -2, 0, 2, 0, 0));
        List<HistoryLog.Entry> changes = HistoryLog.recent(this, 6);
        if (changes.isEmpty()) history.addView(UI.tv(this, "هنوز تغییری بین دو اسکن ثبت نشده است.", 10, UI.MUTED, false), UI.lp(this, -1, -2, 0, 6, 0, 0));
        for (HistoryLog.Entry ch : changes) {
            boolean reviewApproved = "review_approved".equals(ch.field);
            boolean reviewRejected = "review_rejected".equals(ch.field);
            if (reviewApproved || reviewRejected) {
                String label = reviewApproved ? "تأیید دستی" : "رد دستی";
                String detail = ch.note == null || ch.note.isEmpty() ? "" : "\n" + ch.note;
                history.addView(UI.tv(this, label + " • " + ch.title + detail + "  ·  " + Fmt.ago(ch.ts),
                        10, reviewApproved ? UI.PRIMARY : UI.DANGER, false), UI.lp(this, -1, -2, 0, 7, 0, 0));
                continue;
            }
            boolean price = "price".equals(ch.field);
            String field = price ? "قیمت" : ("gb".equals(ch.field) ? "حجم" : "مدت");
            String before = price ? Cfg.priceLabel(this, (long)ch.before) : Fmt.dec(ch.before) + ("gb".equals(ch.field) ? " گیگ" : " روز");
            String after = price ? Cfg.priceLabel(this, (long)ch.after) : Fmt.dec(ch.after) + ("gb".equals(ch.field) ? " گیگ" : " روز");
            history.addView(UI.tv(this, field + " • " + ch.title + "\n" + before + " ← " + after + "  ·  " + Fmt.ago(ch.ts), 10, price ? UI.ACCENT : UI.MUTED, false),
                    UI.lp(this, -1, -2, 0, 7, 0, 0));
        }
        data.addView(history, UI.lp(this, -1, -2, 0, 10, 0, 0));
        data.addView(UI.btn(this, "پاک‌کردن بسته‌های ذخیره‌شده", UI.tint(UI.DANGER), UI.DANGER, v -> new UI.Dlg(this)
                .title("پاک‌کردن اطلاعات")
                .message("همه‌ی بسته‌های ذخیره‌شده و تاریخچه‌ی تغییرات حذف شوند؟")
                .button("پاک شود", 2, d -> { d.dismiss(); Store.clearAll(this); HistoryLog.clear(this); HistoryLog.clearError(this); toast("اطلاعات پاک شد"); render(); })
                .button("انصراف", 1, null)
                .show()), UI.lp(this, -1, -2, 0, 10, 0, 0));

        TextView privacy = UI.tv(this, "حریم خصوصی: فقط نشست تأییدشدهٔ اپراتور انتخابی خوانده می‌شود؛ متن خام و اطلاعات حساب ذخیره یا به سرور بسته‌یاب ارسال نمی‌شود.", 10, UI.MUTED, false);
        privacy.setGravity(Gravity.CENTER);
        col.addView(privacy, UI.lp(this, -1, -2, 0, 16, 0, 0));
    }

    private void showReviewQueue() {
        List<Pkg> queue = Store.reviewQueue(this);
        if (queue.isEmpty()) {
            toast("بسته‌ای برای بازبینی باقی نمانده است");
            return;
        }
        String[] labels = new String[queue.size()];
        final List<Dialog[]> rows = new ArrayList<>();
        for (int i = 0; i < queue.size(); i++) {
            Pkg p = queue.get(i);
            Op op = Cfg.opById(this, p.op);
            String owner = op == null ? p.op : op.name;
            String conflictLabel = p.identityConflict
                    ? "\nتعارض شناسه/مشخصات؛ هر دو نسخه حفظ شده‌اند"
                    : p.classificationConflict
                    ? "\nتعارض طبقه‌بندی؛ برچسب اصلی: " + (p.why == null || p.why.isEmpty() ? "عمومی" : p.why)
                        + "\nبرچسب‌های دیده‌شده: " + p.classificationVariants.replace("\n", " / ")
                    : "";
            labels[i] = owner + " • " + (p.title == null || p.title.isEmpty() ? "بسته‌ی بدون عنوان" : p.title)
                    + "\n" + p.label() + " • " + (p.currencyKnown ? Cfg.priceLabel(this, p.toman) : "واحد/قیمت نیازمند بررسی")
                    + conflictLabel;
        }
        LinearLayout list = UI.vbox(this);
        for (int i = 0; i < queue.size(); i++) {
            final Pkg item = queue.get(i);
            LinearLayout row = UI.vbox(this);
            row.setPadding(dp(14), dp(12), dp(14), dp(12));
            row.setBackground(UI.raisedSmall(this, 16));
            row.addView(UI.tv(this, labels[i], 11, UI.TEXT, false));
            final Dialog[] holder = new Dialog[1];
            row.setOnClickListener(v -> { if (holder[0] != null) holder[0].dismiss(); editReview(item); });
            list.addView(row, UI.lp(this, -1, -2, 0, 0, 0, 10));
            rows.add(holder);
        }
        Dialog dlg = new UI.Dlg(this).title("صف بازبینی بسته‌های مبهم").view(list).button("بستن", 1, null).show();
        for (Dialog[] h : rows) h[0] = dlg;
    }

    private void editReview(Pkg source) {
        final EditText volume = input("حجم صحیح بر حسب گیگ", Fmt.dec(source.gb), value -> {});
        final EditText days = input("مدت صحیح بر حسب روز؛ صفر اگر نامشخص است", Fmt.dec(source.days), value -> {});
        final EditText price = input("قیمت صحیح بر حسب تومان", String.valueOf(source.toman), value -> {});
        volume.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        days.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        price.setInputType(InputType.TYPE_CLASS_NUMBER);
        volume.setTextDirection(View.TEXT_DIRECTION_LTR);
        days.setTextDirection(View.TEXT_DIRECTION_LTR);
        price.setTextDirection(View.TEXT_DIRECTION_LTR);
        volume.setGravity(Gravity.CENTER); days.setGravity(Gravity.CENTER); price.setGravity(Gravity.CENTER);
        volume.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        days.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        price.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        final EditText note = input("یادداشت بازبین (اختیاری)", "", value -> {});
        LinearLayout fields = UI.vbox(this);
        fields.setPadding(0, dp(2), 0, 0);
        String reviewReason = source.note == null || source.note.trim().isEmpty()
                ? (source.why == null || source.why.trim().isEmpty() ? "شواهد کافی برای تأیید خودکار وجود ندارد." : source.why)
                : source.note;
        fields.addView(UI.tv(this, "علت نیاز به بازبینی: " + reviewReason, 10, UI.DANGER, false),
                UI.lp(this, -1, -2, 0, 0, 0, 8));
        fields.addView(UI.tv(this, "مقادیر استخراج‌شده تغییر نمی‌کنند؛ مقادیر تأییدشده جدا ذخیره می‌شوند و فقط پس از تأیید وارد مقایسه خواهند شد.",
                10, UI.MUTED, false), UI.lp(this, -1, -2, 0, 0, 0, 8));
        fields.addView(volume, UI.lp(this, -1, -2, 0, 0, 0, 6));
        fields.addView(days, UI.lp(this, -1, -2, 0, 0, 0, 6));
        fields.addView(price, UI.lp(this, -1, -2, 0, 0, 0, 6));
        fields.addView(note, UI.lp(this, -1, -2, 0, 0, 0, 0));

        new UI.Dlg(this)
                .title("بازبینی: " + (source.title == null ? "بسته" : source.title))
                .view(fields)
                .button("تأیید و ورود به مقایسه", 0, dialog -> {
                    double gb = Fmt.parse(volume.getText().toString(), -1);
                    double validity = Fmt.parse(days.getText().toString(), -1);
                    double priceValue = Fmt.parse(price.getText().toString(), -1);
                    long toman = priceValue < 0 || priceValue > 2000000000L ? -1 : Math.round(priceValue);
                    boolean saved = Store.saveReview(this, source.key, true, gb, validity, toman, note.getText().toString());
                    if (!saved) { toast("مقادیر معتبر وارد کنید: حجم حداقل ۰٫۰۵ گیگ و قیمت به تومان"); return; }
                    dialog.dismiss(); toast("بازبینی ذخیره شد؛ مقادیر تأییدشده وارد مقایسه شدند"); render();
                })
                .button("رد این بسته", 2, dialog -> {
                    boolean saved = Store.saveReview(this, source.key, false, 0, 0, 0, note.getText().toString());
                    if (!saved) { toast("ثبت رد بسته انجام نشد؛ دوباره تلاش کنید"); return; }
                    dialog.dismiss(); toast("بسته از صف بازبینی و رتبه‌بندی حذف شد"); render();
                })
                .button("لغو", 1, null)
                .show();
    }

    private LinearLayout section(LinearLayout col, String title) {
        col.addView(UI.sectionHeader(this, null, title, null), UI.lp(this, -1, -2, 0, 22, 0, 12));
        LinearLayout c = UI.card(this);
        col.addView(c);
        return c;
    }

    private void styleSwitch(Switch sw) { UI.styleSwitch(this, sw); }

    private void swRow(LinearLayout c, String title, String sub, boolean on, CompoundButton.OnCheckedChangeListener l) {
        LinearLayout r = UI.hbox(this);
        LinearLayout t = UI.vbox(this);
        t.addView(UI.tv(this, title, 14, UI.TEXT, false));
        if (sub != null) t.addView(UI.tv(this, sub, 11, UI.MUTED, false));
        r.addView(t, UI.lpw(1f));
        Switch s = new Switch(this);
        styleSwitch(s);
        s.setChecked(on);
        s.setOnCheckedChangeListener(l);
        r.addView(s);
        c.addView(r, UI.lp(this, -1, -2, 0, 8, 0, 4));
    }

    private void chips(LinearLayout c, String[] labels, int sel, final IntCb cb) {
        LinearLayout r = UI.hbox(this);
        for (int i = 0; i < labels.length; i++) {
            final int idx = i;
            TextView t = UI.choice(this, labels[i], i == sel);
            t.setMaxLines(3);
            t.setOnClickListener(v -> cb.on(idx));
            r.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
            if (i < labels.length - 1) r.addView(new View(this), new LinearLayout.LayoutParams(dp(8), 1));
        }
        c.addView(r, UI.lp(this, -1, -2, 0, 8, 0, 8));
    }

    private void stepRow(LinearLayout c, String title, String sub, final int val, final int min, final int max, final int step, String suffix, final IntCb cb) {
        LinearLayout r = UI.hbox(this);
        LinearLayout t = UI.vbox(this);
        t.addView(UI.tv(this, title, 13, UI.TEXT, false));
        if (sub != null) t.addView(UI.tv(this, sub, 10, UI.MUTED, false));
        r.addView(t, UI.lpw(1f));
        r.addView(UI.btn(this, "−", UI.CARD2, UI.TEXT, v -> cb.on(Math.max(min, val - step))));
        TextView n = UI.tv(this, Fmt.fa(String.valueOf(val)) + suffix, 14, UI.PRIMARY, true);
        n.setGravity(Gravity.CENTER);
        n.setMinWidth(dp(56));
        r.addView(n);
        r.addView(UI.btn(this, "+", UI.CARD2, UI.TEXT, v -> cb.on(Math.min(max, val + step))));
        c.addView(r, UI.lp(this, -1, -2, 0, 6, 0, 6));
    }

    private EditText input(String hint, String text, final StrCb cb) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setTextSize(14);
        e.setSingleLine();
        e.setInputType(InputType.TYPE_CLASS_TEXT);
        e.setText(text);
        UI.styleInput(this, e);
        e.setMinHeight(dp(48));
        e.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
        e.setTextDirection(View.TEXT_DIRECTION_ANY_RTL);
        e.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void afterTextChanged(Editable s) { cb.on(s.toString()); }
        });
        return e;
    }

    private void numberRow(LinearLayout c, String label, String cur, StrCb cb) {
        c.addView(UI.tv(this, label, 13, UI.TEXT, false), UI.lp(this, -1, -2, 0, 10, 0, 4));
        EditText value = input("", cur, cb);
        // Numeric settings use centered LTR presentation so digits/decimal separators stay predictable.
        value.setTextDirection(View.TEXT_DIRECTION_LTR);
        value.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        value.setGravity(Gravity.CENTER);
        value.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        c.addView(value);
    }

    private void addOp() {
        String name = newName == null ? "" : newName.trim();
        String pkg = newPkg == null ? "" : newPkg.trim();
        if (name.isEmpty() || pkg.isEmpty() || name.length() > 40) {
            toast("نام اپراتور و نام پکیج معتبر (حداکثر ۴۰ نویسه برای نام) وارد کنید");
            return;
        }
        if (!Cfg.validPackageName(pkg)) {
            toast("نام پکیج معتبر نیست؛ نمونه: ir.example.app");
            return;
        }
        List<Op> l = Cfg.ops(this);
        for (Op existing : l) if (existing.pkgs.contains(pkg)) {
            toast("این پکیج قبلاً به «" + existing.name + "» اختصاص داده شده است");
            return;
        }
        int[] pal = {0xFF8B5CF6, 0xFFEC4899, 0xFF22C55E, 0xFFF97316, 0xFF06B6D4};
        String[] cur = {"AUTO", "IRR", "IRT"};
        l.add(new Op("c" + System.currentTimeMillis(), name, pal[l.size() % pal.length], cur[Math.max(0, Math.min(2, newCur))], false, pkg));
        Cfg.saveOps(this, l);
        newName = "";
        newPkg = "";
        render();
    }

    private void editOp(final Op o) {
        final EditText e = input("com.example.app, com.example.beta", TextUtils.join(", ", o.pkgs), s -> {});
        e.setTextDirection(View.TEXT_DIRECTION_LTR);
        FrameLayout f = new FrameLayout(this);
        f.addView(e);
        new UI.Dlg(this)
                .title("پکیج‌های " + o.name)
                .message("نام پکیج برنامه‌ها را با ویرگول جدا کنید.")
                .view(f)
                .button("ذخیره", 0, dialog -> {
            List<String> proposed = new ArrayList<>();
            for (String raw : e.getText().toString().split("[,\\s]+")) {
                String value = raw.trim();
                if (value.isEmpty()) continue;
                if (!Cfg.validPackageName(value)) {
                    toast("نام پکیج نامعتبر است: " + value);
                    return;
                }
                if (proposed.contains(value)) {
                    toast("پکیج تکراری وارد شده است: " + value);
                    return;
                }
                for (Op other : Cfg.ops(this)) {
                    if (!other.id.equals(o.id) && other.pkgs.contains(value)) {
                        toast("این پکیج به «" + other.name + "» اختصاص دارد: " + value);
                        return;
                    }
                }
                proposed.add(value);
            }
            if (proposed.isEmpty()) {
                toast("حداقل یک نام پکیج معتبر وارد کنید");
                return;
            }
            List<Op> updated = Cfg.ops(this);
            boolean found = false;
            for (Op item : updated) {
                if (item.id.equals(o.id)) {
                    item.pkgs.clear(); item.pkgs.addAll(proposed); found = true; break;
                }
            }
            if (!found) { toast("اپراتور تغییر کرده است؛ صفحه را تازه کنید"); return; }
            Cfg.saveOps(this, updated);
            dialog.dismiss();
            render();
                })
                .button("لغو", 1, null)
                .show();
    }

    // ---------------------------------------------------------------- export

    private static String csv(String value) {
        String safe = value == null ? "" : value.replace("\"", "\"\"");
        return "\"" + safe + "\"";
    }

    private void exportCsv() {
        final Context app = getApplicationContext();
        toast("در حال آماده‌سازی خروجی…");
        uiDataExecutor.execute(() -> {
            final List<Pkg> all = Store.snapshot(app);
            if (all.isEmpty()) {
                runOnUiThread(() -> { if (!isFinishing()) toast("داده‌ای برای خروجی نیست"); });
                return;
            }
            String ts = new SimpleDateFormat("MMdd_HHmmss", Locale.US).format(new Date());
            try {
                String where = save("bastehyab_" + ts + ".csv", "text/csv", o -> {
                    StringBuilder sb = new StringBuilder("\uFEFFoperator,title,gb,days,price_toman,price_with_vat_toman,vat_percent,currency_known,ambiguous,per_gb_toman,restricted,reason,review_note,captured\n");
                    Map<String, Pkg> uniqueRows = new LinkedHashMap<>();
                    for (Pkg p : all) {
                        if (p.op == null || p.op.isEmpty()) continue;
                        Pkg prev = uniqueRows.get(p.sig());
                        if (prev == null || p.ts > prev.ts) uniqueRows.put(p.sig(), p);
                    }
                    for (Pkg p : uniqueRows.values()) {
                        Op op = Cfg.opById(app, p.op);
                        sb.append(csv(op == null ? p.op : op.name)).append(',').append(csv(p.title)).append(',')
                                .append(p.gb).append(',').append(p.days).append(',')
                                .append(p.currencyKnown ? String.valueOf(p.toman) : "").append(',')
                                .append(p.currencyKnown ? String.valueOf(Cfg.finalPrice(app, p)) : "").append(',')
                                .append(Cfg.vat(app)).append(',')
                                .append(p.currencyKnown).append(',')
                                .append(p.ambig).append(',')
                                .append(p.currencyKnown && !p.ambig ? String.valueOf(Math.round(p.perGb())) : "").append(',')
                                .append(p.restricted).append(',').append(csv(p.why)).append(',')
                                .append(csv(p.note)).append(',')
                                .append(new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(new Date(p.ts))).append('\n');
                    }
                    o.write(sb.toString().getBytes(StandardCharsets.UTF_8));
                });
                runOnUiThread(() -> { if (!isFinishing()) toast("ذخیره شد: " + where); });
            } catch (Exception e) {
                String error = e.getClass().getSimpleName();
                runOnUiThread(() -> { if (!isFinishing()) toast("ساخت خروجی ناموفق بود: " + error); });
            }
        });
    }

    private void exportDiag() {
        // Flush the in-memory snapshot first; otherwise a fast tap just after a scan may
        // incorrectly report that no diagnostic exists because the debounce has not fired.
        ScanService.flushDiagnostics();
        final File f = new File(getFilesDir(), "diag.txt");
        if (!f.exists()) {
            toast("هنوز گزارشی ساخته نشده؛ برنامه‌ی اپراتور را باز کنید و صفحه‌ی بسته‌ها را ببینید.");
            return;
        }
        String ts = new SimpleDateFormat("MMdd_HHmmss", Locale.US).format(new Date());
        try {
            String where = save("diag_" + ts + ".txt", "text/plain", o -> {
                try (InputStream i = new FileInputStream(f)) {
                    byte[] buf = new byte[8192];
                    int n;
                    while ((n = i.read(buf)) > 0) o.write(buf, 0, n);
                }
            });
            toast("ذخیره شد: " + where);
        } catch (Exception e) {
            toast(e.toString());
        }
    }

    /** Returns a human-readable location. API 29+ uses MediaStore Downloads; older Android uses the app's own Downloads folder. */
    private String save(String name, String mime, W w) throws Exception {
        if (Build.VERSION.SDK_INT < 29) {
            File dir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
            if (dir == null) throw new java.io.IOException("حافظه‌ی خارجی در دسترس نیست");
            if (!dir.exists() && !dir.mkdirs()) throw new java.io.IOException("ساخت پوشه‌ی خروجی ناموفق بود");
            File out = new File(dir, name);
            try (OutputStream o = new FileOutputStream(out)) {
                w.w(o);
            } catch (Exception e) {
                out.delete();
                throw e;
            }
            return out.getAbsolutePath();
        }
        ContentValues v = new ContentValues();
        v.put(MediaStore.Downloads.DISPLAY_NAME, name);
        v.put(MediaStore.Downloads.MIME_TYPE, mime);
        Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
        if (u == null) throw new java.io.IOException("ساخت فایل در Downloads ناموفق بود");
        try (OutputStream o = getContentResolver().openOutputStream(u)) {
            if (o == null) throw new java.io.IOException("دسترسی نوشتن به فایل خروجی برقرار نشد");
            w.w(o);
        } catch (Exception e) {
            getContentResolver().delete(u, null, null);
            throw e;
        }
        return "Downloads";
    }
}
