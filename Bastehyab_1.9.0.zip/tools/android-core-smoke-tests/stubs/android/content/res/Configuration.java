package android.content.res; public class Configuration { public float fontScale=1.0f; }
