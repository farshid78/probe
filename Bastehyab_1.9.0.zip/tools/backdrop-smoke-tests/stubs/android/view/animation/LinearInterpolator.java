package android.view.animation; public class LinearInterpolator {}
