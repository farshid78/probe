package android.animation;
public class ValueAnimator {
    public static final int INFINITE = -1;
    public interface AnimatorUpdateListener { void onAnimationUpdate(ValueAnimator animation); }
    private boolean started;
    private Object value = Float.valueOf(0f);
    public static ValueAnimator ofFloat(float... values) { ValueAnimator a=new ValueAnimator(); if(values!=null&&values.length>0)a.value=Float.valueOf(values[0]); return a; }
    public void setDuration(long duration) {}
    public void setRepeatCount(int count) {}
    public void setInterpolator(Object interpolator) {}
    public void addUpdateListener(AnimatorUpdateListener listener) {}
    public Object getAnimatedValue() { return value; }
    public boolean isStarted() { return started; }
    public void start() { started=true; }
    public void cancel() { started=false; }
    public static boolean areAnimatorsEnabled() { return true; }
}
