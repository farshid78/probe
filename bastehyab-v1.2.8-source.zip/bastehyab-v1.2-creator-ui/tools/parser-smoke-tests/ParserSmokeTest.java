package app.bastehyab;
import android.view.accessibility.AccessibilityNodeInfo;
public class ParserSmokeTest {
 private static void ok(boolean value,String message){if(!value)throw new AssertionError(message);}
 private static Pkg scan(String price,String unit,String opCurrency) {
   AccessibilityNodeInfo root=new AccessibilityNodeInfo(null,0);
   AccessibilityNodeInfo card=new AccessibilityNodeInfo(null,0);
   card.add(new AccessibilityNodeInfo("۳۰ روزه ۵ گیگابایت",30));
   card.add(new AccessibilityNodeInfo(price,60));
   if(unit!=null)card.add(new AccessibilityNodeInfo(unit,60));
   root.add(card);
   Op op=new Op("x","آزمایش",0,"AUTO".equals(opCurrency)?"AUTO":opCurrency,true,"test.operator");
   Extractor.Result r=Extractor.extract(root,op,2000);
   ok(r.items.size()==1,"expected exactly one offer, got="+r.items.size()+" diagnostics="+r.dump);
   return r.items.get(0);
 }
 public static void main(String[] args) throws Exception {
   ok(Fmt.norm("۱۲۳٤٥٦ ك يـ \u200fتومان").equals("123456 ک ی تومان"),"Persian/Arabic digit and letter normalization");
   ok(Fmt.norm(null).isEmpty(),"null normalization");
   Pkg rial=scan("۶۲۶٬۶۰۰","ریال","AUTO");
   ok(rial.currencyKnown,"explicit rial unit must be known");
   ok(rial.toman==62660,"rial must convert to toman exactly: "+rial.toman);
   Pkg toman=scan("۶۲۶٬۶۰۰","تومان","AUTO");
   ok(toman.currencyKnown && toman.toman==626600,"explicit toman must not be divided by ten");
   Pkg unknown=scan("۶۲۶٬۶۰۰",null,"AUTO");
   ok(!unknown.currencyKnown && unknown.ambig,"unknown unit must be flagged ambiguous");
   Pkg fixedRial=scan("۶۲۶٬۶۰۰",null,"IRR");
   ok(fixedRial.currencyKnown && fixedRial.toman==62660,"fixed IRR operator profile must convert");
   AccessibilityNodeInfo mixedRoot=new AccessibilityNodeInfo(null,0);
   AccessibilityNodeInfo mixedCard=new AccessibilityNodeInfo(null,0);
   mixedCard.add(new AccessibilityNodeInfo("۳۰ روزه ۵ گیگابایت",30));
   mixedCard.add(new AccessibilityNodeInfo("۹۰٬۰۰۰ ریال",60));
   mixedCard.add(new AccessibilityNodeInfo("۷۰٬۰۰۰",60));
   mixedRoot.add(mixedCard);
   Extractor.Result mixed=Extractor.extract(mixedRoot,new Op("x","آزمایش",0,"AUTO",true,"test.operator"),2000);
   ok(mixed.items.size()==1,"mixed-currency test package should be detected");
   Pkg mixedPkg=mixed.items.get(0);
   ok(mixedPkg.toman==9000,"unknown raw amount must not win over normalized rial amount: "+mixedPkg.toman);
   ok(mixedPkg.ambig,"competing amount with unknown unit must make package ambiguous");
   AccessibilityNodeInfo privateRoot=new AccessibilityNodeInfo(null,0);
   AccessibilityNodeInfo privateCard=new AccessibilityNodeInfo(null,0);
   privateCard.add(new AccessibilityNodeInfo("۳۰ روزه ۵ گیگابایت",30));
   privateCard.add(new AccessibilityNodeInfo("۹۰٬۰۰۰ ریال",60).editable(true));
   privateCard.add(new AccessibilityNodeInfo("۷۰٬۰۰۰ ریال",80).password(true));
   privateCard.add(new AccessibilityNodeInfo("۸۰٬۰۰۰ ریال",100).visible(false));
   privateRoot.add(privateCard);
   Extractor.Result privateScan=Extractor.extract(privateRoot,new Op("x","آزمایش",0,"IRR",true,"test.operator"),2000);
   ok(privateScan.items.isEmpty(),"editable, password and non-visible content must not produce offers");
   Pkg privacyPkg=new Pkg(); privacyPkg.op="x"; privacyPkg.key="x|1"; privacyPkg.title="۳۰ روزه ۵ گیگابایت";
   privacyPkg.gb=5; privacyPkg.days=30; privacyPkg.toman=9000; privacyPkg.raw="این متن خام نباید ذخیره شود";
   ok(!privacyPkg.json().has("raw"),"raw accessibility-card text must not be persisted in package JSON");
   AccessibilityNodeInfo large=new AccessibilityNodeInfo(null,0);
   for(int i=0;i<8100;i++) large.add(new AccessibilityNodeInfo("",i));
   Extractor.Result limited=Extractor.extract(large,new Op("x","test",0,"AUTO",true,"test.operator"),2000);
   ok(limited.incomplete && limited.dump.contains("complete=false"),"node-cap truncation must be explicit");
   AccessibilityNodeInfo partialRoot=new AccessibilityNodeInfo(null,0);
   AccessibilityNodeInfo partialCard=new AccessibilityNodeInfo(null,0);
   partialCard.add(new AccessibilityNodeInfo("۳۰ روزه ۵ گیگابایت",30));
   partialCard.add(new AccessibilityNodeInfo("۶۲۶٬۶۰۰ ریال",60));
   partialRoot.add(partialCard);
   for(int i=0;i<8100;i++) partialRoot.add(new AccessibilityNodeInfo("",100+i));
   Extractor.Result partial=Extractor.extract(partialRoot,new Op("x","test",0,"AUTO",true,"test.operator"),2000);
   ok(partial.incomplete && !partial.items.isEmpty(),"partial tree should retain valid fragments and report incompleteness");
   ok(partial.items.get(0).ambig,"packages from truncated tree must be marked ambiguous");
   AccessibilityNodeInfo root=new AccessibilityNodeInfo(null,0);
   AccessibilityNodeInfo c1=new AccessibilityNodeInfo(null,0);
   c1.add(new AccessibilityNodeInfo("۳۰ روزه ۵ گیگابایت",30)); c1.add(new AccessibilityNodeInfo("۶۲۶٬۶۰۰",60)); c1.add(new AccessibilityNodeInfo("ریال",60));
   AccessibilityNodeInfo c2=new AccessibilityNodeInfo(null,100);
   c2.add(new AccessibilityNodeInfo("۳۰ روزه ۵ گیگابایت",130)); c2.add(new AccessibilityNodeInfo("۶۲۶٬۶۰۰",160)); c2.add(new AccessibilityNodeInfo("ریال",160));
   root.add(c1).add(c2);
   Extractor.Result duplicate=Extractor.extract(root,new Op("x","test",0,"AUTO",true,"test.operator"),2000);
   ok(duplicate.items.size()==1 && duplicate.duplicates==1,"duplicate cards must be counted and collapsed");
   ok(!duplicate.dump.contains("۳۰ روزه") && !duplicate.dump.contains("۶۲۶"),"diagnostic must not contain raw page text or price data");
   // Fast pass skips hidden subtrees: a hidden decoy beside a visible card must be pruned, and the result must match.
   AccessibilityNodeInfo mixRoot=new AccessibilityNodeInfo(null,0);
   AccessibilityNodeInfo visibleCard=new AccessibilityNodeInfo(null,0);
   visibleCard.add(new AccessibilityNodeInfo("۳۰ روزه ۵ گیگابایت",30));
   visibleCard.add(new AccessibilityNodeInfo("۹۰٬۰۰۰ ریال",60));
   mixRoot.add(visibleCard);
   AccessibilityNodeInfo decoy=new AccessibilityNodeInfo(null,0).visible(false);
   decoy.add(new AccessibilityNodeInfo("۳۰ روزه ۱۰ گیگابایت",90));
   decoy.add(new AccessibilityNodeInfo("۱۲۰٬۰۰۰ ریال",100));
   mixRoot.add(decoy);
   Op fastOp=new Op("x","آزمایش",0,"IRR",true,"test.operator");
   Extractor.Result mixScan=Extractor.extract(mixRoot,fastOp,2000);
   ok(mixScan.items.size()==1 && !mixScan.fullTraversal && mixScan.prunedHidden>0,"fast pass must prune hidden subtrees without full re-walk when visible offers exist");

   // Fallback: when the only offer sits under a hidden wrapper, the full traversal must still find it.
   AccessibilityNodeInfo wrapRoot=new AccessibilityNodeInfo(null,0);
   AccessibilityNodeInfo wrapper=new AccessibilityNodeInfo(null,0).visible(false);
   AccessibilityNodeInfo wrapped=new AccessibilityNodeInfo(null,0);
   wrapped.add(new AccessibilityNodeInfo("۳۰ روزه ۵ گیگابایت",30));
   wrapped.add(new AccessibilityNodeInfo("۹۰٬۰۰۰ ریال",60));
   wrapper.add(wrapped);
   wrapRoot.add(wrapper);
   Extractor.Result wrapScan=Extractor.extract(wrapRoot,fastOp,2000);
   ok(wrapScan.items.size()==1 && wrapScan.fullTraversal,"offers under a hidden wrapper must be recovered by the full-traversal fallback");

   // International / roaming bundles are recognised from the card's own text; page tabs never classify a card.
   ok(Extractor.INTL.matcher(Fmt.norm("رومینگ ترکیه 30روزه")).find(),"roaming bundles must be recognised");
   ok(Extractor.INTL.matcher(Fmt.norm("بسته بین الملل ۳۰ روزه")).find(),"international bundles must be recognised");
   ok(!Extractor.INTL.matcher(Fmt.norm("بسته ۳۰ روزه ۳۰ گیگابایت")).find(),"domestic bundles must not be recognised as international");
   ok(!Extractor.whyOf("بسته ۳۰ روزه ۳۰ گیگابایت بسته بین الملل",30,1).equals(Extractor.INTL_WHY),"a tab label must not turn a domestic card into an international one");
   // Megabyte volumes are read correctly (750 MB = 0.732 GB).
   ok(Math.abs(Extractor.vol("۷۵۰ مگابایت")[0] - 750/1024.0) < 1e-9,"750 MB must convert to GB");

   // Flat lists (no card container): title and price are sibling leaves and must still pair.
   AccessibilityNodeInfo flat=new AccessibilityNodeInfo(null,0);
   flat.add(new AccessibilityNodeInfo("۳۰ روزه ۵ گیگابایت",10));
   flat.add(new AccessibilityNodeInfo("۹۰٬۰۰۰ ریال",60));
   Extractor.Result flatScan=Extractor.extract(flat,new Op("x","آزمایش",0,"IRR",true,"test.operator"),2000);
   ok(flatScan.items.size()==1 && flatScan.items.get(0).toman==9000 && flatScan.items.get(0).currencyKnown,"flat title and price siblings must pair into one package");

   System.out.println("PASS: normalization, null handling, currency conversion, unknown-unit rejection, mixed-unit ambiguity, editable/password/invisible-node exclusion, raw-data persistence exclusion, fixed currency, truncation visibility and package ambiguity, duplicate collapse, privacy-safe diagnostics.");
 }
}
