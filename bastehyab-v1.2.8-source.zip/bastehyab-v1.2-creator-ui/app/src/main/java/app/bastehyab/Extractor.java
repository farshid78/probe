package app.bastehyab;

import android.graphics.Rect;
import android.view.accessibility.AccessibilityNodeInfo;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Turns an accessibility tree into package offers (price / volume / duration), operator-agnostic. */
final class Extractor {
    static final class N {
        N parent;
        final List<N> kids = new ArrayList<>();
        String text, id;
        final Rect b = new Rect();
        List<N> lv = new ArrayList<>(); // text leaves in subtree
        boolean leaf, price, unitOnly, isVol;
        double amt, mul;
        int unit, pc, vc; // unit: 0 none, 1 rial, 2 toman; pc/vc: price / volume leaves below

        int cx() { return b.centerX(); }
        int cy() { return b.centerY(); }
    }

    static final class Result {
        final List<Pkg> items = new ArrayList<>();
        final Set<String> keys = new HashSet<>();
        String dump = "";
        int leaves;
        int nodes;
        int maxDepth;
        int duplicates;
        int prunedHidden;
        boolean incomplete;
        boolean fullTraversal;
        String incompleteReason = "";
    }

    private static final class Cand {
        N leaf;
        long toman;
        int kind; // 0 normal, 1 unit price (monthly / per GB ...), 2 old price, 3 discount / credit amount, 4 labelled "price"
        boolean currencyKnown;
    }

    private static final class Pick {
        long toman;
        long[] alts = new long[0];
        String note = "";
        boolean ambig;
        boolean currencyKnown;
    }

    private static final class BuildState {
        int nodes;
        int maxDepth;
        int prunedHidden; // hidden subtrees skipped in fast mode
        boolean truncated;
        String reason = "";

        void truncate(String why) {
            truncated = true;
            if (reason.isEmpty()) reason = why;
        }
    }

    private static final int MAX_TREE_DEPTH = 60;
    private static final int MAX_TREE_NODES = 8000;
    private static final int F = Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE;
    private static final Pattern VOL = Pattern.compile(
            "(\\d+(?:\\.\\d+)?)\\s*(گیگابایت|گیگا|گیگ|مگابایت|مگا|مگ|ترابایت|ترا|gb|mb|tb)", F);
    private static final Pattern DUR = Pattern.compile("(\\d+(?:\\.\\d+)?)\\s*(روز|ماه|هفته|ساعت|سال)");
    private static final Pattern DURN = Pattern.compile(
            "(یک|دو|سه|چهار|پنج|شش|هفت|هشت|نه|ده|دوازده|پانزده|بیست|سی|شصت|نود)\\s*(روزه|ماهه|هفته|ساله)");
    private static final Pattern DURW = Pattern.compile("(روزانه|هفتگی|ماهانه|سالانه)");
    private static final Pattern UNIT = Pattern.compile("تومان|تومن|ریال");
    private static final Pattern UNITONLY = Pattern.compile("^\\s*(میلیون|هزار)?\\s*(تومان|تومن|ریال)\\s*$");
    private static final Pattern NUMONLY = Pattern.compile("^\\d{1,4}(?:\\.\\d+)?$");
    private static final Pattern PRICE = Pattern.compile(
            "(\\d{1,3}(?:[,.]\\d{3})+|\\d+(?:\\.\\d+)?)(?:\\s*(میلیون|هزار))?\\s*(تومان|تومن|ریال)?");
    // price written inside a title: "۹۸۹۰۰۰ت", "333000 تومان", "۳۳۳ هزار تومان"
    private static final Pattern TPRICE = Pattern.compile(
            "(?<![\\d.,])(\\d{1,3}(?:,\\d{3})+|\\d+(?:\\.\\d+)?)\\s*(هزار)?\\s*(?:تومان|تومن|ت)(?![\\u0600-\\u06FF])");
    private static final Pattern DURCHIP = Pattern.compile("^\\s*(روزانه|هفتگی|ماهانه|ماهیانه|سالانه)\\s*$");
    private static final Pattern SEP = Pattern.compile("\\d{1,3}(?:[,.]\\d{3})+");
    private static final Pattern CODE = Pattern.compile("[A-Za-z]*[Oo]ffers?Package-([A-Za-z0-9]+)-");
    private static final Pattern R_TIME = Pattern.compile("نیمه\\s?شب|بامداد|صبح|ظهر|\\d\\s*(?:تا|الی)\\s*\\d");
    private static final Pattern R_NIGHT = Pattern.compile("شبانه|نیمه\\s?شب");
    private static final Pattern R_NAZR = Pattern.compile("نذر\\s*آب");
    private static final Pattern R_DAYS = Pattern.compile("(?<![\\p{L}])(?:یک|دو|سه|چهار|پنج|\\d)?\\s?شنبه|جمعه|آخر\\s?هفته|تعطیل");
    private static final Pattern R_USER = Pattern.compile("مشترکین جدید|مشترک جدید|ثبت ?نام|ویژه مشترک|اولین خرید|دعوت");
    private static final Pattern R_NAT = Pattern.compile("آی ?نو|اینترنت ملی|ایرانی");
    private static final Pattern R_BUNDLE = Pattern.compile("پیامک|مکالمه|تماس|sms");
    private static final Pattern R_SUB = Pattern.compile("اشتراک|سرویس دیجیتال|هدیه|کد دیجیتال|فیلیمو|نماوا");
    private static final Pattern R_RENEW = Pattern.compile("تمدید خودکار|رزرو");
    private static final Pattern R_UNL = Pattern.compile("نامحدود|مصرف منصفانه");
    private static final Pattern R_APP = Pattern.compile("اپلیکیشن|اینستاگرام|تلگرام|واتس|یوتیوب|آپارات|بازی|روبیکا|(?<![\\p{L}])ایتا(?![\\p{L}])|(?<![\\p{L}])بله(?![\\p{L}])|سروش|تیک ?تاک|فوتبال|ورزش|شبکه های اجتماعی|پیام ?رسان");
    private static final Pattern R_SPECIAL = Pattern.compile("ویژه(?:\\s?ی)?\\s+(?!شما(?![\\p{L}]))\\p{L}{3,}");
    private static final Pattern R_NET = Pattern.compile("داخلی|مخصوص");
    // international and roaming bundles: a separate, non-suspicious class (never a domestic substitute)
    static final Pattern INTL = Pattern.compile("بین[\\s\\u200c]?الملل|رومینگ|خارج\\s?از\\s?کشور");
    private static final Pattern R_CATEGORY = Pattern.compile("شبانه|نذر\\s*آب|بین\\s*الملل|رومینگ|هدیه|ویژه|تعرفه|عمومی|عادی");
    // labels around a price leaf
    private static final Pattern K_OLD = Pattern.compile("قبل از|پیش از|قیمت اصلی|قیمت پایه|بدون تخفیف|قیمت قبلی|قبلی");
    private static final Pattern K_UNIT = Pattern.compile(
            "ماهانه|ماهیانه|هر ?ماه|در ?ماه|ماهی|/ ?ماه|هر ?گیگ|به ?ازای|روزانه|هر ?روز|در ?روز|هفتگی|هر ?هفته|قسط|اقساط");
    private static final Pattern K_MAIN = Pattern.compile(
            "قیمت|مبلغ|با تخفیف|پس از تخفیف|نهایی|قابل ?پرداخت|با مالیات|شامل مالیات");
    private static final Pattern K_DISC = Pattern.compile(
            "تخفیف|هدیه|اعتبار هدیه|پاداش|جایزه|کش ?بک|بازگشت|مالیات|ارزش ?افزوده|صرفه ?جویی");

    /**
     * Fast pass skips hidden subtrees (Accessibility reports them as not visible; they carry no
     * readable text in captured screens). Only if that yields no packages do we re-walk the full
     * tree, so wrappers that hide visible children are still handled, at the cost of speed.
     */
    static Result extract(AccessibilityNodeInfo root, Op op, int screenH) {
        Result fast = extractOnce(root, op, screenH, true);
        if (fast.leaves == 0 && fast.prunedHidden > 0) {
            Result full = extractOnce(root, op, screenH, false);
            full.fullTraversal = true;
            return full;
        }
        return fast;
    }

    private static Result extractOnce(AccessibilityNodeInfo root, Op op, int screenH, boolean pruneHidden) {
        Result res = new Result();
        BuildState state = new BuildState();
        N tree = build(root, null, 0, state, pruneHidden);
        res.prunedHidden = state.prunedHidden;
        res.nodes = state.nodes;
        res.maxDepth = state.maxDepth;
        res.incomplete = state.truncated;
        res.incompleteReason = state.reason;
        if (tree == null) {
            res.incomplete = true;
            if (res.incompleteReason.isEmpty()) res.incompleteReason = "درخت صفحه قابل خواندن نبود";
            res.dump = "pkg=" + (root == null ? "unknown" : String.valueOf(root.getPackageName()))
                    + " nodes=0 complete=false reason=" + res.incompleteReason;
            return res;
        }
        mark(tree);
        List<N> leaves = tree.lv;
        res.leaves = leaves.size();

        for (N l : leaves) {
            double[] p = price(l.text);
            if (p != null) {
                l.price = true;
                l.amt = p[0];
                l.unit = (int) p[1];
            } else {
                Matcher um = UNITONLY.matcher(Fmt.norm(l.text));
                if (um.matches()) {
                    l.unitOnly = true;
                    String mu = um.group(1);
                    l.mul = mu == null ? 0 : mu.equals("میلیون") ? 1e6 : 1e3;
                    l.unit = um.group(2).equals("ریال") ? 1 : 2;
                }
            }
        }
        // "120" + "هزار تومان" written as two separate leaves
        for (int i = 0; i < leaves.size(); i++) {
            N l = leaves.get(i);
            if (!l.unitOnly || l.mul == 0) continue;
            for (int d = -1; d <= 1; d += 2) {
                int j = i + d;
                if (j < 0 || j >= leaves.size()) continue;
                N o = leaves.get(j);
                if (o.price || o.unitOnly) continue;
                String n = Fmt.norm(o.text).trim();
                if (NUMONLY.matcher(n).matches()) {
                    o.price = true;
                    o.amt = Double.parseDouble(n) * l.mul;
                    o.unit = l.unit;
                    break;
                }
            }
        }
        for (N l : leaves) l.isVol = !l.price && !l.unitOnly && vol(l.text) != null;
        count(tree);

        List<N> cards = new ArrayList<>();
        findCards(tree, cards, 0);

        Map<String, Pkg> out = new LinkedHashMap<>();
        for (N card : cards) {
            Pkg p = make(card, op);
            if (p != null) {
                if (out.containsKey(p.key)) res.duplicates++;
                else out.put(p.key, p);
            }
        }
        // Only for layouts where card grouping found nothing; mixing both sources produces false pairings.
        boolean cleanCard = false;
        for (Pkg p : out.values()) if (p.currencyKnown && !p.ambig) cleanCard = true;
        if (!cleanCard) flatPairs(tree, op, out);

        // fallback: container nodes whose own text already holds the whole offer (price leaf scrolled off-screen)
        List<N> all = new ArrayList<>();
        flatten(tree, all);
        for (N x : all) {
            if (x.text == null || x.leaf || x.pc > 0) continue;
            Pkg p = fromText(x, op);
            if (p != null) {
                if (out.containsKey(p.key)) res.duplicates++;
                else out.put(p.key, p);
            }
        }

        res.items.addAll(out.values());
        if (res.incomplete) {
            for (Pkg p : res.items) {
                p.ambig = true;
                String reason = "نتیجه از درخت ناقص صفحه استخراج شده و برای رتبه‌بندی قطعی مناسب نیست";
                p.note = (p.note == null || p.note.isEmpty()) ? reason : p.note + "، " + reason;
            }
        }
        for (Pkg p : res.items) res.keys.add(p.key);
        StringBuilder diagnostic = new StringBuilder();
        diagnostic.append("pkg=").append(root.getPackageName())
                .append(" nodes=").append(res.nodes).append(" depth=").append(res.maxDepth)
                .append(" leaves=").append(res.leaves).append(" cards=").append(cards.size())
                .append(" items=").append(res.items.size()).append(" duplicates=").append(res.duplicates)
                .append(" complete=").append(!res.incomplete);
        if (res.incomplete) diagnostic.append(" reason=").append(res.incompleteReason);
        for (Pkg item : res.items) {
            diagnostic.append("\nitem volumeGB=").append(item.gb)
                    .append(" days=").append(item.days)
                    .append(" currencyKnown=").append(item.currencyKnown)
                    .append(" priceToman=").append(item.currencyKnown ? item.toman : "unknown")
                    .append(" restricted=").append(item.restricted)
                    .append(" ambiguous=").append(item.ambig);
        }
        res.dump = diagnostic.toString();
        return res;
    }

    // ---------------------------------------------------------------- tree

    private static N build(AccessibilityNodeInfo n, N parent, int d, BuildState state, boolean pruneHidden) {
        if (n == null) return null;
        // Never read editable fields or password nodes (login, OTP and other user-entered values).
        if (n.isEditable() || n.isPassword()) return null;
        boolean visible = n.isVisibleToUser();
        if (pruneHidden && !visible) {
            // Hidden subtrees are skipped entirely (each child lookup is an IPC call; this is the main cost).
            state.prunedHidden++;
            return null;
        }
        if (d > MAX_TREE_DEPTH) {
            state.truncate("حد عمق درخت " + MAX_TREE_DEPTH + " رسید");
            return null;
        }
        if (state.nodes >= MAX_TREE_NODES) {
            state.truncate("حد تعداد گره " + MAX_TREE_NODES + " رسید");
            return null;
        }
        state.nodes++;
        state.maxDepth = Math.max(state.maxDepth, d);
        N x = new N();
        x.parent = parent;
        n.getBoundsInScreen(x.b);
        CharSequence t = visible ? n.getText() : null;
        if (visible && (t == null || t.length() == 0)) t = n.getContentDescription();
        if (t != null) {
            String s = t.toString().replaceAll("[\\u200e\\u200f\\u202a-\\u202e\\u2066-\\u2069]", "")
                    .replace("\n", ", ").trim();
            if (!s.isEmpty()) x.text = s.length() > 300 ? s.substring(0, 300) : s;
        }
        String id = visible ? n.getViewIdResourceName() : null;
        if (id != null) x.id = id.substring(id.indexOf('/') + 1);
        for (int i = 0; i < n.getChildCount(); i++) {
            if (state.nodes >= MAX_TREE_NODES) {
                state.truncate("حد تعداد گره " + MAX_TREE_NODES + " رسید");
                break;
            }
            AccessibilityNodeInfo child = n.getChild(i);
            if (child == null) continue;
            try {
                N k = build(child, x, d + 1, state, pruneHidden);
                if (k != null) x.kids.add(k);
            } finally {
                child.recycle();
            }
        }
        return x;
    }

    private static boolean mark(N x) {
        boolean any = false;
        for (N k : x.kids) {
            if (mark(k)) any = true;
            x.lv.addAll(k.lv);
        }
        if (x.text != null) {
            if (!any) {
                x.leaf = true;
                x.lv.add(x);
            }
            return true;
        }
        return any;
    }

    private static void count(N x) {
        x.pc = 0;
        x.vc = 0;
        if (x.leaf) {
            if (x.price) x.pc = 1;
            if (x.isVol) x.vc = 1;
        }
        for (N k : x.kids) {
            count(k);
            x.pc += k.pc;
            x.vc += k.vc;
        }
    }

    /**
     * Flat lists: title (volume + duration) and price are sibling text leaves with no card container.
     * Pair each title with the nearest price below it that horizontally overlaps it. Packages already
     * found through cards are not duplicated (same operator + volume + duration + price).
     */
    private static void flatPairs(N tree, Op op, Map<String, Pkg> out) {
        List<N> titles = new ArrayList<>(), prices = new ArrayList<>(), units = new ArrayList<>();
        for (N l : tree.lv) {
            if (l.b.bottom <= l.b.top) continue; // zero-height nodes are not on screen
            if (l.unitOnly) units.add(l);
            else if (l.price) prices.add(l);
            else if (l.isVol) titles.add(l);
        }
        if (titles.isEmpty() || prices.isEmpty()) return;
        Set<String> sigs = new HashSet<>();
        for (Pkg p : out.values()) sigs.add(p.sig());
        Set<N> used = new HashSet<>();
        final int maxGap = 420; // px below a title where its price is expected
        for (N t : titles) {
            N best = null;
            int bestGap = Integer.MAX_VALUE;
            for (N p : prices) {
                if (used.contains(p)) continue;
                int gap = p.b.top - t.b.bottom;
                if (gap < -10 || gap > maxGap) continue;
                if (p.cx() < t.b.left || p.cx() > t.b.right) continue; // must sit under the same card column
                if (gap < bestGap) { bestGap = gap; best = p; }
            }
            if (best == null) continue;
            used.add(best);
            double[] v = vol(t.text);
            if (v == null) continue;
            double days = dur(t.text);
            int unit = best.unit;
            if (unit == 0) {
                N nearest = null;
                int nd = Integer.MAX_VALUE;
                for (N u : units) {
                    int d = Math.abs(u.b.centerY() - best.b.centerY());
                    if (d < 120 && d < nd && Math.abs(u.cx() - best.cx()) < 260) { nd = d; nearest = u; }
                }
                if (nearest != null) unit = Fmt.norm(nearest.text).contains("ریال") ? 1 : 2;
            }
            if (unit == 0) unit = "IRR".equals(op.cur) ? 1 : "IRT".equals(op.cur) ? 2 : 0;
            long tom = Math.round(toman(best.amt, unit, op.cur));
            String why = whyOf(t.text, days, (int) v[1]);
            Pick pk = new Pick();
            pk.toman = tom;
            pk.currencyKnown = unit != 0;
            pk.ambig = unit == 0;
            pk.alts = new long[]{tom};
            if (unit == 0) pk.note = "واحد پول در متن صفحه مشخص نبود؛ این مبلغ تا زمان تأیید واحد، قابل مقایسه نیست";
            Pkg pkg = mk(op, t.text, v[0], days, tom, why, null, pk, t.text);
            if (pkg == null) continue;
            if (sigs.contains(pkg.sig())) continue;
            sigs.add(pkg.sig());
            out.put(pkg.key, pkg);
        }
    }

    private static void flatten(N x, List<N> out) {
        out.add(x);
        for (N k : x.kids) flatten(k, out);
    }

    /** Cards = repeating sibling branches that each hold a price and a volume (works whatever the number of prices per card). */
    private static void findCards(N x, List<N> out, int depth) {
        if (depth > 70) return;
        List<N> ks = new ArrayList<>();
        for (N k : x.kids) if (k.pc > 0 && k.vc > 0) ks.add(k);
        if (ks.size() >= 2) {
            for (N k : ks) {
                int n = 0;
                for (N g : k.kids) if (g.pc > 0 && g.vc > 0) n++;
                if (n >= 2) findCards(k, out, depth + 1);
                else out.add(k);
            }
        } else if (ks.size() == 1) {
            findCards(ks.get(0), out, depth + 1);
        } else if (x.pc > 0 && x.vc > 0) {
            out.add(x);
        }
    }

    // ---------------------------------------------------------------- parsing

    /** returns {amount, unit} or null. unit: 0 none, 1 rial, 2 toman */
    private static double[] price(String t) { return price(t, false); }

    private static double[] price(String t, boolean allowVol) {
        String s = Fmt.norm(t);
        if (s.contains("%") || s.contains("\u066a") || s.contains("درصد")) return null;
        boolean hasUnit = UNIT.matcher(s).find();
        // a leaf that holds a volume is a TITLE ("38 گیگ 30 روز 333000 تومان"), never the price leaf itself
        if (!allowVol && VOL.matcher(s).find()) return null;
        if (!hasUnit && (VOL.matcher(s).find() || DUR.matcher(s).find())) return null;
        Matcher m = PRICE.matcher(s);
        while (m.find()) {
            String num = m.group(1), mul = m.group(2), un = m.group(3);
            boolean sep = SEP.matcher(num).matches();
            boolean whole = s.trim().equals(m.group().trim());
            if (un == null && mul == null && !sep && !(whole && num.matches("\\d{4,}"))) continue;
            double v = sep ? Double.parseDouble(num.replace(",", "").replace(".", "")) : Double.parseDouble(num);
            if (mul != null) v *= mul.equals("میلیون") ? 1e6 : 1e3;
            if (v < 100) return null;
            int unit = un == null ? 0 : un.equals("ریال") ? 1 : 2;
            return new double[]{v, unit};
        }
        return null;
    }

    /** returns {firstGb, distinctCount} or null */
    static double[] vol(String s) {
        Matcher m = VOL.matcher(Fmt.norm(s));
        double first = -1;
        Set<Double> seen = new HashSet<>();
        while (m.find()) {
            double n = Double.parseDouble(m.group(1));
            String u = m.group(2).toLowerCase(Locale.ROOT);
            double g = (u.startsWith("گیگ") || u.equals("gb")) ? n
                    : (u.startsWith("مگ") || u.equals("mb")) ? n / 1024.0 : n * 1024.0;
            if (first < 0) first = g;
            seen.add(g);
        }
        return first < 0 ? null : new double[]{first, seen.size()};
    }

    /** how many different volumes a title mentions */
    static int volCount(String title) {
        double[] v = vol(title);
        return v == null ? 0 : (int) v[1];
    }

    private static double word(String w) {
        switch (w) {
            case "یک": return 1;
            case "دو": return 2;
            case "سه": return 3;
            case "چهار": return 4;
            case "پنج": return 5;
            case "شش": return 6;
            case "هفت": return 7;
            case "هشت": return 8;
            case "نه": return 9;
            case "ده": return 10;
            case "پانزده": return 15;
            case "بیست": return 20;
            case "سی": return 30;
            case "شصت": return 60;
            case "نود": return 90;
            default: return 12;
        }
    }

    /** days, 0 if unknown */
    private static double dur(String s) {
        String n = Fmt.norm(s);
        Matcher m = DUR.matcher(n);
        if (m.find()) {
            double v = Double.parseDouble(m.group(1));
            String u = m.group(2);
            if (u.equals("روز")) return v;
            if (u.equals("هفته")) return v * 7;
            if (u.equals("ماه")) return v * 30;
            if (u.equals("سال")) return v * 365;
            return v / 24.0; // ساعت
        }
        Matcher w = DURN.matcher(n);
        if (w.find()) {
            double v = word(w.group(1));
            String u = w.group(2);
            return u.startsWith("روز") ? v : u.startsWith("هفته") ? v * 7 : u.startsWith("ماه") ? v * 30 : v * 365;
        }
        Matcher x = DURW.matcher(n);
        if (x.find()) {
            String u = x.group(1);
            return u.equals("روزانه") ? 1 : u.equals("هفتگی") ? 7 : u.equals("ماهانه") ? 30 : 365;
        }
        return 0;
    }

    /** price (toman) written inside the title itself, or -1 */
    static long titlePrice(String title) {
        Matcher m = TPRICE.matcher(Fmt.norm(title));
        long last = -1;
        while (m.find()) {
            double v = Double.parseDouble(m.group(1).replace(",", ""));
            if (m.group(2) != null) v *= 1000;
            if (v >= 1000) last = Math.round(v);
        }
        return last;
    }

    /** stable identity of a package: never contains its price, and splits same-title cards that differ in kind */
    static String keyOf(String opId, String title, String code, String why) {
        if (code != null && !code.isEmpty()) return opId + "|" + code;
        String t = Fmt.norm(title);
        t = TPRICE.matcher(t).replaceAll("").replace(" ", "");
        return opId + "|" + t + (why == null || why.isEmpty() ? "" : "#" + why);
    }

    private static double toman(double amt, int unit, String cur) {
        int resolved = unit;
        if (resolved == 0) resolved = "IRR".equals(cur) ? 1 : "IRT".equals(cur) ? 2 : 0;
        if (resolved == 1) return amt / 10.0;
        if (resolved == 2) return amt;
        // Unknown currency is deliberately not guessed; the package is marked non-comparable.
        return amt;
    }

    static String restr(String s) { return whyOf(s, 0, 1); }

    /** why a package must not be compared with ordinary ones ("" = ordinary). */
    static final String INTL_WHY = "بین‌الملل/رومینگ";

    static String whyOf(String s, double days, int volCount) {
        String n = Fmt.norm(s);
        if (R_NAZR.matcher(n).find()) return "بسته‌ی نذر آب/طرح ویژه";
        if (R_NIGHT.matcher(n).find()) return "بسته‌ی شبانه";
        if (R_TIME.matcher(n).find()) return "ساعت خاص";
        if (R_DAYS.matcher(n).find()) return "روزهای خاص";
        if (R_USER.matcher(n).find()) return "ویژه‌ی مشترکین خاص";
        if (R_NAT.matcher(n).find()) return "ترافیک ملی";
        if (R_BUNDLE.matcher(n).find()) return "بسته‌ی ترکیبی";
        if (R_SUB.matcher(n).find()) return "همراه با اشتراک/هدیه";
        if (R_RENEW.matcher(n).find()) return "تمدید خودکار/رزرو";
        if (R_UNL.matcher(n).find()) return "نامحدود (حد منصفانه)";
        if (R_APP.matcher(n).find()) return "ویژه‌ی اپلیکیشن";
        if (R_SPECIAL.matcher(n).find()) return "ویژه‌ی سرویس/مشترک خاص";
        if (R_NET.matcher(n).find()) return "ترافیک خاص";
        if (days > 0 && days < 1) return "بسته‌ی ساعتی";
        if (volCount > 1) return "حجم ترکیبی";
        return "";
    }

    /** cards of Irancell's personalised "پیشنهادی" page carry ids like promoOffersPackage-... */
    private static boolean promoCard(N card) {
        for (N l : card.lv) if (l.id != null && l.id.startsWith("promo")) return true;
        return false;
    }

    private static String codeOf(N card) {
        for (N l : card.lv) {
            if (l.id == null) continue;
            Matcher m = CODE.matcher(l.id);
            if (m.find()) return m.group(1);
        }
        return "";
    }

    // ---------------------------------------------------------------- price choice

    private static String near(List<N> lv, int i, int d) {
        N me = lv.get(i);
        for (int j = i + d; j >= 0 && j < lv.size(); j += d) {
            N o = lv.get(j);
            if (o.price || o.unitOnly) continue;
            String t = Fmt.norm(o.text);
            if (t.length() > 18) return "";
            // a label only qualifies the price if it is physically next to it (same row / directly above or below)
            int gap = Math.max(0, Math.max(me.b.top, o.b.top) - Math.min(me.b.bottom, o.b.bottom));
            if (gap > 0.6 * Math.max(1, me.b.height())) return "";
            // a bare duration chip ("روزانه") is the package type, not a per-day price label
            if (DURCHIP.matcher(t).matches()) return "";
            return t;
        }
        return "";
    }

    private static int kind(List<N> lv, N leaf) {
        int i = lv.indexOf(leaf);
        String ctx = (Fmt.norm(leaf.text) + " " + near(lv, i, -1) + " " + near(lv, i, 1))
                .replace("پرداخت مستقیم", " ").replace("از اعتبار", " ").replace("خرید", " ");
        if (K_OLD.matcher(ctx).find()) return 2;
        if (K_UNIT.matcher(ctx).find()) return 1;
        if (K_MAIN.matcher(ctx).find()) return 4;
        if (K_DISC.matcher(ctx).find()) return 3;
        return 0;
    }

    /** is `small` just `large` split per month / week / day / GB ? */
    private static boolean explains(long small, long large, double gb, double days) {
        if (small <= 0) return false;
        double r = (double) large / small;
        double[] ds = {days / 30.0, days / 7.0, days, gb};
        for (double d : ds) if (d >= 1.8 && Math.abs(r - d) / d <= 0.07) return true;
        return false;
    }

    private static String kindName(int k) {
        switch (k) {
            case 1: return "مبلغ ماهانه/واحدی";
            case 2: return "قیمت قبلی";
            case 3: return "تخفیف/اعتبار";
            default: return "مبلغ دیگر";
        }
    }

    private static Pick pick(N card, List<N> pl, int cardUnit, Op op, double gb, double days) {
        List<Cand> cs = new ArrayList<>();
        boolean hasKnownCurrencyCandidate = false;
        boolean hasUnknownCurrencyCandidate = false;
        for (N l : pl) {
            Cand c = new Cand();
            c.leaf = l;
            int resolvedUnit = l.unit != 0 ? l.unit : cardUnit;
            if (resolvedUnit == 0) resolvedUnit = "IRR".equals(op.cur) ? 1 : "IRT".equals(op.cur) ? 2 : 0;
            c.currencyKnown = resolvedUnit != 0;
            hasKnownCurrencyCandidate |= c.currencyKnown;
            hasUnknownCurrencyCandidate |= !c.currencyKnown;
            c.toman = Math.round(toman(l.amt, resolvedUnit, op.cur));
            c.kind = kind(card.lv, l);
            cs.add(c);
        }
        // Never compare an amount with an unknown unit against normalized Toman values.
        // Prefer evidence-backed candidates, but keep the package ambiguous if an unknown
        // competing amount exists on the same card.
        List<Cand> comparable = new ArrayList<>();
        for (Cand c : cs) if (!hasKnownCurrencyCandidate || c.currencyKnown) comparable.add(c);
        Cand best = null;
        if (op.policy == 1 || op.policy == 2) {
            for (Cand c : comparable) {
                if (best == null || (op.policy == 1 ? c.toman > best.toman : c.toman < best.toman)) best = c;
            }
        } else {
            List<Cand> f = new ArrayList<>();
            for (Cand c : comparable) if (c.kind == 0 || c.kind == 4) f.add(c);
            if (f.isEmpty()) f.addAll(comparable);
            if (f.size() > 1) {
                List<Cand> g = new ArrayList<>(f);
                for (Cand s : f) {
                    for (Cand big : f) if (big.toman > s.toman * 1.2 && explains(s.toman, big.toman, gb, days)) g.remove(s);
                }
                if (!g.isEmpty()) f = g;
            }
            if (f.size() > 1) {
                int maxH = 0;
                for (Cand c : f) maxH = Math.max(maxH, c.leaf.b.height());
                List<Cand> g = new ArrayList<>();
                for (Cand c : f) if (c.leaf.b.height() >= 0.88 * maxH) g.add(c);
                if (!g.isEmpty()) f = g;
            }
            if (f.size() > 1) {
                List<Cand> g = new ArrayList<>();
                for (Cand c : f) if (c.kind == 4) g.add(c);
                if (!g.isEmpty() && g.size() < f.size()) f = g;
            }
            for (Cand c : f) if (best == null || c.toman < best.toman) best = c;
        }
        Pick pk = new Pick();
        pk.toman = best.toman;
        pk.currencyKnown = best.currencyKnown;
        Set<Long> distinct = new HashSet<>();
        for (Cand c : comparable) distinct.add(c.toman);
        pk.alts = new long[distinct.size()];
        int i = 0;
        for (long v : distinct) pk.alts[i++] = v;
        StringBuilder note = new StringBuilder();
        boolean other = false;
        for (Cand c : comparable) {
            if (c.toman == best.toman) continue;
            other = true;
            String nm = explains(Math.min(c.toman, best.toman), Math.max(c.toman, best.toman), gb, days)
                    ? "مبلغ ماهانه/واحدی" : kindName(c.kind);
            if (note.length() > 0) note.append("، ");
            note.append(Fmt.num(c.toman)).append(" (").append(nm).append(')');
        }
        if (other) pk.note = "مبالغ دیگر در همین کارت: " + note;
        // ambiguous when the decision was not backed by a label / unit-price rule
        boolean unexplained = false;
        for (Cand c : comparable) {
            if (c.toman != best.toman && c.kind == 0 && !explains(Math.min(c.toman, best.toman), Math.max(c.toman, best.toman), gb, days))
                unexplained = true;
        }
        pk.ambig = !pk.currencyKnown || hasUnknownCurrencyCandidate || (unexplained && op.policy == 0);
        if (hasUnknownCurrencyCandidate && hasKnownCurrencyCandidate) {
            pk.note = (pk.note.isEmpty() ? "" : pk.note + "، ")
                    + "یک مبلغ رقیب در همین کارت واحد پول مشخصی نداشت؛ انتخاب قیمت نیازمند بررسی است";
        }
        if (!pk.currencyKnown) {
            pk.note = (pk.note.isEmpty() ? "" : pk.note + "، ")
                    + "واحد پول در متن صفحه مشخص نبود؛ این مبلغ تا زمان تأیید واحد، قابل مقایسه نیست";
        }
        return pk;
    }

    // ---------------------------------------------------------------- building packages

    private static N nearestDur(N card, N from) {
        N best = null;
        double bd = Double.MAX_VALUE;
        for (N l : card.lv) {
            if (l.price || l.unitOnly || dur(l.text) <= 0) continue;
            double d = Math.hypot(l.cx() - from.cx(), l.cy() - from.cy());
            if (d < bd) {
                bd = d;
                best = l;
            }
        }
        return best;
    }

    private static String rawOf(N card) {
        StringBuilder sb = new StringBuilder();
        for (N l : card.lv) {
            if (sb.length() > 0) sb.append(" | ");
            sb.append(l.text);
            if (sb.length() > 420) break;
        }
        return sb.length() > 420 ? sb.substring(0, 420) : sb.toString();
    }

    /** Collect short category headings preceding this card in ancestor branches. */
    private static String categoryContext(N card) {
        StringBuilder out = new StringBuilder();
        N branch = card;
        int depth = 0;
        while (branch.parent != null && depth++ < 12) {
            N parent = branch.parent;
            for (N sibling : parent.kids) {
                if (sibling == branch) break;
                if (sibling.pc > 0 || sibling.vc > 0) continue;
                for (N leaf : sibling.lv) {
                    String t = Fmt.norm(leaf.text);
                    if (t.length() <= 48 && R_CATEGORY.matcher(t).find()) {
                        if (out.length() > 0) out.append(' ');
                        out.append(t);
                    }
                }
            }
            branch = parent;
        }
        return out.toString();
    }

    private static Pkg make(N card, Op op) {
        List<N> pl = new ArrayList<>();
        int cardUnit = 0;
        for (N l : card.lv) {
            if (l.price) pl.add(l);
            else if (l.unitOnly) cardUnit = l.unit;
        }
        if (pl.isEmpty()) return null;
        N tl = null;
        boolean tlDur = false;
        for (N l : card.lv) {
            if (!l.isVol) continue;
            boolean d = dur(l.text) > 0;
            if (tl == null || (d && !tlDur)) {
                tl = l;
                tlDur = d;
            }
        }
        if (tl == null) return null;
        double[] v = vol(tl.text);
        double days = dur(tl.text);
        if (days <= 0) {
            N dl = nearestDur(card, tl);
            if (dl != null) days = dur(dl.text);
        }
        Pick pk = pick(card, pl, cardUnit, op, v[0], days);
        long tp = titlePrice(tl.text);
        if (tp > 0 && tp != pk.toman) {
            boolean inAlts = false;
            for (long a : pk.alts) if (a == tp) inAlts = true;
            if (inAlts) {
                pk.toman = tp;
                pk.currencyKnown = true; // titlePrice() only accepts explicit toman markers
                pk.ambig = false;
            } else {
                pk.ambig = true;
                pk.note = (pk.note.isEmpty() ? "" : pk.note + "، ") + "قیمت داخل عنوان: " + Fmt.num(tp) + " تومان";
            }
        }
        StringBuilder all = new StringBuilder();
        for (N l : card.lv) if (!l.price && !l.unitOnly) all.append(l.text).append(' ');
        boolean intl = INTL.matcher(Fmt.norm(all.toString())).find();
        String why = intl ? INTL_WHY : whyOf(all.toString(), days, (int) v[1]); // own text only: page tabs (e.g. "ساعات خاص") must not tag every card
        String shownTitle = tl.text;
        if (intl) for (N l : card.lv) if (!l.price && !l.unitOnly && INTL.matcher(Fmt.norm(l.text)).find()) { shownTitle = l.text; break; }
        String raw = rawOf(card);
        if (promoCard(card)) pk.note = (pk.note.isEmpty() ? "" : pk.note + "، ") + "پیشنهاد اختصاصی خط شما؛ ممکن است برای همه فعال نباشد";
        return mk(op, shownTitle, v[0], days, pk.toman, why, codeOf(card), pk, raw);
    }

    private static Pkg fromText(N x, Op op) {
        String s = x.text;
        if (s.length() > 250 || x.lv.size() > 16) return null;
        double[] v = vol(s);
        if (v == null || v[1] > 1) return null;
        double[] pr = price(s, true);
        if (pr == null) return null;
        String n = Fmt.norm(s);
        int sepCount = 0;
        Matcher m = SEP.matcher(n);
        while (m.find()) sepCount++;
        if (sepCount > 2) return null;
        int unit = (int) pr[1];
        if (unit == 0) unit = n.contains("ریال") ? 1 : (n.contains("تومان") || n.contains("تومن")) ? 2 : 0;
        String title = null;
        for (N l : x.lv) {
            if (vol(l.text) != null) {
                title = l.text;
                break;
            }
        }
        if (title == null) title = s.split(", ")[0];
        double days = dur(title);
        if (days <= 0) days = dur(s);
        double[] tv = vol(title);
        if (tv == null) return null;
        if (unit == 0) unit = "IRR".equals(op.cur) ? 1 : "IRT".equals(op.cur) ? 2 : 0;
        long tom = Math.round(toman(pr[0], unit, op.cur));
        String fwhy = INTL.matcher(Fmt.norm(s)).find() ? INTL_WHY : whyOf(s, days, (int) tv[1]);
        Pkg p = mk(op, title, tv[0], days, tom, fwhy, codeOf(x), null, s);
        p.currencyKnown = unit != 0;
        if (!p.currencyKnown) {
            p.ambig = true;
            p.note = "واحد پول در متن صفحه مشخص نبود؛ این مبلغ تا زمان تأیید واحد، قابل مقایسه نیست";
        }
        return p;
    }

    private static Pkg mk(Op op, String title, double gb, double days, long toman, String why, String code, Pick pk, String raw) {
        if (gb < 0.05 || gb > 5000 || toman < 100 || toman > 2000000000L) return null;
        if (Fmt.norm(title).trim().startsWith("از ")) return null; // "starting from ..." tile, not a real package
        Pkg p = new Pkg();
        p.op = op.id;
        p.title = title;
        p.gb = gb;
        p.days = days > 1000 ? 0 : days;
        p.toman = toman;
        p.why = why;
        p.restricted = !why.isEmpty();
        p.code = code;
        p.raw = raw;
        if (pk != null) {
            p.note = pk.note;
            p.ambig = pk.ambig;
            p.currencyKnown = pk.currencyKnown;
            p.alts = pk.alts;
        } else {
            p.currencyKnown = true;
            p.alts = new long[]{toman};
        }
        p.key = keyOf(op.id, title, code, why);
        return p;
    }
}
