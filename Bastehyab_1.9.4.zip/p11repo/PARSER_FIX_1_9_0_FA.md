# گزارش اصلاح مسیر Parser — نسخهٔ منبع 1.9.0

## علت ریشه‌ای

`Extractor.fromText()` نتیجهٔ nullable تابع `mk()` را بدون بررسی استفاده می‌کرد. `mk()` عمداً برای حجم کمتر از `0.05GB`، حجم بیش از `5000GB`، قیمت خارج از بازهٔ `100..2,000,000,000` تومان و عنوان‌هایی که با «از » شروع می‌شوند `null` برمی‌گرداند. بنابراین یک کاندید متنی نامعتبر می‌توانست با `NullPointerException` کل `Extractor.extract()` همان root را متوقف کند.

## تغییرات

- پیش از دسترسی به فیلدهای `Pkg`، مقدار برگشتی `mk()` در `fromText()` بررسی می‌شود؛ کاندید ردشده حذف می‌شود و سایر کارت‌ها ادامه پیدا می‌کنند.
- ورودی null برای node متنی و context نامعتبر اپراتور به‌صورت نتیجهٔ ناقص و کنترل‌شده مدیریت می‌شود.
- استخراج نام package ریشه از diagnostic حذف شد؛ metadata هویتی در dump ثبت نمی‌شود و دسترسی غیرضروری به root هم ایجاد نمی‌کند.
- diagnostic استخراج به شمارنده‌ها و فرادادهٔ ساختاری محدود شد؛ قیمت، حجم، یادداشت بسته و متن صفحه از `dump` حذف شدند.
- تمام سه call site تابع nullable `mk()` بررسی شدند: `flatPairs()` و حلقهٔ `make()` از قبل null را رد می‌کردند و با تست رگرسیون صریح پوشش داده شدند؛ `fromText()` guard لازم را دریافت کرد.
- تست‌های رگرسیون برای 10MB، 49MB، عنوان «از ...»، قیمت خارج از محدوده، مرزهای معتبر حداقل/حداکثر، سه بستهٔ معتبر همراه یک کارت خراب، ارقام فارسی/عربی و 300 ورودی متنی adversarial قطعی اضافه شدند.
- تست stale-node و sanitizer فعلی حفظ شدند؛ fixtureها فاقد شماره، ایمیل، شناسه یا متن حساب واقعی‌اند.

## فایل‌های تغییرکرده

- `app/src/main/java/app/bastehyab/Extractor.java`
- `tools/parser-smoke-tests/ParserSmokeTest.java`
- `tools/parser-smoke-tests/stubs/android/view/accessibility/AccessibilityNodeInfo.java`
- `tools/parser-smoke-tests/README.md`
- `CHANGELOG.md`
- `PARSER_FIX_1_9_0_FA.md`

## محدودهٔ تضمین آزمون adversarial

تست adversarial روی 300 متن ساختگی deterministic در مسیرهای متن تجمیعی، کارت ساختاریافته و فهرست هندسی، با `Op` معتبر، root قابل ساخت از Android `AccessibilityNodeInfo` و داده‌های متنی بدون دادهٔ شخصی اجرا می‌شود. خطاهای Runtime ناشی از nodeهای stale که API دسترس‌پذیری آن‌ها را گزارش می‌کند در مرز build هر شاخه مدیریت می‌شوند. این آزمون اثبات ریاضی برای تمام حالت‌های Android framework یا تمام اپ‌های اپراتوری نیست و جای آزمون instrumentation/device را نمی‌گیرد. خطاهای `Error` مانند `OutOfMemoryError` عمداً catch نمی‌شوند.

## نتایج آزمون در محیط اجرا

- آزمون رگرسیون ابتدا روی `Extractor.java` اصلیِ داخل ZIP اجرا شد و همان `NullPointerException` در `fromText()` را در خط 1158 بازتولید کرد؛ سپس با اصلاح اعمال‌شده همان تست PASS شد (red/green تأیید شد).
- `tools/fixture-sanitizer/test.sh` — PASS
- `tools/parser-smoke-tests/run.sh` — PASS؛ شامل 300 ورودی adversarial قطعی و سناریوهای رگرسیون فوق
- `tools/android-core-smoke-tests/run.sh` — PASS
- `tools/popup-overlay-smoke-tests/run.sh` — PASS
- `tools/ui-layout-smoke-tests/run.sh` — PASS؛ کنتراست تم‌های تاریک، روشن و تک‌رنگ و قراردادهای RTL
- `tools/android-core-smoke-tests/check-accessibility-api.sh` — PASS
- `tools/backdrop-smoke-tests/run.sh` — FAIL در مرحلهٔ کامپایل harness؛ Stubها کلاس‌های `android.animation.ValueAnimator`، `android.os.Build`، `android.view.animation.LinearInterpolator` و callbackهای lifecycle موردنیاز `View` را ندارند. این خطا از مسیر Parser نیست و build واقعی Android را هم تعیین نمی‌کند.

Gradle و `adb` در محیط موجود نیستند و مخزن Gradle Wrapper ندارد؛ بنابراین Gradle Unit Test، Android Lint، APK build و device test اجرا نشده‌اند. این موارد PASS اعلام نمی‌شوند.
