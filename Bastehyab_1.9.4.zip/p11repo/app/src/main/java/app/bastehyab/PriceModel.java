package app.bastehyab;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Canonical money parsing/conversion. Internal unit is whole toman; unknown units never normalize. */
final class PriceModel {
    enum Currency { UNKNOWN, IRR, IRT }
    enum Confidence { NONE, LOW, MEDIUM, HIGH }
    static final class Parsed {
        final long rawAmount, normalizedToman; final Currency currency; final Confidence confidence;
        Parsed(long raw, long toman, Currency c, Confidence f) { rawAmount=raw; normalizedToman=toman; currency=c; confidence=f; }
        boolean comparable() { return currency != Currency.UNKNOWN && confidence != Confidence.NONE && normalizedToman > 0; }
    }
    private PriceModel() {}
    static long toToman(long amount, Currency currency) {
        if (amount <= 0) throw new IllegalArgumentException("amount");
        if (currency == Currency.UNKNOWN) throw new IllegalArgumentException("currency");
        if (currency == Currency.IRT) return amount;
        return amount / 10L; // rial-to-toman is exact for valid rial amounts
    }
    static long safeVat(long toman, int percent) {
        if (toman <= 0 || percent < 0 || percent > 100) throw new IllegalArgumentException("money/vat");
        return BigDecimal.valueOf(toman).multiply(BigDecimal.valueOf(100L + percent))
                .divide(BigDecimal.valueOf(100), 0, RoundingMode.HALF_UP).longValueExact();
    }
    static Parsed parse(String input, Currency context) {
        if (input == null || input.length() > 300) return null;
        String s = Fmt.norm(input).toLowerCase(java.util.Locale.ROOT);
        if (s.matches(".*(?:^|\\s)-\\s*[0-9].*")) return null;
        Currency c = s.contains("ریال") ? Currency.IRR : (s.contains("تومان") || s.contains("تومن")) ? Currency.IRT : Currency.UNKNOWN;
        Confidence confidence = c == Currency.UNKNOWN ? Confidence.NONE : Confidence.HIGH;
        if (c == Currency.UNKNOWN && context != null && context != Currency.UNKNOWN) { c=context; confidence=Confidence.LOW; }
        Matcher compound = Pattern.compile("([0-9][0-9,،.]*)\\s*هزار\\s*و\\s*([0-9][0-9,،.]*)\\s*(?:تومان|تومن|ریال)").matcher(s);
        if (compound.find()) {
            try {
                long a = new BigDecimal(compound.group(1).replace(",", "").replace("،", "")).multiply(BigDecimal.valueOf(1000)).longValueExact();
                long b = new BigDecimal(compound.group(2).replace(",", "").replace("،", "")).longValueExact();
                long raw = Math.addExact(a,b);
                if (raw <= 0 || raw > 20000000000L) return null;
                long normalized = c == Currency.UNKNOWN ? 0 : toToman(raw,c);
                return new Parsed(raw, normalized, c, confidence);
            } catch(Exception ex) { return null; }
        }
        Matcher m = Pattern.compile("(?<![\\p{L}])([0-9][0-9,،.]*)(?:\\s*(هزار|میلیون))?").matcher(s);
        long found=0; boolean any=false;
        while(m.find()) {
            String n=m.group(1).replace(",", "").replace("،", "");
            // Dot is decimal only when not a 3-digit grouping; money amounts must resolve to whole units.
            if (n.matches("[0-9]{1,3}(?:\\.[0-9]{3})+")) n=n.replace(".", "");
            else if (n.indexOf('.')>=0) return null;
            try {
                BigDecimal v=new BigDecimal(n);
                if (m.group(2)!=null) v=v.multiply(m.group(2).equals("میلیون")?BigDecimal.valueOf(1000000):BigDecimal.valueOf(1000));
                long amount=v.longValueExact();
                if (amount <= 0 || amount > 20000000000L) return null;
                found=amount; any=true;
            } catch(Exception ex) { return null; }
        }
        if (!any) return null;
        if (c==Currency.UNKNOWN) return new Parsed(found,0,c,confidence);
        try { long t=toToman(found,c); if(t<100 || t>2000000000L) return null; return new Parsed(found,t,c,confidence); }
        catch(Exception ex) { return null; }
    }
}
