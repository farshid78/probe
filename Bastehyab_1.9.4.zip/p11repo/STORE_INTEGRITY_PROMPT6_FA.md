# گزارش اجرای Prompt 6 — یکپارچگی و هم‌زمانی Store

**مبنای تغییر:** سورس Prompt 5 (Price/Tax) در نسخهٔ 1.9.0

## نتیجه

Store بازطراحی محدود و درون‌پروژه‌ای شد؛ abstraction عمومی یا لایهٔ repository جداگانه اضافه نشد. مالکیت داده، قفل map و صف واحد I/O در خود `Store` مشخص شده است. مصرف‌کنندگان لازم در `MainActivity` و `Compare` به قرارداد جدید متصل شدند.

## تغییرات اصلی

### ۱. مالکیت داده و API مخزن

- `Store.snapshot(Context)` snapshot نقطه‌ای می‌دهد؛ هم `List` جدید است و هم تمام `Pkg`ها با `Pkg.copy()` کپی عمیق می‌شوند.
- `Store.all(Context)` برای سازگاری باقی مانده و دقیقاً همان قرارداد snapshot را دارد.
- `Store.upsert(...)` قبل از ورود به map ورودی را کپی می‌کند؛ `raw` موقت Accessibility ذخیره نمی‌شود.
- `Store.update(...)` فقط یک کپی جداشده را به mutator می‌دهد و پس از اعتبارسنجی، نسخهٔ جدید را commit می‌کند.
- `clearOp` و `clearAll` فقط map را تغییر می‌دهند و ذخیره را صف می‌کنند.
- هیچ reference از map داخلی یا آرایهٔ `alts` آن به بیرون داده نمی‌شود.

### ۲. thread ownership و مسیر I/O

- `LOCK` تنها نقطهٔ حفاظت map و metadata است.
- `STORE_IO` یک `ScheduledExecutorService` تک‌ریسمانه و process-scoped است؛ load، JSON decode/encode، نوشتن تاریخچه، fsync و rename فقط روی همین صف اجرا می‌شوند.
- قفل فقط برای snapshot/merge/mutate map نگه داشته می‌شود؛ JSON serialization و file I/O خارج lock است.
- `flush()` asynchronous است و روی main thread منتظر دیسک نمی‌ماند.
- writeها coalesce می‌شوند: اگر write در حال اجرا باشد و mutation جدیدی برسد، بعد از write فعلی آخرین snapshot هم ذخیره می‌شود.
- callback جدید `whenLoaded(...)` پس از load اولیه روی main looper فراخوانی می‌شود؛ `MainActivity` بعد از بارگذاری، صفحه را دوباره render می‌کند تا snapshot خالی اولیه با دادهٔ دیسک جایگزین شود.
- `Compare.run()` برای ranking و تشخیص بسته‌های روی صفحه فقط یک snapshot مشترک می‌گیرد.

### ۳. ذخیره‌سازی اتمیک و backup

- ساخت فایل موقت `data.json.tmp` در همان directory انجام می‌شود.
- محتوا flush می‌شود و `FileDescriptor.sync()` تلاش می‌شود؛ در فایل‌سیستم‌هایی که fsync در دسترس نیست، کد تشخیصی غیرحساس ثبت و عملیات rename ادامه داده می‌شود.
- backup با کپی به `data.json.bak.tmp` و rename اتمیک refresh می‌شود، اما فقط وقتی primary قبلی کاملاً معتبر باشد.
- سپس `android.system.Os.rename` فایل temp را به primary جایگزین می‌کند؛ rename در همان filesystem اتمیک است.
- backup پس از save موفق حذف نمی‌شود. primary خراب یا نیمه‌معتبر هم backup سالم قبلی را بازنویسی نمی‌کند.
- خطای write باعث باقی‌ماندن write در وضعیت pending و retry زمان‌بندی‌شده می‌شود.

### ۴. schema، migration و quarantine

- قالب جدید root دارای `schemaVersion: 2` و آرایهٔ `records` است.
- قالب فعلی قدیمی پروژه (یک `JSONArray` ریشه‌ای) به‌عنوان نسخهٔ legacy پذیرفته و در write بعدی به schema 2 تبدیل می‌شود.
- migration قبلی تشخیص قطعیت واحد پول حفظ شده است: فقط متن دارای واحد روشن یا پروفایل ثابت اپراتور می‌تواند قطعیت را بازیابی کند؛ در غیر این صورت رکورد مبهم می‌ماند.
- هر رکورد جداگانه parse و validate می‌شود. رکورد معیوب به quarantine count می‌رود و مانع حفظ سایر رکوردها نمی‌شود.
- فایل خالی، JSON خراب، schema پشتیبانی‌نشده و فایل بیش از 8 MiB با کد مشخص مدیریت می‌شوند.
- در صورت نامعتبر بودن primary، backup سالم برای recovery استفاده می‌شود.

### ۵. سقف داده و سیاست نگهداری

- ظرفیت هدف: ۲۵۰۰ بسته.
- ۲۳۰۰ جایگاه برای رکوردهای معمولی در نظر گرفته شده و ۲۰۰ جایگاه رزرو برای رکوردهای مبهم/نیازمند بررسی، تأییدشده/ردشده یا محدودشده است.
- وقتی سقف مربوط پر باشد، رکورد جدید پذیرفته نمی‌شود و `STORE_CAPACITY_REACHED` و شمارندهٔ رد ظرفیت ثبت می‌شوند.
- دادهٔ موجود به‌صورت خودکار حذف نمی‌شود؛ رکوردهای مهم و حتی فایل legacy بیش‌ازسقف حفظ می‌شوند و فقط diagnostic نمایش داده می‌شود. حذف فقط از مسیرهای صریح کاربر مثل حذف اپراتور یا پاک‌کردن داده انجام می‌شود.
- این نسخه عمداً به‌جای pruning خودکارِ غیرقابل‌بازگشت از admission control استفاده می‌کند؛ آرشیو دائمی مستقل برای رکوردهای prune‌شده در این scope اضافه نشده است.

### ۶. diagnostic و حریم خصوصی

کدهای نمونه: `STORE_EMPTY_FILE`، `STORE_DOCUMENT_INVALID`، `STORE_SCHEMA_NEWER`، `STORE_BACKUP_RECOVERED`، `STORE_RECORDS_QUARANTINED_n`، `STORE_WRITE_FAILED`، `STORE_WRITE_RECOVERED`، `STORE_FSYNC_UNAVAILABLE` و `STORE_CAPACITY_REACHED`.

در log و diagnostic هیچ متن خام صفحه، عنوان بسته، شناسهٔ اپراتور/حساب، یا serialized record ثبت نمی‌شود.

## تست‌ها

همهٔ تست‌های زیر در این اجرا PASS شدند:

- یک رکورد خراب بین ۱۰ رکورد سالم: ۱۰ رکورد سالم حفظ شدند و quarantine برابر ۱ شد.
- backup recovery از primary خراب و migration از آرایهٔ legacy.
- فایل خالی، سند خراب و schema پشتیبانی‌نشده.
- deep-copy مرز ورودی/خروجی، شامل آرایهٔ `alts`.
- رقابت هم‌زمان `Compare.run()`، review، reprice، upsert و snapshot.
- clear هم‌زمان با load اولیه و clear در حالی که write در حال اجرا بود.
- دو write متوالی، retry پس از خطای قبل و بعد از rename، و باقی‌ماندن backup پس از save موفق.
- main-thread non-blocking: در حالی که rename روی صف I/O عمداً متوقف بود، فراخوانی `flush()` بدون انتظار دیسک برگشت.
- benchmark snapshot برای ۲۵۰۰ رکورد.
- تست‌های موجود parser، scan/core، review queue، popup/overlay، UI layout، fixture sanitizer و Accessibility API compatibility.

### Benchmark محدود

در harness محلی JVM و با ۲۵۰۰ رکورد مصنوعی، زمان deep snapshot در آخرین اجرا **median حدود 0.69 ms** و **p95 حدود 6.09 ms** بود (۵۰ نمونه). p95 در اجرای آخر به‌دلیل نوسان زمان‌بندی/GC بالاتر بود؛ این اندازه‌گیری فقط هزینهٔ کپی snapshot را نشان می‌دهد، نه I/O یا عملکرد ART روی دستگاه واقعی، و نتیجهٔ قطعی عملکرد موبایل محسوب نمی‌شود. از آن برای توجیه افزودن abstraction بزرگ استفاده نشد؛ پیاده‌سازی به یک lock، یک صف تک‌ریسمانه و APIهای محدود Store بسنده می‌کند.

## محدودیت‌های اعتبارسنجی

- build واقعی Android/Gradle اجرا نشد: پروژه Gradle wrapper ندارد و در محیط اجرا `gradle` و `ANDROID_HOME` در دسترس نبودند.
- تست‌های ذخیره‌سازی با stubهای JVM برای Android و JSON و با شبیه‌سازی خطای rename اجرا شدند؛ جایگزین تست filesystem واقعی Android یا تست روی دستگاه نیستند.
- executor در lifecycle اکتیویتی/سرویس shutdown نمی‌شود تا کارهای صف‌شده ادامه پیدا کنند؛ `flush()` فقط صف را تخلیه می‌کند و main thread را متوقف نمی‌کند. در قطع ناگهانی کل process توسط سیستم، هیچ executor درون‌فرآیندی نمی‌تواند تکمیل write در حال اجرا را تضمین کند؛ atomic rename و backup برای recovery از فایل قبلی طراحی شده‌اند.
- خودکارسازی حذف داده عمداً انجام نشده؛ در سقف ظرفیت، رکوردهای جدید رد می‌شوند تا حذف خاموش و غیرقابل‌بازگشت رخ ندهد.
