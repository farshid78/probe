<div dir="rtl">

# ممیزی منطق غیر-UI بسته‌یاب (سورس 1.8.2، همراه نسخه‌ی 1.9.0)

دامنه: ScanService، Extractor، Compare، Store، Pkg، Fmt، Cfg، Op/OpSnapshot، History/HistoryLog، ListEndDetector، ScanStrategyPolicy، Manifest، service_config، build.gradle، CI و تست‌ها.
مسیرها نسبت به `app/src/main/java/app/bastehyab/` هستند مگر ذکر شده. هیچ فایلی در پروژه تغییر داده نشده و چیزی اجرا نشده است؛ همه‌ی موارد از خواندن کد استخراج شده‌اند. هر جا اجرا لازم است برچسب «تأییدنشده» خورده است.

علامت «(باز-از-قبل)» یعنی در `AUDIT_AND_ROADMAP_1_6_8_FA.md` یا `PROMPTS_NEXT_STEPS_FA.md` یا README به‌عنوان مورد شناخته‌شده آمده و هنوز در کد باز است. بقیه‌ی موارد در اسناد نیامده‌اند.

---

## ۱. باگ، منطق، کرش، race و thread-safety

1. [severity: high] — NPE در مسیر `fromText` باعث شکست کل اسکن صفحه می‌شود — `Extractor.java:1157-1158` (مقصد null: `1167-1168`)
   `mk()` در چند حالت `null` برمی‌گرداند: حجم زیر 0.05 گیگ (مثلاً «۱۰ مگ»)، قیمت بالای ۲ میلیارد تومان، یا عنوان شروع‌شده با «از ». سپس `fromText` بدون بررسی `p.currencyKnown = ...` را اجرا می‌کند و NPE می‌دهد. NPE در `performScanWork` (`ScanService.java:900`) فقط به‌صورت `out.error` ثبت می‌شود. در نتیجه همه‌ی بسته‌های آن root در آن اسکن از بین می‌رود و تا زمانی که آن گره روی صفحه هست تکرار می‌شود. گارد «از ...» دقیقاً برای کاشی «شروع از» نوشته شده، ولی از همین مسیر به NPE می‌رسد.
   راه‌حل: `if (p == null) return null;` بعد از `mk` در `fromText`، و یک try/catch حول هر کارت/گره در `extractOnce` تا یک گره بد کل خروجی را نکشد.

2. [severity: high] — خطای غیر-RuntimeException (مثل OutOfMemoryError) `scanning` را برای همیشه true نگه می‌دارد — `ScanService.java:750-754` و `1161-1168`
   lambda داخل `worker.execute` هیچ try/finally ندارد. اگر `performScanWork` یا `performAdaptiveScroll` یک `Error` پرتاب کند، `h.post(finishScan)` هرگز اجرا نمی‌شود. `scanning` تا بازراه‌اندازی سرویس true می‌ماند و همه‌ی اسکن‌های بعدی فقط `scanAgain = true` می‌کنند (`scan()` خط 725 و `scheduleScan` خط 508).
   راه‌حل: در lambda، `Throwable` را بگیر و همیشه `h.post(() -> finishScan(outcomeOrErrorOutcome))` را اجرا کن.

3. [severity: high] — تشخیص «پایان فهرست» می‌تواند از رویداد scroll کهنه یا مربوط به view دیگر ساخته شود — `ScanService.java:661-678`، `1111-1121`، `1058-1065`
   `onAccessibilityEvent` هر `TYPE_VIEW_SCROLLED` از هر view داخل برنامه‌ی هدف را در `fullLast*` می‌نویسد: carousel افقی، تب‌ها، WebView تو در تو. `source` فیلتر نمی‌شود و `fullLastScrollEventAt` در مسیر `fullEndDetector.observe(...)` هرگز چک نمی‌شود؛ فقط `hasFreshBottomMetrics` (تنظیم settle) از آن استفاده می‌کند. دو مرحله‌ی متوالی با همان رویداد کهنه‌ی «ته» حاصل `END_CONFIRMED` می‌دهد و اسکن ناقص با پیام «موفق» تمام می‌شود. این با کامنت خود کد («stale events never prove the bottom» خط 73) در تناقض است. لاگ‌های ایرانسل در ممیزی هم هم‌زمان `ScrollView` عمودی و `HorizontalScrollView` نشان می‌دهند. (مرتبط با مورد باز-از-قبل «درصد پیشرفت stale»)
   راه‌حل: فقط رویدادی را بپذیر که `getSource()` همان scrollable منتخب (یا بزرگ‌ترین عمودی) باشد، یا `getMaxScrollY()>0 && getMaxScrollX()==0`؛ و قبل از `observe` سن `fullLastScrollEventAt` را (مثلاً ≤ ۲.۲ ثانیه) چک کن.

4. [severity: medium] — `Store.load` همه‌چیز-یا-هیچ است و بک‌آپ در حالت عادی وجود ندارد — `Store.java:211-214`، `234-239`، `298`
   یک رکورد بدشکل (مثلاً نبود `gb` یا `toman` که `getDouble/getLong` در `Pkg.from` پرتاب می‌کنند) کل آرایه را رد می‌کند و `m.clear()` اجرا می‌شود. `data.json.bak` پس از هر ذخیره‌ی موفق حذف می‌شود (خط 298)، پس در عمل فقط در کرش وسط ذخیره‌سازی وجود دارد. اولین `save` بعدی فایل خراب را هم با DB خالی بازنویسی می‌کند.
   راه‌حل: هر رکورد را جداگانه try/catch کن و رکوردهای سالم را نگه دار؛ آخرین نسخه‌ی سالم را به‌صورت `.bak` نگه دار (حذفش نکن).

5. [severity: medium] — دو رکورد با عنوان یکسان ولی مدت متفاوت روی یک `key` می‌افتند — `Extractor.java:1122-1125` در برابر `587`، کلید در `741-746`
   در مسیر کارت (`make`) عنوان نمایشی `tl.text` است. مدتی که از leaf دیگر (`nearestDur`) آمده به عنوان اضافه نمی‌شود، ولی در مسیر `flatPairs` اضافه می‌شود (خط 587). `keyOf` از عنوان ساخته می‌شود، پس «۱۰ گیگ» ۷روزه و «۱۰ گیگ» ۳۰روزه که مدتشان جدا نوشته شده یک key می‌گیرند. `res.duplicates++` یکی را کنار می‌گذارد، و در Store دومی اولی را بازنویسی می‌کند. تاریخچه هم تغییر قیمت جعلی ثبت می‌کند. (تأییدنشده: به fixture واقعی بستگی دارد.)
   راه‌حل: `days` (و حجم) را به‌صورت عددی در `keyOf` وارد کن: `opId|gb|days|title#why`.

6. [severity: medium] — کلید بسته به `why` است و `why` از متن همسایه‌ی کارت (در `flatPairs`) می‌آید — `Extractor.java:588-598`، `741-746`
   `context` از leafهای داخل پنجره‌ی عمودی `segment` ساخته می‌شود و با موقعیت اسکرول تغییر می‌کند (بازه‌ی `startY..endY`). همان بسته در دو اسکن می‌تواند once «ساعت خاص» و once بدون برچسب بگیرد، یعنی دو key. نتیجه: رکورد تکراری با یکی «محدود» و دیگری «عادی» که `Compare.run` خط 113 دومی را ترجیح می‌دهد. (تأییدنشده؛ نیاز به fixture.)
   راه‌حل: `why` را از آنچه درون خود کارت/عنوان است بسازد و در `key` نیاورد؛ یا key بدون why بسازد و why را فیلد جدا نگه دارد.

7. [severity: medium] — اشتراک‌گذاری مستقیم اشیاء `Pkg` بین ترد UI و ترد worker بدون قفل — `Store.java:381-384`، `408-418`، `430-440`، `Compare.java:107`
   `Store.all()` فقط لیست را کپی می‌کند، خود `Pkg`ها مشترک‌اند. `saveReview` و `reprice` (ترد UI) فیلدهای همان اشیاء را در جا تغییر می‌دهند، در حالی که `Compare.run` در ترد worker از آن‌ها می‌خواند. خطر: مقدار نیمه‌به‌روز (مثلاً `toman` جدید با `ambig` قدیم) در رتبه‌بندی. وزن کم ولی واقعی.
   راه‌حل: `all()` کپی عمیق (`p.copy()`) برگرداند، یا Pkgها را immutable کن.

8. [severity: medium] — I/O روی main thread و قفل مشترک با worker — `ScanService.java:229`، `Store.java:372-379`، `MainActivity.java:260`، `348`، `621`
   `stopFull → Store.flush`، `onPause → Store.flush` و `Store.all()` برای رندر UI همه روی main هستند و روی `Store.class` قفل می‌گیرند. worker همان قفل را هنگام `save()` (سریالایز کل DB + نوشتن فایل) نگه می‌دارد. در DB بزرگ، main thread تا پایان نوشتن بلاک می‌شود (jank یا در بدترین حالت ANR).
   راه‌حل: snapshot در قفل کوتاه بگیر، سریالایز و I/O را بیرون قفل و روی executor تک‌ریسمانه انجام بده.

9. [severity: low] — leak گره‌ها هنگام استثنا در حلقه‌ی rootها — `ScanService.java:806-899` با catch در `900`
   فقط root جاری در `finally` recycle می‌شود؛ اگر RuntimeException از حلقه بیرون برود، rootهای بعدی در `roots` recycle نمی‌شوند. روی API≥33 `recycle` بی‌اثر است، پس فقط API 24-32 نشتی pool دارد.
   راه‌حل: بعد از حلقه یک finally که همه‌ی rootها را recycle کند.

10. [severity: low] — `fullSeen` و چند static دیگر `volatile`/غیر-thread-safe مختلط‌اند — `ScanService.java:101`، `436`
    `fullSeen` یک `HashSet` ساده است و فقط از main خوانده/نوشته می‌شود (درست)، اما `static` بودن و دسترسی از `MainActivity` آن را به تله تبدیل می‌کند. اگر کسی بعداً از worker بخواند، race می‌شود. وضعیت سرویس عمدتاً boolean/string پراکنده است، نه یک state machine. (باز-از-قبل: «وضعیت رشته‌محور»)
    راه‌حل: یک شیء `ScanSession` immutable/تک‌ریسمانه با enum فاز.

11. [severity: low] — `fullNoNew` فقط نوشته می‌شود و هیچ‌جا خوانده نمی‌شود — `ScanService.java:63`، `110`، `920`، `1088` (باز-از-قبل)
    حالا به پیام یا تصمیم توقف وصل نیست. یا حذف شود یا برای «چند مرحله بدون بسته‌ی تازه ولی با حرکت صفحه» توقف زودهنگام اضافه شود.

12. [severity: low] — `ignorable()` با `toLowerCase()` بدون Locale — `ScanService.java:650-653`
    در locale ترکی `I` به `ı` تبدیل می‌شود و تطبیق `inputmethod` می‌تواند خراب شود. راه‌حل: `toLowerCase(Locale.ROOT)`.

13. [severity: low] — هر پنجره‌ی اپ دیگر با `TYPE_WINDOW_STATE_CHANGED` اسکن را قطع می‌کند — `ScanService.java:194-197`، `682-685`
    Truecaller/bubble/پنجره‌ی مجوز سیستم (غیر `systemui`) وسط اسکن باعث `stopFull("از برنامه‌ی اپراتور خارج شدید")` می‌شود. راه‌حل: چند ثانیه تحمل (grace) یا فقط وقتی پنجره‌ی هدف در `getWindows()` دیگر نیست.

---

## ۲. امنیت، حریم خصوصی و ریسک سیاست Play/Bazaar برای سرویس دسترس‌پذیری

14. [severity: high] — ادعای README «اسکن فقط پس از تأیید کاربر» با رفتار واقعی نمی‌خواند (اسکن منفعل) — `ScanService.java:704-713`، README بخش «حریم خصوصی» (خط ~140)
    وقتی `fullMode` خاموش است، هر رویداد از برنامه‌ی یک اپراتور فعال (`Cfg.opFor`) اسکن کامل درخت + `Store.upsert` + `Compare.run` را برنامه‌ریزی می‌کند و در صورت `Cfg.popup` پنجره‌ی مقایسه روی برنامه‌ی اپراتور نشان می‌دهد؛ بدون هیچ تأیید جداگانه. کل متن صفحه‌ی برنامه‌ی اپراتور (موجودی، شماره تلفن و ...) در حافظه‌ی `Extractor` خوانده می‌شود، هرچند فقط بسته‌ها ذخیره می‌شوند. این بزرگ‌ترین شکاف افشا/سیاست است.
    راه‌حل: حالت منفعل را به‌صورت opt-in صریح (و پیش‌فرض خاموش) در تنظیمات بگذار و متن README/توضیح سرویس را با رفتار واقعی هماهنگ کن.

15. [severity: high] — سرویس برای رویدادهای همه‌ی برنامه‌ها ثبت است (نبود `packageNames`) — `res/xml/service_config.xml:1-8`
    بدون `android:packageNames` سیستم رویداد تمام برنامه‌ها (بانک، پیام‌رسان و ...) را به `onAccessibilityEvent` می‌دهد و فیلتر فقط در کد است (خط 704). این برای بررسی Play/Bazaar و Play Protect ریسک اصلی است و هزینه‌ی CPU هم دارد.
    راه‌حل: بسته‌های اپراتورها را از `Cfg` بخوان و با `setServiceInfo()` در `onServiceConnected` و بعد از هر ویرایش اپراتور به `AccessibilityServiceInfo.packageNames` بده؛ یا حداقل بسته‌های پیش‌فرض را در XML بگذار.

16. [severity: medium] — `flagReportViewIds` استفاده نمی‌شود — `service_config.xml:4`
    هیچ‌جای کد `viewIdResourceName` نمی‌خواند (grep). این flag داده‌ی اضافه و مجوز غیرضروری است. راه‌حل: حذف.

17. [severity: medium] — توضیح سرویس نمی‌گوید که سرویس gesture لمسی (swipe) اجرا می‌کند — `res/values/strings.xml` (`svc_desc`)، `service_config.xml:7` (`canPerformGestures`)، `ScanService.java:1370-1458`
    متن می‌گوید «خرید یا تغییر خودکار انجام نمی‌شود» ولی `dispatchGesture` swipe را داخل برنامه‌ی اپراتور اجرا می‌کند. راه‌حل: صراحتاً بنویس («برای پیمایش خودکار فهرست پس از تأیید شما، حرکت اسکرول انجام می‌دهد»)؛ برای Play این متن باید با Declaration فرم هم‌خوان باشد (تأییدنشده: متن فعلی سیاست Play).

18. [severity: medium] — کاربر می‌تواند هر پکیج دلخواه را «اپراتور» کند و سرویس آن را اسکن می‌کند — `Cfg.java:249-259`، `ScanService.java:704`
    `validPackageName` فقط قالب را چک می‌کند. اگر کاربر (یا فریب‌دهنده) پکیج برنامه‌ی بانکی را اضافه کند، متن آن برنامه (به‌جز editable/password) پردازش می‌شود. فیلتر `isEditable/isPassword` (`Extractor.java:292`) خوب است ولی کافی نیست.
    راه‌حل: هشدار صریح هنگام افزودن پکیج دلخواه و ممنوع‌کردن لیست کوتاهی از پکیج‌های حساس شناخته‌شده.

19. [severity: medium] — تازه‌ترین Android: sideload با «Restricted settings» و قابل‌فعال‌نبودن سرویس — `MainActivity.java:337-389`
    روی Android 13+ برای APK نصب‌شده خارج از فروشگاه (GitHub Releases، دانلود مستقیم) فعال‌کردن سرویس تا زمانی که کاربر «اجازه‌ی تنظیمات محدودشده» را از صفحه‌ی App info ندهد ممکن نیست. UI فقط تنظیمات دسترس‌پذیری را باز می‌کند (grep: عبارت Restricted نیست). این برای onboarding مهم است. (تأییدنشده روی دستگاه)

20. [severity: low] — `diag.txt` بدون متن خام است (مثبت) ولی هنوز یادداشت قیمت و فراداده‌ی صفحه را در Downloads عمومی می‌نویسد — `Extractor.java:259-275`، `ScanService.java:1665-1699`، `MainActivity.java:1266-1290`
    متن خام صفحه وارد dump نمی‌شود (`Extractor` فقط حجم/روز/قیمت/note را می‌نویسد). `note` شامل مبالغ دیگر کارت است. خروجی به `MediaStore.Downloads` می‌رود که برای همه‌ی برنامه‌ها با دسترسی ذخیره‌سازی خوانا است. تناقض جزئی: کامنت `diag()` «۳۰ snapshot» می‌گوید ولی کد ۱۲ تا نگه می‌دارد (خط 1650).
    راه‌حل: برای اشتراک‌گذاری از `ACTION_SEND` + `FileProvider` استفاده کن؛ شماره‌ی نسخه را از `BuildConfig`/`PackageInfo` بخوان (الان hardcode «1.6.8» در خط 1667).

21. [severity: low] — خروجی CSV بدون خنثی‌سازی Formula Injection — `MainActivity.java:1221-1224`
    `csv()` فقط `"` را escape می‌کند. عنوانی که از متن برنامه‌ی اپراتور می‌آید و با `= + - @` شروع شود در Excel/Sheets اجرا می‌شود. راه‌حل: پیشوند `'` برای فیلدهایی که با این نویسه‌ها شروع می‌شوند.

22. [severity: low] — `<queries>` برای همه‌ی launcher intentها دید گسترده‌ی بسته‌ها می‌دهد — `AndroidManifest.xml:4-9`
    فقط برای `getLaunchIntentForPackage` روی چند پکیج اپراتور لازم است. راه‌حل: `<package android:name=.../>` برای پکیج‌های پیش‌فرض اپراتورها (+ queries پویا برای پکیج کاربر کار نمی‌کند، پس trade-off را مستند کن). تأییدنشده که Bazaar/Play این را رد می‌کند.

---

## ۳. کارایی و باتری

23. [severity: high] — تا ۳ پیمایش کامل درخت در هر مرحله‌ی اسکن کامل — `ScanService.java:816`، `846`، `851`، `1264-1286`، `1196-1250`
    هر مرحله: (۱) `Extractor.extract` با پیمایش کامل (تا ۴۵۰۰ گره، بدون pruning هیدن، خط 143)، (۲) `pageFingerprint` → `fingerprintTree` (تا ۱۸۰۰ گره، خط 846)، (۳) در صورت نبود آیتم `looksLikeOfferPage` (تا ۷۰۰ گره)، (۴) `getFullTargetRoot` + `findScrollable` (تا ۱۲۰۰ گره) با `getWindows()` دوباره. هر `getChild` یک IPC است. این دلیل اصلی کندی و مصرف باتری در اسکن است.
    راه‌حل: درخت `N` ساخته‌شده توسط `Extractor` را برگردان و fingerprint و scrollable-selection را از همان بساز (یک پیمایش در هر مرحله).

24. [severity: medium] — اسکن منفعل با هر رویداد محتوا، حداقل هر ۴۵۰ms، بدون سقف — `ScanService.java:370-377`، `704-713`
    در برنامه‌ی اپراتور با اسلایدر/انیمیشن، `TYPE_WINDOW_CONTENT_CHANGED` مدام می‌رسد (فاصله‌ی `notificationTimeout` فقط ۳۵۰ms) و هر اسکن شامل `Store.upsert` و `Compare.run` (دو بار `Store.all`) است. هیچ بک‌آف یا «محتوا تغییر نکرده» (hash) نیست.
    راه‌حل: hash درخت/آیتم‌ها را نگه دار و اگر تغییر نکرده، اسکن بعدی را رد کن؛ پس از N اسکن بدون تغییر بک‌آف نمایی.

25. [severity: medium] — `Cfg.opFor` برای هر رویداد هر برنامه، لیست `Op` را کپی می‌کند — `Cfg.java:96-98`، `135-146`، `159-161`، فراخوانی در `ScanService.java:704`
    `ops()` همیشه `copyOps` می‌کند (آلوکیشن + قفل static). با نبود `packageNames` (مورد ۱۵) این برای رویداد تمام برنامه‌های گوشی اجرا می‌شود. راه‌حل: یک `Set<String>` از بسته‌های فعال به‌صورت volatile نگه دار و فقط هنگام ذخیره‌ی تنظیمات بازسازی کن.

26. [severity: medium] — `String.replaceAll` در مسیر داغ، Pattern هر بار کامپایل می‌شود — `Fmt.java:49-50`، `Extractor.java:336`، `ScanService.java:1503`، `1545`
    `Fmt.norm` هر بار دو `replaceAll` (کامپایل regex) اجرا می‌کند و به‌ازای هر leaf چندین بار صدا زده می‌شود (`price`, `vol`, `dur`, `kind`, `labelKind` ...)؛ `build` نیز برای هر گره یک `replaceAll`. فشار GC و CPU زیاد.
    راه‌حل: Patternهای `static final` و memoize کردن `norm(text)` در `N` (یک بار برای هر leaf).

27. [severity: low] — `kind()` و `pick()` درجه‌ی دوم و سوم دارند — `Extractor.java:830-883`، `916-1022`
    حلقه‌ی تو در توی `lv × lv` (خط 848/865) و `lv.indexOf` (خط 840). روی کارت‌های کوچک بی‌اهمیت است؛ اگر `findCards` به root کامل برسد (خط 626) روی صفحات بلند کند می‌شود. (تأییدنشده؛ نیاز به اندازه‌گیری)

28. [severity: low] — watchdog پنجره‌ی کنترل هر ۱.۸ ثانیه و بازسازی در هر مرحله — `ScanService.java:573-590`، `998`
    `showConfirm` مسیر in-place دارد (`updateViewLayout`)، پس سبک است؛ فقط یک تایمر دائمی در طول اسکن است. اطلاع‌رسانی، نه باگ.

---

## ۴. شکنندگی parser (ارقام، واحد، مدت، نامحدود/شبانه)

29. [severity: medium] — قیمت با «مالیات» دوباره مالیات می‌خورد؛ مبنای VAT برای همه‌ی اپراتورها یکسان فرض شده — `Compare.java:135`، `Cfg.java:216`، `Extractor.java:123-124`
    `Compare.run` همیشه `Fmt.withVat(p.toman, Cfg.vat(c))` اعمال می‌کند، ولی `K_MAIN` عمداً «با مالیات / شامل مالیات / قابل پرداخت» را به‌عنوان قیمت اصلی برمی‌دارد (kind 4). اگر برنامه‌ی یک اپراتور قیمت را با مالیات نشان بدهد، رتبه‌بندی ۱۰٪ دوباره‌شمار می‌شود و با اپراتوری که قیمت پایه نشان می‌دهد ناهمگن می‌شود. `Pkg` هیچ فیلد «قیمت شامل مالیات است؟» ندارد. (تأییدنشده: اینکه کدام اپراتور چه نشان می‌دهد، به fixture بستگی دارد.)
    راه‌حل: فیلد `vatIncluded` در `Pkg`/`Op` و حذف VAT از قیمت‌های kind 4/نشانه‌دار.

30. [severity: medium] — `AUTO` در عمل هیچ استنتاجی نیست؛ بدون واحد صریح بسته هرگز رتبه نمی‌گیرد — `Extractor.java:748-755`، `Cfg.java:19-22`، `Cfg.java:120-122`
    `toman()` برای `cur="AUTO"` و واحد ناشناخته همان مقدار را برمی‌گرداند و `currencyKnown=false` می‌شود. یعنی قیمت بدون کلمه‌ی «تومان/ریال» (یا بدون leaf واحد کنارش) فقط در `r.ambig` می‌ماند. کامنت‌ها و گزارش‌ها («استنتاج خودکار واحد») چیزی بیش از برچسب نیست. در مقابل `samantel` با `IRR` ثابت، هر مبلغ بدون واحد را ÷۱۰ می‌کند و `currencyKnown=true` می‌گذارد؛ اگر برنامه‌ی سامانتل به تومان تغییر کند، قیمت ۱۰ برابر ارزان‌تر رتبه می‌گیرد.
    راه‌حل: استنتاج با بازه‌ی منطقی قیمت/گیگ (مثلاً با اندازه‌ی مبلغ نسبت به میانه‌ی همان اپراتور) و علامت ambiguous برای outlierها؛ نه ثابت‌کردن واحد.

31. [severity: medium] — الگوی حجم `VOL` پیشوند «مگا/ترا» را بدون مرز کلمه می‌پذیرد — `Extractor.java:82`
    «۵۰ مگابیت» (سرعت) با `مگا` به ۵۰ مگابایت تبدیل می‌شود، «گیگابیت» با `گیگا` به گیگابایت، و «۵ ترافیک» با `ترا` به ۵ ترابایت. برای ۱ ترا → ۱۰۲۴ گیگ هم از ۵۰۰۰ تجاوز نمی‌کند. بدون `(?![؀-ۿ])` پایانی.
    راه‌حل: lookahead منفی برای حروف فارسی بعد از واحد و حذف شکل‌های «ترا/مگا» جدا از «بایت».

32. [severity: low] — ضریب‌های مدت و حجم ساده‌شده‌اند — `Extractor.java:667`، `709-712`، `718`
    ۱ مگ = ۱/۱۰۲۴ گیگ (اپراتورها معمولاً ۱۰۲۴ حساب می‌کنند، پس قابل‌قبول)، ۱ ماه = ۳۰ روز، ۱ سال = ۳۶۵ ولی ۱۲ ماه = ۳۶۰. در `DURN` اعداد حرفی فقط تا چند کلمه (`یک..نود`) پوشش دارند و مواردی مثل «هفتاد روزه» یا «صد و بیست» نیستند. `default: return 12` در `word()` (خط 697) بی‌صدا ۱۲ می‌دهد.
    راه‌حل: جدول کامل اعداد حرفی؛ `default → NaN/0` به‌جای ۱۲.

33. [severity: low] — برگه‌ی «۱۰۰ هزار و ۵۰۰ تومان»، leaf عددی ۴+ رقمی بدون واحد و ترکیب `NUMONLY` — `Extractor.java:89-91`، `196-211`، `648`
    مبلغ `۱۲۰ هزار و ۵۰۰ تومان` فقط ۱۲۰ هزار برمی‌دارد. leaf کاملاً عددی ۴+ رقمی (مثلاً سال، تعداد) بدون واحد قیمت تلقی می‌شود (و با `cur` ثابت `currencyKnown=true`). ترکیب «عدد» + «هزار تومان» از جاروی همسایه‌ی ترتیب درخت (نه هندسه) استفاده می‌کند. (تأییدنشده)
    راه‌حل: تست با fixture واقعی؛ جفت‌سازی عدد/واحد با bounds.

34. [severity: low] — بسته‌های نامحدود/شبانه فقط برچسب می‌خورند، parse عددی ندارند — `Extractor.java:97-106`، `780-806`
    «نامحدود» حجم عددی ندارد و `vol()` null می‌دهد، پس این بسته‌ها اصلاً در DB نمی‌آیند مگر حجم عددی هم داشته باشند. برچسب‌ها (`R_UNL` و ...) مبتنی بر regexهای ثابت‌اند و نسخه‌های جدید اپ، عبارت جدید می‌آورد؛ هیچ ماتریس تست برای دیده‌شدن/ندیدن آن‌ها نیست. ایدهٔ ارتقا: نوع بسته (`نامحدود/شبانه/روزانه`) را به‌صورت enum و نه رشته‌ی فارسی نگه دارد.

---

## ۵. داده و Store (dedupe، مهاجرت، حجم، رشد، flush)

35. [severity: medium] — مهاجرت `defv<6` پکیج‌های اضافه‌شده‌ی کاربر را برای اپراتورهای داخلی پاک می‌کند — `Cfg.java:111-128`
    `ex.pkgs.clear(); ex.pkgs.addAll(d.pkgs)` برای `builtin` اجرا می‌شود؛ پکیج‌هایی که کاربر برای مثلاً ایرانسل اضافه کرده (مثلاً نسخه‌ی دوم برنامه) از دست می‌روند. `ex.policy = 0` هم تنظیم کاربر را بازنویسی می‌کند. راه‌حل: اجتماع (`union`) پکیج‌ها و حفظ `policy` کاربر.

36. [severity: medium] — رشد بی‌پایان DB و تاریخچه بدون سقف رکورد — `Store.java:176`، `331-374`، `HistoryLog.java:323-327`
    `Store.m` هرگز پاک‌سازی نمی‌شود (تازگی فقط در `Compare` فیلتر می‌شود: `Compare.java:126`). هر `save` کل آرایه را دوباره سریالایز می‌کند. تاریخچه ۳۰۰ ورودی است ولی در SharedPreferences «cfg» ذخیره می‌شود (`HistoryLog.java:326`)، یعنی هر `apply()` کل XML تنظیمات (شامل `ops`) را بازنویسی می‌کند و هر تغییر قیمت یک پارس/سریالایز کامل JSON تاریخچه را داخل `Store.upsert` و تحت قفل `Store` انجام می‌دهد (`Store.java:356`).
    راه‌حل: حذف رکوردهای قدیمی‌تر از N روز؛ تاریخچه در فایل جدا.

37. [severity: medium] — تاریخچه‌ی قیمت برای نمودار قابل‌استفاده نیست — `HistoryLog.java:297-298`، `History.java:207-214`
    فقط «تغییر»ها ثبت می‌شوند (نه مشاهده‌ی اولیه یا نقطه‌های ثابت)، و فقط `title` ذخیره می‌شود، نه `key` یا `op`. دو بسته با عنوان یکسان در دو اپراتور در تاریخچه یکی می‌شوند و نمی‌توان سری زمانی هر بسته را ساخت. اگر انتخاب قیمت بین دو کاندید در دو اسکن جابه‌جا شود (مثلاً پایه/نهایی) تغییر قیمت جعلی ثبت می‌شود چون `ambig` تنها محافظ است.
    راه‌حل: ثبت `(key, op, ts, toman, gb, days)` در هر مشاهده با ریزش (فقط وقتی تغییر کرد + هر ۲۴ ساعت یک بار).

38. [severity: low] — ذخیره بدون fsync و پنجره‌ی از دست رفتن ۴ ثانیه — `Store.java:288-300`، `372`
    `FileOutputStream` بدون `getFD().sync()`؛ قطع برق می‌تواند فایل کوتاه‌شده بسازد. در حالت منفعل اگر تغییر آخر در پنجره‌ی ۴ ثانیه بعد از آخرین ذخیره بیفتد و پردازش kill شود، از دست می‌رود (flush فقط در stop/pause/unbind). راه‌حل: sync قبل از rename؛ یک Runnable با تأخیر ۴ ثانیه برای flush نهایی.

---

## ۶. بیلد، CI، انتشار

39. [severity: medium] — `minifyEnabled false` و بدون shrinkResources؛ بدون قاعده‌ی امضا/lint سفارشی — `app/build.gradle:53`
    APK انتشار بدون R8 است، یعنی کلاس‌ها/رشته‌ها (شامل نام‌های متدهای دقیق) خوانا است و حجم بیشتر است. هیچ `proguard-rules` نیست. راه‌حل: `minifyEnabled true` + `shrinkResources true` و تست smoke روی APK release؛ چون reflection ندارید ریسکش کم است.

40. [severity: medium] — نسخه‌ها ناهمگن و release notes ثابت و غلط‌اند — `app/build.gradle:26`، `.github/workflows/android-build.yml:310`، `319`، `322`، `ScanService.java:1667`
    `versionName '1.8.2'` ولی متن release و عنوان GitHub Release «1.6.5» ثابت است، `diag.txt` «1.6.8» می‌نویسد و README نشان «1.8.0» دارد. هر push روی `main` یک Release عمومی جدید می‌سازد (`if: github.ref == 'refs/heads/main'`، خط 128). راه‌حل: `versionName` را از یک منبع (gradle.properties) به CI و کد برسان و release را به tag محدود کن.

41. [severity: medium] — `versionCode` از `GITHUB_RUN_NUMBER` است؛ در ریست repo/workflow یا fork نزولی می‌شود — `.github/workflows/android-build.yml:64`، `169`، `app/build.gradle:14`
    `1000000000 + RUN_NUMBER*100 + ATTEMPT`: اگر مخزن بازسازی یا workflow تغییر نام داده شود و run_number از اول شروع شود، نصب روی نسخه‌ی قبلی (آپدیت) رد می‌شود. گارد «بزرگ‌تر از نسخه‌ی منتشرشده» (خط ~191) در CI این را در release می‌گیرد ولی فقط برای GitHub Releases، نه Bazaar. پیش‌فرض محلی (`1000000000`) کوچک‌تر از CI است.
    راه‌حل: versionCode از تعداد commit یا تاریخ UTC (`yyMMddHHmm`) بسازید.

42. [severity: low] — verify فرمی با `grep` شکننده و Lint بدون پیکربندی — `.github/workflows/android-build.yml:61`، `87`
    `grep -q "com.android.application.*8.5.2" build.gradle` با ارتقا AGP می‌شکند. `:app:lintDebug` اجرا می‌شود ولی بدون `lint.xml`/baseline و بدون فعال‌کردن قوانین accessibility. راه‌حل: حذف grepهای نسخه؛ `lint { warningsAsErrors true; abortOnError true }` پس از رفع هشدارهای موجود.

43. [severity: low] — targetSdk 34 در 2026-11 احتمالاً برای Play قدیمی است — `app/build.gradle:21-22`
    Play برای به‌روزرسانی‌ها حداقل targetSdk جدیدتر می‌خواهد (تأییدنشده: عدد دقیق زمان‌بندی 2026). ارتقا به 35/36 نیاز به edge-to-edge و بازبینی سرویس overlay دارد؛ برای Bazaar الزام جداگانه است.

---

## ۷. تست‌ها: چه چیز کم است

JUnit در Gradle فقط ۸ تست دارد (`ListEndDetector` ×3، `OpSnapshot` ×3، `ScanStrategyPolicy` ×2). تست‌های اصلی parser (حدود ۷۷ assertion در `ParserSmokeTest`) و core با `javac`+stub بیرون از Gradle اجرا می‌شوند (فقط در CI/اسکریپت). موارد زیر را در تست‌ها ندیدم (در حد اسکن و grep):

44. [severity: high] — NPE مورد ۱ و کل مسیر `fromText`: تست با leaf «۱۰ مگ ... ۵۰۰۰۰ تومان» و «از ۵ گیگ ...»؛ تست ورودی خراب برای `extractOnce` (هیچ تست «extract هرگز throw نکند» نیست).
45. [severity: high] — `Compare.run`: بدون هیچ تست مستقیم (grep در `tools/` و `app/src/test/`: صفر ارجاع). باید پوشش بدهد: bucket و حد `days`، فیلتر restricted/intl، dedupe با `sig`، میانه و `cheap`، سه metric، مقادیر ambiguous، تازگی (`fresh`)، و ترتیب پایدار `sortRanked`.
46. [severity: medium] — `Store`: بازیابی از JSON خراب/تکه‌تکه، مهاجرت `currencyKnown`، مهاجرت `why/key`، flush با خطای I/O (dirty حفظ شود)، ایزوله‌سازی همزمانی (دو thread). `ReviewQueueSmokeTest` فقط مسیر review را پوشش می‌دهد.
47. [severity: medium] — `Cfg.ops` مهاجرت `defv` (مورد ۳۵) و `Cfg.metric` مهاجرت نسخه‌ی تنظیمات.
48. [severity: medium] — Parser: اعداد فارسی/عربی با جداکننده‌ی «٬» و «٫»، «۱/۵ گیگ»، «هزار تومان» دو leaf جدا، مدت‌ها (ماه/هفته/ساعت/«۳ ماهه»/«هفتگی»)، `مگابیت` (مورد ۳۱)، ریال vs تومان، «نامحدود» و «شبانه». از لیست assertionها فقط «750 MB must convert to GB» و یک نمونه‌ی «ماهانه» مرتبط دیده شد.
49. [severity: medium] — `ScanService`: جلوگیری از stuck شدن `scanning` (مورد ۲)، stale-metrics (مورد ۳)، و زمان‌بندی `scheduleScan` با رویداد طوفانی (توابع استاتیک `eventScanDelay/coalescedScanDeadline` موجودند و قابل‌تست‌اند).
50. [severity: low] — fixtureهای نسخه‌دار هر اپراتور + ابزار `dump-replay` در CI (باز-از-قبل: «ماتریس سازگاری/Fixture»)، و تست instrumentation (باز-از-قبل).

---

## ۸. ایده‌های ارتقا و توسعه (بر پایه‌ی آنچه کد الان دارد)

51. [severity: ایده] — هشدار افت قیمت: `History.diff` و `HistoryLog.record` الان تغییر قیمت را شناسایی می‌کنند. اگر در `finishScan` پس از `Store.upsert` تغییرات منفی بیش از آستانه را برگردانید، می‌توان نشان «قیمت کم شد» روی پنجره‌ی مقایسه یا یک نوتیفیکیشن محلی (نیاز به `POST_NOTIFICATIONS` در API 33+) داد. توجه: چون اسکن فقط وقتی برنامه‌ی اپراتور باز است انجام می‌شود، هشدار پس‌زمینه‌ی واقعی ممکن نیست؛ باید «در اولین اسکن بعدی» باشد.
52. [severity: ایده] — نمودار تاریخچه‌ی قیمت: نیازمند اصلاح مورد ۳۷ (ثبت `key`+`op` و نقطه‌ی هر مشاهده). سپس یک `View` ساده‌ی Canvas (بدون وابستگی) برای هر بسته یا حداقل «کمینه‌ی قیمت/گیگ هر اپراتور در زمان».
53. [severity: ایده] — پشتیبان‌گیری/بازیابی: `allowBackup=false` و تنها خروجی CSV (فقط export). یک export/import JSON با `ACTION_CREATE_DOCUMENT/OPEN_DOCUMENT` (SAF، بدون مجوز ذخیره‌سازی) داده و تنظیمات (`ops`) را قابل‌انتقال می‌کند. مسیر فعلی در `MainActivity.save()` روی API 29+ هر بار ردیف جدید در Downloads می‌سازد.
54. [severity: ایده] — Quick Settings Tile (`TileService`، API 24 پشتیبانی می‌شود) برای «شروع اسکن آخرین اپراتور»، و ویجت صفحه‌ی خانه که `Compare.run` را نشان بدهد (بهترین قیمت/گیگ هر اپراتور). هر دو فقط داده‌ی `Store` را می‌خوانند و به سرویس دسترسی وابسته نیستند.
55. [severity: ایده] — تقویم شمسی: `Fmt.ago` و CSV (`SimpleDateFormat yyyy-MM-dd`) میلادی‌اند. `android.icu.util.PersianCalendar` از API 24 در دسترس است (بدون desugaring).
56. [severity: ایده] — onboarding: قبل از فعال‌سازی سرویس، توضیح «چه چیزی خوانده می‌شود/چه چیزی ذخیره می‌شود» + راهنمای Restricted settings (مورد ۱۹) + تست ۱‌دقیقه‌ای با یک اپراتور.
57. [severity: ایده] — اپراتورهای بیشتر: الان ۵ پکیج ثابت در `Cfg.defaults()`. اضافه‌کردن مثلاً «های‌وب/آسیاتک» نیازمند الگوی Adapter و fixture (مستند ARCHITECTURE_PLAN_FA آن را پیشنهاد می‌کند)؛ مسیر کم‌ریسک‌تر: صادرکردن «پروفایل اپراتور» (cur، سیاست قیمت، برچسب‌ها) به JSON قابل‌اشتراک.
58. [severity: ایده] — i18n و TalkBack: `strings.xml` فقط دو رشته دارد و بقیه‌ی متن در Java ثابت است؛ `contentDescription` فقط ۲ بار در `MainActivity` و صفر بار در `Popup/UI` دیده شد. انتقال به `strings.xml` (+ `values-en`) و افزودن توضیحات دسترس‌پذیری به پنجره‌ی شناور (که خودش روی سرویس دسترسی ساخته شده) منطقی است. مهاجرت به XML/Compose در حوزه‌ی طراح UI است و منطق این سند را تغییر نمی‌دهد.
59. [severity: ایده] — Android 14/15: `TYPE_ACCESSIBILITY_OVERLAY` و `dispatchGesture` همچنان کار می‌کنند ولی (۱) `startActivity` از سرویس برای بازگشت به برنامه (`ScanService.java:413-427`) تحت محدودیت‌های Background Activity Launch است؛ کد خودش فرض می‌کند پنجره‌ی overlay کافی است (تأییدنشده روی Android 14+)، (۲) edge-to-edge اجباری با targetSdk 35، (۳) `isAccessibilityTool` نباید اعلام شود (درست است که نیست).

---

## خلاصه‌ی وضعیت موارد شناخته‌شده در اسناد (هنوز باز)

- `fullNoNew` بی‌مصرف (مورد ۱۱)، انتخاب root با بزرگ‌ترین bounds (`getFullTargetRoot`، `ScanService.java:1196-1252`)، درصد پیشرفت با max (`ScanService.java:567-675`)، state machine رشته‌محور (مورد ۱۰)، نبود تست instrumentation/emulator، نبود Gradle Wrapper، فایل‌های بزرگ (`ScanService` ۱۷۰۲ خط، `Extractor` ۱۱۹۱)، نبود evidence/confidence، نبود fixture نسخه‌دار، ثابت‌های gesture، نبود `LICENSE`.
- بسته‌شده طبق اسناد و تأییدشده در کد: اتصال `ListEndDetector.observe` به حلقه (`ScanService.java:1118-1127`) و مصرف `hasLoadMoreIndicator` (`Extractor.java:341-344`)؛ فقط اشکال مورد ۳ باقی است.

</div>
