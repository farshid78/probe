# گزارش Prompt 11 — تم سازگار با Android و پس‌زمینهٔ کم‌مصرف

## خلاصهٔ تغییرات

این تغییر روی سورس Prompt 10 Accessibility اعمال شده و منطق استخراج، parser، رتبه‌بندی و ذخیره‌سازی بسته‌ها را تغییر نمی‌دهد.

### ۱. انتخاب تم

چهار حالت ظاهری در تنظیمات اضافه/یکپارچه شد:

- **خودکار (سیستم):** مقدار پیش‌فرض جدید؛ از `Configuration.uiMode` و `UI_MODE_NIGHT_MASK` پیروی می‌کند.
- **تیره:** پالت تیره، مستقل از تنظیم Android.
- **روشن:** پالت روشن، مستقل از تنظیم Android.
- **تک‌رنگ:** پالت Mono، مستقل از تنظیم Android.

در manifest برای `MainActivity` مقدار `configChanges="uiMode"` ثبت شده است. در `onConfigurationChanged` پالت، پس‌زمینه و system barها در همان Activity به‌روزرسانی می‌شوند؛ در صورت نیاز محتوای فعلی بازترسیم می‌شود و Activity صرفاً برای تغییر روز/شب recreate نمی‌شود.

### ۲. سیاست حرکت و صرفه‌جویی انرژی

- گزینهٔ «کاهش حرکت پس‌زمینه» به تنظیمات اضافه شد و preference آن در `reduceMotion` نگهداری می‌شود.
- در API 26 به بالا از `ValueAnimator.areAnimatorsEnabled()` استفاده می‌شود؛ در API 24 و 25 مقدار `Settings.Global.ANIMATOR_DURATION_SCALE` بررسی می‌شود.
- تغییر مقدار animator duration scale با `ContentObserver` دنبال می‌شود.
- رویداد Battery Saver با `ACTION_POWER_SAVE_MODE_CHANGED` دنبال می‌شود.
- برای Battery Saver، کاهش حرکت برنامه یا خاموش بودن انیمیشن‌های سیستم، loop به‌طور کامل متوقف می‌شود؛ در این نسخه به‌جای cadence کمتر، حالت ثابت انتخاب شده تا مصرف و رفتار قابل پیش‌بینی باشد.

### ۳. چرخهٔ عمر و رسم

- انیمیشن فقط زمانی اجرا می‌شود که View متصل، قابل مشاهده و متعلق به Activity در حالت resumed باشد.
- با `onPause`، detach، visibility نامرئی، window نامرئی یا فعال‌شدن سیاست کاهش حرکت، animator متوقف می‌شود.
- در `onDestroy` تمام update listenerها حذف و animator لغو می‌شود؛ View dispose‌شده دیگر شروع مجدد نمی‌شود.
- invalidate به حداکثر حدود ۳۰ بار در ثانیه محدود شده است.
- برچسب‌ها، مختصات ثابت و Typeface به فیلدهای static منتقل شده‌اند؛ ساخت shader تنها هنگام تغییر اندازه/تم رخ می‌دهد.
- مقدار فاز با `getAnimatedFraction()` خوانده می‌شود تا به‌جای unbox کردن مقدار boxed در هر frame، مسیر ساده‌تری داشته باشد.
- shader و bitmap سنگین در `onDraw` ساخته نمی‌شوند. خود رسم همچنان از Paintهای ازپیش‌ساخته‌شده و مسیرهای ثابت استفاده می‌کند.

### ۴. خوانایی و کنتراست

پس‌زمینه شبکه‌ای با opacity پایین حفظ شده و به‌عنوان حامل وضعیت استفاده نمی‌شود؛ کارت‌ها و CTA روی سطح مستقل خود قرار دارند. تست پالت موجود برای هر سه پالت روشن، تیره و تک‌رنگ اجرا شده و حداقل نسبت کنتراست بررسی‌شده ۴٫۵:۱ بوده است.

## تست‌ها

### اجراشده در محیط فعلی

موارد زیر در محیط فعلی موفق شدند:

- `tools/backdrop-instrumentation-tests/static-review.py`
- `tools/fixture-sanitizer/test.sh`
- `tools/parser-smoke-tests/run.sh`
- `tools/android-core-smoke-tests/run.sh`
- `tools/store-smoke-tests/run.sh`
- `tools/popup-overlay-smoke-tests/run.sh`
- `tools/ui-layout-smoke-tests/run.sh` شامل بررسی کنتراست پالت‌های Light/Mono/Dark
- `tools/privacy-consent-tests/test.sh`
- `tools/home-live-refresh-smoke-tests/test.py`
- parse فایل‌های Android Manifest و strings XML
- parse فایل YAML مربوط به GitHub Actions

Static Review فقط guardrail کد منبع است و جای اجرای واقعی Android را نمی‌گیرد.

### تست واقعی Android اضافه‌شده، اما در این محیط اجرا نشده

فایل `app/src/androidTest/java/app/bastehyab/AppBackdropInstrumentationTest.java` با AndroidX Test و AndroidJUnitRunner اضافه شده است. این تست‌ها روی View و ValueAnimator واقعی Android اجرا می‌شوند و موارد زیر را بررسی می‌کنند:

- توقف loop در Activity pause/resume، View hidden، window hidden و detach/attach
- خاموش‌شدن loop با Reduce Motion، Battery Saver و animator scale صفر
- دنبال‌کردن وضعیت Auto با Night Mode سیستم و تغییر پالت/system bar بدون destroy شدن Activity
- ثبت FPS واقعی draw و درصد CPU رشتهٔ اصلی در حالت متحرک و ثابت

تست عملکرد، مقدار FPS و CPU را در Logcat با تگ `BastehyabBackdropPerf` ثبت می‌کند. **هیچ عدد FPS/CPU در این گزارش ادعا نشده است** چون Emulator/Android SDK در محیط فعلی در دسترس نبود.

### محدودیت صریح محیط

در این محیط `adb`، `emulator`، Android SDK و Gradle CLI در دسترس نبودند. بنابراین این موارد اجرا نشده‌اند:

- `:app:lintDebug`
- `:app:testDebugUnitTest`
- `:app:assembleDebug`
- `:app:connectedDebugAndroidTest`
- اندازه‌گیری عملی FPS و CPU

Workflow داخل سورس `.github/workflows/android-build.yml` اکنون Android Emulator API 34 را نصب/راه‌اندازی کرده و `:app:connectedDebugAndroidTest` را اجرا می‌کند. نتیجهٔ واقعی این مرحله فقط پس از اجرای GitHub Actions قابل تأیید است.

## نکته دربارهٔ Workflow ریشه‌ای که ZIP را extract می‌کند

اگر از Workflow جداگانه‌ای که قبلاً فرستادی استفاده می‌کنی (Workflow ریشه‌ای که ابتدا ZIP را در `$PROJECT_DIR` extract می‌کند)، فایل workflow داخل ZIP به‌تنهایی اجرا نمی‌شود. در Workflow ریشه‌ای باید نصب SDK را این‌طور گسترش بدهی:

```bash
sdkmanager --install \
  "platform-tools" \
  "platforms;android-34" \
  "build-tools;34.0.0" \
  "emulator" \
  "system-images;android-34;google_apis;x86_64"
```

و بعد از مرحلهٔ Build Debug (یا پس از آنکه APK و test APK ساخته شدند) این مرحله را اضافه کنی:

```yaml
      - name: Run real Android backdrop instrumentation tests (API 34)
        shell: bash
        run: |
          set -euo pipefail
          cd "$PROJECT_DIR"
          echo "no" | avdmanager create avd --force --name bastehyab-api34 \
            --package "system-images;android-34;google_apis;x86_64" --device "pixel_2"
          emulator -avd bastehyab-api34 -no-window -no-audio -no-boot-anim \
            -no-snapshot -wipe-data -gpu swiftshader_indirect -memory 2048 \
            > "$RUNNER_TEMP/bastehyab-emulator.log" 2>&1 &
          EMULATOR_PID=$!
          trap 'adb emu kill >/dev/null 2>&1 || true; kill "$EMULATOR_PID" >/dev/null 2>&1 || true' EXIT
          adb wait-for-device
          booted=0
          for attempt in $(seq 1 180); do
            state="$(adb shell getprop sys.boot_completed 2>/dev/null | tr -d '\r')"
            if [ "$state" = "1" ]; then booted=1; break; fi
            sleep 2
          done
          test "$booted" = "1"
          gradle --no-daemon --stacktrace :app:connectedDebugAndroidTest
          adb logcat -d -s BastehyabBackdropPerf:I
```

Workflow ریشه‌ای خودت را لازم نیست کامل بازنویسی کنی؛ نصب Emulator و اجرای instrumentation را اضافه کن. اگر ZIP تنها منبع پروژه در مخزن است، مطمئن شو ZIP جدید همچنان تنها فایل `.zip` ردیابی‌شده باشد، چون اسکریپت extraction تو دقیقاً یک ZIP انتظار دارد.

## فایل‌ها و نقاط اصلی تغییر

- `app/src/main/java/app/bastehyab/UI.java`
- `app/src/main/java/app/bastehyab/SplashViews.java`
- `app/src/main/java/app/bastehyab/MainActivity.java`
- `app/src/main/AndroidManifest.xml`
- `app/src/main/res/values/strings.xml`
- `app/src/androidTest/java/app/bastehyab/AppBackdropInstrumentationTest.java`
- `tools/backdrop-instrumentation-tests/`
- `.github/workflows/android-build.yml`
