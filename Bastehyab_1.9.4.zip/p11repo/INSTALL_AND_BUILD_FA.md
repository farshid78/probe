# راهنمای نصب، تست، ساخت و انتشار — بسته‌یاب 1.9.1

## ۱. نصب و فعال‌سازی دسترسی

1. APK را فقط از خروجی Release امضاشده و منبع مورد اعتماد دریافت کنید.
2. برنامه را اجرا کنید و توضیح کاربرد Accessibility را بخوانید.
3. سرویس بسته‌یاب را خودتان در تنظیمات Android فعال کنید.
4. از صفحهٔ خانه اپراتور موردنظر را انتخاب کنید.
5. در برنامهٔ اپراتور، خودتان به صفحهٔ بسته‌های اینترنت بروید و در پنجرهٔ شناور شروع اسکن را تأیید کنید.
6. هنگام اسکن می‌توانید نشست را مکث، ادامه یا متوقف کنید.
7. اگر فهرست به‌طور معتبر قابل اندازه‌گیری نباشد، وضعیت پایان ممکن است `UNKNOWN` بماند.

برنامه پس از تأیید کاربر صفحه را می‌خواند و به‌صورت خودکار خرید، ورود، فعال‌سازی یا پرداخت انجام نمی‌دهد.

## ۲. محیط ساخت

- JDK 17
- Android Gradle Plugin 8.13.2
- Gradle 8.13
- Android SDK Platform 36
- Android Build Tools 36.0.0
- `compileSdk=36` و `targetSdk=36`

نسخهٔ برنامه فقط از `version.properties` خوانده می‌شود:

```properties
VERSION_NAME=1.9.1
VERSION_CODE=1900000001
```

### Gradle Wrapper

`gradle/wrapper/gradle-wrapper.properties` و checksum رسمی Wrapper JAR در مخزن هستند. این محیط Gradle و شبکه ندارد؛ بنابراین JAR و `gradlew`/`gradlew.bat` جعل نشده‌اند. CI با Gradle رسمی 8.13 Wrapper را تولید، JAR را با checksum رسمی بررسی و artifact هفت‌روزهٔ `bastehyab-gradle-wrapper-8.13` را ارائه می‌کند. پس از اولین اجرای موفق، فایل‌های artifact را در مخزن commit کنید.

## ۳. ساخت Debug

پس از commit کردن Wrapper رسمی:

```bash
java -version
./gradlew --version
./gradlew clean :app:lintDebug :app:testDebugUnitTest :app:assembleDebug
```

خروجی:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## ۴. ساخت Release امضاشده

در CI، Release فقط از tag دقیق `v<VERSION_NAME>` یا اجرای دستی از `main` با approval محیط `release` ساخته می‌شود. کلید انتشار فقط در job Release از GitHub Secrets خوانده و در پایان حذف می‌شود. `minifyEnabled=false` باقی مانده و R8 تا افزودن keep rules و تست reflection/resource فعال نمی‌شود.

## ۵. versionCode و baseline فروشگاه‌ها

برای هر نسخه `VERSION_CODE` را دستی و صعودی افزایش دهید. مقدار نباید از تاریخ یا شمارهٔ run ساخته شود. در GitHub Repository Variables مقدار `PUBLISHED_VERSION_CODE_BASELINE` را برابر بزرگ‌ترین versionCode منتشرشده در Google Play و تمام فروشگاه‌های خارجی وارد کنید.

برای آزمون نصب/ارتقا در اولین انتشار GitHub، APK اصلی upload-signed را با نام `Bastehyab-Published-Baseline.apk` به یک GitHub Release مرجع اضافه و متغیر `PUBLISHED_BASELINE_RELEASE_TAG` را تنظیم کنید. APK باید همان upload certificate نسخهٔ جدید را داشته باشد. در Play App Signing ممکن است APK دریافت‌شده از Play با کلید دیگری re-sign شده باشد؛ در این حالت از artifact upload-signed اصلی برای آزمون sideload استفاده کنید و به‌روزرسانی واقعی از مسیر Play internal track را جداگانه تست کنید.

## ۶. رفتار Android 15/16

- target 35: edge-to-edge اجباری می‌شود و Window Insets باید رعایت شوند.
- target 36: opt-out از edge-to-edge غیرفعال و predictive back فعال است؛ مسیر قدیمی `onBackPressed`/`KEYCODE_BACK` قابل اتکا نیست.
- روی نمایشگرهای `sw600dp` محدودیت orientation و aspect ratio نادیده گرفته می‌شود؛ landscape و multi-window باید بررسی شوند.
- Activity فعلی رنگ system bar را مستقیماً تنظیم می‌کند و مسیر عمومی WindowInsets در آن مشاهده نشد؛ آزمون بصری API 35/36 هنوز لازم است.

## ۷. آزمون‌ها

CI این موارد را اجرا می‌کند:

- smoke testهای Parser، Store، Popup، UI و Accessibility.
- `:app:lintDebug`، `:app:testDebugUnitTest` و `:app:assembleDebug`.
- AndroidX Instrumentation روی Emulator API 36.
- در job انتشار: `:app:assembleRelease`، اعتبارسنجی signature/zipalign/package/version و install/upgrade در صورت وجود APK مرجع.

## ۸. وضعیت این تحویل

در محیط تدوین، تست‌های ایستای metadata، استخراج release notes، YAML و `bash -n` برای 19 بلوک workflow موفق شدند. Gradle، Android SDK و adb موجود نبودند؛ بنابراین APK، Lint، JUnit Gradle، Emulator و نصب/ارتقای واقعی اجرا نشده‌اند. جزئیات در `Bastehyab_1.9.1_Prompt12_ReleasePipeline_Report_FA.md` است.
