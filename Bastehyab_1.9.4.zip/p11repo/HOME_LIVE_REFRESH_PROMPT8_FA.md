# گزارش فنی Prompt 8 — به‌روزرسانی زندهٔ Home بدون بازسازی UI

## مبنا و دامنه

این تغییر روی خروجی Prompt 7 (هویت پایدار بسته‌ها) اعمال شده است. ظاهر Cyber Soft UI، ساختار XML/Java فعلی و سه تب حفظ شده‌اند؛ Compose یا کتابخانهٔ جدیدی اضافه نشده است. دامنهٔ تغییر به `MainActivity`، مسیرهای لازم `Compare`، `Popup` و `ScanService`، و تست‌های رگرسیون محدود است.

## تغییرات اصلی

### ۱. Home پایدار و field-level refresh

- چرخهٔ `liveRefresh` دیگر `render()` را فراخوانی نمی‌کند؛ در نتیجه در هر تیک `body.removeAllViews()`، ساخت مجدد `ScrollView`، ساخت مجدد bottom navigation و rebind کل Home انجام نمی‌شود.
- referenceهای Viewهای متغیر در `HomeLiveViews` نگهداری می‌شوند. `updateHomeScanUi()` فقط متن وضعیت، رنگ/برچسب وضعیت، شمارنده‌ها، progress و زمان آخرین به‌روزرسانی را روی Viewهای موجود تغییر می‌دهد.
- متن با `setTextIfChanged` به‌روزرسانی می‌شود و مقدار progress فقط در صورت تغییر تنظیم می‌شود. View زمان آخرین به‌روزرسانی focusable نیست و از اعلان‌های دسترس‌پذیری حذف شده تا تغییر زمان، TalkBack focus را مزاحم نشود.
- آمار و بهترین پیشنهاد فقط پس از تغییر نسخهٔ Store به‌روزرسانی می‌شوند؛ در هر تیک ۱۵۰۰ میلی‌ثانیه‌ای مقایسهٔ سنگین تکرار نمی‌شود.

### ۲. Snapshot و رتبه‌بندی در background

- `Store.snapshotState()` یک snapshot جداشده به همراه version همان لحظه می‌دهد.
- `Compare.run(Context, List<Pkg>, Set<String>)` امکان رتبه‌بندی روی snapshot آماده را فراهم می‌کند.
- دریافت snapshot و اجرای `Compare.run` برای Home و تب مقایسه روی executor تک‌ریسمانهٔ `Bastehyab-UiData` انجام می‌شود؛ فقط اعمال نتیجه به Viewها روی main thread است.
- مسیرهای دیگری که از UI می‌توانستند مقایسهٔ سنگین اجرا کنند نیز اصلاح شدند: انتخاب اپراتور در پنجرهٔ شناور و «آزمایش پنجرهٔ شناور» در تنظیمات. این کارها اکنون روی worker انجام می‌شوند. مسیر مقایسهٔ داخل worker اسکن از قبل background بود.
- خروجی CSV نیز snapshot و آماده‌سازی فایل را روی executor انجام می‌دهد.

### ۳. Diff فهرست مقایسه

- تب مقایسه یک ساختار ثابت برای summary، empty state و container فهرست می‌سازد.
- ردیف‌ها با `Pkg.key` نگاشت می‌شوند. ردیف‌های بدون تغییر reuse می‌شوند؛ فقط ردیف‌های جدید، حذف‌شده، جابه‌جاشده یا دارای signature متفاوت در `compareResultsList` دست‌کاری می‌شوند.
- سقف نمایشی ۸۰ ردیف حفظ شده تا حجم View tree کنترل شود.

### ۴. Lifecycle و حالت‌های قابل مشاهده

- ticker فقط وقتی Home واقعاً صفحهٔ فعال Activity است و اسکن در حالت full است زمان‌بندی می‌شود.
- `onPause`، `onStop`، `onDestroy`، تغییر تب و نامرئی‌شدن Home callback را متوقف می‌کنند. guard مستقل از زمان‌بندی مجدد، callback تکراری را مسدود می‌کند.
- بازگشت به Home همان View tree، scroll و focus را نگه می‌دارد؛ بازگشت به Settings هم دیگر فرم را از نو نمی‌سازد و ورودی‌های در حال ویرایش/dialogها را بی‌دلیل از بین نمی‌برد.
- وضعیت‌ها در Home با برچسب‌های روشن نمایش داده می‌شوند: دسترسی خاموش، رضایت لازم، مکث، در انتظار اتصال/تأیید، در حال اجرا، خطا، بدون داده و کامل‌شدن.
- هنگام نابودی/قطع سرویس، worker رتبه‌بندی پنجرهٔ شناور shutdown می‌شود و callbackهای منقضی‌شده اجازهٔ نمایش پنجرهٔ قدیمی را ندارند.

## بررسی کارایی: آنچه واقعاً اندازه‌گیری شد

| شاخص ساختاری | قبل | بعد |
|---|---:|---:|
| تعداد تیک در ۵ دقیقه با فاصلهٔ ۱۵۰۰ms | ۲۰۰ | ۲۰۰ |
| بازسازی ریشهٔ Home از مسیر ticker | تا ۲۰۰ بار | ۰ |
| فراخوانی `render()` از `liveRefresh` | ۱ در هر تیک | ۰ |
| تغییر childهای Home در مسیر ticker | بازسازی کامل صفحه | ۰ تغییر ساختاری؛ فقط propertyهای Viewهای موجود |
| رتبه‌بندی سنگین در main thread از مسیرهای اصلاح‌شده | وجود داشت | به worker منتقل شد |

این شمارش از آزمون ساختاری و بررسی مسیرهای کد به دست آمده است، نه از اجرای واقعی پنج‌دقیقه‌ای روی گوشی. در این محیط Android SDK، Gradle، ADB یا emulator در دسترس نبود؛ بنابراین عدد واقعی CPU، میانگین/p95 زمان فریم، jank و مصرف باتری را نمی‌توان صادقانه گزارش کرد.

برای اندازه‌گیری روی دستگاه، نشانگرهای Perfetto/Android Trace زیر در کد ثبت شده‌اند:

- `BY.Home.LiveRefresh`
- `BY.Home.SnapshotCompare`
- `BY.Compare.SnapshotRank`

با اجرای پنج‌دقیقه‌ای روی همان دستگاه/نسخهٔ Android، می‌توان زمان این بخش‌ها و Frame timeline را در Android Studio Profiler یا Perfetto مقایسه کرد. این گزارش ادعای بهبود عددی CPU یا frame time ندارد؛ تنها حذف بازسازی‌های دوره‌ای و انتقال محاسبه از main thread را با تست ساختاری تأیید می‌کند.

## آزمون‌ها

همهٔ تست‌های زیر در محیط موجود PASS شدند:

- `tools/home-live-refresh-smoke-tests/test.py`: شبیه‌سازی ساختاری ۲۰۰ تیک / پنج دقیقه، عدم فراخوانی `render()` و `removeAllViews` در ticker، به‌روزرسانی field-level، snapshot/background ranking، diff ردیف‌ها، lifecycle، worker پنجرهٔ شناور و مسیر آزمایش پنجره.
- `tools/parser-smoke-tests/run.sh`
- `tools/store-smoke-tests/run.sh` شامل migration، deep copy، خطاهای atomic write، raceهای Store، identity و benchmarkهای JVM
- `tools/android-core-smoke-tests/run.sh`
- `tools/popup-overlay-smoke-tests/run.sh`
- `tools/ui-layout-smoke-tests/run.sh`
- `tools/fixture-sanitizer/test.sh`
- `tools/android-core-smoke-tests/check-accessibility-api.sh`

Build کامل Gradle، تست instrumentation روی Android، بررسی واقعی TalkBack/focus/scroll و پروفایل CPU/frame روی دستگاه اجرا نشده‌اند. این‌ها برای تأیید نهایی پذیرش UX باید روی دستگاه انجام شوند.
