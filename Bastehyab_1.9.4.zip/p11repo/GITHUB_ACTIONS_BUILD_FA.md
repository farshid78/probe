# راهنمای CI و انتشار بسته‌یاب 1.9.1

Workflow در `.github/workflows/android-build.yml` دو job جدا دارد.

## CI عادی — `build-test`

- روی push تمام branchها و tagهای `v*` اجرا می‌شود؛ `workflow_dispatch` نیز فقط برای اعتبارسنجی از `main` پذیرفته می‌شود.
- فقط `contents: read` دارد و هیچ signing secret دریافت نمی‌کند.
- JDK 17، Gradle رسمی 8.13، AGP 8.13.2 و Android SDK 36 را آماده می‌کند.
- در نبود Wrapper کامل، task رسمی Gradle Wrapper را اجرا و checksum رسمی JAR را کنترل می‌کند؛ artifact هفت‌روزهٔ `bastehyab-gradle-wrapper-8.13` برای commit دستی فایل‌های Wrapper تولید می‌شود.
- smoke testها، Android Lint، `testDebugUnitTest`، `assembleDebug` و AndroidX Instrumentation روی Emulator API 36 را اجرا می‌کند.
- Debug APK و SHA-256 را به‌صورت artifact موقت بارگذاری می‌کند.

## انتشار — `release`

- فقط برای tag دقیق `v<VERSION_NAME>` یا `workflow_dispatch` از `main` اجرا می‌شود.
- از GitHub Environment با نام `release` استفاده می‌کند؛ Required reviewers باید در تنظیمات Environment فعال شوند.
- مجوز `contents: write` فقط در همین job وجود دارد.
- versionCode ثابت و کانونی را با baseline همهٔ فروشگاه‌ها و APK انتشار قبلی مقایسه می‌کند.
- `assembleRelease` را با keystore انتشار اجرا می‌کند؛ `apksigner`، `zipalign`، package ID، versionName و versionCode بررسی می‌شوند.
- گواهی امضا و نصب/ارتقا با نسخهٔ قبلی upload-signed روی Emulator API 36 بررسی می‌شوند.
- Release notes را از بخش همان نسخه در `CHANGELOG.md` استخراج می‌کند.
- APK، SHA-256، fingerprint گواهی و Release notes را منتشر می‌کند؛ tag یا Release موجود بازنویسی نمی‌شود.

## نسخه‌بندی

منبع یگانهٔ نسخه `version.properties` است. در نسخهٔ آمادهٔ این تغییر:

```properties
VERSION_NAME=1.9.1
VERSION_CODE=1900000001
```

برای هر انتشار `VERSION_CODE` باید به‌صورت دستی از مقدار قبلی بزرگ‌تر شود؛ شمارهٔ run یا تاریخ برای ساخت آن استفاده نمی‌شود. در GitHub Repository Variables مقدار `PUBLISHED_VERSION_CODE_BASELINE` را برابر بزرگ‌ترین versionCode منتشرشده در Play Console و همهٔ فروشگاه‌های خارجی وارد کنید.

برای import کردن APK مرجع، یک GitHub Release با tag دلخواه بسازید، APK اصلی upload-signed را با نام `Bastehyab-Published-Baseline.apk` به آن اضافه کنید و `PUBLISHED_BASELINE_RELEASE_TAG` را برابر tag قرار دهید. APK باید package ID درست، versionCode برابر baseline و همان upload certificate مورد استفاده برای ساخت Release داشته باشد. اگر Play App Signing فعال است، APK دانلودشده از Play ممکن است با کلید گوگل امضا شده باشد؛ برای آزمون sideload upgrade باید artifact اصلی upload-signed را وارد کنید.

## Secrets

| نام | مقدار |
|---|---|
| `ANDROID_KEYSTORE_BASE64` | محتوای Base64 فایل JKS |
| `KEYSTORE_PASSWORD` | رمز keystore |
| `KEY_ALIAS` | alias کلید |
| `KEY_PASSWORD` | رمز کلید |

این چهار secret فقط در job انتشار در دسترس‌اند. هیچ‌کدام نباید در مخزن، log یا artifact قرار گیرند.

## تنظیمات مخزن

1. GitHub Settings → Environments → `release` → Required reviewers.
2. GitHub Settings → Secrets and variables → Actions → Variables: `PUBLISHED_VERSION_CODE_BASELINE` و در صورت نیاز `PUBLISHED_BASELINE_RELEASE_TAG`.
3. Secrets چهارگانهٔ امضا را در همان بخش اضافه کنید.
4. Immutable releases را در تنظیمات مخزن فعال کنید.
5. `.github/dependabot.yml` و SHA pinning actionها حفظ شده‌اند.

## محدودیت‌ها

این محیط Gradle و Android SDK ندارد؛ بنابراین Gradle Wrapper task، Lint، JUnit Gradle، assembleDebug/Release، Emulator و آزمون install/upgrade اجرا نشده‌اند. JAR و اسکریپت‌های Wrapper جعل نشده‌اند؛ پس از اولین CI موفق، artifact Wrapper را دریافت و فایل‌های آن را در مخزن commit کنید. R8/minify نیز عمداً خاموش مانده تا keep rules و آزمون reflection/resource جداگانه اضافه شوند.
