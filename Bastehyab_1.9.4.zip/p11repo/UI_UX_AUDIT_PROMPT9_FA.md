# گزارش ممیزی و اصلاح UI/UX — Prompt 9

## دامنه و تصمیم اجرایی

- مبنا: سورس `Bastehyab_1.9.0_Prompt8_HomeLive.zip`.
- دامنهٔ کد: `MainActivity.java`، `UI.java` و تنظیم کوچک متن کنترل‌های پنجرهٔ شناور در `Popup.java`؛ بدون Compose و بدون کتابخانهٔ جدید.
- زبان بصری Cyber Soft UI، سه حالت dark/light/mono، فونت‌های Noto Sans Arabic، navigation سه‌تب و قابلیت‌های موجود حفظ شدند.
- هدف، افزایش وضوح اطلاعات و رفتار responsive بود؛ نه بازطراحی کامل برند.

## جدول ممیزی صفحه‌به‌صفحه

| صفحه / بخش | مشکل مشاهده‌شده در سورس مبنا | شدت | اصلاح اعمال‌شده |
|---|---|---:|---|
| Home — هویت صفحه | برچسب فنی monospace در ابتدای Hero بیش از نیاز تزئینی بود | کم | به برچسب فارسی سادهٔ «پردازش محلی و آفلاین» تبدیل شد؛ عنوان و توضیح برند حفظ شدند |
| Home — دسترسی | وضعیت دسترسی و رضایت متن داشت، اما رنگ وضعیت دسترسی خاموش مانند خطا نمایش داده می‌شد | متوسط | خاموش/نیازمند رضایت با Warning، فعال با Success؛ متن وضعیت هم‌رنگ معنایی شد |
| Home — اسکن | وضعیت‌های در انتظار/اجرا، موفق، مکث و خطا از نظر رنگ کاملاً معنایی نبودند | متوسط | Waiting/Running با Info، Paused/Disabled با Warning، Complete با Success، Error با Danger، No data با Muted |
| Home — CTA | دکمهٔ پیشنهاد برتر نیز primary fill داشت و با CTA رضایت/دسترسی رقابت می‌کرد | متوسط | CTA رضایت/دسترسی تنها دکمهٔ پررنگ اصلی ماند؛ مشاهدهٔ رتبه‌بندی secondary شد؛ دکمه‌های اپراتورها secondary باقی ماندند |
| Home — آمار | captionهای آماری تک‌خطی و ellipsize می‌شدند | متوسط | امکان دو خط و تراز وسط؛ حداقل اندازهٔ متن مشترک افزایش یافت |
| Compare — عنوان بسته | عنوان به دو خط محدود و انتهای آن ellipsize می‌شد | زیاد | عنوان کامل بدون ellipsize نمایش داده می‌شود؛ اطلاعات حجم و اعتبار به ردیف‌های مستقل منتقل شد |
| Compare — مشخصات | حجم، مدت، نوع بسته و برچسب ویژه/بین‌الملل به‌صورت جداگانه قابل اسکن نبودند | زیاد | حجم، اعتبار و نوع بسته ردیف مستقل؛ برچسب محدود/ویژه، بین‌الملل/رومینگ و تخفیف از هم تفکیک شدند |
| Compare — قیمت | قیمت نهایی و هزینهٔ هر گیگ در دو ستون فشرده می‌شدند؛ واحد هزینهٔ هر گیگ حذف شده بود | زیاد | دو بلوک عمودی و واضح؛ قیمت نهایی و هزینهٔ هر گیگ با واحد فعال نمایش داده می‌شوند |
| Compare — عرض کم | Header و chip شمارنده می‌توانستند در عرض کم کنار هم فشرده شوند | متوسط | در عرض کمتر از ۳۸۰dp یا fontScale بزرگ، Header عمودی می‌شود؛ flagها نیز به‌جای ردیف افقی در ستون قرار می‌گیرند |
| Compare — دسترس‌پذیری | کارت نتیجه اطلاعات معنایی کافی برای TalkBack نداشت | متوسط | contentDescription شامل رتبه، اپراتور، حجم، اعتبار و قیمت؛ کارت focusable شد |
| Settings — hierarchy | برچسب‌های تکراری `CONFIG` و عنوان‌های monospace بر گروه‌ها غلبه می‌کردند | کم | eyebrow ساده و فارسی/خوانا؛ گروه‌بندی موجود حفظ شد |
| Settings — اپراتورها | لوگو، نام، فهرست package و دو کنترل در یک ردیف افقی شلوغ بودند | زیاد | نام/پکیج در بخش اصلی و دکمه/سوئیچ در ردیف کنترلی جدا؛ شناسه‌های package با BidiFormatter در قطعهٔ LTR محصور شدند |
| Settings — حذف اپراتور | حذف اپراتور سفارشی و داده‌های مربوط به آن بدون تأیید صریح انجام می‌شد | زیاد | Dialog تأیید با شرح پیامد و پیام موفقیت پس از حذف اضافه شد |
| Dialog — متن | متن بلند می‌توانست ارتفاع پنجره را بیش از فضای مفید صفحه افزایش دهد | زیاد | ScrollView محدودشونده به ارتفاع پویا (۵۶٪ ارتفاع صفحه، سقف ۴۸۰dp و کف ۱۴۰dp) با رعایت محدودیت parent/keyboard |
| Dialog — دکمه‌ها | دکمه‌ها همیشه افقی بودند و در صفحهٔ کوچک/fontScale بالا جا نمی‌شدند | زیاد | در عرض کمتر از ۴۰۰dp، fontScale حداقل ۱٫۱۵ یا سه دکمه و بیشتر، چیدمان عمودی و تمام‌عرض |
| Soft UI | glow پررنگ روی دکمهٔ اصلی و خط تزئینی گرادیانی در heading مرزها را کم‌رنگ می‌کرد | متوسط | glow اصلی حذف شد؛ border/hairline باقی ماند؛ خط heading ساده و باریک شد؛ primary همچنان fill و کنتراست کافی دارد |
| Typography | حداقل متن مشترک ۱۰٫۵sp بود و بعضی متن‌های بدنه در اندازهٔ کوچک ناخوانا می‌شدند | زیاد | حداقل `UI.tv` به ۱۲sp، فاصلهٔ خطوط بیشتر؛ دکمه‌ها ۱۴sp، inputها ۱۴sp، قیمت و مشخصات مهم ۱۴–۱۶sp؛ اندازه‌ها همچنان sp هستند و fontScale سیستم را می‌پذیرند |
| RTL / عدد و شناسه | نام package لاتین در متن ترکیبی فارسی ممکن بود ترتیب bidi را به‌هم بزند | متوسط | package nameها با `BidiFormatter.unicodeWrap` جداگانه LTR می‌شوند؛ متن اطراف RTL می‌ماند؛ قیمت‌ها با واحد فارسی حفظ شدند |

## Design token specification

همهٔ paletteها در یک نقطه (`UI.applyTheme`) تعریف می‌شوند. مقادیر زیر ARGB هستند؛ semantic tokenها در هر theme یک معنی ثابت دارند.

| Token | Dark Cyber | Light | Mono | کاربرد |
|---|---|---|---|---|
| BG | `#111526` | `#E6E8F7` | `#14161A` | پس‌زمینهٔ صفحه |
| CARD | `#161B2E` | `#E9EBFA` | `#181B20` | سطح کارت |
| CARD2 | `#1C2238` | `#DDE0F3` | `#1F2329` | سطح ثانویه / کنترل |
| INSET | `#0D1020` | `#D9DCF0` | `#0F1114` | سطح فرورفته |
| STROKE | `#2B3456` | `#C9CDE8` | `#343A43` | مرز و hairline |
| TEXT | `#EEF1FF` | `#1B1F3A` | `#F1F3F6` | متن اصلی |
| MUTED | `#9AA3C7` | `#566086` | `#9AA2AD` | متن ثانویه |
| PRIMARY | `#A58CFF` | `#5B3BE0` | `#D0D6E0` | اقدام اصلی/انتخاب |
| ACCENT | `#2BE4F5` | `#08708A` | `#8FB4C9` | داده/تأکید بصری |
| SUCCESS | `#2EF2A5` | `#097049` | `#7ED3B2` | موفق/تکمیل |
| WARN | `#FFB84D` | `#9A5A00` | `#E0B96A` | مکث/نیاز به توجه/دسترسی خاموش |
| DANGER | `#FF6B86` | `#C22F52` | `#E58B91` | خطا/حذف/محدودیت |
| INFO | `#6E9BFF` | `#2865C7` | `#9DB8C9` | در حال اجرا/انتظار/بین‌الملل |
| G1 / G2 | `#5E3BF2` / `#7B4DFF` | `#5E3BF2` / `#7B4DFF` | `#565D68` / `#6B737F` | gradient دکمهٔ primary |

- رنگ اپراتور از `Op.color` همان اپراتور می‌آید و به‌عنوان رنگ معنایی success/warning/danger استفاده نمی‌شود.
- در Mono، semantic tokenها حفظ می‌شوند؛ accentهای صرفاً تزئینی به ramp خاکستری نگاشت می‌شوند.
- تست کنتراست برای TEXT، MUTED، PRIMARY، ACCENT، SUCCESS، WARN، DANGER و INFO روی CARD و متن سفید روی هر دو سر gradient دکمه اجرا شد؛ حداقل ۴٫۵:۱ پاس شد.
- Glow دکمهٔ اصلی حذف شد؛ primary با gradient پر، متن سفید، حالت pressed و border مشخص می‌شود. elevation سیستمی اضافه نشده است.

## قواعد تایپوگرافی و چیدمان

- `UI.tv`: حداقل ۱۲sp و lineSpacing برابر ۴dp با multiplier برابر ۱٫۱۶؛ Noto Sans Arabic حفظ شده است.
- دکمه‌ها ۱۴sp، inputها ۱۴sp؛ قیمت نهایی و مقادیر اصلی ۱۴ تا ۱۶sp.
- `sp` استفاده می‌شود، بنابراین fontScale سیستم نادیده گرفته نمی‌شود.
- Breakpoint صفحهٔ compact: عرض کمتر از ۳۸۰dp یا fontScale حداقل ۱٫۲.
- Dialog: عرض حداکثر ۴۴۰dp و حاشیهٔ افقی ۱۲dp؛ actionها زیر ۴۰۰dp یا fontScale حداقل ۱٫۱۵ عمودی می‌شوند.
- شناسه‌های package در قطعهٔ LTR محصورند؛ جهت پاراگراف فارسی RTL باقی می‌ماند.

## تست‌ها و اعتبارسنجی

موفق:
- parser smoke tests
- android-core smoke tests و ListEndDetector
- Store smoke tests و benchmarkهای موجود
- backdrop smoke test
- fixture sanitizer
- popup overlay smoke test (با به‌روزرسانی stubهای اندازه‌گیری ScrollView)
- privacy/consent smoke tests
- UI layout / palette contrast / RTL static checks
- Accessibility API compatibility
- `git diff --check`

محدودیت:
- Gradle، Gradle wrapper، Android SDK، `adb` و `emulator` در محیط اجرا موجود نیستند؛ بنابراین Android APK build و اجرای Activity روی emulator انجام نشده است.
- مطابق درخواست، NeuPreview برای جایگزینی screenshot واقعی استفاده نشده است.
- screenshot قبل/بعد از Activity در این تحویل وجود ندارد. گرفتن screenshot واقعی dark/light/mono و آزمون عرض ۳۲۰dp، tablet، landscape و fontScale بالا به محیط emulator متصل نیاز دارد.
- harness پنجرهٔ شناور، UI.java و Popup.java را با test doubles کامپایل می‌کند؛ `MainActivity` در این محیط Android SDK کامل برای compile ندارد.

## فایل‌های تغییر یافته

- `app/src/main/java/app/bastehyab/UI.java`
- `app/src/main/java/app/bastehyab/MainActivity.java`
- `app/src/main/java/app/bastehyab/Popup.java`
- تست‌ها و stubهای `tools/ui-layout-smoke-tests`، `tools/popup-overlay-smoke-tests` و `tools/backdrop-smoke-tests`

هیچ dependency جدیدی اضافه نشده و هیچ قابلیت اسکن، مقایسه، فیلتر، بازبینی یا خروجی حذف نشده است.
