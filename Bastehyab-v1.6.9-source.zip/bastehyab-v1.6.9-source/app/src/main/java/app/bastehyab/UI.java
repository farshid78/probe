package app.bastehyab;

import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.content.res.ColorStateList;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

final class UI {
    // Higher-contrast midnight palette: calm surfaces, one clear primary action and restrained accents.
    static final int BG = 0xFF07101F, CARD = 0xFF11213A, CARD2 = 0xFF1B3150, STROKE = 0xFF3A557A,
            PRIMARY = 0xFF4AD9EA, ACCENT = 0xFFB39BFF, TEXT = 0xFFF7FAFF, MUTED = 0xFFB3C1D7,
            DANGER = 0xFFFF829A, BLUE = 0xFF72A8FF;

    static int dp(Context c, float v) { return Math.round(v * c.getResources().getDisplayMetrics().density); }

    static int sz(Context c, int v) { return v > 0 ? dp(c, v) : v; }

    static GradientDrawable rr(Context c, int fill, float r) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(c, r));
        return g;
    }

    static GradientDrawable rr(Context c, int fill, float r, int stroke) {
        GradientDrawable g = rr(c, fill, r);
        g.setStroke(dp(c, 1), stroke);
        return g;
    }

    static GradientDrawable grad(Context c, int a, int b, float r) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{a, b});
        g.setCornerRadius(dp(c, r));
        return g;
    }

    static int tint(int color) { return (color & 0x00FFFFFF) | 0x33000000; }

    static TextView tv(Context c, String s, float sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setTextDirection(View.TEXT_DIRECTION_RTL);
        // TextAlignment.GRAVITY makes CENTER/START work consistently for RTL Persian text.
        t.setGravity(Gravity.TOP | Gravity.START);
        t.setTextAlignment(View.TEXT_ALIGNMENT_GRAVITY);
        return t;
    }

    static LinearLayout vbox(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        return l;
    }

    static LinearLayout hbox(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    // sizes: >0 dp, or MATCH_PARENT(-1)/WRAP_CONTENT(-2); margins in dp (start, top, end, bottom)
    static LinearLayout.LayoutParams lp(Context c, int w, int h, float s, float t, float e, float b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(sz(c, w), sz(c, h));
        p.setMargins(0, dp(c, t), 0, dp(c, b));
        p.setMarginStart(dp(c, s));
        p.setMarginEnd(dp(c, e));
        return p;
    }

    static LinearLayout.LayoutParams lp2(Context c, float start) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        p.setMarginStart(dp(c, start));
        return p;
    }

    static LinearLayout.LayoutParams lpw(float weight) {
        return new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, weight);
    }

    static LinearLayout card(Context c) {
        LinearLayout l = vbox(c);
        int p = dp(c, 16);
        l.setPadding(p, p, p, p);
        GradientDrawable panel = grad(c, 0xF0192D49, 0xF0101F37, 18);
        panel.setStroke(dp(c, 1), 0x99516C91);
        l.setBackground(panel);
        l.setClipToOutline(true);
        l.setElevation(dp(c, 2));
        return l;
    }

    static TextView chip(Context c, String s, int bg, int fg) {
        TextView t = tv(c, s, 11, fg, true);
        t.setPadding(dp(c, 9), dp(c, 5), dp(c, 9), dp(c, 5));
        t.setGravity(Gravity.CENTER);
        t.setBackground(rr(c, bg, 10));
        return t;
    }

    static Button btn(Context c, String s, int bg, int fg, View.OnClickListener l) {
        Button b = new Button(c);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextColor(fg);
        b.setTextSize(12.5f);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        GradientDrawable shape = bg == PRIMARY
                ? grad(c, 0xFF4AD9EA, 0xFF6B84F5, 13)
                : grad(c, 0xFF28415F, 0xFF182B47, 13);
        shape.setStroke(dp(c, 1), bg == PRIMARY ? 0xCC9AF0FA : 0xAA587396);
        b.setBackground(new RippleDrawable(ColorStateList.valueOf(0x24FFFFFF), shape, rr(c, 0xFFFFFFFF, 13)));
        b.setStateListAnimator(null);
        b.setMinHeight(dp(c, 44));
        b.setMinimumHeight(dp(c, 44));
        b.setGravity(Gravity.CENTER);
        b.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        b.setTextDirection(View.TEXT_DIRECTION_RTL);
        b.setPadding(dp(c, 12), dp(c, 8), dp(c, 12), dp(c, 8));
        b.setOnClickListener(l);
        return b;
    }
}
