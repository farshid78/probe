package app.bastehyab;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapShader;
import android.graphics.Matrix;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.view.View;

/** Custom drawing for the opening / creator screen. Purely visual; no touch handling. */
final class SplashViews {
    private SplashViews() { }

    static float dp(View v, float value) {
        return value * v.getResources().getDisplayMetrics().density;
    }

    /** Deep cyber-network backdrop: fine grid, connected nodes and restrained data glows. */
    static final class Backdrop extends View {
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint grid = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint links = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint nodes = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint rings = new Paint(Paint.ANTI_ALIAS_FLAG);

        private final float[][] points = {
                {0.06f,0.19f},{0.18f,0.10f},{0.31f,0.20f},{0.46f,0.08f},{0.61f,0.18f},
                {0.78f,0.09f},{0.93f,0.22f},{0.10f,0.43f},{0.25f,0.37f},{0.42f,0.49f},
                {0.62f,0.39f},{0.83f,0.48f},{0.96f,0.40f},{0.06f,0.69f},{0.23f,0.79f},
                {0.39f,0.67f},{0.58f,0.82f},{0.75f,0.69f},{0.93f,0.82f},{0.48f,0.94f}
        };
        private final int[][] edges = {
                {0,1},{1,2},{2,3},{3,4},{4,5},{5,6},{0,7},{7,8},{8,2},{8,9},
                {9,10},{10,4},{10,11},{11,12},{7,13},{13,14},{14,15},{15,9},{15,16},
                {16,17},{17,11},{17,18},{16,19}
        };

        Backdrop(Context c) {
            super(c);
            grid.setStyle(Paint.Style.STROKE);
            grid.setStrokeWidth(dp(this, 0.7f));
            grid.setColor(UI.light ? 0x184F829C : UI.mono ? 0x183F444B : 0x183E85A8);
            links.setStyle(Paint.Style.STROKE);
            links.setStrokeWidth(dp(this, 1.0f));
            links.setColor(UI.light ? 0x28627F92 : UI.mono ? 0x303F454D : 0x3C4D9AB5);
            nodes.setColor(UI.light ? 0x885A9FBA : UI.mono ? 0x88C9CFD7 : 0xAA79D9F4);
            rings.setStyle(Paint.Style.STROKE);
            rings.setStrokeWidth(dp(this, 1.1f));
            rings.setColor(UI.mono ? 0x224D535D : 0x224E98B8);
        }

        @Override protected void onDraw(Canvas cv) {
            float w = getWidth(), h = getHeight();
            if (w <= 0 || h <= 0) return;
            fill.setShader(new LinearGradient(0, 0, w, h,
                    UI.light ? new int[]{0xFFF6FAFC, 0xFFEAF1F5, 0xFFE4EBF0}
                            : UI.mono ? new int[]{0xFF090A0C, 0xFF17191D, 0xFF292C32}
                            : new int[]{0xFF071827, 0xFF112538, 0xFF251B18},
                    null, Shader.TileMode.CLAMP));
            cv.drawRect(0, 0, w, h, fill);
            fill.setShader(new RadialGradient(w * 0.12f, h * 0.20f, dp(this, 310),
                    UI.light ? new int[]{0x555AAACB, 0x005AAACB}
                            : UI.mono ? new int[]{0x337D858F, 0x007D858F}
                            : new int[]{0x6658BDE8, 0x0058BDE8},
                    null, Shader.TileMode.CLAMP));
            cv.drawRect(0, 0, w, h, fill);
            fill.setShader(new RadialGradient(w * 0.92f, h * 0.84f, dp(this, 370),
                    UI.light ? new int[]{0x44C87351, 0x00C87351}
                            : UI.mono ? new int[]{0x22565D66, 0x00565D66}
                            : new int[]{0x66FF895B, 0x00FF895B},
                    null, Shader.TileMode.CLAMP));
            cv.drawRect(0, 0, w, h, fill);

            // Quiet translucent geometry gives the page depth without the old network-grid noise.
            Paint tiles = new Paint(Paint.ANTI_ALIAS_FLAG);
            tiles.setColor(UI.light ? 0x227B9CAE : UI.mono ? 0x22D0D4DA : 0x22D6EEF8);
            cv.drawRoundRect(-w*.14f, h*.07f, w*.18f, h*.21f, dp(this, 18), dp(this, 18), tiles);
            cv.drawRoundRect(w*.81f, h*.06f, w*1.06f, h*.23f, dp(this, 22), dp(this, 22), tiles);
            cv.drawRoundRect(w*.07f, h*.75f, w*.30f, h*.94f, dp(this, 20), dp(this, 20), tiles);
            cv.drawRoundRect(w*.84f, h*.81f, w*1.08f, h*1.02f, dp(this, 20), dp(this, 20), tiles);

            Paint wave = new Paint(Paint.ANTI_ALIAS_FLAG);
            wave.setStyle(Paint.Style.STROKE);
            wave.setStrokeWidth(dp(this, 1.6f));
            wave.setColor(UI.light ? 0x4472A2B5 : UI.mono ? 0x44545B65 : 0x4479D9F4);
            Path curve = new Path();
            curve.moveTo(-w*.10f, h*.89f);
            curve.cubicTo(w*.28f, h*.70f, w*.50f, h*1.02f, w*1.10f, h*.76f);
            cv.drawPath(curve, wave);
            wave.setStrokeWidth(dp(this, .9f));
            wave.setColor(UI.light ? 0x33C87351 : UI.mono ? 0x334A5058 : 0x33FF895B);
            curve.reset();
            curve.moveTo(-w*.10f, h*.94f);
            curve.cubicTo(w*.34f, h*.77f, w*.58f, h*1.06f, w*1.10f, h*.82f);
            cv.drawPath(curve, wave);
        }
    }

    /** Dark interior wallpaper for the app screens; ambient color stays behind charcoal cards. */
    static final class AppBackdrop extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        AppBackdrop(Context c) { super(c); }
        @Override protected void onDraw(Canvas cv) {
            float w = getWidth(), h = getHeight();
            if (w <= 0 || h <= 0) return;
            p.setShader(new LinearGradient(0, 0, w, h,
                    UI.light ? new int[]{0xFFF6FAFC, 0xFFEAF1F5, 0xFFE4EBF0}
                            : UI.mono ? new int[]{0xFF0D0E11, 0xFF17191D, 0xFF22252B}
                            : new int[]{0xFF0A1826, 0xFF121F2C, 0xFF211B19},
                    null, Shader.TileMode.CLAMP));
            cv.drawRect(0, 0, w, h, p);
            p.setShader(new RadialGradient(w * .12f, h * .10f, dp(this, 320),
                    UI.light ? new int[]{0x225AAACB, 0x005AAACB}
                            : UI.mono ? new int[]{0x225E6672, 0x005E6672}
                            : new int[]{0x3361C4E8, 0x0061C4E8},
                    null, Shader.TileMode.CLAMP));
            cv.drawRect(0, 0, w, h, p);
            p.setShader(new RadialGradient(w * .93f, h * .88f, dp(this, 360),
                    UI.light ? new int[]{0x22C87351, 0x00C87351}
                            : UI.mono ? new int[]{0x224C525B, 0x004C525B}
                            : new int[]{0x33FF895B, 0x00FF895B},
                    null, Shader.TileMode.CLAMP));
            cv.drawRect(0, 0, w, h, p);
            p.setShader(null);
            p.setStyle(Paint.Style.FILL);
            p.setColor(UI.light ? 0x0D7B9CAE : UI.mono ? 0x0DE1E4E8 : 0x0DE3F5FF);
            cv.drawRoundRect(-w*.12f, h*.08f, w*.13f, h*.21f, dp(this, 18), dp(this, 18), p);
            cv.drawRoundRect(w*.86f, h*.07f, w*1.08f, h*.22f, dp(this, 20), dp(this, 20), p);
            cv.drawRoundRect(w*.07f, h*.78f, w*.29f, h*.94f, dp(this, 18), dp(this, 18), p);
            cv.drawRoundRect(w*.88f, h*.80f, w*1.08f, h*.96f, dp(this, 18), dp(this, 18), p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(dp(this, 1));
            p.setColor(UI.light ? 0x226F91A1 : UI.mono ? 0x224A5059 : 0x224E91B0);
            Path path = new Path();
            path.moveTo(-w*.10f, h*.88f);
            path.cubicTo(w*.32f, h*.76f, w*.62f, h*.99f, w*1.10f, h*.82f);
            cv.drawPath(path, p);
            p.setStyle(Paint.Style.FILL);
        }
    }

    /** Original Bastehyab brand mark, shared with the launcher icon. */
    static final class BrandMark extends View {
        private final Paint imagePaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        private final Bitmap mark;
        BrandMark(Context c) {
            super(c);
            Bitmap decoded = BitmapFactory.decodeResource(c.getResources(), R.drawable.brand_mark);
            mark = decoded;
        }
        @Override protected void onDraw(Canvas c) {
            if (mark == null || getWidth() <= 0 || getHeight() <= 0) return;
            float side = Math.min(getWidth(), getHeight()) * .94f;
            android.graphics.RectF dst = new android.graphics.RectF(
                    (getWidth() - side) * .5f, (getHeight() - side) * .5f,
                    (getWidth() + side) * .5f, (getHeight() + side) * .5f);
            c.drawBitmap(mark, null, dst, imagePaint);
        }
    }

    /** Soft rounded logo halo with a ice-blue and ember edge light. */
    static final class LogoHalo extends View {
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);

        LogoHalo(Context c) {
            super(c);
            stroke.setStyle(Paint.Style.STROKE);
            stroke.setStrokeWidth(dp(this, 2));
        }

        @Override protected void onDraw(Canvas cv) {
            float w = getWidth(), h = getHeight();
            float inset = dp(this, 2);
            android.graphics.RectF bounds = new android.graphics.RectF(inset, inset, w-inset, h-inset);
            fill.setShader(new LinearGradient(0, 0, w, h,
                    UI.light ? new int[]{0x445AAACB, 0x2273A4BD}
                            : UI.mono ? new int[]{0x443F444D, 0x55252A31}
                            : new int[]{0x6679D9F4, 0x55FF895B},
                    null, Shader.TileMode.CLAMP));
            cv.drawRoundRect(bounds, dp(this, 34), dp(this, 34), fill);
            stroke.setShader(new LinearGradient(0, 0, w, h,
                    UI.mono ? new int[]{0xFFE6E9EF, 0xFF9EA6B1, 0xFFF5F6F8}
                            : new int[]{UI.ICE, UI.BLUE, UI.FIRE},
                    null, Shader.TileMode.CLAMP));
            cv.drawRoundRect(bounds, dp(this, 34), dp(this, 34), stroke);
        }

        static Path hex(float cx, float cy, float r) {
            Path p = new Path();
            for (int i = 0; i < 6; i++) {
                double a = Math.PI / 3 * i - Math.PI / 6;
                float x = (float) (cx + r * Math.cos(a));
                float y = (float) (cy + r * Math.sin(a));
                if (i == 0) p.moveTo(x, y); else p.lineTo(x, y);
            }
            p.close();
            return p;
        }
    }

    /** Accent circle with a paper-plane glyph (Telegram-style). */
    static final class PlaneIcon extends View {
        private final Paint circle = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint glyph = new Paint(Paint.ANTI_ALIAS_FLAG);

        PlaneIcon(Context c) {
            super(c);
            glyph.setColor(0xFFFFFFFF);
        }

        @Override protected void onDraw(Canvas cv) {
            float w = getWidth(), h = getHeight();
            if (w <= 0 || h <= 0) return;
            circle.setShader(new LinearGradient(0, 0, w, h,
                    new int[]{UI.PRIMARY, UI.BLUE}, null, Shader.TileMode.CLAMP));
            cv.drawCircle(w / 2f, h / 2f, Math.min(w, h) / 2f, circle);
            Path p = new Path();
            p.moveTo(w * 0.24f, h * 0.48f);
            p.lineTo(w * 0.78f, h * 0.26f);
            p.lineTo(w * 0.62f, h * 0.76f);
            p.lineTo(w * 0.47f, h * 0.60f);
            p.close();
            cv.drawPath(p, glyph);
            Path fold = new Path();
            fold.moveTo(w * 0.47f, h * 0.60f);
            fold.lineTo(w * 0.78f, h * 0.26f);
            fold.lineTo(w * 0.50f, h * 0.66f);
            fold.close();
            cv.drawPath(fold, glyph);
        }
    }

    /** Creator portrait cropped into a consistent circular frame for compact profile cards. */
    static final class PersonAvatar extends View {
        private final Paint fallback = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint photo = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        private final Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint innerRing = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Matrix shaderMatrix = new Matrix();
        private final Bitmap portrait;
        private final BitmapShader shader;

        PersonAvatar(Context c) {
            super(c);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
            Bitmap loaded;
            try {
                loaded = BitmapFactory.decodeResource(c.getResources(), R.drawable.creator_avatar);
            } catch (RuntimeException ex) {
                loaded = null;
            }
            portrait = loaded;
            shader = portrait == null ? null : new BitmapShader(portrait,
                    Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
            photo.setDither(true);
            if (shader != null) photo.setShader(shader);

            fallback.setColor(UI.light ? 0xFF397F9D : UI.mono ? 0xFF34383F : 0xFF18354A);
            glow.setColor(UI.light ? 0x225AAACB : UI.mono ? 0x224D535D : 0x2279D9F4);
            glow.setStyle(Paint.Style.FILL);
            glow.setShadowLayer(dp(this, 4), 0, 0,
                    UI.light ? 0x335AAACB : UI.mono ? 0x334D535D : 0x4479D9F4);
            ring.setStyle(Paint.Style.STROKE);
            ring.setStrokeWidth(dp(this, 2.2f));
            ring.setShader(new LinearGradient(0, 0, dp(this, 66), dp(this, 66),
                    UI.mono ? new int[]{0xFFE8EBF0, 0xFF9299A3, 0xFFF4F5F7}
                            : new int[]{UI.ICE, UI.BLUE, UI.FIRE}, null, Shader.TileMode.CLAMP));
            innerRing.setStyle(Paint.Style.STROKE);
            innerRing.setStrokeWidth(dp(this, 0.8f));
            innerRing.setColor(UI.mono ? 0x667A828E : 0x6679BBD2);
        }

        @Override protected void onDraw(Canvas cv) {
            super.onDraw(cv);
            float w = getWidth(), h = getHeight();
            if (w <= 0 || h <= 0) return;
            float cx = w * .5f, cy = h * .5f;
            float radius = Math.min(w, h) * .5f - dp(this, 4);
            if (radius <= 0) return;

            cv.drawCircle(cx, cy, radius + dp(this, 1), glow);
            if (shader != null && portrait != null) {
                float diameter = (radius - dp(this, 2)) * 2f;
                float scale = diameter / Math.min(portrait.getWidth(), portrait.getHeight());
                float left = cx - portrait.getWidth() * scale * .5f;
                float top = cy - portrait.getHeight() * scale * .5f;
                shaderMatrix.setScale(scale, scale);
                shaderMatrix.postTranslate(left, top);
                shader.setLocalMatrix(shaderMatrix);
                cv.drawCircle(cx, cy, radius - dp(this, 2), photo);
            } else {
                cv.drawCircle(cx, cy, radius - dp(this, 2), fallback);
                Paint figure = new Paint(Paint.ANTI_ALIAS_FLAG);
                figure.setColor(0xFFF0F6FF);
                cv.drawCircle(cx, cy - radius * .20f, radius * .22f, figure);
                cv.drawOval(cx - radius * .48f, cy + radius * .05f,
                        cx + radius * .48f, cy + radius * .83f, figure);
            }
            cv.drawCircle(cx, cy, radius - dp(this, 1), ring);
            cv.drawCircle(cx, cy, radius - dp(this, 4), innerRing);
            Paint status = new Paint(Paint.ANTI_ALIAS_FLAG);
            status.setColor(0xFF63DDAA);
            cv.drawCircle(cx + radius * .68f, cy + radius * .68f, dp(this, 5.5f), status);
            status.setColor(UI.mono ? 0xFF101114 : UI.light ? 0xFFFFFFFF : 0xFF0A121C);
            cv.drawCircle(cx + radius * .68f, cy + radius * .68f, dp(this, 2.2f), status);
        }
    }
}
