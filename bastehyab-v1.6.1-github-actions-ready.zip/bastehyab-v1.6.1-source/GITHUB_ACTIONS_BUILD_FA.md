# ساخت و امضای خودکار بسته‌یاب با GitHub Actions

این پروژه برای ساخت APK به Android Studio روی رایانه شما نیاز ندارد. GitHub Actions روی runner لینوکس، Java 17، Android SDK API 34 و Gradle 8.7 را نصب می‌کند و خروجی را می‌سازد.

## خروجی گردش‌کار

- با هر Push روی هر شاخه: اجرای تست‌ها و ساخت `Bastehyab-Debug.apk`
- فقط روی شاخه `main`: ساخت `Bastehyab-Release.apk` با کلید انتشار، بررسی امضا و تراز APK، ساخت فایل SHA256 و ایجاد GitHub Release
- اجرای دستی از شاخه `main`: همان خروجی Release را تولید می‌کند
- اجرای دستی از شاخه‌های دیگر: فقط تست و Debug انجام می‌دهد

## ۱. ساخت کلید انتشار (فقط یک‌بار)

این دستور به Java `keytool` نیاز دارد، نه Android Studio. روی رایانه شخصی و در پوشه‌ای امن اجرا کنید:

```bash
keytool -genkeypair -v \
  -keystore bastehyab-release.jks \
  -alias bastehyab \
  -keyalg RSA \
  -keysize 2048 \
  -validity 10000
```

رمزها را در محل امن نگهداری کنید. فایل JKS نباید وارد Git یا ZIP عمومی شود.

**اگر بسته‌یاب قبلاً با یک کلید Release در کافه‌بازار منتشر شده است، همین کلید قبلی باید استفاده شود.** ساخت کلید جدید ممکن است جلوی به‌روزرسانی نسخه نصب‌شده را بگیرد. اگر تا امروز فقط APK دیباگ ساخته‌اید و برنامه هنوز با کلید Release منتشر نشده، می‌توانید یک کلید جدید بسازید.

## ۲. تبدیل JKS به Base64 در Windows PowerShell

در همان پوشه‌ای که فایل `bastehyab-release.jks` قرار دارد اجرا کنید:

```powershell
[Convert]::ToBase64String([IO.File]::ReadAllBytes("$PWD\bastehyab-release.jks")) | Set-Clipboard
```

اکنون متن Base64 در Clipboard قرار دارد. آن را در Secret اول GitHub قرار دهید.

## ۳. تعریف چهار Secret در مخزن خصوصی

به مسیر زیر بروید:

`Repository → Settings → Secrets and variables → Actions → New repository secret`

این چهار Secret را با همین نام‌ها بسازید:

| نام Secret | مقدار |
|---|---|
| `ANDROID_KEYSTORE_BASE64` | متن Base64 فایل JKS |
| `KEYSTORE_PASSWORD` | رمز keystore |
| `KEY_ALIAS` | نام Alias؛ در دستور بالا `bastehyab` |
| `KEY_PASSWORD` | رمز کلید |

مقدارها را در Workflow یا فایل‌های پروژه ننویسید و برای کسی ارسال نکنید.

## ۴. قرار دادن Workflow

فایل زیر باید دقیقاً در این مسیر مخزن باشد:

`.github/workflows/android-build.yml`

بعد از Commit و Push، از تب **Actions** اجرای `Bastehyab Android Build and Release` را باز کنید.

## ۵. دریافت APK

در صفحه اجرای موفق Workflow، بخش **Artifacts** دو خروجی نشان می‌دهد:

- `bastehyab-debug-apk`: فقط برای آزمایش
- `bastehyab-release-signed-apk`: نسخه امضاشده برای بارگذاری در کافه‌بازار، به‌همراه SHA256

روی شاخه `main` علاوه بر Artifact، در بخش **Releases** نیز فایل `Bastehyab-Release.apk` قرار می‌گیرد. برای بازار فقط همین Release امضاشده را انتخاب کنید، نه Debug.

## ۶. انتشار نسخه‌های بعدی

پیش از هر انتشار جدید، در `app/build.gradle` مقدار `versionCode` را افزایش دهید و `versionName` را به نسخه جدید تغییر دهید. کلید و چهار Secret باید ثابت بمانند. فایل JKS را در چند محل امن و رمزگذاری‌شده پشتیبان‌گیری کنید.

## نکات مهم

- مخزن خصوصی مانع اجرای GitHub Actions نیست؛ Secrets در اجرای Workflow همان مخزن قابل استفاده‌اند.
- این Workflow APK را در GitHub می‌سازد و در GitHub Release قرار می‌دهد؛ انتشار در کافه‌بازار همچنان با بارگذاری فایل Release در پنل بازار انجام می‌شود.
- Android Studio برای ساخت APK لازم نیست؛ فقط برای ساخت کلید، Java `keytool` استفاده می‌شود.
- اگر نام شاخه اصلی مخزن `main` نیست، شرط‌های `github.ref == 'refs/heads/main'` در Workflow را به نام شاخه اصلی تغییر دهید.
