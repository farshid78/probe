package app.bastehyab;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.RippleDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Shared visual system for Bastehyab. All screens consume the same light/dark tokens. */
final class UI {
    private UI() { }

    static boolean light;
    static int BG, CARD, CARD2, STROKE, PRIMARY, ACCENT, TEXT, MUTED, DANGER, BLUE;
    static final int SUCCESS = 0xFF45C995;
    static Typeface BODY, MEDIUM, BOLD;

    static void applyTheme(Context c) {
        light = "light".equals(Cfg.sp(c).getString("appearance", "dark"));
        if (light) {
            BG = 0xFFF4F0F9; CARD = 0xFFFFFFFF; CARD2 = 0xFFF0EAF7; STROKE = 0xFFE0D7EA;
            PRIMARY = 0xFF9448D7; ACCENT = 0xFFCB58B9; TEXT = 0xFF29243B;
            MUTED = 0xFF746D84; DANGER = 0xFFD95075; BLUE = 0xFF647EE8;
        } else {
            BG = 0xFF351247; CARD = 0xFF29283A; CARD2 = 0xFF353349; STROKE = 0xFF48445F;
            PRIMARY = 0xFFB65AF2; ACCENT = 0xFFF08ADF; TEXT = 0xFFF7F2FF;
            MUTED = 0xFFB5AEC8; DANGER = 0xFFFF7F9C; BLUE = 0xFF8F9BFF;
        }
        if (BODY == null || MEDIUM == null || BOLD == null) {
            try {
                BODY = Typeface.createFromAsset(c.getAssets(), "fonts/NotoSansArabic-Regular.ttf");
                MEDIUM = Typeface.createFromAsset(c.getAssets(), "fonts/NotoSansArabic-Medium.ttf");
                BOLD = Typeface.createFromAsset(c.getAssets(), "fonts/NotoSansArabic-Bold.ttf");
            } catch (RuntimeException fontError) {
                BODY = Typeface.create("sans-serif", Typeface.NORMAL);
                MEDIUM = Typeface.create("sans-serif-medium", Typeface.NORMAL);
                BOLD = Typeface.create("sans-serif", Typeface.BOLD);
            }
        }
    }

    static int themeColor(int color) {
        int alpha = color >>> 24;
        int rgb = color & 0x00FFFFFF;
        int mapped = rgb;
        if (light) {
            switch (rgb) {
                case 0x07101F: case 0x050B15: case 0x0C1B31: case 0x091426: case 0x0B172A:
                case 0x101828: case 0x10182D: case 0x07152F: case 0x0B2348: mapped = BG; break;
                case 0x11213A: case 0x101F37: case 0x0E1A30: case 0x0E1A2D: case 0x0E1A32:
                case 0x1B2942: case 0x182D4A: case 0x172238: mapped = CARD; break;
                case 0x1B3150: case 0x28415F: case 0x182B47: case 0x263B5A: case 0x16283A:
                case 0x152D42: case 0x0C1931: case 0x1A2D4A: case 0x142642: mapped = CARD2; break;
                case 0xF7FAFF: case 0xFFFFFF: mapped = TEXT; break;
                case 0xB3C1D7: case 0xB9D5E9: case 0x8393B0: mapped = MUTED; break;
                case 0x4AD9EA: case 0x55E8FF: case 0x54E8F7: case 0x41DDF4: case 0x35D9F5:
                case 0x37DFF4: case 0x38DDF2: mapped = PRIMARY; break;
                case 0xB39BFF: case 0x9D78FF: case 0x9D7BFF: mapped = ACCENT; break;
                case 0xFF829A: case 0xFF718F: mapped = DANGER; break;
                case 0x3A557A: case 0x516C91: case 0x587396: mapped = STROKE; break;
                default: break;
            }
        } else {
            switch (rgb) {
                case 0x07101F: case 0x050B15: case 0x0C1B31: case 0x091426: case 0x0B172A:
                case 0x101828: case 0x10182D: case 0x07152F: case 0x0B2348: mapped = BG; break;
                case 0x11213A: case 0x101F37: case 0x0E1A30: case 0x0E1A2D: case 0x0E1A32:
                case 0x1B2942: case 0x182D4A: case 0x172238: mapped = CARD; break;
                case 0x1B3150: case 0x28415F: case 0x182B47: case 0x263B5A: case 0x16283A:
                case 0x152D42: case 0x0C1931: case 0x1A2D4A: case 0x142642: mapped = CARD2; break;
                case 0xF7FAFF: case 0xFFFFFF: mapped = TEXT; break;
                case 0xB3C1D7: case 0xB9D5E9: case 0x8393B0: mapped = MUTED; break;
                case 0x4AD9EA: case 0x55E8FF: case 0x54E8F7: case 0x41DDF4: case 0x35D9F5:
                case 0x37DFF4: case 0x38DDF2: mapped = PRIMARY; break;
                case 0xB39BFF: case 0x9D78FF: case 0x9D7BFF: mapped = ACCENT; break;
                case 0xFF829A: case 0xFF718F: mapped = DANGER; break;
                case 0x3A557A: case 0x516C91: case 0x587396: mapped = STROKE; break;
                default: break;
            }
        }
        return (alpha << 24) | (mapped & 0x00FFFFFF);
    }

    static void applyTypefaceTree(View view) {
        if (view instanceof TextView) {
            TextView text = (TextView) view;
            if (text instanceof Button || text instanceof android.widget.Switch) text.setTypeface(MEDIUM);
            else if (text.getTypeface() != null && text.getTypeface().isBold()) text.setTypeface(BOLD);
            else text.setTypeface(BODY);
            text.setIncludeFontPadding(false);
        }
        if (view instanceof android.view.ViewGroup) {
            android.view.ViewGroup group = (android.view.ViewGroup) view;
            for (int i = 0; i < group.getChildCount(); i++) applyTypefaceTree(group.getChildAt(i));
        }
    }

    static int dp(Context c, float v) { return Math.round(v * c.getResources().getDisplayMetrics().density); }
    static int sz(Context c, int v) { return v > 0 ? dp(c, v) : v; }

    static int surfaceColor(int color) {
        if ((color & 0x00FFFFFF) == 0x00FFFFFF || (color >>> 24) == 0) return color;
        return themeColor(color);
    }
    private static int shade(int color, float factor) {
        int a = color & 0xFF000000;
        int red = Math.max(0, Math.min(255, Math.round(((color >> 16) & 255) * factor)));
        int green = Math.max(0, Math.min(255, Math.round(((color >> 8) & 255) * factor)));
        int blue = Math.max(0, Math.min(255, Math.round((color & 255) * factor)));
        return a | (red << 16) | (green << 8) | blue;
    }
    static GradientDrawable rr(Context c, int fill, float r) {
        int resolved = surfaceColor(fill);
        GradientDrawable g;
        if ((resolved >>> 24) == 0xFF) {
            float up = light ? 1.025f : 1.11f;
            float down = light ? 0.985f : 0.91f;
            g = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                    new int[]{shade(resolved, up), shade(resolved, down)});
        } else {
            g = new GradientDrawable();
            g.setColor(resolved);
        }
        g.setCornerRadius(dp(c, r));
        return g;
    }
    static GradientDrawable rr(Context c, int fill, float r, int stroke) {
        GradientDrawable g = rr(c, fill, r); g.setStroke(dp(c, 1), surfaceColor(stroke)); return g;
    }
    static GradientDrawable grad(Context c, int a, int b, float r) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{surfaceColor(a), surfaceColor(b)}); g.setCornerRadius(dp(c, r)); return g;
    }
    static Drawable appBackground(Context c) {
        if (light) return new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{0xFFF7F2FB, 0xFFF0EAF7, 0xFFEAE3F4});
        return new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{0xFF3B174E, 0xFF21133B, 0xFF14152F});
    }
    static int tint(int color) { return (themeColor(color) & 0x00FFFFFF) | 0x22000000; }
    static int contrastText(int background) {
        double r = ((background >> 16) & 255) / 255.0;
        double g = ((background >> 8) & 255) / 255.0;
        double b = (background & 255) / 255.0;
        r = r <= 0.04045 ? r / 12.92 : Math.pow((r + 0.055) / 1.055, 2.4);
        g = g <= 0.04045 ? g / 12.92 : Math.pow((g + 0.055) / 1.055, 2.4);
        b = b <= 0.04045 ? b / 12.92 : Math.pow((b + 0.055) / 1.055, 2.4);
        double luminance = 0.2126 * r + 0.7152 * g + 0.0722 * b;
        return luminance > 0.42 ? 0xFF182338 : 0xFFFFFFFF;
    }

    static TextView tv(Context c, String s, float sp, int color, boolean bold) {
        TextView t = new TextView(c); t.setText(s); t.setTextSize(Math.max(10.5f, sp)); t.setTextColor(themeColor(color));
        t.setTypeface(bold ? BOLD : BODY);
        t.setTextDirection(View.TEXT_DIRECTION_RTL); t.setGravity(Gravity.TOP | Gravity.START);
        t.setTextAlignment(View.TEXT_ALIGNMENT_GRAVITY); t.setIncludeFontPadding(false);
        t.setLineSpacing(dp(c, 2f), 1.08f);
        return t;
    }
    static LinearLayout vbox(Context c) {
        LinearLayout l = new LinearLayout(c); l.setOrientation(LinearLayout.VERTICAL);
        l.setLayoutDirection(View.LAYOUT_DIRECTION_RTL); return l;
    }
    static LinearLayout hbox(Context c) {
        LinearLayout l = new LinearLayout(c); l.setOrientation(LinearLayout.HORIZONTAL);
        l.setLayoutDirection(View.LAYOUT_DIRECTION_RTL); l.setGravity(Gravity.CENTER_VERTICAL); return l;
    }
    static LinearLayout.LayoutParams lp(Context c, int w, int h, float s, float t, float e, float b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(sz(c, w), sz(c, h));
        p.setMargins(0, dp(c, t), 0, dp(c, b)); p.setMarginStart(dp(c, s)); p.setMarginEnd(dp(c, e)); return p;
    }
    static LinearLayout.LayoutParams lp2(Context c, float start) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        p.setMarginStart(dp(c, start)); return p;
    }
    static LinearLayout.LayoutParams lpw(float weight) { return new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, weight); }
    static LinearLayout card(Context c) {
        LinearLayout l = vbox(c);
        int p = dp(c, 16);
        l.setPadding(p, p, p, p);
        GradientDrawable panel = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                light ? new int[]{0xFFFFFFFF, 0xFFF9F5FC} : new int[]{0xFF373449, 0xFF29283A});
        panel.setCornerRadius(dp(c, 20));
        panel.setStroke(dp(c, 1), STROKE);
        l.setBackground(panel);
        l.setClipToOutline(true);
        l.setElevation(dp(c, light ? 2 : 5));
        return l;
    }
    static TextView chip(Context c, String s, int bg, int fg) {
        TextView t = tv(c, s, 11, fg, true);
        t.setPadding(dp(c, 11), dp(c, 8), dp(c, 11), dp(c, 8));
        boolean selected = (themeColor(bg) & 0x00FFFFFF) == (PRIMARY & 0x00FFFFFF);
        if (selected) {
            t.setTextColor(0xFFFFFFFF);
            t.setBackground(grad(c, light ? 0xFF9448D7 : 0xFFB65AF2,
                    light ? 0xFFBD55C5 : 0xFFE66ADC, 13));
        } else t.setBackground(rr(c, bg, 13, STROKE));
        t.setGravity(Gravity.CENTER);
        return t;
    }
    static Button btn(Context c, String s, int bg, int fg, View.OnClickListener l) {
        Button b = new Button(c);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextSize(13);
        b.setTypeface(MEDIUM);
        boolean primary = (themeColor(bg) & 0x00FFFFFF) == (PRIMARY & 0x00FFFFFF);
        GradientDrawable shape = primary
                ? new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                    light ? new int[]{0xFF9448D7, 0xFFC64FAE} : new int[]{0xFFCE55EA, 0xFF7646E8})
                : new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                    new int[]{surfaceColor(bg), surfaceColor(bg)});
        shape.setCornerRadius(dp(c, 16));
        shape.setStroke(dp(c, 1), primary ? (light ? 0xFFB76BEA : 0xFF9D69F2) : STROKE);
        b.setTextColor(primary ? 0xFFFFFFFF : themeColor(fg));
        b.setBackground(new RippleDrawable(ColorStateList.valueOf(0x33FFFFFF), shape,
                rr(c, 0xFFFFFFFF, 16)));
        b.setStateListAnimator(null);
        b.setMinHeight(dp(c, 48));
        b.setMinimumHeight(dp(c, 48));
        b.setGravity(Gravity.CENTER);
        b.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        b.setTextDirection(View.TEXT_DIRECTION_RTL);
        b.setPadding(dp(c, 16), dp(c, 10), dp(c, 16), dp(c, 10));
        b.setOnClickListener(l);
        return b;
    }
}
