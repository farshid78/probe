package android.view.accessibility;
import android.graphics.Rect;
import java.util.*;
public class AccessibilityNodeInfo {
 private String text, desc, id, pkg="test.operator"; private final List<AccessibilityNodeInfo> children=new ArrayList<>();
 private int top, left=0, right=100, bottom; private boolean visible=true, editable=false, password=false, scrollable=false;
 public AccessibilityNodeInfo(String t,int y){text=t;top=y;bottom=y+20;}
 public AccessibilityNodeInfo add(AccessibilityNodeInfo n){children.add(n);return this;}
 public AccessibilityNodeInfo visible(boolean v){visible=v;return this;}
 public AccessibilityNodeInfo editable(boolean v){editable=v;return this;}
 public AccessibilityNodeInfo password(boolean v){password=v;return this;}
 public AccessibilityNodeInfo scrollable(boolean v){scrollable=v;return this;}
 public AccessibilityNodeInfo bounds(int l,int t,int r,int b){left=l;top=t;right=r;bottom=b;return this;}
 public boolean isVisibleToUser(){return visible;} public boolean isEditable(){return editable;} public boolean isPassword(){return password;}
 public void getBoundsInScreen(Rect r){r.left=left;r.right=right;r.top=top;r.bottom=bottom;}
 public CharSequence getText(){return text;} public CharSequence getContentDescription(){return desc;}
 public String getViewIdResourceName(){return id;} public int getChildCount(){return children.size();}
 public AccessibilityNodeInfo getChild(int i){return children.get(i);} public CharSequence getPackageName(){return pkg;} public void recycle(){}
 public static final int ACTION_SCROLL_FORWARD=4096;
 public boolean isScrollable(){return scrollable;}
 public boolean performAction(int a){return false;}
}
