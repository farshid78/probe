package app.bastehyab;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

/** Bounded private history of observed package changes. */
final class HistoryLog {
    static final class Entry {
        final String title, field;
        final double before, after;
        final long ts;
        Entry(String title, String field, double before, double after, long ts) {
            this.title=title; this.field=field; this.before=before; this.after=after; this.ts=ts;
        }
    }
    static synchronized void record(Context c, Pkg old, Pkg cur) {
        List<History.Change> changes = History.diff(old, cur);
        if (changes.isEmpty()) return;
        SharedPreferences sp = Cfg.sp(c);
        JSONArray a;
        try { a = new JSONArray(sp.getString("history", "[]")); }
        catch (Exception e) { a = new JSONArray(); }
        try {
            for (History.Change ch : changes) {
                JSONObject x = new JSONObject();
                x.put("title", cur.title); x.put("field", ch.field);
                x.put("before", ch.before); x.put("after", ch.after); x.put("ts", ch.ts);
                a.put(x);
            }
            JSONArray bounded = new JSONArray();
            for (int i=Math.max(0,a.length()-300); i<a.length(); i++) bounded.put(a.getJSONObject(i));
            sp.edit().putString("history", bounded.toString()).apply();
        } catch (Exception ignored) {}
    }
    static synchronized List<Entry> recent(Context c, int limit) {
        List<Entry> out = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(Cfg.sp(c).getString("history", "[]"));
            for (int i=a.length()-1; i>=0 && out.size()<limit; i--) {
                JSONObject x=a.getJSONObject(i);
                out.add(new Entry(x.optString("title", ""), x.optString("field", ""),
                        x.optDouble("before", 0), x.optDouble("after", 0), x.optLong("ts", 0)));
            }
        } catch (Exception ignored) {}
        return out;
    }
    static synchronized void clear(Context c) { Cfg.sp(c).edit().remove("history").apply(); }
}
