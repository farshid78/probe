package app.bastehyab;

import android.content.Context;
import org.json.JSONArray;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

final class Store {
    private static final Map<String, Pkg> m = new LinkedHashMap<>();
    private static boolean loaded;
    private static long lastSave;


    private static void migrateCurrencyCertainty(Pkg p, Context c) {
        // Older records had no currency-certainty field. Recover only from explicit unit evidence
        // in the retained card text or a fixed operator profile; otherwise fail closed.
        Op op = Cfg.opById(c, p.op);
        String evidence = Fmt.norm((p.title == null ? "" : p.title) + " " + (p.raw == null ? "" : p.raw));
        boolean explicit = evidence.contains("ریال") || evidence.contains("تومان") || evidence.contains("تومن");
        boolean fixed = op != null && ("IRR".equals(op.cur) || "IRT".equals(op.cur));
        if (!p.currencyKnown && (explicit || fixed)) p.currencyKnown = true;
        if (!p.currencyKnown) {
            p.ambig = true;
            if (p.note == null || p.note.isEmpty()) p.note = "واحد پول از داده ذخیره‌شده قابل تأیید نیست";
        }
    }

    private static File f(Context c) {
        return new File(c.getApplicationContext().getFilesDir(), "data.json");
    }

    private static void load(Context c) {
        if (loaded) return;
        loaded = true;
        boolean sanitizedRawRecords = false;
        try (BufferedReader r = new BufferedReader(new InputStreamReader(new FileInputStream(f(c)), StandardCharsets.UTF_8))) {
            StringBuilder sb = new StringBuilder();
            String ln;
            while ((ln = r.readLine()) != null) sb.append(ln);
            JSONArray a = new JSONArray(sb.toString());
            for (int i = 0; i < a.length(); i++) {
                Pkg p = Pkg.from(a.getJSONObject(i));
                migrateCurrencyCertainty(p, c);
                // Retain the previously classified restriction when raw page text is no longer
                // persisted; only the current scan uses its in-memory text for classification.
                String evidence = p.title + " " + p.raw + " " + p.why;
                String parsedWhy = Extractor.whyOf(evidence, p.days, Extractor.volCount(p.title));
                String w = Extractor.mergeWhy(parsedWhy, p.why);
                if (Extractor.INTL.matcher(Fmt.norm(evidence)).find()) {
                    w = Extractor.mergeWhy(Extractor.INTL_WHY, w);
                }
                p.why = w;
                p.restricted = !w.isEmpty();
                if (p.raw != null && !p.raw.isEmpty()) {
                    p.raw = "";
                    sanitizedRawRecords = true;
                }
                p.key = Extractor.keyOf(p.op, p.title, p.code, p.why);
                Pkg old = m.get(p.key);
                if (old == null || p.ts >= old.ts) m.put(p.key, p);
            }
            if (sanitizedRawRecords) save(c);
        } catch (Exception e) {
            android.util.Log.e("BastehyabStore", "Could not load package database", e);
            File backup = new File(c.getFilesDir(), "data.json.bak");
            if (backup.exists()) {
                // Do not merge a partially parsed corrupt primary file with the backup.
                m.clear();
                try {
                    File target = f(c);
                    if (target.exists()) target.delete();
                    if (backup.renameTo(target)) {
                        try (BufferedReader r = new BufferedReader(new InputStreamReader(new FileInputStream(target), StandardCharsets.UTF_8))) {
                            StringBuilder sb = new StringBuilder(); String ln;
                            while ((ln = r.readLine()) != null) sb.append(ln);
                            JSONArray a = new JSONArray(sb.toString());
                            for (int i = 0; i < a.length(); i++) {
                                Pkg p = Pkg.from(a.getJSONObject(i));
                                migrateCurrencyCertainty(p, c);
                                String evidence = p.title + " " + p.raw + " " + p.why;
                                String parsedWhy = Extractor.whyOf(evidence, p.days, Extractor.volCount(p.title));
                                String w = Extractor.mergeWhy(parsedWhy, p.why);
                                if (Extractor.INTL.matcher(Fmt.norm(evidence)).find()) {
                                    w = Extractor.mergeWhy(Extractor.INTL_WHY, w);
                                }
                                p.why = w;
                                p.restricted = !w.isEmpty();
                                p.raw = "";
                                p.key = Extractor.keyOf(p.op, p.title, p.code, p.why);
                                m.put(p.key, p);
                            }
                            save(c);
                        }
                    }
                } catch (Exception recovery) {
                    android.util.Log.e("BastehyabStore", "Database recovery failed", recovery);
                }
            }
        }
    }

    private static void save(Context c) {
        lastSave = System.currentTimeMillis();
        JSONArray a = new JSONArray();
        for (Pkg p : m.values()) {
            try {
                a.put(p.json());
            } catch (Exception ignored) {}
        }
        File target = f(c);
        File temp = new File(c.getFilesDir(), "data.json.tmp");
        File backup = new File(c.getFilesDir(), "data.json.bak");
        try {
            try (Writer w = new OutputStreamWriter(new FileOutputStream(temp), StandardCharsets.UTF_8)) {
                w.write(a.toString());
                w.flush();
            }
            if (backup.exists()) backup.delete();
            if (target.exists() && !target.renameTo(backup)) throw new java.io.IOException("backup rename failed");
            if (!temp.renameTo(target)) {
                if (backup.exists()) backup.renameTo(target);
                throw new java.io.IOException("atomic replace failed");
            }
            if (backup.exists()) backup.delete();
        } catch (Exception e) {
            android.util.Log.e("BastehyabStore", "Could not persist package database", e);
        }
    }

    // returns number of new/changed packages
    static synchronized int upsert(Context c, List<Pkg> items) {
        load(c);
        int ch = 0;
        long now = System.currentTimeMillis();
        for (Pkg p : items) {
            // Last line of defence: malformed or zero-price offers must never enter storage.
            if (p == null || p.op == null || p.key == null || p.key.trim().isEmpty()
                    // Keep uncertain offers for manual review. Compare.run() excludes them from
                    // definitive rankings; dropping them here made Samantel appear to have 0 offers.
                    || p.gb < 0.05 || p.gb > 5000 || p.toman < 100 || p.toman > 2000000000L
                    || Double.isNaN(p.gb) || Double.isInfinite(p.gb)
                    || Double.isNaN(p.days) || Double.isInfinite(p.days) || p.days < 0) continue;
            Pkg o = m.get(p.key);
            p.ts = now;
            if (o != null) HistoryLog.record(c, o, p);
            if (o == null || o.toman != p.toman || Math.abs(o.gb - p.gb) > 1e-9
                    || o.days != p.days || o.restricted != p.restricted
                    || o.ambig != p.ambig || o.currencyKnown != p.currencyKnown) ch++;
            // Raw accessibility text is transient parser input, not a stored user datum.
            p.raw = "";
            p.ts = now;
            m.put(p.key, p);
        }
        if (ch > 0 || now - lastSave > 60000) save(c);
        return ch;
    }

    static synchronized List<Pkg> all(Context c) {
        load(c);
        return new ArrayList<>(m.values());
    }

    static synchronized void clearOp(Context c, String opId) {
        load(c);
        Iterator<Pkg> it = m.values().iterator();
        while (it.hasNext()) if (it.next().op.equals(opId)) it.remove();
        save(c);
    }

    static synchronized void reprice(Context c, String opId, int policy) {
        load(c);
        for (Pkg p : m.values()) {
            if (!p.op.equals(opId) || p.alts.length < 2 || policy == 0) continue;
            long best = p.alts[0];
            for (long a : p.alts) best = policy == 1 ? Math.max(best, a) : Math.min(best, a);
            p.toman = best;
            // A user-selected price policy cannot clear ambiguity caused by incomplete extraction
            // or unknown currency evidence. A fresh complete scan must resolve it.
        }
        save(c);
    }

    static synchronized void clearAll(Context c) {
        load(c);
        m.clear();
        save(c);
    }
}
