package app.bastehyab;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.graphics.Rect;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;
import android.widget.Toast;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class ScanService extends AccessibilityService {
    static volatile ScanService inst;
    static volatile String lastScanStatus = "هنوز اسکن انجام نشده است";
    static volatile int lastScannedPackages, lastValidPackages, lastSuspiciousPackages, lastDuplicatePackages;
    static volatile long lastCompletedScanAt;
    static volatile long lastScanDurationMs;
    static volatile String lastOpId = "";
    static volatile String lastEmptyReason = "";
    static volatile String lastPackageStatus = "";

    // ---- user-started full extraction: the app scrolls the operator list ONLY after an explicit user request
    static volatile boolean fullMode;
    static volatile boolean fullStartedScanning;
    static volatile boolean fullTargetObservedOnce;
    static volatile String fullTargetOpId = "";
    static volatile String fullTargetPackage = "";
    static volatile long fullStartedAt;
    static volatile long fullLastStepAt;
    static volatile int fullSteps, fullNoNew;
    static volatile int fullNoMove, fullScrollStrategy;
    static volatile String lastScrollMethod = "هنوز اسکرولی انجام نشده";
    static volatile boolean fullFinished;
    static final java.util.Set<String> fullSeen = new HashSet<>();
    static final int FULL_MAX_STEPS = 120;
    static final long FULL_WAIT_MS = 240000L;
    static final long FULL_MAX_MS = 300000L;

    /** Start only for the exact package opened by the operator button; wait for a real offer page. */
    static synchronized void startFull(String operatorId, String targetPackage) {
        fullSeen.clear();
        fullSteps = 0;
        fullNoNew = 0;
        fullNoMove = 0;
        fullScrollStrategy = 0;
        lastScrollMethod = "هنوز اسکرولی انجام نشده";
        fullLastFingerprint = "";
        fullFinished = false;
        fullStartedScanning = false;
        fullTargetObservedOnce = false;
        fullTargetOpId = operatorId == null ? "" : operatorId.trim();
        fullTargetPackage = targetPackage == null ? "" : targetPackage.trim();
        // Navigation time is not part of the five-minute extraction window.
        fullStartedAt = 0L;
        fullLastStepAt = 0L;
        lastPackageStatus = "";
        if (fullTargetOpId.isEmpty() || fullTargetPackage.isEmpty()) {
            fullMode = false;
            lastScanStatus = "استخراج خودکار شروع نشد؛ شناسه‌ی اپراتور یا برنامه معتبر نیست";
            return;
        }
        fullMode = true;
        lastScanStatus = "استخراج خودکار آماده است؛ در انتظار صفحه‌ی بسته‌های اینترنت";
        if (inst != null) {
            // The floating comparison window is touchable. Keeping it visible over an app
            // can swallow the very swipe used to scroll that app, especially in Irancell/MCI.
            if (inst.popup != null) inst.popup.hide();
            inst.h.removeCallbacks(inst.fullTimeout);
            inst.h.postDelayed(inst.fullTimeout, FULL_WAIT_MS);
        }
    }

    static boolean isFullTarget(String packageName) {
        return !fullTargetPackage.isEmpty() && fullTargetPackage.equals(packageName);
    }

    /** Ignore window changes until the target operator app was actually reached. */
    static boolean shouldStopFullForWindowChange(String packageName) {
        return fullMode && fullTargetObservedOnce && !ignorable(packageName == null ? "" : packageName)
                && !isFullTarget(packageName == null ? "" : packageName);
    }

    static synchronized void stopFull(String reason) {
        if (!fullMode) return;
        fullMode = false;
        // A stationary viewport does not prove that the end of the list was reached.
        fullFinished = reason != null
                && (reason.contains("پایان قطعی فهرست") || reason.contains("فهرست تمام شد"));
        if (inst != null) inst.h.removeCallbacks(inst.fullTimeout);
        lastScanStatus = (reason == null ? "استخراج خودکار متوقف شد" : reason)
                + " • " + fullSeen.size() + " بسته‌ی یکتا";
    }

    private final Handler h = new Handler(Looper.getMainLooper());
    private final Runnable fullTimeout = () -> {
        if (fullMode) stopFull(fullStartedScanning
                ? "توقف: مهلت پنج‌دقیقه‌ای استخراج به پایان رسید"
                : "توقف: مهلت ورود به صفحه‌ی بسته‌های اینترنت به پایان رسید");
    };
    private final Runnable job = this::scan;
    // Keep a bounded history of distinct page snapshots per operator. A single last-page
    // snapshot concealed failures on earlier scroll pages in the previous diagnostic export.
    private final Map<String, List<String>> dumps = new HashMap<>();
    private Popup popup;
    private long lastScanAt;
    private static volatile String fullLastFingerprint = "";
    private final Runnable writeDiag = this::writeDiagnosticFile;
    private int emptyStreak;
    private boolean scanning, scanAgain;
    private String fg = "", dismissed = "";

    @Override public void onInterrupt() {
        h.removeCallbacks(job);
        pendingReset();
        stopFull("سرویس دسترسی‌پذیری متوقف شد");
        if (popup != null) popup.hide();
    }

    private void pendingReset() {
        scanAgain = false;
        scanning = false;
    }

    @Override protected void onServiceConnected() {
        inst = this;
        // Remove a possible raw diagnostic file left by versions before the privacy fix.
        File legacyDiagnostic = new File(getFilesDir(), "diag.txt");
        if (legacyDiagnostic.exists()) legacyDiagnostic.delete();
        dumps.clear();
        popup = new Popup(this);
        popup.onClose(() -> dismissed = fg);
    }

    @Override public boolean onUnbind(Intent i) {
        h.removeCallbacksAndMessages(null);
        pendingReset();
        stopFull("سرویس دسترسی‌پذیری غیرفعال شد");
        inst = null;
        dumps.clear();
        if (popup != null) popup.hide();
        return super.onUnbind(i);
    }

    private static boolean ignorable(String p) {
        String s = p.toLowerCase();
        return s.equals("com.android.systemui") || s.contains("inputmethod") || s.contains("keyboard") || s.contains("honeyboard");
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent e) {
        CharSequence cs = e.getPackageName();
        if (cs == null || popup == null) return;
        String p = cs.toString();
        if (fullMode && isFullTarget(p)) fullTargetObservedOnce = true;
        // Returning to Bastehyab is also leaving the selected operator; stop only after the
        // target app has actually appeared, not during the launcher's transition animation.
        if (e.getEventType() == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
                && shouldStopFullForWindowChange(p)) {
            stopFull("استخراج خودکار متوقف شد؛ از برنامه‌ی اپراتور خارج شدید");
        }
        if (p.equals(getPackageName())) return;
        if (e.getEventType() == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED && !ignorable(p) && !p.equals(fg)) {
            fg = p;
            if (!p.equals(dismissed)) dismissed = "";
            popup.hide();
        }
        Op op = Cfg.opFor(this, p);
        if (op == null || !op.enabled) return;
        long now = System.currentTimeMillis();
        // Debounce noisy accessibility events, but keep scrolling responsive.
        // A 450 ms floor prevents repeated full-tree walks while avoiding the old 900 ms lag.
        boolean scrollEvent = e.getEventType() == AccessibilityEvent.TYPE_VIEW_SCROLLED;
        long floor = fullMode ? 220L : (scrollEvent ? 220L : 450L);
        long delay = Math.max(fullMode || scrollEvent ? 120L : 180L, lastScanAt + floor - now);
        h.removeCallbacks(job);
        h.postDelayed(job, delay);
    }

    private void scan() {
        if (scanning) {
            scanAgain = true;
            return;
        }
        scanning = true;
        if (fullMode && popup != null) popup.hide();
        final long scanStartedAt = android.os.SystemClock.elapsedRealtime();
        lastScanAt = System.currentTimeMillis();
        int scanned = 0, valid = 0, suspicious = 0, duplicates = 0, fullNew = 0;
        Set<String> scanKeys = new HashSet<>();
        boolean incomplete = false;
        String operatorLabel = "";
        try {
        List<AccessibilityNodeInfo> roots = new ArrayList<>();
        List<AccessibilityWindowInfo> ws = getWindows();
        if (ws != null) {
            for (AccessibilityWindowInfo w : ws) {
                if (w == null) continue;
                try {
                    if (w.getType() == AccessibilityWindowInfo.TYPE_APPLICATION) {
                        AccessibilityNodeInfo r = w.getRoot();
                        if (r != null) roots.add(r);
                    }
                } finally {
                    // getWindows() returns owned AccessibilityWindowInfo instances.
                    w.recycle();
                }
            }
        }
        if (roots.isEmpty()) {
            AccessibilityNodeInfo r = getRootInActiveWindow();
            if (r != null) roots.add(r);
        }
        DisplayMetrics dm = getResources().getDisplayMetrics();
        boolean fullTargetObserved = false;
        boolean packagePageFound = false;
        String fullFingerprint = "";
        for (AccessibilityNodeInfo r : roots) {
            try {
                String p = String.valueOf(r.getPackageName());
                if (fullMode && !isFullTarget(p)) continue;
                Op op = Cfg.opFor(this, p);
                if (op == null || !op.enabled) continue;
                if (fullMode) {
                    fullTargetObserved = true;
                    fullTargetObservedOnce = true;
                }
                Extractor.Result res = Extractor.extract(r, op, dm.heightPixels);
                operatorLabel = op.name;
                lastOpId = op.id;
                incomplete |= res.incomplete;
                duplicates += res.duplicates;
                diag(p, res.dump);
                for (Pkg item : res.items) {
                    if (!scanKeys.add(item.key)) {
                        duplicates++;
                        continue;
                    }
                    scanned++;
                    if (item.currencyKnown && !item.ambig) valid++;
                    else suspicious++;
                }
                boolean offerPage = fullMode && looksLikeOfferPage(r);
                if (offerPage) {
                    packagePageFound = true;
                    fullFingerprint = pageFingerprint(r);
                }
                if (res.items.isEmpty()) {
                    lastEmptyReason = "گره‌ها: " + res.nodes + "، متن‌های قابل‌مشاهده: " + res.leaves
                            + (res.fullTraversal ? "، پیمایش کامل" : "");
                    if (++emptyStreak >= 3) popup.hide();
                    continue;
                }
                packagePageFound = true;
                if (fullMode && fullFingerprint.isEmpty()) fullFingerprint = pageFingerprint(r);
                emptyStreak = 0;
                Store.upsert(this, res.items);
                boolean hasDefinitivePrice = false;
                for (int i = res.items.size() - 1; i >= 0; i--) {
                    Pkg latest = res.items.get(i);
                    if (latest.currencyKnown && !latest.ambig && latest.toman >= 100) {
                        lastPackageStatus = latest.title + " • " + Cfg.priceLabel(this, latest.toman) + " ثبت شد";
                        hasDefinitivePrice = true;
                        break;
                    }
                }
                if (!hasDefinitivePrice) {
                    Pkg uncertain = res.items.get(res.items.size() - 1);
                    lastPackageStatus = uncertain.title + " • استخراج شد و برای بررسی دستی نگهداری شد";
                }
                // Include uncertain entries in end-of-list detection too; they are not stored/ranked,
                // but their appearance proves that the next screen is not necessarily empty.
                if (fullMode) for (Pkg item : res.items) if (fullSeen.add(item.sig())) fullNew++;
                Compare.Result cr = Compare.run(this, res.keys);
                // Never place the touchable comparison overlay above an app while a swipe is
                // being dispatched for automatic full extraction.
                if (fullMode || !Cfg.popup(this) || p.equals(dismissed)
                        || cr.ranked.isEmpty() || cr.ops < Cfg.minOps(this)) continue;
                popup.show(cr, res.keys);
            } finally {
                // Every root must be recycled, including roots skipped by operator/target filters.
                r.recycle();
            }
        }
        lastScannedPackages = scanned;
        lastValidPackages = valid;
        lastSuspiciousPackages = suspicious;
        lastDuplicatePackages = duplicates;
        lastCompletedScanAt = System.currentTimeMillis();
        if (fullMode && fullTargetObserved && !fullStartedScanning && packagePageFound) {
            fullStartedScanning = true;
            fullNoNew = 0;
            fullStartedAt = System.currentTimeMillis();
            if (inst != null) {
                inst.h.removeCallbacks(inst.fullTimeout);
                inst.h.postDelayed(inst.fullTimeout, FULL_MAX_MS);
            }
            lastScanStatus = "صفحه‌ی بسته‌ها شناسایی شد؛ استخراج خودکار آغاز شد";
        } else if (fullMode && fullTargetObserved && !fullStartedScanning) {
            lastScanStatus = "استخراج خودکار آماده است؛ به صفحه‌ی خرید بسته‌های اینترنت بروید";
        } else {
            lastScanStatus = (incomplete ? "استخراج ناقص؛ بخشی از درخت صفحه در دسترس نبود"
                    : scanned == 0 ? "در صفحه‌ی فعلی بسته‌ای شناسایی نشد (" + lastEmptyReason + ")" : "اسکن کامل شد")
                    + (operatorLabel.isEmpty() ? "" : " • " + operatorLabel);
        }
        if (fullMode && fullStartedScanning && fullTargetObserved && packagePageFound)
            advanceFull(fullNew, fullFingerprint);
        } catch (RuntimeException scanError) {
            lastCompletedScanAt = System.currentTimeMillis();
            lastScanStatus = "خطا در اسکن: " + scanError.getClass().getSimpleName();
            android.util.Log.w("BastehyabScan", "Accessibility scan failed: " + scanError.getClass().getSimpleName());
        } finally {
            lastScanDurationMs = Math.max(0L, android.os.SystemClock.elapsedRealtime() - scanStartedAt);
            scanning = false;
            if (scanAgain) {
                scanAgain = false;
                h.removeCallbacks(job);
                h.postDelayed(job, 180L);
            }
        }
    }

    /**
     * Recognize an operator offer page even when an individual card is temporarily unreadable.
     * This lets full extraction continue across sparse/partially-rendered pages instead of
     * waiting forever for the parser to produce at least one package.
     */
    private boolean looksLikeOfferPage(AccessibilityNodeInfo root) {
        if (root == null) return false;
        boolean hasInternet = false, hasBundle = false, hasOfferData = false;
        java.util.ArrayDeque<AccessibilityNodeInfo> q = new java.util.ArrayDeque<>();
        java.util.List<AccessibilityNodeInfo> owned = new java.util.ArrayList<>();
        q.add(root);
        int visited = 0;
        try {
            while (!q.isEmpty() && visited++ < 700) {
                AccessibilityNodeInfo n = q.removeFirst();
                CharSequence t = n.getText();
                CharSequence d = n.getContentDescription();
                String v = ((t == null ? "" : t.toString()) + " " + (d == null ? "" : d.toString())).toLowerCase(java.util.Locale.ROOT);
                if (v.contains("اینترنت") || v.contains("internet")) hasInternet = true;
                if (v.contains("بسته") || v.contains("package")) hasBundle = true;
                if (v.contains("گیگ") || v.contains("مگ") || v.contains("قیمت") || v.contains("تومان")
                        || v.contains("ریال") || v.contains("خرید")) hasOfferData = true;
                if (hasInternet && hasBundle && hasOfferData) return true;
                for (int i = 0; i < n.getChildCount(); i++) {
                    AccessibilityNodeInfo child = n.getChild(i);
                    if (child != null) { owned.add(child); q.addLast(child); }
                }
            }
        } catch (RuntimeException ignored) {
            return false;
        } finally {
            for (AccessibilityNodeInfo n : owned) try { n.recycle(); } catch (RuntimeException ignored) {}
        }
        return hasBundle && hasOfferData;
    }

    /** One step of the user-started extraction. The scroll method adapts when the app ignores it. */
    private void advanceFull(int newThisScan, String fingerprint) {
        long now = System.currentTimeMillis();
        if (now - fullLastStepAt < 850L) return;
        fullLastStepAt = now;
        fullSteps++;
        fullNoNew = newThisScan == 0 ? fullNoNew + 1 : 0;

        String fp = fingerprint == null ? "" : fingerprint;
        if (!fp.isEmpty() && fp.equals(fullLastFingerprint)) {
            fullNoMove++;
            // ACTION_SCROLL_FORWARD is best when supported. If the visible page did not change,
            // try a real vertical gesture inside the list, then a broader app-window swipe.
            if (fullNoMove == 1) fullScrollStrategy = Math.max(fullScrollStrategy, 1);
            else if (fullNoMove >= 2) fullScrollStrategy = 2;
        } else if (!fp.isEmpty()) {
            fullLastFingerprint = fp;
            fullNoMove = 0;
        }

        lastScanStatus = "استخراج کامل: مرحله " + fullSteps + "، " + fullSeen.size()
                + " بسته‌ی یکتا؛ " + newThisScan + " بسته‌ی تازه";
        if (fullSteps >= FULL_MAX_STEPS || now - fullStartedAt > FULL_MAX_MS) {
            stopFull("توقف ایمن: به سقف زمان یا تعداد حرکت رسید");
            return;
        }
        if (fullNoMove >= 4) {
            stopFull("اسکرول متوقف شد؛ پایان فهرست یا محدودیت اپ قابل تأیید نیست");
            return;
        }

        boolean requested = performAdaptiveScroll();
        if (!requested) {
            stopFull("اسکرول خودکار در این صفحه پشتیبانی نشد؛ فهرست را دستی کمی پایین ببرید");
            return;
        }
        lastScanStatus += " • " + lastScrollMethod;
        h.removeCallbacks(job);
        h.postDelayed(job, 1000L);
    }

    /**
     * Scroll strategy: accessible list action first, then a vertical swipe inside the detected
     * list, finally a swipe in the app content viewport. This is only called after the user has
     * explicitly started a scan and the selected operator's offers page has been recognized.
     */
    private boolean performAdaptiveScroll() {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return false;
        if (!isFullTarget(String.valueOf(root.getPackageName()))) {
            root.recycle();
            return false;
        }

        Rect appBounds = new Rect();
        root.getBoundsInScreen(appBounds);
        AccessibilityNodeInfo list = findScrollable(root);
        Rect listBounds = new Rect(appBounds);
        boolean actionAccepted = false;
        if (list != null) {
            list.getBoundsInScreen(listBounds);
            if (fullScrollStrategy == 0) {
                try { actionAccepted = list.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD); }
                catch (RuntimeException ignored) { actionAccepted = false; }
            }
            if (list != root) list.recycle();
        }
        root.recycle();

        if (actionAccepted) {
            lastScrollMethod = "فرمان پیمایش فهرست";
            return true;
        }

        if (fullScrollStrategy == 0) fullScrollStrategy = 1;
        if (fullScrollStrategy <= 1) {
            if (dispatchVerticalSwipe(listBounds)) {
                fullScrollStrategy = 1;
                lastScrollMethod = "حرکت لمسی داخل فهرست";
                return true;
            }
            fullScrollStrategy = 2;
        }

        if (dispatchVerticalSwipe(appBounds)) {
            fullScrollStrategy = 2;
            lastScrollMethod = "حرکت لمسی در ناحیه‌ی اصلی برنامه";
            return true;
        }
        return false;
    }

    private boolean dispatchVerticalSwipe(Rect bounds) {
        if (bounds == null) return false;
        int width = bounds.width(), height = bounds.height();
        if (width < 180 || height < 260) return false;
        int x = bounds.left + width / 2;
        int y1 = bounds.top + Math.round(height * 0.82f);
        int y2 = bounds.top + Math.round(height * 0.30f);
        if (y1 <= y2) return false;
        Path path = new Path();
        path.moveTo(x, y1);
        path.lineTo(x, y2);
        try {
            GestureDescription gesture = new GestureDescription.Builder()
                    .addStroke(new GestureDescription.StrokeDescription(path, 0L, 420L))
                    .build();
            return dispatchGesture(gesture, null, null);
        } catch (RuntimeException e) {
            android.util.Log.w("BastehyabScan", "Scroll gesture unavailable: " + e.getClass().getSimpleName());
            return false;
        }
    }

    /** A short-lived hash of visible text and geometry; raw page text is never written to disk. */
    private String pageFingerprint(AccessibilityNodeInfo root) {
        if (root == null) return "";
        java.util.ArrayDeque<AccessibilityNodeInfo> queue = new java.util.ArrayDeque<>();
        java.util.List<AccessibilityNodeInfo> owned = new java.util.ArrayList<>();
        queue.add(root);
        int hash = 1, count = 0, visited = 0;
        try {
            while (!queue.isEmpty() && visited++ < 1800) {
                AccessibilityNodeInfo n = queue.removeFirst();
                if (!n.isEditable() && !n.isPassword() && n.isVisibleToUser()) {
                    CharSequence text = n.getText();
                    if (text == null || text.length() == 0) text = n.getContentDescription();
                    if (text != null && text.length() > 0) {
                        String value = Fmt.norm(text.toString());
                        if (!value.isEmpty()) {
                            Rect b = new Rect();
                            n.getBoundsInScreen(b);
                            hash = 31 * hash + value.hashCode();
                            hash = 31 * hash + b.top / 8;
                            hash = 31 * hash + b.left / 8;
                            count++;
                        }
                    }
                }
                for (int i = 0; i < n.getChildCount(); i++) {
                    AccessibilityNodeInfo child = n.getChild(i);
                    if (child != null) { owned.add(child); queue.addLast(child); }
                }
            }
        } catch (RuntimeException ignored) {
            // A partial fingerprint is still useful for retry selection; parser marks truncation separately.
        } finally {
            for (AccessibilityNodeInfo n : owned) try { n.recycle(); } catch (RuntimeException ignored) {}
        }
        return count + ":" + Integer.toHexString(hash);
    }

    /**
     * Pick the largest visible scroll container, preferring tall content over small horizontal
     * carousels. The returned node remains owned by the caller; every other child is recycled.
     */
    static AccessibilityNodeInfo findScrollable(AccessibilityNodeInfo root) {
        if (root == null) return null;
        java.util.ArrayDeque<AccessibilityNodeInfo> queue = new java.util.ArrayDeque<>();
        java.util.List<AccessibilityNodeInfo> owned = new ArrayList<>();
        queue.add(root);
        AccessibilityNodeInfo best = null;
        long bestScore = -1L;
        int visited = 0;
        while (!queue.isEmpty() && visited++ < 600) {
            AccessibilityNodeInfo n = queue.poll();
            if (n.isScrollable() && n.isVisibleToUser()) {
                Rect bounds = new Rect();
                n.getBoundsInScreen(bounds);
                long width = Math.max(0L, (long) bounds.width());
                long height = Math.max(0L, (long) bounds.height());
                // Reject horizontal carousels and tiny nested controls. A package list is
                // normally a tall viewport; the fallback below handles unusual tablet layouts.
                boolean verticalCandidate = height >= width * 0.55 && height >= 240L;
                if (verticalCandidate) {
                    long score = width * height + 3L * height * height;
                    if (score > bestScore) {
                        bestScore = score;
                        best = n;
                    }
                }
            }
            for (int i = 0; i < n.getChildCount(); i++) {
                AccessibilityNodeInfo c = n.getChild(i);
                if (c != null) { owned.add(c); queue.add(c); }
            }
        }
        // If no tall vertical viewport exists, do not guess: horizontal carousels are not
        // a safe substitute for the main package list.
        for (AccessibilityNodeInfo c : owned) if (c != best) c.recycle();
        return best;
    }

    void showTest() {
        Compare.Result cr = Compare.run(this, new HashSet<String>());
        if (cr.ranked.isEmpty()) {
            Toast.makeText(this, "هنوز داده‌ای برای نمایش نیست", Toast.LENGTH_SHORT).show();
            return;
        }
        popup.show(cr, new HashSet<String>());
    }

    void hideComparisonPopup() {
        if (popup != null) popup.hide();
    }

    private void diag(String p, String dump) {
        List<String> history = dumps.get(p);
        if (history == null) {
            history = new ArrayList<>();
            dumps.put(p, history);
        }
        // Avoid logging the same viewport repeatedly; retain up to the latest 30 distinct
        // snapshots so the exported report shows what happened before and after each scroll.
        if (history.isEmpty() || !history.get(history.size() - 1).equals(dump)) {
            history.add("time=" + new java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US)
                    .format(new java.util.Date()) + " step=" + fullSteps + " unique=" + fullSeen.size()
                    + " scroll=" + lastScrollMethod + "\n" + dump);
            while (history.size() > 30) history.remove(0);
        }
        // Debounce file I/O but always write the newest snapshot.
        h.removeCallbacks(writeDiag);
        h.postDelayed(writeDiag, 450L);
    }

    /** Force a final report write before sharing the diagnostic file. */
    static void flushDiagnostics() {
        ScanService service = inst;
        if (service == null) return;
        service.h.removeCallbacks(service.writeDiag);
        service.writeDiagnosticFile();
    }

    private void writeDiagnosticFile() {
        StringBuilder sb = new StringBuilder();
        sb.append("Bastehyab diagnostic • version 1.5.0\n");
        sb.append("capturedAt=").append(new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.US)
                .format(new java.util.Date())).append('\n');
        sb.append("status=").append(lastScanStatus).append('\n');
        sb.append("fullMode=").append(fullMode).append(" target=").append(fullTargetPackage)
                .append(" steps=").append(fullSteps).append(" unique=").append(fullSeen.size())
                .append(" noMove=").append(fullNoMove).append(" scrollStrategy=").append(fullScrollStrategy)
                .append(" scrollMethod=").append(lastScrollMethod).append('\n');
        sb.append("lastScanDurationMs=").append(lastScanDurationMs)
                .append(" scanned=").append(lastScannedPackages).append(" valid=").append(lastValidPackages)
                .append(" suspicious=").append(lastSuspiciousPackages).append(" duplicates=")
                .append(lastDuplicatePackages).append('\n');
        List<String> keys = new ArrayList<>(dumps.keySet());
        java.util.Collections.sort(keys);
        for (String key : keys) {
            sb.append("=== package=").append(key).append(" snapshots=")
                    .append(dumps.get(key).size()).append('\n');
            int page = 0;
            for (String snapshot : dumps.get(key)) {
                sb.append("--- snapshot ").append(++page).append(" ---\n")
                        .append(snapshot).append('\n');
            }
        }
        try (Writer w = new OutputStreamWriter(new FileOutputStream(
                new File(getFilesDir(), "diag.txt")), StandardCharsets.UTF_8)) {
            w.write(sb.toString());
        } catch (Exception ignored) {}
    }

}
