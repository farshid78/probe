package app.bastehyab;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Shared visual system for Bastehyab. All screens consume the same light/dark tokens. */
final class UI {
    private UI() { }

    static boolean light;
    static int BG, CARD, CARD2, STROKE, PRIMARY, ACCENT, TEXT, MUTED, DANGER, BLUE;
    static final int SUCCESS = 0xFF159B83;
    static Typeface BODY, MEDIUM, BOLD;

    static void applyTheme(Context c) {
        light = "light".equals(Cfg.sp(c).getString("appearance", "dark"));
        if (light) {
            BG = 0xFFF4F7FC; CARD = 0xFFFFFFFF; CARD2 = 0xFFE9EFF7; STROKE = 0xFFD8E1EE;
            PRIMARY = 0xFF087E9B; ACCENT = 0xFF7656D6; TEXT = 0xFF17243B;
            MUTED = 0xFF65748A; DANGER = 0xFFD94862; BLUE = 0xFF2878B8;
        } else {
            BG = 0xFF07152F; CARD = 0xFF0D2343; CARD2 = 0xFF142D50; STROKE = 0xFF294365;
            PRIMARY = 0xFF12D9F2; ACCENT = 0xFFB5A4FF; TEXT = 0xFFF4F7FC;
            MUTED = 0xFFACBED4; DANGER = 0xFFFF829A; BLUE = 0xFF62BCEB;
        }
        if (BODY == null || MEDIUM == null || BOLD == null) {
            try {
                BODY = Typeface.createFromAsset(c.getAssets(), "fonts/NotoSansArabic-Regular.ttf");
                MEDIUM = Typeface.createFromAsset(c.getAssets(), "fonts/NotoSansArabic-Medium.ttf");
                BOLD = Typeface.createFromAsset(c.getAssets(), "fonts/NotoSansArabic-Bold.ttf");
            } catch (RuntimeException fontError) {
                BODY = Typeface.create("sans-serif", Typeface.NORMAL);
                MEDIUM = Typeface.create("sans-serif-medium", Typeface.NORMAL);
                BOLD = Typeface.create("sans-serif", Typeface.BOLD);
            }
        }
    }

    static int themeColor(int color) {
        int alpha = color >>> 24;
        int rgb = color & 0x00FFFFFF;
        int mapped = rgb;
        if (light) {
            switch (rgb) {
                case 0x07101F: case 0x050B15: case 0x0C1B31: case 0x091426: case 0x0B172A: case 0x101828: case 0x10182D: mapped = 0xFFF3F6FC; break;
                case 0x11213A: case 0x101F37: case 0x0E1A30: case 0x0E1A2D: case 0x0E1A32: mapped = 0xFFFFFFFF; break;
                case 0x1B3150: case 0x28415F: case 0x182B47: case 0x263B5A: case 0x16283A: case 0x152D42: case 0x0C1931: case 0x1A2D4A: case 0x142642: mapped = 0xFFE8EEF8; break;
                case 0xF7FAFF: case 0xFFFFFF: mapped = 0xFF182338; break;
                case 0xB3C1D7: case 0xB9D5E9: case 0x8393B0: mapped = 0xFF65738B; break;
                case 0x4AD9EA: case 0x55E8FF: case 0x54E8F7: case 0x41DDF4: case 0x35D9F5: case 0x37DFF4: case 0x38DDF2: mapped = 0xFF087E9B; break;
                case 0xB39BFF: case 0x9D78FF: case 0x9D7BFF: mapped = 0xFF7656D6; break;
                case 0xFF829A: case 0xFF718F: mapped = 0xFFD94862; break;
                case 0x3A557A: case 0x516C91: case 0x587396: mapped = 0xFFD7E0EF; break;
                default: break;
            }
        } else {
            switch (rgb) {
                case 0x07101F: case 0x050B15: case 0x0C1B31: case 0x091426: case 0x0B172A: case 0x101828: case 0x10182D: mapped = 0xFF0D1424; break;
                case 0x11213A: case 0x101F37: case 0x0E1A30: case 0x0E1A2D: case 0x0E1A32: mapped = 0xFF172238; break;
                case 0x1B3150: case 0x28415F: case 0x182B47: case 0x263B5A: case 0x16283A: case 0x152D42: case 0x0C1931: case 0x1A2D4A: case 0x142642: mapped = 0xFF22314B; break;
                case 0xF7FAFF: case 0xFFFFFF: mapped = 0xFFF4F7FF; break;
                case 0xB3C1D7: case 0xB9D5E9: case 0x8393B0: mapped = 0xFFACB8CC; break;
                case 0x4AD9EA: case 0x55E8FF: case 0x54E8F7: case 0x41DDF4: case 0x35D9F5: case 0x37DFF4: case 0x38DDF2: mapped = 0xFF12D9F2; break;
                case 0xB39BFF: case 0x9D78FF: case 0x9D7BFF: mapped = 0xFFB5A4FF; break;
                case 0xFF829A: case 0xFF718F: mapped = 0xFFFF829A; break;
                case 0x3A557A: case 0x516C91: case 0x587396: mapped = 0xFF34445F; break;
                default: break;
            }
        }
        return (alpha << 24) | (mapped & 0x00FFFFFF);
    }

    static void applyTypefaceTree(View view) {
        if (view instanceof TextView) {
            TextView text = (TextView) view;
            if (text instanceof Button || text instanceof android.widget.Switch) text.setTypeface(MEDIUM);
            else if (text.getTypeface() != null && text.getTypeface().isBold()) text.setTypeface(BOLD);
            else text.setTypeface(BODY);
            text.setIncludeFontPadding(false);
        }
        if (view instanceof android.view.ViewGroup) {
            android.view.ViewGroup group = (android.view.ViewGroup) view;
            for (int i = 0; i < group.getChildCount(); i++) applyTypefaceTree(group.getChildAt(i));
        }
    }

    static int dp(Context c, float v) { return Math.round(v * c.getResources().getDisplayMetrics().density); }
    static int sz(Context c, int v) { return v > 0 ? dp(c, v) : v; }

    static int surfaceColor(int color) {
        if ((color & 0x00FFFFFF) == 0x00FFFFFF || (color >>> 24) == 0) return color;
        return themeColor(color);
    }
    static GradientDrawable rr(Context c, int fill, float r) {
        GradientDrawable g = new GradientDrawable(); g.setColor(surfaceColor(fill)); g.setCornerRadius(dp(c, r)); return g;
    }
    static GradientDrawable rr(Context c, int fill, float r, int stroke) {
        GradientDrawable g = rr(c, fill, r); g.setStroke(dp(c, 1), surfaceColor(stroke)); return g;
    }
    static GradientDrawable grad(Context c, int a, int b, float r) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{surfaceColor(a), surfaceColor(b)}); g.setCornerRadius(dp(c, r)); return g;
    }
    static GradientDrawable appBackground(Context c) {
        return light ? grad(c, 0xFFF8FAFF, 0xFFEAF0FA, 0)
                : grad(c, 0xFF0B2348, 0xFF07152F, 0);
    }
    static int tint(int color) { return (themeColor(color) & 0x00FFFFFF) | 0x22000000; }
    static int contrastText(int background) {
        double r = ((background >> 16) & 255) / 255.0;
        double g = ((background >> 8) & 255) / 255.0;
        double b = (background & 255) / 255.0;
        r = r <= 0.04045 ? r / 12.92 : Math.pow((r + 0.055) / 1.055, 2.4);
        g = g <= 0.04045 ? g / 12.92 : Math.pow((g + 0.055) / 1.055, 2.4);
        b = b <= 0.04045 ? b / 12.92 : Math.pow((b + 0.055) / 1.055, 2.4);
        double luminance = 0.2126 * r + 0.7152 * g + 0.0722 * b;
        return luminance > 0.42 ? 0xFF182338 : 0xFFFFFFFF;
    }

    static TextView tv(Context c, String s, float sp, int color, boolean bold) {
        TextView t = new TextView(c); t.setText(s); t.setTextSize(sp); t.setTextColor(themeColor(color));
        t.setTypeface(bold ? BOLD : BODY);
        t.setTextDirection(View.TEXT_DIRECTION_RTL); t.setGravity(Gravity.TOP | Gravity.START);
        t.setTextAlignment(View.TEXT_ALIGNMENT_GRAVITY); t.setIncludeFontPadding(false);
        t.setLineSpacing(dp(c, 1.5f), 1.05f);
        return t;
    }
    static LinearLayout vbox(Context c) {
        LinearLayout l = new LinearLayout(c); l.setOrientation(LinearLayout.VERTICAL);
        l.setLayoutDirection(View.LAYOUT_DIRECTION_RTL); return l;
    }
    static LinearLayout hbox(Context c) {
        LinearLayout l = new LinearLayout(c); l.setOrientation(LinearLayout.HORIZONTAL);
        l.setLayoutDirection(View.LAYOUT_DIRECTION_RTL); l.setGravity(Gravity.CENTER_VERTICAL); return l;
    }
    static LinearLayout.LayoutParams lp(Context c, int w, int h, float s, float t, float e, float b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(sz(c, w), sz(c, h));
        p.setMargins(0, dp(c, t), 0, dp(c, b)); p.setMarginStart(dp(c, s)); p.setMarginEnd(dp(c, e)); return p;
    }
    static LinearLayout.LayoutParams lp2(Context c, float start) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        p.setMarginStart(dp(c, start)); return p;
    }
    static LinearLayout.LayoutParams lpw(float weight) { return new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, weight); }
    static LinearLayout card(Context c) {
        LinearLayout l = vbox(c); int p = dp(c, 17); l.setPadding(p, p, p, p);
        GradientDrawable panel = grad(c, light ? 0xFFFFFFFF : 0xFF1B2941, light ? 0xFFFDFEFF : 0xFF172238, 19);
        panel.setStroke(dp(c, 1), STROKE); l.setBackground(panel); l.setClipToOutline(true);
        l.setElevation(dp(c, light ? 1 : 2)); return l;
    }
    static TextView chip(Context c, String s, int bg, int fg) {
        TextView t = tv(c, s, 11, fg, true); t.setPadding(dp(c, 10), dp(c, 7), dp(c, 10), dp(c, 7));
        if ((bg & 0x00FFFFFF) == (PRIMARY & 0x00FFFFFF)) t.setTextColor(light ? 0xFFFFFFFF : 0xFF071326);
        t.setGravity(Gravity.CENTER); t.setBackground(rr(c, bg, 11)); return t;
    }
    static Button btn(Context c, String s, int bg, int fg, View.OnClickListener l) {
        Button b = new Button(c); b.setText(s); b.setAllCaps(false); b.setTextColor(themeColor(fg));
        b.setTextSize(13); b.setTypeface(MEDIUM);
        boolean primary = (bg & 0x00FFFFFF) == (PRIMARY & 0x00FFFFFF)
                || (bg & 0x00FFFFFF) == 0x004AD9EA || (bg & 0x00FFFFFF) == 0x0035D9F5;
        if (primary) b.setTextColor(light ? 0xFFFFFFFF : 0xFF071326);
        GradientDrawable shape = primary
                ? grad(c, light ? 0xFF315CFF : 0xFF6F8DFF, light ? 0xFF5277FF : 0xFF5574E8, 14)
                : grad(c, surfaceColor(bg), surfaceColor(bg), 14);
        shape.setStroke(dp(c, 1), surfaceColor(primary ? 0xFF315CFF : STROKE));
        b.setBackground(new RippleDrawable(ColorStateList.valueOf(0x22000000), shape, rr(c, 0xFFFFFFFF, 14)));
        b.setStateListAnimator(null); b.setMinHeight(dp(c, 48)); b.setMinimumHeight(dp(c, 48));
        b.setGravity(Gravity.CENTER); b.setTextAlignment(View.TEXT_ALIGNMENT_CENTER); b.setTextDirection(View.TEXT_DIRECTION_RTL);
        b.setPadding(dp(c, 14), dp(c, 9), dp(c, 14), dp(c, 9)); b.setOnClickListener(l); return b;
    }
}
