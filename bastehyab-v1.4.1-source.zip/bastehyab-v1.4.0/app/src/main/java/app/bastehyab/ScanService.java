package app.bastehyab;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.graphics.Rect;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;
import android.widget.Toast;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class ScanService extends AccessibilityService {
    static volatile ScanService inst;
    static volatile String lastScanStatus = "هنوز اسکن انجام نشده است";
    static volatile int lastScannedPackages, lastValidPackages, lastSuspiciousPackages, lastDuplicatePackages;
    static volatile long lastCompletedScanAt;
    static volatile long lastScanDurationMs;
    static volatile String lastOpId = "";
    static volatile String lastEmptyReason = "";
    static volatile String lastPackageStatus = "";

    // ---- user-started full extraction: the app scrolls the operator list ONLY after an explicit user request
    static volatile boolean fullMode;
    static volatile boolean fullStartedScanning;
    static volatile String fullTargetOpId = "";
    static volatile String fullTargetPackage = "";
    static volatile long fullStartedAt;
    static volatile long fullLastStepAt;
    static volatile int fullSteps, fullNoNew;
    static volatile boolean fullFinished;
    static final java.util.Set<String> fullSeen = new HashSet<>();
    static final int FULL_MAX_STEPS = 80;
    static final long FULL_MAX_MS = 180000L;

    /** Start only for the exact package opened by the operator button; wait for a real offer page. */
    static synchronized void startFull(String operatorId, String targetPackage) {
        fullSeen.clear();
        fullSteps = 0;
        fullNoNew = 0;
        fullFinished = false;
        fullStartedScanning = false;
        fullTargetOpId = operatorId == null ? "" : operatorId.trim();
        fullTargetPackage = targetPackage == null ? "" : targetPackage.trim();
        fullStartedAt = System.currentTimeMillis();
        fullLastStepAt = 0L;
        lastPackageStatus = "";
        if (fullTargetOpId.isEmpty() || fullTargetPackage.isEmpty()) {
            fullMode = false;
            lastScanStatus = "استخراج خودکار شروع نشد؛ شناسه‌ی اپراتور یا برنامه معتبر نیست";
            return;
        }
        fullMode = true;
        lastScanStatus = "استخراج خودکار آماده است؛ در انتظار صفحه‌ی بسته‌های اینترنت";
        if (inst != null) {
            inst.h.removeCallbacks(inst.fullTimeout);
            inst.h.postDelayed(inst.fullTimeout, FULL_MAX_MS);
        }
    }

    static boolean isFullTarget(String packageName) {
        return !fullTargetPackage.isEmpty() && fullTargetPackage.equals(packageName);
    }

    static synchronized void stopFull(String reason) {
        if (!fullMode) return;
        fullMode = false;
        fullFinished = reason != null && reason.contains("پایان لیست");
        if (inst != null) inst.h.removeCallbacks(inst.fullTimeout);
        lastScanStatus = (reason == null ? "استخراج خودکار متوقف شد" : reason)
                + " • " + fullSeen.size() + " بسته‌ی یکتا";
    }

    private final Handler h = new Handler(Looper.getMainLooper());
    private final Runnable fullTimeout = () -> {
        if (fullMode) stopFull(fullStartedScanning
                ? "توقف: مهلت سه‌دقیقه‌ای استخراج به پایان رسید"
                : "توقف: مهلت ورود به صفحه‌ی بسته‌های اینترنت به پایان رسید");
    };
    private final Runnable job = this::scan;
    private final Map<String, String> dumps = new HashMap<>();
    private Popup popup;
    private long lastDiag, lastScanAt;
    private int emptyStreak;
    private boolean scanning, scanAgain;
    private String fg = "", dismissed = "";

    @Override public void onInterrupt() {
        h.removeCallbacks(job);
        pendingReset();
        stopFull("سرویس دسترسی‌پذیری متوقف شد");
        if (popup != null) popup.hide();
    }

    private void pendingReset() {
        scanAgain = false;
        scanning = false;
    }

    @Override protected void onServiceConnected() {
        inst = this;
        // Remove a possible raw diagnostic file left by versions before the privacy fix.
        File legacyDiagnostic = new File(getFilesDir(), "diag.txt");
        if (legacyDiagnostic.exists()) legacyDiagnostic.delete();
        dumps.clear();
        popup = new Popup(this);
        popup.onClose(() -> dismissed = fg);
    }

    @Override public boolean onUnbind(Intent i) {
        h.removeCallbacksAndMessages(null);
        pendingReset();
        stopFull("سرویس دسترسی‌پذیری غیرفعال شد");
        inst = null;
        dumps.clear();
        if (popup != null) popup.hide();
        return super.onUnbind(i);
    }

    private static boolean ignorable(String p) {
        String s = p.toLowerCase();
        return s.equals("com.android.systemui") || s.contains("inputmethod") || s.contains("keyboard") || s.contains("honeyboard");
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent e) {
        CharSequence cs = e.getPackageName();
        if (cs == null || popup == null) return;
        String p = cs.toString();
        // Returning to Bastehyab is also leaving the selected operator; stop before filtering own events.
        if (fullMode && e.getEventType() == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
                && !ignorable(p) && !isFullTarget(p)) {
            stopFull("استخراج خودکار متوقف شد؛ از برنامه‌ی اپراتور خارج شدید");
        }
        if (p.equals(getPackageName())) return;
        if (e.getEventType() == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED && !ignorable(p) && !p.equals(fg)) {
            fg = p;
            if (!p.equals(dismissed)) dismissed = "";
            popup.hide();
        }
        Op op = Cfg.opFor(this, p);
        if (op == null || !op.enabled) return;
        long now = System.currentTimeMillis();
        // Debounce noisy accessibility events, but keep scrolling responsive.
        // A 450 ms floor prevents repeated full-tree walks while avoiding the old 900 ms lag.
        boolean scrollEvent = e.getEventType() == AccessibilityEvent.TYPE_VIEW_SCROLLED;
        long floor = fullMode ? 220L : (scrollEvent ? 220L : 450L);
        long delay = Math.max(fullMode || scrollEvent ? 120L : 180L, lastScanAt + floor - now);
        h.removeCallbacks(job);
        h.postDelayed(job, delay);
    }

    private void scan() {
        if (scanning) {
            scanAgain = true;
            return;
        }
        scanning = true;
        final long scanStartedAt = android.os.SystemClock.elapsedRealtime();
        lastScanAt = System.currentTimeMillis();
        int scanned = 0, valid = 0, suspicious = 0, duplicates = 0, fullNew = 0;
        Set<String> scanKeys = new HashSet<>();
        boolean incomplete = false;
        String operatorLabel = "";
        try {
        List<AccessibilityNodeInfo> roots = new ArrayList<>();
        List<AccessibilityWindowInfo> ws = getWindows();
        if (ws != null) {
            for (AccessibilityWindowInfo w : ws) {
                if (w == null) continue;
                try {
                    if (w.getType() == AccessibilityWindowInfo.TYPE_APPLICATION) {
                        AccessibilityNodeInfo r = w.getRoot();
                        if (r != null) roots.add(r);
                    }
                } finally {
                    // getWindows() returns owned AccessibilityWindowInfo instances.
                    w.recycle();
                }
            }
        }
        if (roots.isEmpty()) {
            AccessibilityNodeInfo r = getRootInActiveWindow();
            if (r != null) roots.add(r);
        }
        DisplayMetrics dm = getResources().getDisplayMetrics();
        boolean fullTargetObserved = false;
        boolean packagePageFound = false;
        for (AccessibilityNodeInfo r : roots) {
            try {
                String p = String.valueOf(r.getPackageName());
                if (fullMode && !isFullTarget(p)) continue;
                Op op = Cfg.opFor(this, p);
                if (op == null || !op.enabled) continue;
                if (fullMode) fullTargetObserved = true;
                Extractor.Result res = Extractor.extract(r, op, dm.heightPixels);
                operatorLabel = op.name;
                lastOpId = op.id;
                incomplete |= res.incomplete;
                duplicates += res.duplicates;
                diag(p, res.dump);
                for (Pkg item : res.items) {
                    if (!scanKeys.add(item.key)) {
                        duplicates++;
                        continue;
                    }
                    scanned++;
                    if (item.currencyKnown && !item.ambig) valid++;
                    else suspicious++;
                }
                boolean offerPage = fullMode && looksLikeOfferPage(r);
                if (offerPage) packagePageFound = true;
                if (res.items.isEmpty()) {
                    lastEmptyReason = "گره‌ها: " + res.nodes + "، متن‌های قابل‌مشاهده: " + res.leaves
                            + (res.fullTraversal ? "، پیمایش کامل" : "");
                    if (++emptyStreak >= 3) popup.hide();
                    continue;
                }
                packagePageFound = true;
                emptyStreak = 0;
                Store.upsert(this, res.items);
                boolean hasDefinitivePrice = false;
                for (int i = res.items.size() - 1; i >= 0; i--) {
                    Pkg latest = res.items.get(i);
                    if (latest.currencyKnown && !latest.ambig && latest.toman >= 100) {
                        lastPackageStatus = latest.title + " • " + Fmt.num(latest.toman) + " تومان ثبت شد";
                        hasDefinitivePrice = true;
                        break;
                    }
                }
                if (!hasDefinitivePrice) {
                    Pkg uncertain = res.items.get(res.items.size() - 1);
                    lastPackageStatus = uncertain.title + " • استخراج شد و برای بررسی دستی نگهداری شد";
                }
                // Include uncertain entries in end-of-list detection too; they are not stored/ranked,
                // but their appearance proves that the next screen is not necessarily empty.
                if (fullMode) for (Pkg item : res.items) if (fullSeen.add(item.sig())) fullNew++;
                Compare.Result cr = Compare.run(this, res.keys);
                if (!Cfg.popup(this) || p.equals(dismissed) || cr.ranked.isEmpty() || cr.ops < Cfg.minOps(this)) continue;
                popup.show(cr, res.keys);
            } finally {
                // Every root must be recycled, including roots skipped by operator/target filters.
                r.recycle();
            }
        }
        lastScannedPackages = scanned;
        lastValidPackages = valid;
        lastSuspiciousPackages = suspicious;
        lastDuplicatePackages = duplicates;
        lastCompletedScanAt = System.currentTimeMillis();
        if (fullMode && fullTargetObserved && !fullStartedScanning && packagePageFound) {
            fullStartedScanning = true;
            fullNoNew = 0;
            lastScanStatus = "صفحه‌ی بسته‌ها شناسایی شد؛ استخراج خودکار آغاز شد";
        } else if (fullMode && fullTargetObserved && !fullStartedScanning) {
            lastScanStatus = "استخراج خودکار آماده است؛ به صفحه‌ی خرید بسته‌های اینترنت بروید";
        } else {
            lastScanStatus = (incomplete ? "استخراج ناقص؛ بخشی از درخت صفحه در دسترس نبود"
                    : scanned == 0 ? "در صفحه‌ی فعلی بسته‌ای شناسایی نشد (" + lastEmptyReason + ")" : "اسکن کامل شد")
                    + (operatorLabel.isEmpty() ? "" : " • " + operatorLabel);
        }
        if (fullMode && fullStartedScanning && fullTargetObserved && packagePageFound) advanceFull(fullNew);
        } catch (RuntimeException scanError) {
            lastCompletedScanAt = System.currentTimeMillis();
            lastScanStatus = "خطا در اسکن: " + scanError.getClass().getSimpleName();
            android.util.Log.w("BastehyabScan", "Accessibility scan failed: " + scanError.getClass().getSimpleName());
        } finally {
            lastScanDurationMs = Math.max(0L, android.os.SystemClock.elapsedRealtime() - scanStartedAt);
            scanning = false;
            if (scanAgain) {
                scanAgain = false;
                h.removeCallbacks(job);
                h.postDelayed(job, 180L);
            }
        }
    }

    /**
     * Recognize an operator offer page even when an individual card is temporarily unreadable.
     * This lets full extraction continue across sparse/partially-rendered pages instead of
     * waiting forever for the parser to produce at least one package.
     */
    private boolean looksLikeOfferPage(AccessibilityNodeInfo root) {
        if (root == null) return false;
        boolean hasInternet = false, hasBundle = false, hasOfferData = false;
        java.util.ArrayDeque<AccessibilityNodeInfo> q = new java.util.ArrayDeque<>();
        java.util.List<AccessibilityNodeInfo> owned = new java.util.ArrayList<>();
        q.add(root);
        int visited = 0;
        try {
            while (!q.isEmpty() && visited++ < 700) {
                AccessibilityNodeInfo n = q.removeFirst();
                CharSequence t = n.getText();
                CharSequence d = n.getContentDescription();
                String v = ((t == null ? "" : t.toString()) + " " + (d == null ? "" : d.toString())).toLowerCase(java.util.Locale.ROOT);
                if (v.contains("اینترنت") || v.contains("internet")) hasInternet = true;
                if (v.contains("بسته") || v.contains("package")) hasBundle = true;
                if (v.contains("گیگ") || v.contains("مگ") || v.contains("قیمت") || v.contains("تومان")
                        || v.contains("ریال") || v.contains("خرید")) hasOfferData = true;
                if (hasInternet && hasBundle && hasOfferData) return true;
                for (int i = 0; i < n.getChildCount(); i++) {
                    AccessibilityNodeInfo child = n.getChild(i);
                    if (child != null) { owned.add(child); q.addLast(child); }
                }
            }
        } catch (RuntimeException ignored) {
            return false;
        } finally {
            for (AccessibilityNodeInfo n : owned) try { n.recycle(); } catch (RuntimeException ignored) {}
        }
        return hasBundle && hasOfferData;
    }

    /** One step of the user-started full extraction: count progress, then scroll the list once. */
    private void advanceFull(int newThisScan) {
        long now = System.currentTimeMillis();
        if (now - fullLastStepAt < 800L) return; // ignore event bursts; one step per settled screen
        fullLastStepAt = now;
        fullSteps++;
        fullNoNew = newThisScan == 0 ? fullNoNew + 1 : 0;
        lastScanStatus = "استخراج کامل: مرحله " + fullSteps + "، " + fullSeen.size()
                + " بسته‌ی یکتا؛ " + newThisScan + " بسته در این مرحله";
        if (fullNoNew >= 3) { stopFull("پایان لیست"); return; }
        if (fullSteps >= FULL_MAX_STEPS || now - fullStartedAt > FULL_MAX_MS) { stopFull("توقف: حد مجاز رسید"); return; }

        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root != null && !isFullTarget(String.valueOf(root.getPackageName()))) {
            root.recycle();
            stopFull("استخراج خودکار متوقف شد؛ صفحه‌ی اپراتور فعال نیست");
            return;
        }
        AccessibilityNodeInfo list = findScrollable(root);
        if (list == null) {
            if (root != null) root.recycle();
            stopFull("لیست قابل اسکرول پیدا نشد");
            return;
        }
        boolean moved = list.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD);
        if (list != root) list.recycle();
        if (root != null) root.recycle();
        if (!moved) { stopFull("پایان لیست"); return; }
        h.removeCallbacks(job);
        h.postDelayed(job, 900L);
    }

    /**
     * Pick the largest visible scroll container, preferring tall content over small horizontal
     * carousels. The returned node remains owned by the caller; every other child is recycled.
     */
    static AccessibilityNodeInfo findScrollable(AccessibilityNodeInfo root) {
        if (root == null) return null;
        java.util.ArrayDeque<AccessibilityNodeInfo> queue = new java.util.ArrayDeque<>();
        java.util.List<AccessibilityNodeInfo> owned = new ArrayList<>();
        queue.add(root);
        AccessibilityNodeInfo best = null;
        long bestScore = -1L;
        int visited = 0;
        while (!queue.isEmpty() && visited++ < 600) {
            AccessibilityNodeInfo n = queue.poll();
            if (n.isScrollable() && n.isVisibleToUser()) {
                Rect bounds = new Rect();
                n.getBoundsInScreen(bounds);
                long width = Math.max(0L, (long) bounds.width());
                long height = Math.max(0L, (long) bounds.height());
                // Reject horizontal carousels and tiny nested controls. A package list is
                // normally a tall viewport; the fallback below handles unusual tablet layouts.
                boolean verticalCandidate = height >= width * 0.55 && height >= 240L;
                if (verticalCandidate) {
                    long score = width * height + 3L * height * height;
                    if (score > bestScore) {
                        bestScore = score;
                        best = n;
                    }
                }
            }
            for (int i = 0; i < n.getChildCount(); i++) {
                AccessibilityNodeInfo c = n.getChild(i);
                if (c != null) { owned.add(c); queue.add(c); }
            }
        }
        // If no tall vertical viewport exists, do not guess: horizontal carousels are not
        // a safe substitute for the main package list.
        for (AccessibilityNodeInfo c : owned) if (c != best) c.recycle();
        return best;
    }

    void showTest() {
        Compare.Result cr = Compare.run(this, new HashSet<String>());
        if (cr.ranked.isEmpty()) {
            Toast.makeText(this, "هنوز داده‌ای برای نمایش نیست", Toast.LENGTH_SHORT).show();
            return;
        }
        popup.show(cr, new HashSet<String>());
    }

    private void diag(String p, String dump) {
        dumps.put(p, dump);
        long now = System.currentTimeMillis();
        if (now - lastDiag < 3000) return;
        lastDiag = now;
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, String> en : dumps.entrySet()) sb.append("=== ").append(en.getValue()).append('\n');
        try (Writer w = new OutputStreamWriter(new FileOutputStream(new File(getFilesDir(), "diag.txt")), StandardCharsets.UTF_8)) {
            w.write(sb.toString());
        } catch (Exception ignored) {}
    }
}
