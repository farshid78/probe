#!/usr/bin/env python3
"""Validate the versioned fixture corpus, prove it is anonymous, emit a TSV for FixtureMatrix."""
from __future__ import annotations
import importlib.util
import json
import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
PII = re.compile(
    r'(?i)(?:\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b'
    r'|\b[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}\b'
    r'|(?<!\d)(?:(?:\+|00)?98|0)?9[0-9۰-۹]{9}(?!\d)'
    r'|(?<!\d)[0-9۰-۹]{11,}(?!\d)'
    r'|(?:password|editable|isPassword|inputType=password)\s*[=:]\s*(?:1|true|yes))'
)
EXPECTED_IDS = {'irancell', 'mci', 'rightel', 'samantel', 'shatel'}


def load_sanitizer():
    spec = importlib.util.spec_from_file_location(
        'bh_sanitizer', ROOT / 'tools/fixture-sanitizer/sanitize_accessibility.py')
    mod = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(mod)
    return mod.sanitize


def main() -> int:
    manifest = json.loads((HERE / 'corpus.json').read_text(encoding='utf-8'))
    issues = []
    if manifest.get('schema') != 1 or manifest.get('adapter_schema') != 1:
        issues.append('corpus schema version must be 1')
    if manifest.get('apis') != [24, 36]:
        issues.append('corpus must cover API 24 and 36')
    fixtures = manifest.get('fixtures', [])
    if len(fixtures) != 10:
        issues.append(f'expected 10 fixtures, got {len(fixtures)}')
    providers = {f.get('provider') for f in fixtures}
    if providers != EXPECTED_IDS:
        issues.append(f'provider coverage mismatch: {sorted(providers)}')
    sanitize = load_sanitizer()
    rows = [f"schema\t{manifest['schema']}"]
    for f in fixtures:
        rel = f['path']
        path = HERE / rel
        if not path.is_file():
            issues.append(f'missing fixture {rel}')
            continue
        text = path.read_text(encoding='utf-8')
        if '##### WINDOW' not in text or not re.search(r'^\s*#\d+ ', text, re.M):
            issues.append(f'{rel} is not an accessibility tree dump')
        if PII.search(text):
            issues.append(f'{rel} contains a phone/email/UUID/long id/secret marker')
        safe, stats = sanitize(text)
        if safe != text or stats:
            issues.append(f'{rel} is not already anonymous: {stats}')
        if 'vis=0' in text:
            issues.append(f'{rel} hides nodes; corpus fixtures must be fully visible')
        expected = f['expected']
        rows.append('\t'.join([
            f['version'], f['provider'], str(f['api']), f['package'], f['currency'], rel,
            str(expected['items']), str(expected['gb']), str(expected['days']),
            str(expected['toman']), str(expected['currencyKnown']).lower(),
        ]))
    if issues:
        for issue in issues:
            print('FAIL: ' + issue)
        return 1
    print('\n'.join(rows))
    return 0


if __name__ == '__main__':
    sys.exit(main())
