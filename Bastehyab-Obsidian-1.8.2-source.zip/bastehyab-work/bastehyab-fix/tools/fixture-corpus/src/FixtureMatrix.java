package app.bastehyab;

import app.bastehyab.provider.ProviderAdapter;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Replays every versioned, privacy-safe fixture through the real Extractor and asserts
 * the authored expectations. It also verifies that the ProviderAdapter catalogue covers
 * every provider/API combination in the corpus and prints the compatibility matrix.
 */
public final class FixtureMatrix {
    private static int failures;
    private static int checks;

    private static void ok(boolean value, String message) {
        checks++;
        if (!value) { failures++; System.out.println("FAIL: " + message); }
    }

    public static void main(String[] args) throws Exception {
        if (args.length != 2) {
            System.err.println("usage: FixtureMatrix <corpus_dir> <manifest.tsv>");
            System.exit(2);
        }
        Path root = Paths.get(args[0]);
        Path manifest = Paths.get(args[1]);
        int schema = -1;
        Set<String> ids = new HashSet<>(Arrays.asList(ProviderAdapter.ids()));
        Set<String> seen = new HashSet<>();
        int replayed = 0;
        for (String line : Files.readAllLines(manifest)) {
            if (line.isEmpty() || line.startsWith("#")) continue;
            String[] f = line.split("\t", -1);
            if (f.length == 2 && "schema".equals(f[0])) { schema = Integer.parseInt(f[1]); continue; }
            if (f.length != 11) throw new IllegalArgumentException("bad manifest row: " + line);
            String version = f[0], provider = f[1], pkg = f[3], currency = f[4], rel = f[5];
            int api = Integer.parseInt(f[2]);
            int expectedItems = Integer.parseInt(f[6]);
            double gb = Double.parseDouble(f[7]), days = Double.parseDouble(f[8]);
            long toman = Long.parseLong(f[9]);
            boolean currencyKnown = Boolean.parseBoolean(f[10]);

            ProviderAdapter.Profile profile = ProviderAdapter.forId(provider);
            ok(profile != null, "no ProviderAdapter profile for " + provider);
            if (profile == null) continue;
            ok(profile.owns(pkg), "profile does not own package " + pkg);
            ok(profile.currency.equals(currency), "currency mismatch for " + provider);
            ok(profile.supports(api), "unsupported API " + api + " for " + provider);
            ok(ids.contains(provider), "unknown provider id " + provider);
            ok(seen.add(version + "/" + provider + "/api" + api), "duplicate fixture " + provider);

            List<String> dump = Files.readAllLines(root.resolve(rel));
            Op op = new Op(provider, provider, 0, currency, true, pkg);
            op.policy = ProviderAdapter.POLICY_AUTO;
            Extractor.Result result = Extractor.extract(DumpHarness.parse(dump), op, 2320);
            ok(result.items.size() == expectedItems,
                    provider + " api" + api + ": expected " + expectedItems
                            + " offers, got " + result.items.size() + " (" + result.dump + ")");
            if (result.items.isEmpty()) continue;
            Pkg p = result.items.get(0);
            ok(p.gb == gb, provider + " api" + api + ": gb " + p.gb + " != " + gb);
            ok(p.days == days, provider + " api" + api + ": days " + p.days + " != " + days);
            ok(p.toman == toman, provider + " api" + api + ": toman " + p.toman + " != " + toman);
            ok(p.currencyKnown == currencyKnown, provider + " api" + api + ": currencyKnown mismatch");
            ok(!p.ambig, provider + " api" + api + ": fixture must not be ambiguous");
            ok(p.raw != null, provider + " api" + api + ": raw card text must be retained for review");
            replayed++;
        }
        ok(schema == ProviderAdapter.SCHEMA_VERSION,
                "corpus schema " + schema + " != adapter schema " + ProviderAdapter.SCHEMA_VERSION);
        ok(replayed == 10, "expected 10 versioned fixtures, replayed " + replayed);
        System.out.println("--- ProviderAdapter compatibility matrix (provider|currency|anchor|api|status|version):");
        System.out.print(ProviderAdapter.matrix(new int[]{24, 36}));
        if (failures > 0) {
            System.out.println("FAIL: " + failures + " of " + checks + " corpus checks failed.");
            System.exit(1);
        }
        System.out.println("PASS: " + replayed + " versioned privacy-safe fixtures x "
                + checks + " assertions; ProviderAdapter covers all 5 operators on API 24/36.");
    }
}
