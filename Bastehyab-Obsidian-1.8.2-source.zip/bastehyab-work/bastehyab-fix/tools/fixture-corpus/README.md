# Versioned fixture corpus & ProviderAdapter matrix

`corpus.json` is the manifest of **synthetic, already-anonymous** accessibility-tree
dumps. It is versioned (`schema: 1`) and must stay in lockstep with
`ProviderAdapter.SCHEMA_VERSION`. Each of the five built-in operators has one fixture
for Android 7 / API 24 and one for Android 16 / API 36 — ten frames total.

```
tools/fixture-corpus/
  corpus.json                 manifest: version, provider, api, package, currency, expectations
  emit_manifest.py            privacy audit + TSV emitter for the Java matrix runner
  run.sh                      compiles the real Extractor and replays every fixture
  src/FixtureMatrix.java      asserts expectations and prints the compatibility matrix
  v1/<provider>/api{24,36}/01_tree.txt
```

The dumps contain **no** phone numbers, e-mail addresses, UUIDs, long numeric IDs,
tokens, editable/password nodes or hidden nodes. `emit_manifest.py` proves this by running
the repository's own `sanitize_accessibility.py` over each fixture and requiring the output
to be byte-identical with zero redactions. Real captured dumps must never be committed;
sanitize them with `tools/fixture-sanitizer/sanitize_accessibility.py` first and keep them
outside the repository.

`ProviderAdapter` (`app/src/main/java/app/bastehyab/ProviderAdapter.java`) is the single
source of truth for the built-in operator catalogue. `Cfg.defaults()` builds the operators
from it, and `FixtureMatrix` verifies that every fixture's package, currency, API level and
schema version agree with its profile. `tools/dump-replay/run.sh` remains available for
ad-hoc replay of private dumps.

Run everything with `bash tools/run-all-checks.sh` (the corpus runner is one of its suites),
or standalone with `bash tools/fixture-corpus/run.sh`.
