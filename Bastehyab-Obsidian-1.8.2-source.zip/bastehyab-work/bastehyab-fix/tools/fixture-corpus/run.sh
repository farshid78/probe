#!/usr/bin/env bash
# Versioned, anonymized fixture corpus: privacy audit + real-Extractor compatibility matrix.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
HERE="$(cd "$(dirname "$0")" && pwd)"
OUT="$(mktemp -d)"
trap 'rm -rf "$OUT"' EXIT
python3 "$ROOT/tools/generate-resource-stubs.py" >/dev/null
python3 "$HERE/emit_manifest.py" > "$OUT/manifest.tsv"
PARSER="$ROOT/tools/parser-smoke-tests/stubs"
REPLAY="$ROOT/tools/dump-replay/stubs"
APP="$ROOT/app/src/main/java/app/bastehyab"
mkdir -p "$OUT/classes"
javac -d "$OUT/classes" \
  "$PARSER/android/graphics/Rect.java" \
  "$PARSER/org/json/JSONObject.java" \
  "$PARSER/org/json/JSONArray.java" \
  "$PARSER/org/json/JSONException.java" \
  "$REPLAY/android/view/accessibility/AccessibilityNodeInfo.java" \
  "$REPLAY/app/bastehyab/R.java" \
  "$REPLAY/app/bastehyab/S.java" \
  "$APP/Fmt.java" "$APP/Pkg.java" "$APP/Op.java" "$APP/Privacy.java" "$APP/Evidence.java" "$APP/Extractor.java" \
  "$APP/provider/ProviderAdapter.java" \
  "$ROOT/tools/dump-replay/src/DumpHarness.java" \
  "$HERE/src/FixtureMatrix.java"
java -Dfile.encoding=UTF-8 -Dsun.jnu.encoding=UTF-8 -cp "$OUT/classes" \
  app.bastehyab.FixtureMatrix "$HERE" "$OUT/manifest.tsv"
