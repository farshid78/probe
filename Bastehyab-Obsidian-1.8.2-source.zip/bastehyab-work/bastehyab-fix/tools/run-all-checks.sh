#!/usr/bin/env bash
# One entry point for all plain-JVM static checks. The Gradle build runs separately in CI.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
python3 "$ROOT/tools/generate-resource-stubs.py" >/dev/null
for script in \
  "$ROOT/tools/parser-smoke-tests/run.sh" \
  "$ROOT/tools/android-core-smoke-tests/run.sh" \
  "$ROOT/tools/popup-overlay-smoke-tests/run.sh" \
  "$ROOT/tools/backdrop-smoke-tests/run.sh" \
  "$ROOT/tools/fixture-sanitizer/test.sh" \
  "$ROOT/tools/junit-jvm-tests/run.sh" \
  "$ROOT/tools/fixture-corpus/run.sh" \
  "$ROOT/tools/resource-validation/run.sh" \
  "$ROOT/tools/device-acceptance/run.sh" \
  "$ROOT/tools/ui-layout-smoke-tests/run.sh"; do
  echo "== $(basename "$(dirname "$script")")/$(basename "$script") =="
  bash "$script"
done
echo 'PASS: all JVM smoke tests, resource contracts, palette contrast and layout checks.'
