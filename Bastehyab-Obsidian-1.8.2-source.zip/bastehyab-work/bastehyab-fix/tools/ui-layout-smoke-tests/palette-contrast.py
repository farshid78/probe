#!/usr/bin/env python3
"""Check WCAG AA contrast for the three semantic Bastehyab neumorphic themes."""
from __future__ import annotations
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[2]
UI = ROOT / "app/src/main/java/app/bastehyab/UI.java"
source = UI.read_text(encoding="utf-8")


def channel(value: int) -> float:
    v = value / 255.0
    return v / 12.92 if v <= .04045 else ((v + .055) / 1.055) ** 2.4


def luminance(rgb: str) -> float:
    h = rgb.lstrip("#")
    r, g, b = (int(h[i:i + 2], 16) for i in (0, 2, 4))
    return .2126 * channel(r) + .7152 * channel(g) + .0722 * channel(b)


def contrast(a: str, b: str) -> float:
    hi, lo = sorted((luminance(a), luminance(b)), reverse=True)
    return (hi + .05) / (lo + .05)


light_start = source.index("if (light) {")
mono_start = source.index("} else if (mono) {", light_start)
dark_start = source.index("} else {", mono_start)
end = source.index("        if (BODY", dark_start)
blocks = {
    "light": source[light_start:mono_start],
    "mono": source[mono_start:dark_start],
    "dark": source[dark_start:end],
}

TOKENS = ("CARD", "TEXT", "MUTED", "PRIMARY", "ACCENT", "DANGER", "SUCCESS")
DARK_INK = "#16233A"
WHITE_INK = "#FFFFFF"
minimum = 1000.0
for theme, block in blocks.items():
    values = {}
    for token in TOKENS:
        match = re.search(rf"\b{token}\s*=\s*(0xFF[0-9A-Fa-f]{{6}})", block)
        if not match:
            raise SystemExit(f"palette token {token} missing in {theme} theme")
        values[token] = "#" + match.group(1)[4:]
    for token in TOKENS[1:]:
        ratio = contrast(values[token], values["CARD"])
        minimum = min(minimum, ratio)
        if ratio < 4.5:
            raise SystemExit(f"{theme} {token} contrast is {ratio:.2f}:1 (requires 4.5:1)")
    bg = luminance(values["PRIMARY"])
    with_white = (1.0 + .05) / (bg + .05)
    with_dark = (bg + .05) / (luminance(DARK_INK) + .05)
    ink = DARK_INK if with_dark >= with_white else WHITE_INK
    button = contrast(ink, values["PRIMARY"])
    minimum = min(minimum, button)
    if button < 4.5:
        raise SystemExit(f"{theme} primary button text contrast is {button:.2f}:1")
    print(f"PASS: {theme} palette contrast (button {button:.2f}:1)")

# The implementation must use the same contrast-text decision as this test.
assert "0xFF16233A" in source and "0xFFFFFFFF" in source
assert "return withDark >= withWhite ? 0xFF16233A : 0xFFFFFFFF" in source
print(f"PASS: all semantic tokens and primary buttons >= 4.5:1 (minimum {minimum:.2f}:1)")
