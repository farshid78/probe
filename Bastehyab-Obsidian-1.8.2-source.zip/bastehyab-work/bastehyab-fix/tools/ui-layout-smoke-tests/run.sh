#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
python3 "$HERE/palette-contrast.py"
python3 "$HERE/check_ui.py"
