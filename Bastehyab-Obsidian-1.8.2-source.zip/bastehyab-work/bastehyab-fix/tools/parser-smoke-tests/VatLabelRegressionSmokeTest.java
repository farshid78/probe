package app.bastehyab;

import android.view.accessibility.AccessibilityNodeInfo;

/** Regression for field-level VAT evidence: proximity matters, generic tax words do not. */
public final class VatLabelRegressionSmokeTest {
    private static void ok(boolean value, String message) {
        if (!value) throw new AssertionError(message);
    }

    private static Pkg scan(String label, int labelY) {
        AccessibilityNodeInfo root = new AccessibilityNodeInfo(null, 0);
        AccessibilityNodeInfo card = new AccessibilityNodeInfo(null, 0);
        card.add(new AccessibilityNodeInfo("۳۰ روزه ۵ گیگابایت", 30).bounds(0, 30, 100, 50));
        card.add(new AccessibilityNodeInfo("۱۰۰٬۰۰۰ تومان", 60).bounds(0, 60, 100, 80));
        card.add(new AccessibilityNodeInfo(label, labelY).bounds(0, labelY, 100, labelY + 20));
        root.add(card);
        Op op = new Op("x", "آزمایش", 0, "IRT", true, "test.operator");
        Extractor.Result result = Extractor.extract(root, op, 2000);
        ok(result.items.size() == 1, "expected one offer, diagnostics=" + result.dump);
        return result.items.get(0);
    }

    public static void main(String[] args) {
        ok(scan("قابل پرداخت", 80).vatIncluded,
                "a nearby payable label must mark only this amount as VAT-inclusive");
        ok(!scan("قابل پرداخت", 500).vatIncluded,
                "a distant payable label must not be associated with this price");
        ok(!scan("مالیات ۱۰ درصد", 80).vatIncluded,
                "a generic tax percentage is not evidence of a VAT-inclusive amount");
        ok(Extractor.vatIncludedEvidence("شامل ارزش افزوده"),
                "legacy persisted text may still be migrated from explicit evidence");
        ok(!Extractor.vatIncludedEvidence("قیمت پایه"),
                "legacy base-price text must not be misclassified as VAT-inclusive");
        System.out.println("PASS: VAT label proximity, distance guard, strict evidence and legacy migration helper.");
    }
}
