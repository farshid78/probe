package org.json;

/** Mirrors Android's checked org.json exception so JVM harnesses catch real compile errors. */
public class JSONException extends Exception {
    public JSONException(String message) { super(message); }
    public JSONException(String message, Throwable cause) { super(message, cause); }
    public JSONException(Throwable cause) { super(cause); }
}
