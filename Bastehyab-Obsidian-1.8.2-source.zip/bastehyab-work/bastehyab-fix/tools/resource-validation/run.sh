#!/usr/bin/env bash
# Static AAPT-adjacent checks; the authoritative AAPT2 link is :app:assembleDebug in CI.
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
python3 "$HERE/check_assets.py"
