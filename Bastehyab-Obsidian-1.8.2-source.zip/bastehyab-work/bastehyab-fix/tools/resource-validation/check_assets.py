#!/usr/bin/env python3
"""Static AAPT-adjacent validation: resource graph, font tables and the monochrome icon.

The authoritative AAPT2 resource link runs in CI via :app:assembleDebug; this suite makes
the important invariants explicit and fails fast on the plain JVM / in CI before Gradle.
"""
from __future__ import annotations
import re
import struct
import sys
from pathlib import Path
from xml.etree import ElementTree as ET

ROOT = Path(__file__).resolve().parents[2]
RES = ROOT / 'app/src/main/res'
ASSETS = ROOT / 'app/src/main/assets/fonts'
errors: list[str] = []

VALUE_TAGS = {'string', 'color', 'dimen', 'style', 'integer', 'bool', 'plurals',
              'string-array', 'array', 'item', 'attr', 'declare-styleable'}
FILE_TYPES = {'drawable', 'mipmap', 'xml', 'raw', 'anim', 'animator', 'menu',
              'layout', 'color', 'font'}
DEFS: dict[str, set[str]] = {}
REFERENCE = re.compile(r'@(?!\+)(?!android:)(?!null\b)([a-zA-Z]+)/([A-Za-z0-9_.]+)')
FONT_REF = re.compile(r'fonts/([A-Za-z0-9_\-]+\.[ttfotTTFOT]{3})')


def add(kind: str, name: str) -> None:
    DEFS.setdefault(kind, set()).add(name)


def main() -> int:
    xml_files = sorted(RES.rglob('*.xml'))
    for path in RES.rglob('*'):
        if not path.is_file():
            continue
        parts = path.relative_to(RES).parts
        top = parts[0].split('-')[0]
        if top.startswith('values') and path.suffix == '.xml':
            text = path.read_text(encoding='utf-8')
            for tag, name in re.findall(r'<(string|color|dimen|style|integer|bool|plurals|'
                                        r'string-array|array|item|attr)\s+[^>]*name="([^"]+)"', text):
                add('id' if tag == 'item' else tag, name)
            for name in re.findall(r'@\+id/([A-Za-z0-9_]+)', text):
                add('id', name)
        elif top in FILE_TYPES and len(parts) >= 2:
            add(top, path.stem)

    # Parse every resource XML and verify every non-framework reference resolves.
    for path in xml_files:
        text = path.read_text(encoding='utf-8')
        try:
            ET.fromstring(text)
        except ET.ParseError as error:
            errors.append(f'{path.relative_to(ROOT)} is invalid XML: {error}')
            continue
        for kind, name in REFERENCE.findall(text):
            if kind in ('drawable', 'mipmap'):
                known = DEFS.get('drawable', set()) | DEFS.get('mipmap', set())
            else:
                known = DEFS.get(kind, set())
            if name not in known:
                errors.append(f'{path.relative_to(ROOT)} references missing @{kind}/{name}')

    # Font binaries must be real sfnt tables, and every code reference must resolve.
    fonts = sorted(ASSETS.glob('*.ttf'))
    if len(fonts) < 4:
        errors.append(f'expected at least four bundled fonts, found {len(fonts)}')
    for font in fonts:
        head = font.read_bytes()[:4]
        if head not in (b'\x00\x01\x00\x00', b'OTTO', b'true', b'ttcf'):
            errors.append(f'{font.name} has no valid sfnt/TrueType signature: {head!r}')
        if font.stat().st_size < 1000:
            errors.append(f'{font.name} is too small to be a usable font')
        with font.open('rb') as handle:
            handle.seek(4)
            try:
                tables = struct.unpack('>H', handle.read(2))[0]
            except struct.error:
                tables = 0
        if tables == 0:
            errors.append(f'{font.name} declares zero sfnt tables')
    sources = list((ROOT / 'app/src/main/java/app/bastehyab').glob('*.java'))
    referenced_fonts = set()
    for source in sources:
        referenced_fonts.update(FONT_REF.findall(source.read_text(encoding='utf-8')))
    for name in referenced_fonts:
        if not (ASSETS / name).is_file():
            errors.append(f'code references a missing bundled font: fonts/{name}')
    if not referenced_fonts:
        errors.append('no bundled font is referenced from the app sources')

    # Monochrome adaptive icon + legacy density fallback + API scope contract.
    launcher = RES / 'mipmap-anydpi-v26/ic_launcher.xml'
    if not launcher.is_file():
        errors.append('adaptive launcher icon is missing')
    else:
        launcher_text = launcher.read_text(encoding='utf-8')
        if '<monochrome' not in launcher_text or '@drawable/ic_launcher_mono' not in launcher_text:
            errors.append('adaptive icon must declare a monochrome layer')
        if 'ic_launcher_mono' not in DEFS.get('drawable', set()):
            errors.append('the monochrome drawable does not exist')
    for density in ('mdpi', 'hdpi', 'xhdpi', 'xxhdpi', 'xxxhdpi'):
        if not any((RES / f'mipmap-{density}').glob('ic_launcher*')):
            errors.append(f'no API 24-25 launcher fallback in mipmap-{density}')
    v31 = RES / 'values-v31/styles.xml'
    if v31.is_file() and 'enableOnBackInvokedCallback' in v31.read_text(encoding='utf-8'):
        errors.append('API 33 predictive-back opt-in must not live in values-v31')
    manifest = ROOT / 'app/src/main/AndroidManifest.xml'
    if '@mipmap/ic_launcher' not in manifest.read_text(encoding='utf-8'):
        errors.append('manifest must wire @mipmap/ic_launcher')

    if errors:
        for error in errors:
            print('FAIL: ' + error)
        return 1
    print(f'PASS: {len(xml_files)} resource XMLs parse, all @type/name references resolve, '
          f'{len(fonts)} sfnt font tables are valid and referenced, '
          f'monochrome adaptive icon and API 24-25 density fallbacks are wired.')
    return 0


if __name__ == '__main__':
    sys.exit(main())
