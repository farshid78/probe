package app.bastehyab;

import android.view.accessibility.AccessibilityNodeInfo;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Stream;

/**
 * Replays captured accessibility-tree dumps (NN_tree.txt) through the real Extractor.
 * Only synthetic, privacy-sanitized fixtures belong in the repository; real dumps stay
 * outside it. Kept on Java 10-compatible syntax so the plain-JVM ECJ harness can compile
 * it without a --release flag.
 */
public final class DumpHarness {
    static final Pattern LINE = Pattern.compile("^(\\s*)#(\\d+) (\\S+)(.*)$");
    static final Pattern ATTR = Pattern.compile("(\\w+)=\"((?:[^\"\\\\]|\\\\.)*)\"");
    static final Pattern BOUNDS = Pattern.compile("b=(-?\\d+),(-?\\d+),(-?\\d+),(-?\\d+)");

    private DumpHarness() {}

    /** Builds the minimal node tree a dump describes. Each WINDOW block starts a new root sibling. */
    public static AccessibilityNodeInfo parse(List<String> lines) {
        AccessibilityNodeInfo top = new AccessibilityNodeInfo(null, null, null, 0, 0, 0, 0, true);
        Deque<Object[]> stack = new ArrayDeque<>();
        for (String ln : lines) {
            if (ln.startsWith("#####")) { stack.clear(); continue; }
            Matcher m = LINE.matcher(ln);
            if (!m.matches()) continue;
            int indent = m.group(1).length();
            String rest = m.group(4);
            String id = null, text = null, desc = null;
            int l = 0, t = 0, r = 0, b = 0;
            Matcher a = ATTR.matcher(rest);
            while (a.find()) {
                if ("id".equals(a.group(1))) id = a.group(2);
                else if ("text".equals(a.group(1))) text = a.group(2);
                else if ("desc".equals(a.group(1))) desc = a.group(2);
            }
            Matcher bm = BOUNDS.matcher(rest);
            if (bm.find()) {
                l = Integer.parseInt(bm.group(1)); t = Integer.parseInt(bm.group(2));
                r = Integer.parseInt(bm.group(3)); b = Integer.parseInt(bm.group(4));
            }
            boolean vis = !rest.contains("vis=0");
            AccessibilityNodeInfo node = new AccessibilityNodeInfo(id, text, desc, l, t, r, b, vis);
            while (!stack.isEmpty() && ((Integer) stack.peek()[0]) >= indent) stack.pop();
            if (stack.isEmpty()) top.kids.add(node);
            else ((AccessibilityNodeInfo) stack.peek()[1]).kids.add(node);
            stack.push(new Object[]{Integer.valueOf(indent), node});
        }
        return top;
    }

    /** Deterministic, privacy-free description of one extracted package. */
    public static String offerKey(Pkg p) {
        return p.gb + "GB/" + p.days + "d/" + (p.currencyKnown ? p.toman + "T" : "unitUnknown")
                + (p.ambig ? "/AMBIG" : "") + (p.vatIncluded ? "/VAT" : "");
    }

    public static void main(String[] args) throws Exception {
        if (args.length != 3) {
            System.err.println("usage: run.sh <dump_dir> <package> <currency>");
            System.exit(2);
        }
        String dir = args[0], pkg = args[1], cur = args[2];
        Op op = new Op("x", "test", 0, cur, true, pkg);
        List<String> files = new ArrayList<>();
        try (Stream<Path> s = Files.list(Paths.get(dir))) {
            s.filter(p -> p.toString().endsWith("_tree.txt")).sorted().forEach(p -> files.add(p.toString()));
        }
        Map<String, Integer> seen = new TreeMap<>();
        for (String f : files) {
            List<String> lines = Files.readAllLines(Paths.get(f));
            AccessibilityNodeInfo root = parse(lines);
            Extractor.Result res = Extractor.extract(root, op, 2320);
            Path file = Paths.get(f);
            System.out.println("RESULT " + file.getFileName() + " items=" + res.items.size()
                    + " dup=" + res.duplicates + " incomplete=" + res.incomplete
                    + " fullTraversal=" + res.fullTraversal + " prunedHidden=" + res.prunedHidden
                    + " nodes=" + res.nodes);
            for (Pkg p : res.items) {
                String key = offerKey(p);
                seen.merge(key, 1, Integer::sum);
                System.out.println("OFFER " + key);
            }
        }
        System.out.println("--- distinct offers (volume/days/price) across frames:");
        seen.forEach((k, v) -> System.out.println("  " + k + "  x" + v));
    }
}
