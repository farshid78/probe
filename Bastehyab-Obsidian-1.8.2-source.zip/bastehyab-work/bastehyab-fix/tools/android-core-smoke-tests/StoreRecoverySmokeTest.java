package app.bastehyab;

import android.content.Context;
import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.lang.reflect.Field;
import java.util.Collections;
import java.util.Map;

/** Proves atomic backup rotation and retryable, non-destructive recovery from a corrupt primary. */
public final class StoreRecoverySmokeTest {
    private static void ok(boolean value, String message) {
        if (!value) throw new AssertionError(message);
    }

    private static Pkg pkg(String key, long toman) {
        Pkg p = new Pkg();
        p.op = "irancell"; p.key = key; p.title = "بسته پایدار";
        p.gb = 5; p.days = 30; p.toman = toman;
        p.ts = System.currentTimeMillis(); p.currencyKnown = true;
        return p;
    }

    /** The production Store is application-scoped; tests must explicitly reset it between file fixtures. */
    private static void resetForTest() throws Exception {
        Field loaded = Store.class.getDeclaredField("loaded");
        loaded.setAccessible(true); loaded.setBoolean(null, false);
        Field dirty = Store.class.getDeclaredField("dirty");
        dirty.setAccessible(true); dirty.setBoolean(null, false);
        Field lastSave = Store.class.getDeclaredField("lastSave");
        lastSave.setAccessible(true); lastSave.setLong(null, 0L);
        Field map = Store.class.getDeclaredField("m");
        map.setAccessible(true); ((Map<?, ?>) map.get(null)).clear();
    }

    public static void main(String[] args) throws Exception {
        resetForTest();
        File dir = Files.createTempDirectory("bastehyab-store-recovery").toFile();
        Context context = new Context() {
            @Override public File getFilesDir() { return dir; }
        };
        File primary = new File(dir, "data.json");
        File backup = new File(dir, "data.json.bak");

        Pkg first = pkg("stable-1", 100000);
        Store.upsert(context, Collections.singletonList(first));
        Store.flush(context);
        ok(primary.isFile(), "first write must create the primary database");
        String firstJson = new String(Files.readAllBytes(primary.toPath()), StandardCharsets.UTF_8);

        Pkg changed = pkg("stable-1", 120000);
        Store.upsert(context, Collections.singletonList(changed));
        Store.flush(context);
        ok(backup.isFile(), "atomic rotation must retain the previous primary as a backup");
        String backupJson = new String(Files.readAllBytes(backup.toPath()), StandardCharsets.UTF_8);
        String secondJson = new String(Files.readAllBytes(primary.toPath()), StandardCharsets.UTF_8);
        ok(backupJson.equals(firstJson) && !backupJson.equals(secondJson),
                "backup must contain the previous committed state, not the new one");

        try (FileOutputStream out = new FileOutputStream(primary)) {
            out.write("{\"broken\":".getBytes(StandardCharsets.UTF_8));
        }
        ok(backup.isFile(), "corrupting the primary must not delete the backup");
        resetForTest(); // simulate a cold start that must consult the backup
        ok(Store.all(context).size() == 1, "load must recover from the healthy backup");
        ok(Store.all(context).get(0).toman == 100000,
                "recovery must use the healthy backup when the primary is corrupt");
        // A clean candidate must be parsed as a whole: write a valid backup with a corrupt tail.
        resetForTest();
        File secondDir = Files.createTempDirectory("bastehyab-store-retry").toFile();
        Context retry = new Context() {
            @Override public File getFilesDir() { return secondDir; }
        };
        File secondPrimary = new File(secondDir, "data.json");
        File secondBackup = new File(secondDir, "data.json.bak");
        Files.write(secondPrimary.toPath(), "{\"broken\":".getBytes(StandardCharsets.UTF_8));
        Files.write(secondBackup.toPath(), "{not json".getBytes(StandardCharsets.UTF_8));
        ok(Store.all(retry).isEmpty(), "all-corrupt candidates must not leak a partial database");
        Pkg valid = pkg("recovered", 150000);
        org.json.JSONArray good = new org.json.JSONArray();
        good.put(valid.json());
        Files.write(secondPrimary.toPath(), good.toString().getBytes(StandardCharsets.UTF_8));
        ok(Store.all(retry).size() == 1 && Store.all(retry).get(0).toman == 150000,
                "a later access must retry rather than latch onto the failed load");

        deleteTree(dir);
        deleteTree(secondDir);
        System.out.println("PASS: atomic backup rotation, non-destructive recovery and retry after all candidates fail.");
    }

    private static void deleteTree(File file) {
        if (file == null || !file.exists()) return;
        File[] children = file.listFiles();
        if (children != null) for (File child : children) deleteTree(child);
        file.delete();
    }
}
