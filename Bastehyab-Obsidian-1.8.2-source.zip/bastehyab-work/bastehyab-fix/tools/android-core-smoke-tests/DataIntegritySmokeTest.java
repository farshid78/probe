package app.bastehyab;

import android.content.Context;
import java.io.File;
import java.nio.file.Files;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;

/** End-to-end JVM regressions for VAT evidence, manual review freshness and numeric parsing. */
public final class DataIntegritySmokeTest {
    private static void ok(boolean value, String message) {
        if (!value) throw new AssertionError(message);
    }

    public static void main(String[] args) throws Exception {
        File dir = Files.createTempDirectory("bastehyab-data-integrity").toFile();
        Context context = new Context() {
            @Override public File getFilesDir() { return dir; }
        };

        ok(Fmt.parse("۱۲٬۳۴۵", -1) == 12345, "Persian thousands separators must parse");
        ok(Fmt.parse("12,345", -1) == 12345, "ASCII thousands separators must parse");
        ok(Fmt.parse(Fmt.num(12345), -1) == 12345, "display/parse round-trip must preserve grouped values");

        Pkg base = new Pkg();
        base.op = "irancell"; base.key = "vat-review-fixture";
        base.title = "بسته آزمایشی ۱ گیگ";
        base.gb = 1; base.days = 30; base.toman = 150000;
        base.currencyKnown = false; base.ambig = true;
        base.ts = System.currentTimeMillis();
        Store.upsert(context, Collections.singletonList(base));
        Store.flush(context);

        // A record older than the freshness window must not be lost after manual approval.
        long stale = System.currentTimeMillis() - 10L * 86400000L;
        Store.all(context).get(0).ts = stale;
        ok(Compare.run(context, new HashSet<String>()).ranked.isEmpty(),
                "an ambiguous stale record must not enter the definitive ranking");

        ok(Store.saveReview(context, base.key, true, 2, 30, 100000,
                "قیمت نهایی شامل مالیات", true),
                "VAT-aware manual approval must be accepted");
        Pkg raw = Store.all(context).get(0);
        ok(raw.ts > stale, "manual approval must refresh the observation timestamp");
        ok(raw.reviewedVatIncluded, "reviewer's VAT evidence must be persisted separately");
        ok(raw.ambig && !raw.currencyKnown && raw.toman == 150000,
                "raw parser values must remain immutable");
        Pkg effective = raw.comparisonVersion();
        ok(effective != raw && effective.vatIncluded && !effective.ambig,
                "the comparison view must carry the reviewer's VAT evidence");
        ok(Cfg.finalPrice(effective, 10) == 100000,
                "a VAT-inclusive reviewed price must not be taxed a second time");
        ok(!Store.saveReview(context, base.key, true, 2, 0, 100000, "invalid", false),
                "zero validity days must be rejected instead of silently dropping the package");
        ok(!Compare.run(context, new HashSet<String>()).ranked.isEmpty(),
                "an approved fresh record must enter the ranking immediately");

        // The fourth metric is selectable and clamps invalid persisted values.
        Cfg.sp(context).edit().putInt("metricModeVersion", 1).apply();
        Cfg.setInt(context, "metric", 99);
        ok(Cfg.metric(context) == Cfg.PER_GB_MONTH,
                "invalid metric index must clamp to the per-GB-month mode");
        Cfg.setInt(context, "metric", Cfg.PER_GB);

        // VAT label evidence is deliberately strict.
        ok(Extractor.vatIncludedEvidence("قیمت نهایی شامل مالیات"), "explicit final label is VAT evidence");
        ok(Extractor.vatIncludedEvidence("مبلغ قابل پرداخت"), "payable label is VAT evidence");
        ok(!Extractor.vatIncludedEvidence("قیمت پایه"), "base price is not VAT-inclusive evidence");
        ok(!Extractor.vatIncludedEvidence(null), "null text is not VAT evidence");

        Pkg zero = new Pkg(); zero.op = "irancell"; zero.key = "zero"; zero.title = "x";
        zero.gb = 5; zero.days = 0; zero.toman = 100000; zero.currencyKnown = true;
        Pkg positive = new Pkg(); positive.op = "irancell"; positive.key = "zero";
        positive.title = "x"; positive.gb = 5; positive.days = 30; positive.toman = 100000;
        positive.currencyKnown = true; positive.ts = System.currentTimeMillis();
        List<History.Change> changes = History.diff(zero, positive);
        ok(changes.size() == 1 && changes.get(0).percent() == 100.0,
                "0 -> positive validity must be reported as +100%, not dropped");

        deleteTree(dir);
        System.out.println("PASS: grouped-number parsing, VAT evidence, VAT-aware review, freshness, fourth metric and 0->positive history.");
    }

    private static void deleteTree(File file) {
        if (file == null || !file.exists()) return;
        File[] children = file.listFiles();
        if (children != null) for (File child : children) deleteTree(child);
        file.delete();
    }
}
