package android.util; public class Log { public static int w(String t,String m){return 0;} public static int e(String t,String m,Throwable x){return 0;} }
