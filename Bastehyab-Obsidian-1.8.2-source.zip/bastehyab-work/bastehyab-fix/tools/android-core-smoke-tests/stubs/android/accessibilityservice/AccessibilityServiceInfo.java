package android.accessibilityservice; public class AccessibilityServiceInfo { public String[] packageNames; }
