package android.content; public class Intent {
 public static final String ACTION_MAIN="android.intent.action.MAIN", CATEGORY_LAUNCHER="android.intent.category.LAUNCHER";
 public static final int FLAG_ACTIVITY_RESET_TASK_IF_NEEDED=0x00200000;
 public Intent(){} public Intent(String action){}
 public Intent setPackage(String p){return this;} public Intent addCategory(String c){return this;}
 public static final int FLAG_ACTIVITY_NEW_TASK=0x10000000;
 public static final int FLAG_ACTIVITY_CLEAR_TOP=0x04000000;
 public static final int FLAG_ACTIVITY_SINGLE_TOP=0x20000000;
 public Intent setClassName(String packageName,String className){return this;}
 public Intent addFlags(int flags){return this;}
}
