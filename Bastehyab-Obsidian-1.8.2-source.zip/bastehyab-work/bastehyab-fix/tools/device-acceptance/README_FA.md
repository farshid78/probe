<div dir="rtl">

# پروتکل پذیرش دستگاهی (مورد ۱۰)

اجرای واقعی روی پنج اپراتور و Android 7/16 به دستگاه فیزیکی، اپلیکیشنهای واقعی اپراتورها و فعالسازی سرویس Accessibility نیاز دارد و در سندباکس/CI قابل انجام نیست. ابزارهای این پوشه **سطح پذیرش را دقیق و غیرقابل تقلب** میکنند:

```bash
# قالب ۵۰ ردیف خالی (۵ اپراتور × ۲ سطح API × ۵ سناریو)
python3 tools/device-acceptance/acceptance_matrix.py --template > results.csv

# پس از پر کردن روی دستگاه
python3 tools/device-acceptance/acceptance_matrix.py results.csv
```

سناریوها: `launch` (بازشدن اپراتور)، `accessibility_bind` (اتصال سرویس با `packageNames` محدود)، `targeted_scan` (تأیید صفحه و اسکن هدفمند)، `end_of_list` (شواهد `ScanStateMachine` + `ListEndDetector`) و `export_redaction` (تأیید صریح و ناشناسسازی CSV/diag).

هر ردیف باید `PASS`/`FAIL`/`BLOCKED`، مدل دستگاه، نام آزمونگر و توضیح داشته باشد. ماتریس ناقص، ردیف تکراری، `PASS` بدون مدل دستگاه، یا حتی یک `FAIL`/`BLOCKED` باعث خروج nonzero میشود؛ بنابراین نمیتوان ماتریس خالی را «سبز» جا زد.

### دستورات اجرا

```bash
./gradlew :app:assembleDebug :app:assembleAndroidTest
adb install -r app/build/outputs/apk/debug/app-debug.apk
adb install -r app/build/outputs/apk/androidTest/debug/app-debug-androidTest.apk
adb shell am instrument -w -e class app.bastehyab.ScanSessionInstrumentationTest,app.bastehyab.CompareListInstrumentationTest \
  app.bastehyab.debug.test/androidx.test.runner.AndroidJUnitRunner
./gradlew :app:connectedDebugAndroidTest
```

سپس برای هر اپراتور: سرویس را فعال کنید، اپلیکیشن را باز کنید، صفحهٔ بستهها را تأیید کنید، اجازه دهید اسکن کامل شود، خروجی بگیرید و نتیجه را در `results.csv` ثبت کنید. **دامپهای واقعی Accessibility هرگز کامیت نمیشوند**؛ پیش از هرگونه اشتراک، با `tools/fixture-sanitizer/sanitize_accessibility.py` ناشناس و بیرون از مخزن نگهداری شوند.

</div>
