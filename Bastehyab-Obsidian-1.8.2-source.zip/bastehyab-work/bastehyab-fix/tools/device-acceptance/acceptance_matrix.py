#!/usr/bin/env python3
"""Validate the five-operator / two-API device acceptance matrix.

No device is available in the CI sandbox, so this tool does not pretend to run tests.
It defines the exact acceptance surface, emits the empty result template and validates
a filled-in matrix, refusing to report success for missing rows or any FAIL.
"""
from __future__ import annotations
import argparse
import csv
import io
import sys

OPERATORS = ('irancell', 'mci', 'rightel', 'samantel', 'shatel')
APIS = (24, 36)  # Android 7 and Android 16
SCENARIOS = ('launch', 'accessibility_bind', 'targeted_scan', 'end_of_list', 'export_redaction')
FIELDS = ('operator', 'api', 'scenario', 'result', 'device', 'tester', 'notes')
EXPECTED = {(op, api, sc) for op in OPERATORS for api in APIS for sc in SCENARIOS}


def template() -> str:
    out = io.StringIO()
    w = csv.DictWriter(out, fieldnames=FIELDS, lineterminator='\n')
    w.writeheader()
    for op in OPERATORS:
        for api in APIS:
            for sc in SCENARIOS:
                w.writerow({'operator': op, 'api': api, 'scenario': sc,
                            'result': '', 'device': '', 'tester': '', 'notes': ''})
    return out.getvalue()


def validate(text: str) -> tuple[list[str], dict[str, int]]:
    issues: list[str] = []
    seen: set[tuple[str, int, str]] = set()
    counts = {'PASS': 0, 'FAIL': 0, 'BLOCKED': 0}
    reader = csv.DictReader(io.StringIO(text))
    if reader.fieldnames != list(FIELDS):
        issues.append(f'bad CSV header: {reader.fieldnames}')
        return issues, counts
    for line_no, row in enumerate(reader, start=2):
        key = (row['operator'], row['api'], row['scenario'])
        try:
            key = (row['operator'].strip(), int(row['api']), row['scenario'].strip())
        except (ValueError, AttributeError):
            issues.append(f'line {line_no}: invalid operator/api/scenario')
            continue
        if key in seen:
            issues.append(f'line {line_no}: duplicate row {key}')
        seen.add(key)
        status = (row['result'] or '').strip().upper()
        if status not in counts:
            issues.append(f'line {line_no}: result must be PASS, FAIL or BLOCKED (got {status!r})')
            continue
        counts[status] += 1
        if status != 'PASS' and not (row['notes'] or '').strip():
            issues.append(f'line {line_no}: {status} requires an explanatory note')
        if status == 'PASS' and not (row['device'] or '').strip():
            issues.append(f'line {line_no}: PASS requires the device model')
    for missing in sorted(EXPECTED - seen):
        issues.append('missing acceptance row: ' + '/'.join(map(str, missing)))
    for extra in sorted(seen - EXPECTED):
        issues.append('unexpected row: ' + '/'.join(map(str, extra)))
    return issues, counts


def self_test() -> int:
    empty = template()
    issues, _ = validate(empty)
    if not any('result must be PASS' in i for i in issues):
        print('FAIL: an empty template must not be accepted as a passing matrix')
        return 1
    rows = [l.split(',') for l in empty.strip().split('\n')]
    filled = [','.join(r) if i == 0 else ','.join(
        [r[0], r[1], r[2], 'PASS', 'Pixel-8', 'tester', '']) for i, r in enumerate(rows)]
    issues, counts = validate('\n'.join(filled) + '\n')
    if issues or counts['PASS'] != len(EXPECTED):
        print('FAIL: a complete PASS matrix must validate: ' + repr(issues[:3]))
        return 1
    print(f'PASS: acceptance surface covers {len(OPERATORS)} operators x {len(APIS)} API levels '
          f'x {len(SCENARIOS)} scenarios = {len(EXPECTED)} required rows; '
          'empty/incomplete/FAIL matrices are rejected.')
    return 0


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('results', nargs='?', help='filled results CSV')
    ap.add_argument('--template', action='store_true', help='print the empty result template')
    ap.add_argument('--self-test', action='store_true', help='validate the validator itself')
    args = ap.parse_args()
    if args.self_test:
        return self_test()
    if args.template:
        sys.stdout.write(template())
        return 0
    if not args.results:
        ap.error('provide a results CSV, --template or --self-test')
    from pathlib import Path
    path = Path(args.results)
    if not path.is_file():
        print(f'FAIL: missing results file {path}')
        return 1
    issues, counts = validate(path.read_text(encoding='utf-8'))
    if issues:
        for issue in issues[:30]:
            print('FAIL: ' + issue)
        if len(issues) > 30:
            print(f'... and {len(issues) - 30} more')
        return 1
    if counts['FAIL'] or counts['BLOCKED']:
        print(f'FAIL: {counts["FAIL"]} failing and {counts["BLOCKED"]} blocked scenarios; '
              'device acceptance is not complete.')
        return 1
    print(f'PASS: all {len(EXPECTED)} device acceptance rows passed on real devices.')
    return 0


if __name__ == '__main__':
    sys.exit(main())
