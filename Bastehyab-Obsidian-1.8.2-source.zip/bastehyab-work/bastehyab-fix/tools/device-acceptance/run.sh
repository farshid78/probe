#!/usr/bin/env bash
# Validate the acceptance-matrix contract on the JVM; real device runs happen outside CI.
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
python3 "$HERE/acceptance_matrix.py" --self-test
