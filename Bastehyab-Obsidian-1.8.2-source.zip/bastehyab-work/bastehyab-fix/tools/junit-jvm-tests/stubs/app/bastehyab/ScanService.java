package app.bastehyab;
/** Minimal stand-in for Cfg's service-configuration callback; JUnit tests do not start a scan. */
public final class ScanService {
    private ScanService() { }
    public static void refreshServiceInfo() { }
}
