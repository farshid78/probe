package org.junit;
import java.util.Objects;
/** Tiny assertion facade; CI uses the real JUnit 4.13.2 dependency. */
public final class Assert {
    private Assert() { }
    private static void failEquals(Object expected, Object actual) {
        throw new AssertionError("expected <" + expected + "> but was <" + actual + ">");
    }
    public static void assertTrue(boolean condition) {
        if (!condition) throw new AssertionError("expected true");
    }
    public static void assertFalse(boolean condition) {
        if (condition) throw new AssertionError("expected false");
    }
    public static void assertEquals(Object expected, Object actual) {
        if (!Objects.equals(expected, actual)) failEquals(expected, actual);
    }
    public static void assertEquals(long expected, long actual) {
        if (expected != actual) failEquals(expected, actual);
    }
    public static void assertEquals(int expected, int actual) {
        if (expected != actual) failEquals(expected, actual);
    }
    public static void assertEquals(double expected, double actual, double delta) {
        if (Double.isNaN(expected) || Double.isNaN(actual)
                || Math.abs(expected - actual) > delta) failEquals(expected, actual);
    }
    public static void assertNotEquals(Object unexpected, Object actual) {
        if (Objects.equals(unexpected, actual)) {
            throw new AssertionError("values must differ: " + actual);
        }
    }
    public static void assertNotEquals(long unexpected, long actual) {
        if (unexpected == actual) throw new AssertionError("values must differ: " + actual);
    }
    // Message overloads mirror JUnit 4 so tests can explain a failure without a second facade.
    public static void assertTrue(String message, boolean condition) {
        if (!condition) throw new AssertionError(message);
    }
    public static void assertFalse(String message, boolean condition) {
        if (condition) throw new AssertionError(message);
    }
    public static void assertEquals(String message, Object expected, Object actual) {
        if (!Objects.equals(expected, actual)) throw new AssertionError(message + ": " + failEqualsText(expected, actual));
    }
    public static void assertEquals(String message, long expected, long actual) {
        if (expected != actual) throw new AssertionError(message + ": " + failEqualsText(expected, actual));
    }
    public static void assertEquals(String message, int expected, int actual) {
        if (expected != actual) throw new AssertionError(message + ": " + failEqualsText(expected, actual));
    }
    public static void assertEquals(String message, double expected, double actual, double delta) {
        if (Double.isNaN(expected) || Double.isNaN(actual) || Math.abs(expected - actual) > delta)
            throw new AssertionError(message + ": " + failEqualsText(expected, actual));
    }
    public static void assertNotEquals(String message, Object unexpected, Object actual) {
        if (Objects.equals(unexpected, actual)) throw new AssertionError(message + ": both were " + actual);
    }
    public static void assertNotEquals(String message, long unexpected, long actual) {
        if (unexpected == actual) throw new AssertionError(message + ": both were " + actual);
    }
    public static void assertNotNull(String message, Object value) {
        if (value == null) throw new AssertionError(message);
    }
    public static void assertNotNull(Object value) {
        if (value == null) throw new AssertionError("expected non-null");
    }
    public static void assertNull(Object value) {
        if (value != null) throw new AssertionError("expected null but was " + value);
    }
    public static void assertNull(String message, Object value) {
        if (value != null) throw new AssertionError(message);
    }
    private static String failEqualsText(Object expected, Object actual) {
        return "expected <" + expected + "> but was <" + actual + ">";
    }
    public static void fail(String message) { throw new AssertionError(message); }
}
