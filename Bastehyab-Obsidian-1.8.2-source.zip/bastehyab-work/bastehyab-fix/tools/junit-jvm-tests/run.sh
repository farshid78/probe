#!/usr/bin/env bash
# Compile and execute the real app/src/test JUnit regressions with lightweight doubles.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
HERE="$(cd "$(dirname "$0")" && pwd)"
CORE="$ROOT/tools/android-core-smoke-tests/stubs"
PARSER="$ROOT/tools/parser-smoke-tests/stubs"
OUT="$(mktemp -d)"
trap 'rm -rf "$OUT"' EXIT
{
  find "$CORE/android" -name '*.java' -print
  find "$CORE/app/bastehyab" -name '*.java' -print
  find "$HERE/stubs" -name '*.java' -print
  printf '%s\n' "$HERE/AccessibilityConsentTest.java"
  printf '%s\n' \
    "$PARSER/android/graphics/Rect.java" \
    "$PARSER/android/view/accessibility/AccessibilityNodeInfo.java" \
    "$PARSER/org/json/JSONObject.java" \
    "$PARSER/org/json/JSONArray.java"
  for f in Fmt Pkg History HistoryLog Op OpSnapshot ListEndDetector ScanStrategyPolicy \
           Cfg Extractor Compare Store Privacy Evidence ScanPhase ScanStateMachine; do
    printf '%s\n' "$ROOT/app/src/main/java/app/bastehyab/$f.java"
  done
  printf '%s\n' \
    "$ROOT/app/src/main/java/app/bastehyab/provider/ProviderAdapter.java" \
    "$ROOT/app/src/main/java/app/bastehyab/diagnostics/DiagnosticReport.java"
  find "$ROOT/app/src/test/java/app/bastehyab" -name '*.java' -print
  printf '%s\n' "$HERE/JUnitSmokeRunner.java"
} > "$OUT/sources.txt"
mkdir -p "$OUT/classes"
javac -Xlint:all -d "$OUT/classes" @"$OUT/sources.txt"
java -cp "$OUT/classes" app.bastehyab.JUnitSmokeRunner
