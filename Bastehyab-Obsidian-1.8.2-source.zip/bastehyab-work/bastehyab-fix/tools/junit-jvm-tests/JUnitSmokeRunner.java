package app.bastehyab;

import org.junit.Test;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/** Runs the repository's JUnit regressions on a plain JVM, without Robolectric or Gradle. */
public final class JUnitSmokeRunner {
    private static final Class<?>[] TESTS = {
            ListEndDetectorTest.class,
            OpSnapshotTest.class,
            ScanStrategyPolicyTest.class,
            CoreRegressionTest.class,
            PrivacyAndIdentityTest.class
    };

    public static void main(String[] args) throws Exception {
        int count = 0;
        for (Class<?> test : TESTS) {
            Object instance = test.getDeclaredConstructor().newInstance();
            for (Method method : test.getDeclaredMethods()) {
                if (!method.isAnnotationPresent(Test.class)) continue;
                method.setAccessible(true);
                try {
                    method.invoke(instance);
                } catch (InvocationTargetException wrapped) {
                    Throwable cause = wrapped.getCause();
                    if (cause instanceof Exception) throw (Exception) cause;
                    if (cause instanceof Error) throw (Error) cause;
                    throw wrapped;
                }
                count++;
            }
        }
        System.out.println("PASS: " + count + " JUnit regressions on the plain JVM.");
    }
}
