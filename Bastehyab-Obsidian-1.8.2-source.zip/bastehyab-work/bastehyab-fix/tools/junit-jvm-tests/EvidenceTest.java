package app.bastehyab;

import android.view.accessibility.AccessibilityNodeInfo;
import org.junit.Test;
import java.util.HashSet;
import java.util.Set;
import static org.junit.Assert.*;

/** Field-level provenance regressions: privacy, persistence and manual-review auditing. */
public final class EvidenceTest {

    private static Pkg scan() {
        AccessibilityNodeInfo root = new AccessibilityNodeInfo(null, 0);
        AccessibilityNodeInfo card = new AccessibilityNodeInfo(null, 0);
        card.add(new AccessibilityNodeInfo("۳۰ روزه ۵ گیگابایت", 30));
        card.add(new AccessibilityNodeInfo("۶۲۶٬۶۰۰ ریال", 60));
        root.add(card);
        Op op = new Op("irancell", "test", 0, "AUTO", true, "com.myirancell");
        Extractor.Result result = Extractor.extract(root, op, 2000);
        assertEquals(1, result.items.size());
        return result.items.get(0);
    }

    @Test public void evidenceIsStructuralAndNeverContainsRawPageText() {
        Evidence e = Evidence.of(Evidence.Field.PRICE, Evidence.Method.EXPLICIT_LABEL,
                "com.myirancell:id/price", 0.95, true, "irancell", "62660");
        assertEquals(Evidence.Field.PRICE, e.field);
        assertEquals(Evidence.Method.EXPLICIT_LABEL, e.method);
        assertEquals(0.95, e.confidence, 0.0001);
        assertTrue(e.vatIncluded);
        assertEquals(16, e.fingerprint.length());
        assertTrue(e.fingerprint.matches("[0-9a-f]{16}"));
        assertTrue(e.nodeId.matches("[0-9a-f]{1,16}"));
        assertFalse("raw view ids must not be persisted",
                e.nodeId.contains("myirancell") || e.nodeId.contains("price"));
        assertFalse("raw page text must not be persisted", e.fingerprint.contains("62660"));
        assertTrue(Evidence.hasStrongSupport(java.util.Collections.singletonList(e)));
        assertFalse(Evidence.hasStrongSupport(java.util.Collections.singletonList(
                Evidence.of(Evidence.Field.PRICE, Evidence.Method.HEURISTIC,
                        "x", 0.4, false, "x"))));
    }

    @Test public void extractedPackagesCarryFieldLevelEvidence() {
        Pkg p = scan();
        assertFalse("every extracted package must explain itself", p.evidences.isEmpty());
        Set<Evidence.Field> fields = new HashSet<>();
        for (Evidence e : p.evidences) {
            fields.add(e.field);
            assertTrue(e.confidence >= 0d && e.confidence <= 1d);
            assertEquals(16, e.fingerprint.length());
        }
        assertTrue(fields.contains(Evidence.Field.PRICE));
        assertTrue(fields.contains(Evidence.Field.CURRENCY));
        assertTrue(fields.contains(Evidence.Field.VOLUME));
        assertTrue(fields.contains(Evidence.Field.DURATION));
        assertTrue("an explicitly labelled Rial price is strong evidence",
                Evidence.hasStrongSupport(p.evidences));
        String fingerprint = p.evidenceFingerprint();
        assertEquals(16, fingerprint.length());
        assertEquals(fingerprint, p.evidenceFingerprint());
        assertNotEquals("evidence must be part of the stronger fingerprint",
                p.sourceFingerprint(), fingerprint);
    }

    @Test public void evidenceSurvivesJsonRoundTrip() throws Exception {
        Pkg original = scan();
        Pkg restored = Pkg.from(original.json());
        assertEquals(original.evidences.size(), restored.evidences.size());
        for (int i = 0; i < original.evidences.size(); i++) {
            assertEquals(original.evidences.get(i).field, restored.evidences.get(i).field);
            assertEquals(original.evidences.get(i).method, restored.evidences.get(i).method);
            assertEquals(original.evidences.get(i).fingerprint, restored.evidences.get(i).fingerprint);
            assertEquals(original.evidences.get(i).confidence,
                    restored.evidences.get(i).confidence, 0.0001);
        }
        assertEquals(original.evidenceFingerprint(), restored.evidenceFingerprint());
    }

    @Test public void manualReviewIsAnAuditableEvidenceSource() {
        Pkg p = scan();
        p.reviewStatus = "approved";
        p.reviewSourceFingerprint = p.sourceFingerprint();
        p.reviewedAt = System.currentTimeMillis();
        p.reviewedGb = 6; p.reviewedDays = 30; p.reviewedToman = 70000;
        p.reviewedVatIncluded = true;
        assertTrue(p.hasCurrentManualApproval());
        Pkg effective = p.comparisonVersion();
        boolean manual = false;
        for (Evidence e : effective.evidences) {
            if (e.method == Evidence.Method.MANUAL_REVIEW && e.field == Evidence.Field.PRICE) manual = true;
        }
        assertTrue("the comparison view must record the human correction", manual);
        assertEquals(70000L, effective.toman);
        assertTrue(effective.vatIncluded);
        assertFalse("raw extraction must remain untouched", p.toman == 0);
    }
}
