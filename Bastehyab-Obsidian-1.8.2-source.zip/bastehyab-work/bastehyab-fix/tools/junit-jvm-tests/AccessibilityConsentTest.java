package app.bastehyab;

import android.content.Context;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 * Plain-JVM regression for versioned affirmative consent. It lives outside app/src/test
 * because Gradle unit tests compile against the abstract Android Context, while this
 * harness supplies a concrete in-memory double.
 */
public final class AccessibilityConsentTest {

    @Test public void consentStartsUngrantedAndSurvivesNewContexts() {
        Context context = new Context();
        assertFalse(Cfg.accessibilityConsentGranted(context));
        assertFalse("a null context must never be treated as consent",
                Cfg.accessibilityConsentGranted(null));
        Cfg.grantAccessibilityConsent(context);
        assertTrue(Cfg.accessibilityConsentGranted(context));
        assertTrue("consent is stored in application preferences, not a transient field",
                Cfg.accessibilityConsentGranted(new Context()));
    }

    @Test public void consentCanBeWithdrawn() {
        Context context = new Context();
        Cfg.grantAccessibilityConsent(context);
        Cfg.revokeAccessibilityConsent(context);
        assertFalse(Cfg.accessibilityConsentGranted(context));
    }
}
