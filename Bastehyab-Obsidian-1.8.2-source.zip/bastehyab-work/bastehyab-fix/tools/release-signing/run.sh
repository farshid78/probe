#!/usr/bin/env bash
# Static + live-keystore checks for the always-signed release pipeline.
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
python3 "$HERE/check_release_signing.py"
