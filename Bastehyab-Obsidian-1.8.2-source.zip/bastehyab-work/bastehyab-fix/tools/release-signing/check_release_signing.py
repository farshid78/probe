#!/usr/bin/env python3
"""Contract checks for the always-signed, installable release pipeline."""
from __future__ import annotations
from pathlib import Path
import hashlib
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[2]
errors: list[str] = []


def check(condition: bool, message: str) -> None:
    if not condition:
        errors.append(message)


def read(relative: str) -> str:
    path = ROOT / relative
    check(path.is_file(), f"missing {relative}")
    return path.read_text(encoding="utf-8") if path.is_file() else ""


workflow = read(".github/workflows/build.yml")
gradle = read("app/build.gradle")
gitignore = read(".gitignore")
guide = read("RELEASE_SIGNING_FA.md")
key = ROOT / "ci-preview.p12"
props = ROOT / "ci-preview.properties.example"

check(key.is_file(), "the public CI preview keystore is missing")
digest = ""
if key.is_file():
    raw = key.read_bytes()
    check(len(raw) > 1000 and raw[:1] == b"\x30",
          "ci-preview.p12 is not a plausible PKCS12 DER container")
    digest = hashlib.sha256(raw).hexdigest()
    check(digest in workflow, "CI must pin the SHA-256 of ci-preview.p12")
    check("PREVIEW_KEY_SHA256" in workflow and "sha256sum -c -" in workflow,
          "CI must verify the preview keystore digest before using it")

check("!ci-preview.p12" in gitignore,
      "the public preview keystore must be explicitly unignored")
check(props.is_file(), "ci-preview.properties.example is missing")
values: dict[str, str] = {}
if props.is_file():
    for line in props.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            name, value = line.split("=", 1)
            values[name.strip()] = value.strip()
    check(values.get("storeFile") == "ci-preview.p12",
          "preview properties must point at the committed keystore")
    check((ROOT / values.get("storeFile", "")).is_file(),
          "preview properties point at a missing keystore")
    check(all(values.get(k) for k in ("storePassword", "keyAlias", "keyPassword")),
          "preview properties must contain all four signing values")
    check("PUBLIC" in props.read_text(encoding="utf-8").upper()
          and "NOT" in props.read_text(encoding="utf-8").upper(),
          "preview properties must warn that the key is public and not for production")

# A live keytool load proves the committed keystore really contains a usable
# private key + certificate, not just a plausible-looking file.
keytool = shutil.which("keytool")
if keytool and key.is_file() and values.get("keyAlias") and values.get("storePassword"):
    result = subprocess.run(
        [keytool, "-list", "-keystore", str(key),
         "-storepass", values["storePassword"], "-storetype", "PKCS12",
         "-alias", values["keyAlias"]],
        capture_output=True, text=True, check=False)
    check(result.returncode == 0 and "PrivateKeyEntry" in result.stdout,
          "the committed preview keystore cannot be opened with its documented "
          "alias/password: " + result.stderr.strip()[:200])
    print("PASS: preview keystore opens with keytool and contains a PrivateKeyEntry")
else:
    print("NOTE: keytool unavailable on PATH; skipped live keystore load")

check("BH_SIGNING_MODE=production" in workflow
      and "BH_SIGNING_MODE=preview" in workflow,
      "CI must distinguish private production signing from public preview signing")
check("if: env.KEYSTORE_BASE64 != ''" in workflow
      and "if: env.KEYSTORE_BASE64 == ''" in workflow,
      "both signing paths must be selected explicitly")
check("apksigner verify --verbose" in workflow and "*unsigned*" in workflow,
      "CI must verify the APK signature and reject unsigned APKs")
check("Build and verify an installable signed Release APK" in workflow
      and "Upload the verified signed Release APK" in workflow
      and "installable-release-preview-" in workflow,
      "every push must build, verify and upload an installable signed APK artifact")
check("app/build/outputs/apk/release/*.apk" not in workflow,
      "CI must never publish Gradle's raw unsigned output glob")
check("release-assets/" in workflow
      and "Bastehyab-${BH_VERSION_NAME}-${BH_VERSION_CODE}-" in workflow,
      "CI must publish a branded, versioned APK from a verified staging directory")
check("app-release-unsigned.apk" in workflow and "Refusing to publish" in workflow,
      "CI must explicitly reject app-release-unsigned.apk")
check("if: always()" in workflow
      and "Remove signing material from the runner" in workflow,
      "signing material cleanup must run in both modes")
check("tasks.matching { it.name == 'assembleRelease' }" in gradle
      and "signingPropertiesFile.isFile()" in gradle,
      "Gradle must fail closed when a Release build has no signing material")
check("ci-preview.p12" in guide and "KEYSTORE_BASE64" in guide
      and "apksigner" in guide,
      "RELEASE_SIGNING_FA.md must document both signing paths and verification")

for message in errors:
    print("FAIL:", message, file=sys.stderr)
if errors:
    sys.exit(1)
print(f"PASS: always-signed release contracts ({digest[:12]}...), "
      "production + public preview paths, apksigner gate, branded asset name.")
