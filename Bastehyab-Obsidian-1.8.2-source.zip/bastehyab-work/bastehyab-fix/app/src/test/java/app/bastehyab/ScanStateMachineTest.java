package app.bastehyab;

import org.junit.Test;
import static org.junit.Assert.*;
import static app.bastehyab.ScanStateMachine.Event;
import static app.bastehyab.ScanStateMachine.State;

/** Every legal/illegal transition of the scan session is exercised on the plain JVM. */
public final class ScanStateMachineTest {

    @Test public void startRequiresConfirmThenAnObservedTargetBeforeScanning() {
        ScanStateMachine m = new ScanStateMachine();
        assertEquals(State.IDLE, m.state());
        assertFalse(m.isActive());
        assertEquals(ScanPhase.IDLE, m.phase());
        assertTrue(m.dispatch(Event.START));
        assertEquals(State.WAITING_CONFIRM, m.state());
        assertTrue(m.isAwaitingConfirm());
        assertFalse("cannot scan before the user confirms the offers page",
                m.dispatch(Event.BEGIN_SCAN));
        assertTrue(m.dispatch(Event.CONFIRM));
        assertEquals(State.WAITING_PAGE, m.state());
        assertTrue(m.isConfirmed());
        assertFalse("cannot scan before the target package window was observed",
                m.dispatch(Event.BEGIN_SCAN));
        assertTrue(m.dispatch(Event.TARGET_SEEN));
        assertTrue(m.isTargetObserved());
        assertTrue(m.dispatch(Event.BEGIN_SCAN));
        assertEquals(State.SCANNING, m.state());
        assertEquals(ScanPhase.SCANNING, m.phase());
    }

    @Test public void pauseAndResumePreserveTheExactPreviousState() {
        ScanStateMachine waiting = new ScanStateMachine();
        waiting.dispatch(Event.START);
        waiting.dispatch(Event.CONFIRM);
        assertTrue(waiting.dispatch(Event.PAUSE));
        assertEquals(State.PAUSED, waiting.state());
        assertEquals(ScanPhase.PAUSED, waiting.phase());
        assertTrue(waiting.dispatch(Event.RESUME));
        assertEquals(State.WAITING_PAGE, waiting.state());

        ScanStateMachine scanning = new ScanStateMachine();
        scanning.dispatch(Event.START);
        scanning.dispatch(Event.CONFIRM);
        scanning.dispatch(Event.TARGET_SEEN);
        scanning.dispatch(Event.BEGIN_SCAN);
        scanning.dispatch(Event.PAUSE);
        scanning.dispatch(Event.RESUME);
        assertEquals(State.SCANNING, scanning.state());
        assertTrue(scanning.isScanning());
        assertEquals(0, scanning.rejected());
    }

    @Test public void illegalTransitionsAreRejectedWithoutMutatingState() {
        ScanStateMachine m = new ScanStateMachine();
        assertFalse(m.dispatch(Event.PAUSE));
        assertFalse(m.dispatch(Event.RESUME));
        assertFalse(m.dispatch(Event.CONFIRM));
        assertFalse(m.dispatch(Event.STOP));
        assertEquals(State.IDLE, m.state());
        assertEquals(4, m.rejected());
        assertTrue(m.lastRejection().contains("STOP"));
        assertTrue(m.diagnostics().contains("rejected=4"));
        assertTrue(m.dispatch(Event.START));
        assertEquals("a rejected event must not be counted as a transition", 1, m.transitions());
    }

    @Test public void stopAndFailureAreTerminalAndRestartIsClean() {
        ScanStateMachine done = new ScanStateMachine();
        done.dispatch(Event.START);
        done.stop(true);
        assertEquals(State.FINISHED, done.state());
        assertTrue(done.isFinished());
        assertFalse(done.isActive());
        assertEquals(ScanPhase.FINISHED, done.phase());

        ScanStateMachine failed = new ScanStateMachine();
        failed.dispatch(Event.START);
        failed.dispatch(Event.FAIL);
        assertEquals(ScanPhase.ERROR, failed.phase());
        assertTrue(failed.dispatch(Event.START));
        assertEquals(State.WAITING_CONFIRM, failed.state());
        assertFalse("a restarted session must forget the old target observation",
                failed.isTargetObserved());

        ScanStateMachine idle = new ScanStateMachine();
        idle.dispatch(Event.START);
        idle.stop(false);
        assertEquals(State.IDLE, idle.state());
        assertFalse(idle.isFinished());
    }
}
