package app.bastehyab;

import org.junit.Test;
import java.util.Arrays;
import static org.junit.Assert.*;

/** Privacy redaction, stable offer identity and 64-bit fingerprint regressions. */
public final class PrivacyAndIdentityTest {
    @Test public void freeTextExportsRedactPersonalIdentifiers() {
        String scrubbed = Privacy.scrub(
                "شماره ۰۹۱۲۳۴۵۶۷۸۹ و user@example.com و 123456789012345 "
                        + "و 550E8400-E29B-41D4-A716-446655440000");
        assertTrue(scrubbed.contains("[PHONE]"));
        assertTrue(scrubbed.contains("[EMAIL]"));
        assertTrue(scrubbed.contains("[ID]"));
        assertTrue(scrubbed.contains("[UUID]"));
        assertFalse(scrubbed.contains("09123456789"));
        assertFalse(scrubbed.contains("user@example.com"));
        assertFalse(scrubbed.contains("123456789012345"));
        assertFalse(scrubbed.contains("550E8400-E29B-41D4-A716-446655440000"));
        assertEquals("", Privacy.scrub(null));
    }

    @Test public void dynamicCountersDoNotCreateDuplicateRecords() {
        String first = Extractor.keyOf("mci", "۵ گیگ ۳۰ روزه | موجودی ۱۲", null, "", 5, 30);
        String second = Extractor.keyOf("mci", "۵ گیگ ۳۰ روزه | موجودی ۹۸۷", null, "", 5, 30);
        assertEquals(first, second);
        assertNotEquals(first, Extractor.keyOf("mci", "۵ گیگ ۳۰ روزه", null, "", 6, 30));
        assertNotEquals(first, Extractor.keyOf("mci", "۵ گیگ ۳۰ روزه", null, "", 5, 7));
        assertNotEquals(first, Extractor.keyOf("mci", "۵ گیگ ۳۰ روزه", null, "شبانه", 5, 30));
    }

    @Test public void viewportFingerprintsUseFullSixtyFourBits() {
        long a = Privacy.hash64(Arrays.asList("offer-A@12:34", "offer-B@56:78"));
        long again = Privacy.hash64(Arrays.asList("offer-A@12:34", "offer-B@56:78"));
        long b = Privacy.hash64(Arrays.asList("offer-A@12:34", "offer-C@56:78"));
        assertEquals(a, again);
        assertNotEquals(a, b);
        assertTrue(Long.toHexString(a).length() > 8);
    }
}
