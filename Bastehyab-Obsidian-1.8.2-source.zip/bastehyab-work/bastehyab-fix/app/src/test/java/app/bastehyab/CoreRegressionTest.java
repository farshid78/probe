package app.bastehyab;

import org.junit.Test;
import java.util.List;
import static org.junit.Assert.*;

/** Pure JVM regressions for data-integrity bugs found in the 88-item audit. */
public final class CoreRegressionTest {
    private static Pkg pkg(double gb, double days, long toman, boolean vatIncluded) {
        Pkg p = new Pkg();
        p.op = "irancell"; p.key = "fixture"; p.title = "بسته آزمایشی";
        p.gb = gb; p.days = days; p.toman = toman;
        p.ts = System.currentTimeMillis();
        p.currencyKnown = true; p.ambig = false; p.vatIncluded = vatIncluded;
        return p;
    }

    @Test public void groupingSeparatorsRoundTripThroughParse() {
        assertEquals(12345.0, Fmt.parse("۱۲٬۳۴۵", -1), 0.0001);
        assertEquals(12345.0, Fmt.parse("12,345", -1), 0.0001);
        assertEquals(12345.0, Fmt.parse(Fmt.num(12345), -1), 0.0001);
        assertEquals(1.5, Fmt.parse("۱٫۵", -1), 0.0001);
    }

    @Test public void vatInclusivePricesAreNeverTaxedTwice() {
        Pkg plain = pkg(10, 30, 100000, false);
        Pkg inclusive = pkg(10, 30, 100000, true);
        assertEquals(110000L, Cfg.finalPrice(plain, 10));
        assertEquals(100000L, Cfg.finalPrice(inclusive, 10));
    }

    @Test public void fourthMetricUsesPricePerGbMonth() {
        Pkg p = pkg(10, 30, 100000, false);
        assertEquals(10000.0, Compare.value(p, Cfg.PER_GB_MONTH, 30, 100000), 0.0001);
        assertEquals(10000.0, Compare.value(p, Cfg.PER_GB, 30, 100000), 0.0001);
        assertEquals(-30.0, Compare.value(p, Cfg.DURATION, 30, 100000), 0.0001);
        assertEquals(Double.MAX_VALUE, Compare.value(pkg(10, 0, 100000, false),
                Cfg.PER_GB_MONTH, 30, 100000), 0.0001);
    }

    @Test public void zeroToPositiveHistoryIsReportedAsGrowth() {
        Pkg old = pkg(5, 0, 100000, false);
        Pkg current = pkg(5, 30, 100000, false);
        current.key = old.key;
        List<History.Change> changes = History.diff(old, current);
        assertEquals(1, changes.size());
        assertEquals("days", changes.get(0).field);
        assertEquals(0.0, changes.get(0).before, 0.0001);
        assertEquals(30.0, changes.get(0).after, 0.0001);
        assertEquals(100.0, changes.get(0).percent(), 0.0001);
    }

    @Test public void onlyExplicitLabelsCountAsVatEvidence() {
        assertTrue(Extractor.vatIncludedEvidence("قیمت نهایی شامل مالیات"));
        assertTrue(Extractor.vatIncludedEvidence("مبلغ قابل پرداخت"));
        assertFalse(Extractor.vatIncludedEvidence("قیمت پایه"));
        assertFalse(Extractor.vatIncludedEvidence("مالیات ۱۰ درصد"));
        assertFalse(Extractor.vatIncludedEvidence(null));
    }

    @Test public void reviewedVatEvidenceAppliesToTheEffectiveComparisonPackage() {
        Pkg raw = pkg(5, 30, 150000, false);
        raw.ambig = true; raw.currencyKnown = false;
        raw.reviewStatus = "approved";
        raw.reviewedGb = 6; raw.reviewedDays = 30; raw.reviewedToman = 120000;
        raw.reviewedVatIncluded = true;
        raw.reviewedAt = System.currentTimeMillis();
        raw.reviewSourceFingerprint = raw.sourceFingerprint();
        assertTrue(raw.hasCurrentManualApproval());
        Pkg effective = raw.comparisonVersion();
        assertTrue(effective.vatIncluded);
        assertFalse(effective.ambig);
        assertTrue(effective.currencyKnown);
        assertEquals(120000L, Cfg.finalPrice(effective, 10));
    }
}
