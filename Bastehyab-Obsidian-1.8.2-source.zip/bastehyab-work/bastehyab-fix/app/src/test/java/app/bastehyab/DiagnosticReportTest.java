package app.bastehyab;

import app.bastehyab.diagnostics.DiagnosticReport;
import org.junit.Test;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import static org.junit.Assert.*;

/** The diagnostics module is pure Java, deterministic and independent of Android types. */
public final class DiagnosticReportTest {

    @Test public void reportIsSortedDeterministicAndPrivacyFree() {
        Map<String, List<String>> dumps = new LinkedHashMap<>();
        dumps.put("com.shmapp", Arrays.asList("frame-a", "frame-b"));
        dumps.put("com.myirancell", Arrays.asList("frame-c"));
        DiagnosticReport report = new DiagnosticReport()
                .header("Bastehyab", "1.9.0")
                .line("status", "scan-finished")
                .line("lastOpId=irancell noNew=0")
                .sections(dumps);
        String first = report.render();
        assertEquals(first, new DiagnosticReport()
                .header("Bastehyab", "1.9.0")
                .line("status", "scan-finished")
                .line("lastOpId=irancell noNew=0")
                .sections(dumps).render());
        assertTrue(first.contains("=== package=com.myirancell snapshots=1"));
        assertTrue(first.indexOf("com.myirancell") < first.indexOf("com.shmapp"));
        assertTrue(first.contains("--- snapshot 2 ---"));
        assertTrue(first.endsWith("\n"));
        // The builder emits exactly what callers pass: it never invents or reverses redaction.
        assertEquals("status=[REDACTED]\n",
                new DiagnosticReport().line("status", "[REDACTED]").render());
    }

    @Test public void emptyAndNullSectionsAreSafe() {
        assertEquals("Bastehyab diagnostic • version 1.9.0\n",
                new DiagnosticReport().header("Bastehyab", "1.9.0").render());
        assertNotNull(new DiagnosticReport().sections(null).render());
        assertNotNull(new DiagnosticReport().sections(new HashMap<String, List<String>>()).render());
        assertEquals("k=7\n", new DiagnosticReport().line("k", 7).render());
    }
}
