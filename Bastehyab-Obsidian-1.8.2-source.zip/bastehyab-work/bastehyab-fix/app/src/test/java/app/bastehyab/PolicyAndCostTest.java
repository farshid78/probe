package app.bastehyab;

import app.bastehyab.provider.ProviderAdapter;

import org.junit.Test;
import static org.junit.Assert.*;

/** Single-source-of-truth regressions for policies, VAT and cost arithmetic. */
public final class PolicyAndCostTest {
    private static Pkg pkg(double gb, double days, long toman, boolean vat) {
        Pkg p = new Pkg();
        p.op = "irancell"; p.key = "cost"; p.title = "test";
        p.gb = gb; p.days = days; p.toman = toman;
        p.ts = System.currentTimeMillis();
        p.currencyKnown = true; p.ambig = false; p.vatIncluded = vat;
        return p;
    }

    @Test public void vatIsAppliedExactlyOnceAndOnlyInPkg() {
        Pkg plain = pkg(10, 30, 100000, false);
        Pkg inclusive = pkg(10, 30, 100000, true);
        assertEquals(110000L, plain.finalToman(10));
        assertEquals(100000L, inclusive.finalToman(10));
        assertEquals("Cfg must delegate to the one VAT rule", plain.finalToman(10), Cfg.finalPrice(plain, 10));
        assertEquals(inclusive.finalToman(10), Cfg.finalPrice(inclusive, 10));
    }

    @Test public void compareDelegatesToPackageCostArithmetic() {
        Pkg p = pkg(10, 30, 100000, false);
        long price = Cfg.finalPrice(p, 10); // 110000
        double ratio = (double) price / p.toman;
        assertEquals(p.perGbMonth() * ratio, Compare.value(p, Cfg.PER_GB_MONTH, 30, price), 0.0001);
        assertEquals(p.monthlyCost(30) * ratio, Compare.value(p, Cfg.MY_USAGE, 30, price), 0.0001);
        assertEquals(price / p.gb, Compare.value(p, Cfg.PER_GB, 30, price), 0.0001);
        assertEquals(-30.0, Compare.value(p, Cfg.DURATION, 30, price), 0.0001);
        assertEquals(Double.MAX_VALUE, Compare.value(pkg(10, 0, 100000, false),
                Cfg.PER_GB_MONTH, 30, price), 0.0001);
    }

    @Test public void vatAwareHelpersAgreeWithTheBaseCalculation() {
        Pkg p = pkg(10, 30, 100000, false);
        double ratio = (double) p.finalToman(10) / p.toman;
        assertEquals(p.perGbMonth() * ratio, p.perGbMonth(10), 0.0001);
        assertEquals(p.monthlyCost(30) * ratio, p.monthlyCost(30, 10), 0.0001);
        Pkg weekly = pkg(2, 7, 40000, false);
        assertEquals(weekly.monthlyCost(30) * ((double) weekly.finalToman(10) / weekly.toman),
                weekly.monthlyCost(30, 10), 0.0001);
    }

    @Test public void policyNormalizationAndCatalogueAreConsistent() {
        assertEquals(ProviderAdapter.POLICY_AUTO, ProviderAdapter.normalizePolicy(-1));
        assertEquals(ProviderAdapter.POLICY_LARGEST, ProviderAdapter.normalizePolicy(1));
        assertEquals(ProviderAdapter.POLICY_SMALLEST, ProviderAdapter.normalizePolicy(2));
        assertEquals(ProviderAdapter.POLICY_AUTO, ProviderAdapter.normalizePolicy(9));
        assertEquals(5, ProviderAdapter.all().size());
        assertNotNull(ProviderAdapter.forPackage("com.myirancell"));
        assertNull(ProviderAdapter.forPackage("com.unknown"));
        assertTrue(ProviderAdapter.forId("samantel").supports(24));
        assertTrue(ProviderAdapter.forId("samantel").supports(36));
    }

    @Test public void acceptedButImmobileForwardActionIsNotIndependentProof() {
        ListEndDetector d = new ListEndDetector();
        assertEquals(ListEndDetector.State.UNKNOWN, d.observe(100, 100, false, false, 1));
        // Android accepted ACTION_SCROLL_FORWARD, but the viewport did not move: no proof.
        assertEquals(ListEndDetector.State.UNKNOWN, d.observe(100, 100, false, true, 2));
        assertEquals(ListEndDetector.State.UNKNOWN, d.observe(100, 100, false, true, 3));
        assertEquals(ListEndDetector.State.UNKNOWN, d.observe(100, 100, false, true, 4));
        assertEquals(ListEndDetector.State.UNKNOWN, d.observe(100, 100, false, false, 5));
        assertEquals(ListEndDetector.State.END_CONFIRMED, d.observe(100, 100, false, false, 6));
    }
}
