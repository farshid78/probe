package app.bastehyab;

import android.content.Context;
import java.util.Locale;

/** One application-scoped resource accessor; UI code never embeds Persian literals. */
final class S {
    private static Context app;

    private S() { }

    static synchronized void init(Context context) {
        if (app == null && context != null) app = context.getApplicationContext();
    }

    static String s(int id) {
        Context context = app;
        return context == null ? fallback(id) : context.getResources().getString(id);
    }

    static String s(int id, Object... args) {
        Context context = app;
        if (context == null) return String.format(Locale.US, fallback(id), args);
        return context.getResources().getString(id, args);
    }

    /** Safe fallback for JVM smoke tests; the generated test double overrides this method. */
    static String fallback(int id) { return ""; }
}
