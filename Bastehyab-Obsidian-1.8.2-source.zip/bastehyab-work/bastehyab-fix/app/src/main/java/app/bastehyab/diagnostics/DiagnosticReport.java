package app.bastehyab.diagnostics;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

/**
 * Pure-Java diagnostic report builder. Extracted from ScanService so the accessibility
 * layer no longer owns formatting, section sorting or file rendering. No Android types
 * and no free-text page content: callers pass already-scrubbed, structural values.
 */
public final class DiagnosticReport {
    private final StringBuilder sb = new StringBuilder();

    public DiagnosticReport header(String product, String version) {
        sb.append(product).append(" diagnostic • version ").append(version).append('\n');
        return this;
    }

    public DiagnosticReport line(String text) {
        sb.append(text).append('\n');
        return this;
    }

    public DiagnosticReport line(String key, Object value) {
        return line(key + "=" + String.valueOf(value));
    }

    /** Sorted, deterministic package/snapshot sections; never depends on map iteration order. */
    public DiagnosticReport sections(Map<String, List<String>> dumps) {
        if (dumps == null) return this;
        List<String> keys = new ArrayList<>(dumps.keySet());
        Collections.sort(keys);
        for (String key : keys) {
            List<String> snapshots = dumps.get(key) == null
                    ? Collections.<String>emptyList() : dumps.get(key);
            sb.append("=== package=").append(key).append(" snapshots=")
                    .append(snapshots.size()).append('\n');
            int page = 0;
            for (String snapshot : snapshots) {
                sb.append("--- snapshot ").append(++page).append(" ---\n")
                        .append(snapshot).append('\n');
            }
        }
        return this;
    }

    public String render() { return sb.toString(); }
}
