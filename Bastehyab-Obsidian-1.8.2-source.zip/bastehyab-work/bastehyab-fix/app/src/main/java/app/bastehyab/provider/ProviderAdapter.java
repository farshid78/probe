package app.bastehyab.provider;

import app.bastehyab.R;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * Versioned, per-operator adapter profiles. This is the single source of truth for the
 * built-in operator catalogue: package names, default currency, supported Android API
 * range, the price-label strategy used by the corpus matrix, and the price-selection
 * policy exposed in settings. Cfg, the fixture corpus and the compatibility matrix all
 * read from here, so a provider change can never silently diverge between runtime and
 * tests.
 *
 * Profiles contain no user data and no raw accessibility text. They are safe to commit.
 */
public final class ProviderAdapter {
    /** Bump when a profile changes; the versioned corpus must declare the same value. */
    public static final int SCHEMA_VERSION = 1;
    public static final int MIN_SUPPORTED_API = 24;   // Android 7.0, the app's minSdk
    public static final int MAX_SUPPORTED_API = 36;   // Android 16, the app's targetSdk

    /** Price-selection strategies; kept here so Cfg, Extractor, Store and the UI agree. */
    public static final int POLICY_AUTO = 0, POLICY_LARGEST = 1, POLICY_SMALLEST = 2;

    public static final class Profile {
        public final String id;
        public final int nameRes;
        public final int color;
        public final String currency;                 // AUTO | IRR | IRT
        public final String[] packages;
        public final int firstApi, lastApi;
        public final int adapterVersion;
        /** ASCII hint: which labelled amount the provider's page foregrounds. */
        public final String priceAnchor;
        /** True when the provider prints explicit Rial amounts instead of Toman. */
        public final boolean rialLabelled;

        Profile(String id, int nameRes, int color, String currency, String[] packages,
                int firstApi, int lastApi, int adapterVersion, String priceAnchor,
                boolean rialLabelled) {
            this.id = id;
            this.nameRes = nameRes;
            this.color = color;
            this.currency = currency;
            this.packages = packages;
            this.firstApi = firstApi;
            this.lastApi = lastApi;
            this.adapterVersion = adapterVersion;
            this.priceAnchor = priceAnchor;
            this.rialLabelled = rialLabelled;
        }

        public boolean owns(String packageName) {
            if (packageName == null) return false;
            for (String p : packages) if (p.equals(packageName)) return true;
            return false;
        }

        public boolean supports(int api) { return api >= firstApi && api <= lastApi; }

        /** One deterministic row for the compatibility matrix; no localized free text. */
        public String matrixRow(int api) {
            return id + "|" + currency + "|" + priceAnchor + "|api" + api
                    + "|" + (supports(api) ? "supported" : "unsupported")
                    + "|v" + adapterVersion;
        }
    }

    private static final Profile[] PROFILES = {
        new Profile("irancell", R.string.s_a781a56cf677, 0xFFFFCB05, "AUTO",
                new String[]{"com.myirancell"}, MIN_SUPPORTED_API, MAX_SUPPORTED_API, 1,
                "explicit-unit", true),
        new Profile("mci", R.string.s_39d3d1816c83, 0xFF1EA7E1, "AUTO",
                new String[]{"ir.mci.ecareapp"}, MIN_SUPPORTED_API, MAX_SUPPORTED_API, 1,
                "labelled-price", true),
        new Profile("rightel", R.string.s_0c02bea509c4, 0xFFD81B60, "AUTO",
                new String[]{"ir.rightel.myrightel"}, MIN_SUPPORTED_API, MAX_SUPPORTED_API, 1,
                "short-validity", true),
        new Profile("samantel", R.string.s_dbae1cdc796d, 0xFFFF7043, "IRR",
                new String[]{"com.mysamantel"}, MIN_SUPPORTED_API, MAX_SUPPORTED_API, 1,
                "base-price-vat", true),
        new Profile("shatel", R.string.s_5c9f29eacf97, 0xFF26A69A, "AUTO",
                new String[]{"com.shmapp"}, MIN_SUPPORTED_API, MAX_SUPPORTED_API, 1,
                "explicit-unit", true),
    };

    private ProviderAdapter() {}

    public static List<Profile> all() {
        return Collections.unmodifiableList(Arrays.asList(PROFILES));
    }

    public static Profile forId(String id) {
        if (id != null) for (Profile p : PROFILES) if (p.id.equals(id)) return p;
        return null;
    }

    public static Profile forPackage(String packageName) {
        if (packageName != null) for (Profile p : PROFILES) if (p.owns(packageName)) return p;
        return null;
    }

    public static boolean validPolicy(int policy) {
        return policy == POLICY_AUTO || policy == POLICY_LARGEST || policy == POLICY_SMALLEST;
    }

    public static int normalizePolicy(int policy) { return validPolicy(policy) ? policy : POLICY_AUTO; }

    /** Stable, machine-readable compatibility matrix used by the fixture-corpus runner. */
    public static String matrix(int[] apis) {
        StringBuilder sb = new StringBuilder();
        for (Profile p : PROFILES) {
            for (int api : apis) sb.append(p.matrixRow(api)).append('\n');
        }
        return sb.toString();
    }

    /** Every built-in operator must be covered by a versioned corpus fixture. */
    public static String[] ids() {
        String[] out = new String[PROFILES.length];
        for (int i = 0; i < PROFILES.length; i++) out[i] = PROFILES[i].id;
        return out;
    }
}
