package app.bastehyab;

import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Field-level provenance for an extracted package. Replaces the old free-text {@code note}
 * as the machine-readable answer to "why was this value chosen?".
 *
 * Privacy: no raw accessibility text is ever stored. The source node identity is a 64-bit
 * hash of the view-id/bounds token, and every fingerprint is a 64-bit FNV-1a hash over
 * structural values only. Evidence is therefore safe to persist alongside the package.
 */
final class Evidence {
    enum Field { PRICE, VOLUME, DURATION, CURRENCY, VAT, TITLE }
    enum Method {
        EXPLICIT_LABEL, EXPLICIT_UNIT, NEAREST_LABEL, STRUCTURAL_CARD,
        HEURISTIC, OPERATOR_PROFILE, MANUAL_REVIEW
    }

    final Field field;
    final Method method;
    /** Hashed, non-reversible source-node identity; never a view id or raw page text. */
    final String nodeId;
    /** 0..1; higher means a labelled, unambiguous source. */
    final double confidence;
    final boolean vatIncluded;
    /** 16-hex-char 64-bit fingerprint over structural tokens (no user data). */
    final String fingerprint;

    private Evidence(Field field, Method method, String nodeId, double confidence,
                     boolean vatIncluded, String fingerprint) {
        this.field = field;
        this.method = method;
        this.nodeId = nodeId;
        this.confidence = Math.max(0d, Math.min(1d, confidence));
        this.vatIncluded = vatIncluded;
        this.fingerprint = fingerprint;
    }

    static Evidence of(Field field, Method method, String nodeId, double confidence,
                       boolean vatIncluded, String... structuralTokens) {
        String token = nodeId == null || nodeId.isEmpty() ? "anonymous-node" : nodeId;
        String hashedNode = hex64(Privacy.hash64(Arrays.asList(token)));
        List<String> parts = new ArrayList<>();
        parts.add(field.name());
        parts.add(method.name());
        parts.add(hashedNode);
        parts.add(String.valueOf(Math.round(Math.max(0d, Math.min(1d, confidence)) * 1000d) / 1000d));
        parts.add(String.valueOf(vatIncluded));
        for (String value : structuralTokens) parts.add(value == null ? "" : value);
        return new Evidence(field, method, hashedNode, confidence, vatIncluded,
                hex64(Privacy.hash64(parts)));
    }

    /**
     * Price evidence derived from the parser's candidate kind:
     * 5 = explicit base price, 4 = labelled final price, 0 = unlabelled amount.
     */
    /** Fixed-width unsigned hex so fingerprints are always exactly 16 characters. */
    static String hex64(long hash) {
        return String.format(java.util.Locale.ROOT, "%016x", hash);
    }

    static Evidence price(String opId, String nodeId, long toman, int kind,
                          boolean currencyKnown, boolean vatIncluded, String bounds) {
        Method method = kind == 5 || kind == 4 ? Method.EXPLICIT_LABEL
                : kind == 1 ? Method.NEAREST_LABEL : Method.HEURISTIC;
        double confidence = kind == 5 ? 0.95 : kind == 4 ? 0.9 : kind == 1 ? 0.7 : 0.6;
        if (!currencyKnown) confidence = Math.min(confidence, 0.35);
        return of(Field.PRICE, method, nodeId, confidence, vatIncluded,
                opId, Long.toString(toman), Integer.toString(kind), bounds);
    }

    JSONObject json() {
        JSONObject o = new JSONObject();
        o.put("f", field.name());
        o.put("m", method.name());
        o.put("n", nodeId);
        o.put("c", confidence);
        o.put("v", vatIncluded);
        o.put("h", fingerprint);
        return o;
    }

    static Evidence from(JSONObject o) {
        Field field = parse(o.optString("f", ""), Field.values(), Field.PRICE);
        Method method = parse(o.optString("m", ""), Method.values(), Method.HEURISTIC);
        String node = o.optString("n", "");
        double confidence = o.optDouble("c", 0d);
        boolean vat = o.optBoolean("v", false);
        String hash = o.optString("h", "");
        return new Evidence(field, method, node, confidence, vat, hash);
    }

    private static <T extends Enum<T>> T parse(String value, T[] values, T fallback) {
        for (T v : values) if (v.name().equals(value)) return v;
        return fallback;
    }

    static JSONArray toJson(List<Evidence> items) {
        JSONArray a = new JSONArray();
        if (items != null) for (Evidence e : items) if (e != null) a.put(e.json());
        return a;
    }

    static List<Evidence> listFrom(JSONArray a) {
        List<Evidence> out = new ArrayList<>();
        if (a == null) return out;
        for (int i = 0; i < a.length(); i++) {
            try { out.add(from(a.getJSONObject(i))); }
            catch (RuntimeException ignored) { /* drop a corrupt evidence row */ }
        }
        return out;
    }

    /** True when at least one field is backed by a labelled, high-confidence source. */
    static boolean hasStrongSupport(List<Evidence> items) {
        if (items == null) return false;
        for (Evidence e : items) {
            if (e != null && e.confidence >= 0.9
                    && (e.method == Method.EXPLICIT_LABEL || e.method == Method.EXPLICIT_UNIT
                        || e.method == Method.MANUAL_REVIEW)) return true;
        }
        return false;
    }
}
