package app.bastehyab;

import android.content.Context;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * One comparison card, built once per RecyclerView holder. bind() only updates values,
 * so scrolling no longer recreates a whole tree of views for every row.
 */
final class CompareRowView extends LinearLayout {
    private final TextView badge, operatorChip, restrictedChip, discountChip;
    private final TextView label, duration, totalValue, perValue;
    private final OperatorLogo logo;

    CompareRowView(Context c) {
        super(c);
        setOrientation(LinearLayout.VERTICAL);
        setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        setPadding(UI.dp(c, 14), UI.dp(c, 13), UI.dp(c, 14), UI.dp(c, 13));
        setMinimumHeight(UI.dp(c, 156));
        setBackground(UI.rr(c, UI.CARD, 20, UI.STROKE));

        LinearLayout top = UI.hbox(c);
        badge = UI.tv(c, "", 13, UI.TEXT, true);
        badge.setGravity(Gravity.CENTER);
        top.addView(badge, UI.lp(c, 34, 34, 0, 0, 8, 0));
        logo = new OperatorLogo(c, "");
        top.addView(logo, UI.lp(c, 34, 30, 0, 0, 7, 0));
        operatorChip = UI.chip(c, "", UI.tint(UI.MUTED), UI.MUTED);
        top.addView(operatorChip);
        restrictedChip = UI.chip(c, S.s(R.string.s_e434e331efa9), UI.tint(UI.DANGER), UI.DANGER);
        top.addView(restrictedChip, UI.lp(c, -2, -2, 5, 0, 0, 0));
        discountChip = UI.chip(c, "", UI.tint(UI.SUCCESS), UI.SUCCESS);
        top.addView(discountChip, UI.lp(c, -2, -2, 5, 0, 0, 0));
        addView(top);

        label = UI.tv(c, "", 16, UI.TEXT, true);
        label.setMaxLines(2);
        label.setEllipsize(TextUtils.TruncateAt.END);
        label.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
        label.setTextAlignment(View.TEXT_ALIGNMENT_GRAVITY);
        addView(label, UI.lp(c, -1, -2, 0, 9, 0, 3));

        duration = UI.tv(c, "", 10, UI.MUTED, false);
        addView(duration, UI.lp(c, -1, -2, 0, 0, 0, 10));

        LinearLayout metrics = UI.hbox(c);
        LinearLayout total = UI.vbox(c);
        total.addView(UI.tv(c, S.s(R.string.s_56d3be2002e1), 9, UI.MUTED, false));
        totalValue = UI.tv(c, "", 13, UI.TEXT, true);
        total.addView(totalValue, UI.lp(c, -1, -2, 0, 3, 0, 0));
        metrics.addView(total, UI.lpw(1f));
        LinearLayout per = UI.vbox(c);
        per.setGravity(Gravity.CENTER);
        per.addView(UI.tv(c, S.s(R.string.s_756c6784b36b), 9, UI.MUTED, false));
        perValue = UI.tv(c, "", 12, UI.TEXT, true);
        perValue.setGravity(Gravity.CENTER);
        perValue.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        per.addView(perValue, UI.lp(c, -1, -2, 0, 3, 0, 0));
        metrics.addView(per, UI.lpw(1f));
        addView(metrics);
    }

    void bind(Pkg p, int rank, Compare.Result cr, Op op, View.OnClickListener click) {
        int opColor = op == null ? UI.MUTED : op.color;
        int fill = rank == 1 ? UI.CARD2 : UI.CARD;
        int border = rank == 1 ? UI.PRIMARY : UI.STROKE;
        setBackground(UI.rr(getContext(), fill, 20, border));
        setElevation(UI.dp(getContext(), rank == 1 ? 7 : 5));

        badge.setText(Fmt.fa(String.valueOf(rank)));
        badge.setTextColor(rank == 1 ? 0xFFFFFFFF : UI.TEXT);
        badge.setBackground(UI.rr(getContext(), rank == 1 ? UI.PRIMARY : UI.CARD2, 12));
        logo.bind(op == null ? p.op : op.id);

        operatorChip.setText(op == null ? p.op : op.name);
        UI.setChipSelected(getContext(), operatorChip, false, UI.tint(opColor));
        operatorChip.setTextColor(opColor);

        restrictedChip.setVisibility(p.restricted ? View.VISIBLE : View.GONE);
        double metric = cr != null && cr.val.containsKey(p.key) ? cr.val.get(p.key) : 0d;
        double med = cr == null ? 0d : cr.median;
        long discount = cr != null && cr.metric != Cfg.DURATION && med > 0 && metric < med
                ? Math.round((med - metric) * 100d / med) : 0;
        if (discount > 0) {
            discountChip.setVisibility(View.VISIBLE);
            discountChip.setText(Fmt.fa(String.valueOf(discount)) + S.s(R.string.s_a870dad44972));
        } else {
            discountChip.setVisibility(View.GONE);
        }

        label.setText(p.label());
        duration.setText(S.s(R.string.s_63604f744e43) + Fmt.dec(p.days) + S.s(R.string.s_69ff4a27e5a6));
        totalValue.setText(Cfg.priceLabel(getContext(), Cfg.finalPrice(getContext(), p)));
        double perGbToman = p.gb > 0 ? Cfg.finalPrice(getContext(), p) / p.gb : 0;
        perValue.setText(Cfg.priceNumber(getContext(), Math.round(perGbToman)) + S.s(R.string.s_98666716b309));
        perValue.setTextColor(rank == 1 ? UI.PRIMARY : UI.TEXT);
        setOnClickListener(click);
    }
}
