package app.bastehyab;

import java.nio.charset.StandardCharsets;
import java.util.regex.Pattern;

/** Deterministic redaction for *free-text* exports. Structured numeric fields are untouched. */
final class Privacy {
    private static final Pattern UUID = Pattern.compile(
            "(?i)\\b[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\\b");
    private static final Pattern EMAIL = Pattern.compile(
            "(?i)\\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,}\\b");
    private static final Pattern IRAN_MOBILE = Pattern.compile(
            "(?<!\\d)(?:\\+?98|0)?9\\d{9}(?!\\d)");
    private static final Pattern LONG_ID = Pattern.compile("(?<!\\d)\\d{10,}(?!\\d)");

    private Privacy() { }

    static String scrub(String value) {
        if (value == null || value.isEmpty()) return "";
        // Normalize Persian/Arabic digits and invisible marks before matching.
        String text = Fmt.norm(value);
        text = UUID.matcher(text).replaceAll("[UUID]");
        text = EMAIL.matcher(text).replaceAll("[EMAIL]");
        text = IRAN_MOBILE.matcher(text).replaceAll("[PHONE]");
        text = LONG_ID.matcher(text).replaceAll("[ID]");
        return text;
    }

    /** Stable 64-bit FNV-1a over UTF-8, used to avoid 32-bit viewport fingerprint collisions. */
    static long hash64(Iterable<String> values) {
        long hash = 0xcbf29ce484222325L;
        for (String value : values) {
            for (byte b : value.getBytes(StandardCharsets.UTF_8)) {
                hash ^= b & 0xff;
                hash *= 0x100000001b3L;
            }
            hash ^= 0xff; // record separator cannot occur inside UTF-8 text
            hash *= 0x100000001b3L;
        }
        return hash;
    }
}
