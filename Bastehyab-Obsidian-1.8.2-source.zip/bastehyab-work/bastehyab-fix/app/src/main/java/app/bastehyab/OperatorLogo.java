package app.bastehyab;

import android.content.Context;
import android.view.View;

/**
 * Operator badge. Extracted from MainActivity so the reusable RecyclerView row can bind
 * a different operator without allocating a new View (and so the UI layer stays smaller).
 */
final class OperatorLogo extends View {
    private String id = "";
    private final android.graphics.Paint paint =
            new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
    private android.graphics.drawable.Drawable operatorIcon;
    private int brandColor;

    OperatorLogo(Context c, String id) {
        super(c);
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        bind(id);
    }

    /** Re-resolve the operator as the holder is recycled across different operators. */
    void bind(String value) {
        id = value == null ? "" : value;
        Context c = getContext();
        Op op = Cfg.opById(c, id);
        brandColor = op == null ? 0xFF9C72E8 : op.color;
        android.graphics.drawable.Drawable found = null;
        if (op != null && op.pkgs != null) {
            for (String pkg : op.pkgs) {
                try {
                    found = c.getPackageManager().getApplicationIcon(pkg);
                    break;
                } catch (android.content.pm.PackageManager.NameNotFoundException ignored) { }
            }
        }
        operatorIcon = found == null ? null : found.getConstantState() == null
                ? found : found.getConstantState().newDrawable(c.getResources()).mutate();
        setContentDescription(op == null ? S.s(R.string.s_acd750693554) : S.s(R.string.s_28f4f735c785) + op.name);
        invalidate();
    }

    @Override protected void onDraw(android.graphics.Canvas c) {
        float w = getWidth(), h = getHeight();
        if (w <= 0 || h <= 0) return;
        float side = Math.min(w, h) * .90f;
        float left = (w - side) * .5f, top = (h - side) * .5f;
        paint.setStyle(android.graphics.Paint.Style.FILL);
        paint.setColor(0x22FFFFFF);
        c.drawRoundRect(left - UI.dp(getContext(), 2), top - UI.dp(getContext(), 2),
                left + side + UI.dp(getContext(), 2), top + side + UI.dp(getContext(), 2),
                UI.dp(getContext(), 11), UI.dp(getContext(), 11), paint);
        if (operatorIcon != null) {
            operatorIcon.setBounds(Math.round(left), Math.round(top), Math.round(left + side), Math.round(top + side));
            operatorIcon.draw(c);
        } else {
            paint.setColor((brandColor & 0x00FFFFFF) | 0xFF000000);
            c.drawRoundRect(left, top, left + side, top + side,
                    UI.dp(getContext(), 12), UI.dp(getContext(), 12), paint);
            paint.setColor(0xFFFFFFFF);
            paint.setTextAlign(android.graphics.Paint.Align.CENTER);
            paint.setTypeface(android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.BOLD));
            paint.setTextSize(side * .40f);
            String mark = id.equals("irancell") ? "I" : id.equals("mci") ? "M"
                    : id.equals("rightel") ? "R" : id.equals("samantel") ? "S" : "SM";
            c.drawText(mark, w * .5f, h * .5f + side * .14f, paint);
        }
    }
}
