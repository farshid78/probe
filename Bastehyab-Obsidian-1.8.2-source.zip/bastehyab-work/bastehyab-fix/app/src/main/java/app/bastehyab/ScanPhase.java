package app.bastehyab;

/** Explicit, named states for the accessibility scan session; diagnostics no longer infer free strings. */
enum ScanPhase {
    IDLE(R.string.phase_idle),
    WAITING_CONFIRM(R.string.phase_waiting_confirm),
    WAITING_PAGE(R.string.phase_waiting_page),
    SCANNING(R.string.phase_scanning),
    PAUSED(R.string.phase_paused),
    FINISHED(R.string.phase_finished),
    ERROR(R.string.phase_error);

    private final int label;

    ScanPhase(int label) { this.label = label; }

    String label() { return S.s(label); }
}
