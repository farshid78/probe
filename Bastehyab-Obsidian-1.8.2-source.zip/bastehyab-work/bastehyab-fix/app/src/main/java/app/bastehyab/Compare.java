package app.bastehyab;

import android.content.Context;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

final class Compare {
    private static final int[] BUCKET_LABELS = {
            R.string.s_15270886eadd, R.string.s_f95cdce37682, R.string.s_3eae222b1a7c,
            R.string.s_95ea0688ffbe, R.string.s_bcfa7a10fba9};

    /** Resolved at render time, after the application context has been initialized. */
    static String[] buckets() {
        String[] labels = new String[BUCKET_LABELS.length];
        for (int i = 0; i < BUCKET_LABELS.length; i++) labels[i] = S.s(BUCKET_LABELS[i]);
        return labels;
    }

    static String bucketLabel(int index) {
        return index >= 0 && index < BUCKET_LABELS.length ? S.s(BUCKET_LABELS[index]) : "";
    }

    static boolean inBucket(double days, int b) {
        if (b == 0) return true;
        if (days <= 0) return false;
        switch (b) {
            case 1: return days <= 7;
            case 2: return days > 7 && days <= 35;
            case 3: return days > 35 && days <= 100;
            default: return days > 100;
        }
    }

    /** duration class used to compare like with like: 0 unknown, 1 hours/day, 2 week, 3 month, 4 quarter, 5 longer */
    /** Intl/roaming has its own switch and must not be hidden by the domestic-special switch. */
    static boolean passesSpecialFilters(Pkg p, boolean includeSpecial, boolean includeIntl) {
        if (p == null) return false;
        if (p.isIntl()) return includeIntl;
        return !p.restricted || includeSpecial;
    }

    static int group(double days) {
        if (days <= 0) return 0;
        if (days <= 1) return 1;
        if (days <= 7) return 2;
        if (days <= 35) return 3;
        if (days <= 100) return 4;
        return 5;
    }

    static final class Result {
        final List<Pkg> ranked = new ArrayList<>();
        final Map<String, Double> val = new HashMap<>();
        final List<Pkg> ambig = new ArrayList<>(); // kept out of the ranking: price could not be trusted
        final Map<String, Integer> rank = new HashMap<>();
        final java.util.Set<String> cheap = new HashSet<>(); // far below the median: double-check
        final List<Pkg> screen = new ArrayList<>(); // ranked packages that are on the current screen
        int bucket;
        double median;
        int ops, metric, staleExcluded;
        String label = "", unit = "";
        Pkg bestScreen;
        int rankScreen;
    }

    /** Keep the displayed ordinal in exact agreement with the numeric comparison value. */
    static void sortRanked(List<Pkg> packages, final Map<String, Double> values) {
        Collections.sort(packages, (a, b) -> {
            Double av = values.get(a.key), bv = values.get(b.key);
            int cmp = Double.compare(av == null ? Double.MAX_VALUE : av,
                    bv == null ? Double.MAX_VALUE : bv);
            if (cmp == 0) cmp = Boolean.compare(a.restricted, b.restricted);
            if (cmp == 0) cmp = a.op.compareTo(b.op);
            return cmp != 0 ? cmp : a.key.compareTo(b.key);
        });
    }

    static double value(Pkg p, int metric, double usage, long price) {
        if (p.gb <= 0 || price <= 0) return Double.MAX_VALUE;
        // Pkg owns the arithmetic; `price` is already the VAT-aware amount from Cfg.finalPrice,
        // so scaling the base calculation removes the old second source of truth.
        double ratio = p.toman > 0 ? (double) price / (double) p.toman : 0d;
        switch (metric) {
            case Cfg.DURATION:
                // Negative duration sorts longest-validity bundles first with the shared ascending sorter.
                return p.days > 0 ? -p.days : Double.MAX_VALUE;
            case Cfg.PER_GB_MONTH: {
                if (p.days <= 0 || ratio <= 0) return Double.MAX_VALUE;
                double base = p.perGbMonth();
                return base >= Double.MAX_VALUE / 2 ? Double.MAX_VALUE : base * ratio;
            }
            case Cfg.MY_USAGE: {
                if (p.days <= 0 || ratio <= 0) return Double.MAX_VALUE;
                double base = p.monthlyCost(usage);
                return base >= Double.MAX_VALUE / 2 ? Double.MAX_VALUE : base * ratio;
            }
            default: return price / p.gb;
        }
    }

    static Result run(Context c, Set<String> onScreen) {
        final Result r = new Result();
        int metric = Cfg.metric(c);
        double usage = Cfg.usage(c);
        r.metric = metric;
        r.bucket = Cfg.bucket(c);
        long minTs = System.currentTimeMillis() - Cfg.fresh(c) * 86400000L;
        Set<String> enabled = new HashSet<>();
        for (Op o : Cfg.ops(c)) if (o.cmp) enabled.add(o.id);
        Set<String> seen = new HashSet<>();
        float minGb = Cfg.minGb(c);
        int maxDays = Cfg.maxDays(c);
        boolean restricted = Cfg.restricted(c);
        boolean intl = Cfg.intl(c);
        // The signature includes classification so a limited offer cannot shadow a general-purpose twin.
        Map<String, Pkg> uniq = new HashMap<>();
        for (Pkg raw : Store.all(c)) {
            // Manual approval is applied as a separate comparison view; raw extraction remains intact.
            if ("rejected".equals(raw.reviewStatus)) continue;
            Pkg p = raw.comparisonVersion();
            String sg = p.sig();
            Pkg o = uniq.get(sg);
            if (o == null || (o.restricted && !p.restricted) || (o.restricted == p.restricted && p.ts > o.ts)) uniq.put(sg, p);
        }
        // a package that is on screen may have been merged into a twin with another title: keep it "on screen"
        Set<String> screenKeys = new HashSet<>();
        if (onScreen != null) {
            for (Pkg raw : Store.all(c)) {
                if ("rejected".equals(raw.reviewStatus)) continue;
                Pkg p = raw.comparisonVersion();
                Pkg merged = uniq.get(p.sig());
                if (onScreen.contains(raw.key) && merged != null) screenKeys.add(merged.key);
            }
        }
        for (Pkg p : uniq.values()) {
            if (!enabled.contains(p.op)) continue;
            if (p.ts < minTs) { r.staleExcluded++; continue; }
            if (p.gb < minGb) continue;
            if (maxDays > 0 && p.days > maxDays) continue;
            if (!inBucket(p.days, r.bucket)) continue;
            if (!passesSpecialFilters(p, restricted, intl)) continue;
            // Ambiguous offers may be inspected manually, but never enter the definitive ranking.
            if (!p.currencyKnown || p.ambig) {
                r.ambig.add(p);
                continue;
            }
            double v = value(p, metric, usage, Cfg.finalPrice(c, p));
            if (v >= Double.MAX_VALUE / 2) continue;
            r.val.put(p.key, v);
            r.ranked.add(p);
            seen.add(p.op);
        }
        sortRanked(r.ranked, r.val);
        r.ops = seen.size();
        if (!r.ranked.isEmpty()) {
            int n = r.ranked.size();
            double hi = r.val.get(r.ranked.get(n / 2).key);
            r.median = n % 2 == 1 ? hi : (hi + r.val.get(r.ranked.get(n / 2 - 1).key)) / 2;
        }
        // "too cheap" is judged against packages of the same duration class, so a long package is not
        // flagged just because it is naturally cheaper per GB-month than a weekly one
        Map<Integer, List<Double>> grp = new HashMap<>();
        for (Pkg p : r.ranked) {
            int g = group(p.days);
            List<Double> l = grp.get(g);
            if (l == null) grp.put(g, l = new ArrayList<>());
            l.add(r.val.get(p.key));
        }
        Map<Integer, Double> gmed = new HashMap<>();
        for (Map.Entry<Integer, List<Double>> e : grp.entrySet()) {
            List<Double> l = e.getValue();
            Collections.sort(l);
            int n = l.size();
            if (n >= 5) gmed.put(e.getKey(), n % 2 == 1 ? l.get(n / 2) : (l.get(n / 2) + l.get(n / 2 - 1)) / 2);
        }
        for (int i = 0; i < r.ranked.size(); i++) {
            Pkg p = r.ranked.get(i);
            r.rank.put(p.key, i + 1);
            if (screenKeys.contains(p.key)) r.screen.add(p);
            Double gm = gmed.get(group(p.days));
            if (metric != Cfg.DURATION && gm != null && r.val.get(p.key) < 0.6 * gm) r.cheap.add(p.key);
        }
        if (!r.screen.isEmpty()) {
            r.bestScreen = r.screen.get(0);
            r.rankScreen = r.rank.get(r.bestScreen.key);
        }
        if (metric == Cfg.DURATION) {
            r.label = S.s(R.string.s_0df601da3dc7);
            r.unit = S.s(R.string.s_bdf3f57c2244);
        } else if (metric == Cfg.PER_GB_MONTH) {
            r.label = S.s(R.string.s_8b0fdaae8e81);
            r.unit = S.s(R.string.s_cbb21b55dbe3);
        } else if (metric == Cfg.MY_USAGE) {
            r.label = S.s(R.string.s_2cdc923fe59b) + Fmt.dec(usage) + S.s(R.string.s_e8b255dd82c6);
            r.unit = S.s(R.string.s_c46c9d47413e);
        } else {
            r.label = S.s(R.string.s_ce1b79c8024f);
            r.unit = S.s(R.string.s_8ab5a8d5dbf9);
        }
        return r;
    }
}
