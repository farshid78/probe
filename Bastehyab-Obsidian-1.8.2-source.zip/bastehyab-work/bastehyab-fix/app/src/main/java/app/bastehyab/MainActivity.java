package app.bastehyab;

import app.bastehyab.provider.ProviderAdapter;

import android.app.AlertDialog;
import androidx.activity.ComponentActivity;
import androidx.activity.OnBackPressedCallback;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.provider.Settings;
import android.text.Editable;
import android.text.InputType;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.graphics.drawable.GradientDrawable;
import android.widget.Button;
import android.view.Gravity;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.HorizontalScrollView;

import android.widget.LinearLayout;
import android.widget.ProgressBar;

import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.List;
import java.util.Locale;

public class MainActivity extends ComponentActivity {
    interface IntCb { void on(int v); }
    interface StrCb { void on(String s); }
    interface W { void w(OutputStream o) throws Exception; }

    private static final int[] ICONS = {R.drawable.ic_home, R.drawable.ic_compare, R.drawable.ic_tune};
    private static final int[] NAMES = {R.string.nav_home, R.string.nav_compare, R.string.settings_title};

    private FrameLayout body;
    private FrameLayout outer;
    private SplashViews.AppBackdrop appBackdrop;
    private View splashView;
    private boolean splashShowing;
    private CheckBox splashRemember;
    private static boolean consentPromptShown;
    private String lastLiveSignature = "";
    private Compare.Result cachedCompare;
    private CompareViewModel compareVm;
    private CompareAdapter compareAdapter;
    private RecyclerView compareList;
    private static final long LIVE_REFRESH_MS = 3000L;
    private final Handler splashHandler = new Handler(Looper.getMainLooper());
    private final Handler liveHandler = new Handler(Looper.getMainLooper());
    private final Runnable liveRefresh = new Runnable() {
        @Override public void run() {
            if (isFinishing()) return;
            String signature = liveSignature();
            // Rebuild the whole view tree only when data or scan state actually changed.
            if (tab == 0 && !splashShowing && !signature.equals(lastLiveSignature)) {
                lastLiveSignature = signature;
                render();
            }
            if (ScanService.session.isActive()) liveHandler.postDelayed(this, LIVE_REFRESH_MS);
        }
    };
    private LinearLayout nav;
    private ScrollView sv;
    private int tab;
    private final int[] scroll = new int[3];
    private String newName = "", newPkg = "";
    private int newCur;

    private int dp(float v) { return UI.dp(this, v); }

    private String liveSignature() {
        return Store.revision() + "|" + tab + "|" + Cfg.metric(this) + "|" + Cfg.bucket(this)
                + "|" + ScanService.session.isActive() + "|" + ScanService.session.isConfirmed()
                + "|" + ScanService.session.isPaused() + "|" + ScanService.session.isScanning()
                + "|" + ScanService.session.isFinished() + "|" + ScanService.fullSteps
                + "|" + ScanService.lastCompletedScanAt + "|" + ScanService.lastScanError;
    }

    private void applySystemBars() {
        getWindow().setStatusBarColor(UI.BG);
        getWindow().setNavigationBarColor(UI.CARD);
        int flags = UI.light ? (View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR) : 0;
        getWindow().getDecorView().setSystemUiVisibility(flags);
    }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        // On API 36+, predictive back gestures bypass Activity.onBackPressed(); use the
        // AndroidX dispatcher so splash dismissal and tab navigation work on every API.
        getOnBackPressedDispatcher().addCallback(new OnBackPressedCallback(true) {
            @Override public void handleOnBackPressed() {
                if (splashShowing) { enterApp(); return; }
                if (tab != 0) {
                    if (sv != null) scroll[tab] = sv.getScrollY();
                    tab = 0;
                    render(false);
                    toast(S.s(R.string.back_to_home));
                    return;
                }
                finish();
            }
        });
        S.init(this);
        compareVm = new ViewModelProvider(this).get(CompareViewModel.class);
        compareVm.result().observe(this, cr -> {
            if (compareAdapter != null && cr != null) compareAdapter.submit(cr);
        });
        UI.applyTheme(this);
        applySystemBars();
        LinearLayout root = UI.vbox(this);
        root.setBackgroundColor(0x00000000);
        body = new FrameLayout(this);
        root.addView(body, new LinearLayout.LayoutParams(-1, 0, 1f));
        nav = UI.hbox(this);
        nav.setBackground(UI.rr(this, UI.CARD, 24, UI.STROKE));
        nav.setElevation(dp(12));
        nav.setPadding(dp(7), dp(7), dp(7), dp(7));
        LinearLayout.LayoutParams navParams = new LinearLayout.LayoutParams(-1, -2);
        navParams.setMargins(dp(14), dp(5), dp(14), dp(12));
        root.addView(nav, navParams);
        outer = new FrameLayout(this);
        appBackdrop = new SplashViews.AppBackdrop(this);
        outer.addView(appBackdrop, new FrameLayout.LayoutParams(-1, -1));
        outer.addView(root, new FrameLayout.LayoutParams(-1, -1));
        setContentView(outer);
        if (b == null) {
            if (!Cfg.sp(this).getBoolean("hideSplash", false)) showCreatorSplash();
            else render();
        } else {
            tab = Cfg.clamp(b.getInt("state.tab", 0), 0, 2);
            for (int i = 0; i < scroll.length; i++) scroll[i] = Math.max(0, b.getInt("state.scroll." + i, 0));
            newName = b.getString("form.name", "");
            newPkg = b.getString("form.pkg", "");
            newCur = b.getInt("form.cur", 0);
            boolean restoreSplash = b.getBoolean("state.splash", false);
            render(); // Rebuild the visible screen and restore the selected tab/scroll position.
            if (restoreSplash) showCreatorSplash();
        }
        // Displayed in normal usage on first launch; it is not buried in settings or a
        // privacy policy, and cannot be replaced by the accessibility-service description.
        if (!consentPromptShown && !Cfg.accessibilityConsentGranted(this)) {
            consentPromptShown = true;
            showAccessibilityDisclosure(false);
        }
    }

    /** Play Accessibility API prominent disclosure with an affirmative opt-in checkbox. */
    private void showAccessibilityDisclosure(boolean openSettingsOnGrant) {
        LinearLayout panel = UI.vbox(this);
        panel.setPadding(dp(20), dp(12), dp(20), dp(8));
        ScrollView disclosureScroll = new ScrollView(this);
        disclosureScroll.setFillViewport(true);
        disclosureScroll.setVerticalScrollBarEnabled(false);
        TextView disclosureText = UI.tv(this, S.s(R.string.accessibility_disclosure_body),
                12, UI.TEXT, false);
        disclosureText.setTextDirection(View.TEXT_DIRECTION_ANY_RTL);
        disclosureScroll.addView(disclosureText);
        panel.addView(disclosureScroll, new LinearLayout.LayoutParams(-1, dp(190)));
        CheckBox accepted = new CheckBox(this);
        accepted.setText(S.s(R.string.accessibility_disclosure_checkbox));
        accepted.setTextColor(UI.TEXT);
        accepted.setTextSize(12);
        accepted.setMinHeight(dp(48));
        accepted.setTextDirection(View.TEXT_DIRECTION_ANY_RTL);
        panel.addView(accepted, UI.lp(this, -1, -2, 0, 8, 0, 0));
        UI.applyTypefaceTree(panel);
        AlertDialog dialog = new AlertDialog.Builder(this, R.style.AppDialog)
                .setTitle(S.s(R.string.accessibility_disclosure_title))
                .setView(panel)
                .setCancelable(false)
                .setNegativeButton(S.s(R.string.accessibility_disclosure_later), null)
                .setPositiveButton(S.s(R.string.accessibility_disclosure_continue), (d, which) -> {
                    Cfg.grantAccessibilityConsent(this);
                    if (openSettingsOnGrant) {
                        startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
                    } else {
                        render();
                    }
                })
                .create();
        dialog.setCanceledOnTouchOutside(false);
        dialog.setOnShowListener(d -> {
            Button positive = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
            positive.setEnabled(false);
            accepted.setOnCheckedChangeListener((checkbox, checked) -> positive.setEnabled(checked));
        });
        dialog.show();
    }

    private void showCreatorSplash() {
        splashShowing = true;
        FrameLayout shell = new FrameLayout(this);
        // Reuse the activity's static cyber wallpaper: one compositor, no stacked animation layers.
        shell.setBackgroundColor(0x00000000);
        View veil = new View(this);
        veil.setBackground(UI.grad(this, UI.light ? 0x22FFFFFF : UI.tint(UI.PRIMARY),
                UI.light ? 0x11EAF0FA : UI.tint(UI.ACCENT), 0));
        shell.addView(veil, new FrameLayout.LayoutParams(-1, -1));

        ScrollView scrollView = new ScrollView(this);
        scrollView.setFillViewport(true);
        scrollView.setVerticalScrollBarEnabled(false);
        shell.addView(scrollView, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout col = UI.vbox(this);
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        col.setPadding(dp(24), dp(30), dp(24), dp(24));
        scrollView.addView(col, new ScrollView.LayoutParams(-1, -2));

        FrameLayout logo = new FrameLayout(this);
        logo.setElevation(dp(12));
        logo.addView(new SplashViews.LogoHalo(this),
                new FrameLayout.LayoutParams(dp(128), dp(128), Gravity.CENTER));
        SplashViews.BrandMark brandMark = new SplashViews.BrandMark(this);
        brandMark.setElevation(dp(7));
        logo.addView(brandMark,
                new FrameLayout.LayoutParams(dp(120), dp(120), Gravity.CENTER));
        col.addView(logo, UI.lp(this, 140, 140, 0, 0, 0, 12));

        TextView title = UI.tv(this, S.s(R.string.app_name), 34, UI.TEXT, true);
        title.setGravity(Gravity.CENTER);
        col.addView(title, UI.lp(this, -1, -2, 0, 0, 0, 2));
        TextView latin = UI.tv(this, "BASTEHYAB", 11, UI.PRIMARY, true);
        latin.setLetterSpacing(0.18f);
        latin.setTextDirection(View.TEXT_DIRECTION_LTR);
        latin.setGravity(Gravity.CENTER);
        col.addView(latin, UI.lp(this, -1, -2, 0, 0, 0, 5));
        TextView subtitle = UI.tv(this, S.s(R.string.app_tagline), 14, UI.ACCENT, true);
        subtitle.setGravity(Gravity.CENTER);
        col.addView(subtitle, UI.lp(this, -1, -2, 0, 0, 0, 20));

        LinearLayout features = UI.hbox(this);
        features.setGravity(Gravity.CENTER);
        String[] featureNames = {S.s(R.string.s_800e3ecf8660), S.s(R.string.s_54eb09aa20da), S.s(R.string.s_9693ae64e714)};
        for (int i=0;i<featureNames.length;i++) {
            TextView f = UI.chip(this, featureNames[i], UI.tint(UI.ACCENT), UI.ACCENT);
            features.addView(f, UI.lp(this, -2, -2, i==0?0:5, 0, 0, 0));
        }
        col.addView(features, UI.lp(this, -1, -2, 0, 0, 0, 18));

        LinearLayout how = UI.card(this);
        how.setPadding(dp(16), dp(15), dp(16), dp(15));
        how.addView(UI.tv(this, S.s(R.string.s_2782bc07c5fd), 14, UI.TEXT, true));
        LinearLayout steps = UI.hbox(this);
        String[] stepsText = {S.s(R.string.s_adfa6967af99), S.s(R.string.s_64bb81bfa7f8), S.s(R.string.s_01e07a930c18)};
        for (int i=0;i<stepsText.length;i++) {
            LinearLayout step = UI.vbox(this);
            step.setGravity(Gravity.CENTER);
            TextView n = UI.tv(this, Fmt.fa(String.valueOf(i+1)), 12, UI.TEXT, true);
            n.setGravity(Gravity.CENTER);
            n.setBackground(UI.rr(this, UI.tint(UI.ACCENT), 18, UI.STROKE));
            step.addView(n, UI.lp(this, 30, 30, 0, 0, 0, 5));
            TextView label = UI.tv(this, stepsText[i], 10, UI.MUTED, true);
            label.setGravity(Gravity.CENTER);
            label.setMaxLines(2);
            step.addView(label);
            steps.addView(step, new LinearLayout.LayoutParams(0, -2, 1f));
        }
        how.addView(steps, UI.lp(this, -1, -2, 0, 12, 0, 0));
        col.addView(how, UI.lp(this, -1, -2, 0, 0, 0, 14));

        TextView enter = UI.btn(this, S.s(R.string.enter_app), UI.PRIMARY, 0xFF061326, v -> enterApp());
        col.addView(enter, UI.lp(this, -1, -2, 0, 0, 0, 10));

        LinearLayout skipRow = UI.hbox(this);
        skipRow.setGravity(Gravity.CENTER_VERTICAL);
        CheckBox remember = new CheckBox(this);
        remember.setText(S.s(R.string.splash_remember));
        remember.setTextColor(UI.MUTED);
        remember.setTextSize(12);
        remember.setMinHeight(dp(48));
        remember.setTextDirection(View.TEXT_DIRECTION_ANY_RTL);
        splashRemember = remember;
        skipRow.addView(remember, UI.lpw(1f));
        skipRow.addView(UI.btn(this, S.s(R.string.splash_skip), UI.CARD2, UI.TEXT,
                v -> enterApp()), UI.lp(this, -2, -2, 8, 0, 0, 0));
        col.addView(skipRow, UI.lp(this, -1, -2, 0, 0, 0, 14));

        LinearLayout creator = UI.hbox(this);
        creator.setGravity(Gravity.CENTER_VERTICAL);
        creator.setPadding(dp(14), dp(13), dp(14), dp(13));
        creator.setBackground(UI.rr(this, UI.CARD2, 18, UI.STROKE));
        creator.setElevation(dp(6));
        creator.addView(new SplashViews.PersonAvatar(this), UI.lp(this, 66, 66, 0, 0, 12, 0));
        LinearLayout creatorText = UI.vbox(this);
        creatorText.addView(UI.tv(this, S.s(R.string.creator), 10, UI.MUTED, false));
        creatorText.addView(UI.tv(this, S.s(R.string.creator_name), 16, UI.TEXT, true),
                UI.lp(this, -1, -2, 0, 3, 0, 0));
        creator.addView(creatorText, UI.lpw(1f));
        TextView contact = UI.tv(this, S.s(R.string.s_412e46465ffd), 10, UI.PRIMARY, true);
        contact.setGravity(Gravity.CENTER);
        contact.setPadding(dp(10), dp(10), dp(10), dp(10));
        contact.setBackground(UI.rr(this, UI.tint(UI.ACCENT), 12, UI.STROKE));
        contact.setOnClickListener(v -> {
            try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/Farshid_Np"))); }
            catch (Exception e) { toast(S.s(R.string.s_ffe5deee06ea)); }
        });
        creator.addView(contact, UI.lp(this, -2, -2, 8, 0, 0, 0));
        col.addView(creator, UI.lp(this, -1, -2, 0, 0, 0, 8));

        TextView privacy = UI.tv(this, S.s(R.string.s_44e78629c548, S.s(R.string.app_version)), 10, UI.MUTED, false);
        privacy.setGravity(Gravity.CENTER);
        privacy.setMaxLines(3);
        col.addView(privacy, UI.lp(this, -1, -2, 0, 0, 0, 0));

        UI.applyTypefaceTree(shell);
        splashView = shell;
        outer.addView(splashView, new FrameLayout.LayoutParams(-1, -1));
    }

    private void enterApp() {
        if (!splashShowing) return;
        splashHandler.removeCallbacksAndMessages(null);
        if (splashRemember != null && splashRemember.isChecked()) {
            Cfg.setBool(this, "hideSplash", true);
        }
        splashRemember = null;
        View fading = splashView;
        if (fading == null) {
            splashShowing = false;
            render();
            return;
        }
        fading.animate().alpha(0f).setDuration(180L).withEndAction(() -> {
            if (splashView == fading) {
                outer.removeView(fading);
                splashView = null;
                splashShowing = false;
                render();
            }
        }).start();
    }

    @Override protected void onSaveInstanceState(Bundle out) {
        out.putInt("state.tab", tab);
        out.putBoolean("state.splash", splashShowing);
        out.putString("form.name", newName == null ? "" : newName);
        out.putString("form.pkg", newPkg == null ? "" : newPkg);
        out.putInt("form.cur", newCur);
        for (int i = 0; i < scroll.length; i++) out.putInt("state.scroll." + i, scroll[i]);
        super.onSaveInstanceState(out);
    }

    @Override protected void onResume() {
        super.onResume();
        if (appBackdrop != null) appBackdrop.resumeLoop();
        if (!splashShowing) { lastLiveSignature = liveSignature(); render(); }
        if (ScanService.session.isActive()) {
            liveHandler.removeCallbacks(liveRefresh);
            liveHandler.postDelayed(liveRefresh, LIVE_REFRESH_MS);
        }
    }

    @Override protected void onPause() {
        liveHandler.removeCallbacks(liveRefresh);
        if (appBackdrop != null) appBackdrop.pauseLoop();
        Store.flush(this);
        super.onPause();
    }

    @Override protected void onDestroy() {
        splashHandler.removeCallbacksAndMessages(null);
        liveHandler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }

    // ---------------------------------------------------------------- shell

    private void render() { render(true); }

    private void render(boolean captureCurrentScroll) {
        if (captureCurrentScroll && sv != null) scroll[tab] = sv.getScrollY();
        body.removeAllViews();
        final ScrollView screenScroll = new ScrollView(this);
        screenScroll.setFillViewport(true);
        screenScroll.setVerticalScrollBarEnabled(false);
        screenScroll.setOverScrollMode(View.OVER_SCROLL_NEVER);
        screenScroll.setClipToPadding(false);
        screenScroll.setClipChildren(false);
        sv = screenScroll;
        LinearLayout col = UI.vbox(this);
        col.setClipChildren(false);
        col.setPadding(dp(18), dp(18), dp(18), dp(28));
        screenScroll.addView(col, new FrameLayout.LayoutParams(-1, -2));
        body.addView(screenScroll, new FrameLayout.LayoutParams(-1, -1));
        cachedCompare = Compare.run(this, new HashSet<String>());
        if (tab == 0) home(col);
        else if (tab == 1) compare(col);
        else settings(col);
        // One computation, one observable source: home, compare and the adapter agree.
        if (compareVm != null) compareVm.publish(cachedCompare);
        lastLiveSignature = liveSignature();
        UI.applyTypefaceTree(col);
        final int y = scroll[tab];
        screenScroll.post(() -> screenScroll.scrollTo(0, y));
        buildNav();
    }

    private void buildNav() {
        nav.removeAllViews();
        nav.setPadding(dp(7), dp(7), dp(7), dp(7));
        GradientDrawable navBg = UI.rr(this, UI.CARD, 24, UI.STROKE);
        navBg.setStroke(dp(1), UI.STROKE);
        nav.setBackground(navBg);
        for (int i = 0; i < 3; i++) {
            final int idx = i;
            boolean on = i == tab;
            LinearLayout it = UI.vbox(this);
            it.setGravity(Gravity.CENTER);
            it.setPadding(dp(7), dp(7), dp(7), dp(7));
            it.setBackground(on
                    ? UI.rr(this, UI.CARD2, 17, UI.PRIMARY)
                    : UI.rr(this, 0x00000000, 17));
            ImageView im = new ImageView(this);
            im.setImageResource(ICONS[i]);
            im.setColorFilter(on ? UI.PRIMARY : UI.MUTED);
            it.addView(im, UI.lp(this, 22, 22, 0, 1, 0, 0));
            TextView label = UI.tv(this, S.s(NAMES[i]), 10, on ? UI.PRIMARY : UI.MUTED, on);
            label.setGravity(Gravity.CENTER);
            it.addView(label, UI.lp(this, -2, -2, 0, 3, 0, 0));
            it.setContentDescription(S.s(NAMES[i]) + (on ? S.s(R.string.s_a1df3ba02b60) : S.s(R.string.s_8652013b0195)));
            it.setSelected(on);
            it.setOnClickListener(v -> {
                // Re-tapping the active destination is intentionally a no-op.
                // Rebuilding the same screen used to reset focus/layout and cause a visible jump.
                if (idx == tab) return;
                if (sv != null) scroll[tab] = sv.getScrollY();
                tab = idx;
                // The target tab already owns its own saved scroll position; do not
                // overwrite it with the outgoing tab's scroll offset during render.
                render(false);
            });
            nav.addView(it, new LinearLayout.LayoutParams(0, -2, 1f));
        }
    }

    private boolean serviceOn() {
        String en = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        return en != null && en.contains(getPackageName());
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }

    // ---------------------------------------------------------------- home

    private void home(LinearLayout col) {
        boolean permission = serviceOn();
        List<Op> ops = Cfg.ops(this);
        List<Pkg> all = Store.all(this);
        Compare.Result cr = cachedCompare != null ? cachedCompare : Compare.run(this, new HashSet<String>());
        int active = 0, withData = 0;
        long latest = 0;
        for (Op o : ops) if (o.enabled) active++;
        for (Pkg p : all) if (p.ts > latest) latest = p.ts;
        for (Op o : ops) {
            for (Pkg p : all) if (p.op.equals(o.id)) { withData++; break; }
        }

        LinearLayout hero = UI.hbox(this);
        hero.setPadding(dp(17), dp(17), dp(17), dp(17));
        GradientDrawable heroBg = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                UI.mono ? new int[]{0xFF202833, UI.CARD}
                        : UI.light ? new int[]{0xFFF7FAFC, UI.CARD}
                        : new int[]{UI.CARD2, UI.CARD});
        heroBg.setCornerRadius(dp(22));
        heroBg.setStroke(dp(1), UI.STROKE);
        hero.setElevation(dp(2));
        hero.setBackground(heroBg);
        ImageView mark = new ImageView(this);
        mark.setImageResource(R.mipmap.ic_launcher);
        mark.setScaleType(ImageView.ScaleType.FIT_CENTER);
        hero.addView(mark, UI.lp(this, 70, 70, 0, 0, 14, 0));
        LinearLayout brand = UI.vbox(this);
        brand.addView(UI.tv(this, S.s(R.string.app_name), 24, UI.TEXT, true));
        brand.addView(UI.tv(this, S.s(R.string.app_tagline), 11, UI.MUTED, false), UI.lp(this, -1, -2, 0, 3, 0, 6));
        brand.addView(UI.chip(this, permission ? S.s(R.string.s_eb0f71ca9d46) : S.s(R.string.s_ba53fd1e7958),
                permission ? UI.tint(UI.SUCCESS) : UI.tint(UI.DANGER), permission ? UI.SUCCESS : UI.DANGER));
        hero.addView(brand, UI.lpw(1f));
        col.addView(hero);

        if (!permission) {
            LinearLayout access = UI.card(this);
            access.addView(UI.tv(this, S.s(R.string.access_enable_title), 14, UI.TEXT, true));
            access.addView(UI.tv(this, S.s(R.string.access_enable_body), 11, UI.MUTED, false), UI.lp(this, -1, -2, 0, 5, 0, 9));
            access.addView(UI.btn(this, S.s(R.string.access_enable_button), UI.PRIMARY, 0xFF061326, v -> {
                if (Cfg.accessibilityConsentGranted(this)) {
                    startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
                } else {
                    showAccessibilityDisclosure(true);
                }
            }), UI.lp(this, -1, -2, 0, 0, 0, 0));
            col.addView(access, UI.lp(this, -1, -2, 0, 12, 0, 0));
        }

        col.addView(sectionTitle(S.s(R.string.s_ca3c4420b9b8), S.s(R.string.s_aa5864b76b3f)), UI.lp(this, -1, -2, 0, 16, 0, 8));
        LinearLayout stats1 = UI.hbox(this);
        stats1.addView(stat(Fmt.fa(String.valueOf(cr.ranked.size())), S.s(R.string.s_fd3b122d64f5)), UI.lpw(1f));
        stats1.addView(stat(Fmt.fa(String.valueOf(withData)), S.s(R.string.s_03b7c508f1eb)), UI.lp2(this, 8));
        LinearLayout stats2 = UI.hbox(this);
        stats2.addView(stat(Fmt.fa(String.valueOf(active)), S.s(R.string.s_714ad7b7b1d3)), UI.lpw(1f));
        stats2.addView(stat(latest == 0 ? "—" : Fmt.ago(latest), S.s(R.string.s_9812fa0d7d8b)), UI.lp2(this, 8));
        col.addView(stats1, UI.lp(this, -1, -2, 0, 0, 0, 8));
        col.addView(stats2, UI.lp(this, -1, -2, 0, 0, 0, 0));

        LinearLayout scan = UI.card(this);
        LinearLayout scanHead = UI.hbox(this);
        scanHead.addView(UI.tv(this, S.s(R.string.s_6a004cb0e655), 14, UI.TEXT, true), UI.lpw(1f));
        scanHead.addView(UI.chip(this, ScanService.session.isActive() ? (ScanService.session.isPaused() ? S.s(R.string.s_42f9026a50c4) : S.s(R.string.s_ba31fd7d85f0)) : S.s(R.string.s_1ccc40303d81),
                ScanService.session.isActive() ? UI.tint(UI.PRIMARY) : UI.tint(UI.ACCENT), ScanService.session.isActive() ? UI.PRIMARY : UI.MUTED));
        scan.addView(scanHead);
        String scanAge = ScanService.lastCompletedScanAt > 0 ? " • " + Fmt.ago(ScanService.lastCompletedScanAt) : "";
        scan.addView(UI.tv(this, ScanService.lastScanStatus + scanAge, 12, UI.MUTED, false), UI.lp(this, -1, -2, 0, 7, 0, 0));
        if (ScanService.lastCompletedScanAt > 0) {
            scan.addView(UI.tv(this, S.s(R.string.s_2034f6bca694) + Fmt.fa(String.valueOf(ScanService.lastScanDurationMs)) + S.s(R.string.s_0a2b5a3cf26e),
                    9, UI.MUTED, false), UI.lp(this, -1, -2, 0, 4, 0, 0));
        }
        scan.addView(UI.tv(this, S.s(R.string.s_a077e9f57e1c) + Fmt.fa(String.valueOf(ScanService.lastScannedPackages))
                + S.s(R.string.s_5f165068855d) + Fmt.fa(String.valueOf(ScanService.lastValidPackages))
                + S.s(R.string.s_b2a977c87cc1) + Fmt.fa(String.valueOf(ScanService.lastSuspiciousPackages))
                + S.s(R.string.s_bfb38790ae9d) + Fmt.fa(String.valueOf(ScanService.lastDuplicatePackages)), 10, UI.MUTED, false),
                UI.lp(this, -1, -2, 0, 5, 0, 0));
        if (ScanService.session.isActive() || ScanService.fullSteps > 0) {
            int pct = ScanService.session.isFinished() ? 100 : Math.min(95, Math.max(1, ScanService.fullSteps * 100 / ScanService.FULL_MAX_STEPS));
            Op target = Cfg.opById(this, ScanService.fullTargetOpId);
            String phase = ScanService.session.isActive() ? (ScanService.session.isPaused() ? S.s(R.string.s_0d5734b433c8) : (ScanService.session.isScanning() ? S.s(R.string.s_b4851156dc52) : (ScanService.session.isConfirmed() ? S.s(R.string.s_b7180c9a70fd) : S.s(R.string.s_b8163c7e7b2b))))
                    : (ScanService.session.isFinished() ? S.s(R.string.s_a27bfab649f3) : S.s(R.string.s_81c8723de8b0));
            scan.addView(UI.tv(this, phase + (target == null ? "" : " • " + target.name) + "  •  " + Fmt.fa(String.valueOf(pct)) + S.s(R.string.s_a489ae36a167),
                    10, UI.PRIMARY, true), UI.lp(this, -1, -2, 0, 7, 0, 3));
            ProgressBar progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
            progress.setProgressTintList(ColorStateList.valueOf(UI.PRIMARY));
            progress.setProgressBackgroundTintList(ColorStateList.valueOf(UI.STROKE));
            progress.setMax(100); progress.setProgress(pct);
            scan.addView(progress, UI.lp(this, -1, 5, 0, 0, 0, 0));
        }
        if (cr.staleExcluded > 0) {
            scan.addView(UI.tv(this, S.s(R.string.stale_data_hint, cr.staleExcluded),
                    11, UI.MUTED, false), UI.lp(this, -1, -2, 0, 8, 0, 0));
        }
        col.addView(scan, UI.lp(this, -1, -2, 0, 12, 0, 0));

        LinearLayout best = UI.card(this);
        LinearLayout bh = UI.hbox(this);
        bh.addView(UI.tv(this, S.s(R.string.s_c84cdbd2de84), 14, UI.TEXT, true), UI.lpw(1f));
        bh.addView(UI.chip(this, S.s(R.string.s_4e72adc1ac27), UI.tint(UI.ACCENT), UI.ACCENT));
        best.addView(bh);
        if (cr.ranked.isEmpty()) {
            best.addView(UI.tv(this, S.s(R.string.s_a788f1e5d8e3),
                    11, UI.MUTED, false), UI.lp(this, -1, -2, 0, 8, 0, 0));
        } else {
            Pkg p = cr.ranked.get(0);
            Op op = Cfg.opById(this, p.op);
            LinearLayout offer = UI.hbox(this);
            LinearLayout details = UI.vbox(this);
            details.addView(UI.chip(this, op == null ? p.op : op.name, UI.tint(op == null ? UI.MUTED : op.color), op == null ? UI.MUTED : op.color));
            details.addView(UI.tv(this, p.label(), 17, UI.TEXT, true), UI.lp(this, -1, -2, 0, 7, 0, 3));
            details.addView(UI.tv(this, S.s(R.string.s_ced4d0d2689b) + Fmt.dec(p.days) + S.s(R.string.s_69ff4a27e5a6), 10, UI.MUTED, false));
            details.addView(UI.tv(this, S.s(R.string.s_287f9c44b2fe) + Cfg.priceLabel(this, Cfg.finalPrice(this, p)), 11, UI.MUTED, false), UI.lp(this, -1, -2, 0, 5, 0, 0));
            offer.addView(details, UI.lpw(1f));
            LinearLayout metric = UI.vbox(this);
            metric.setGravity(Gravity.CENTER);
            String metricValue = cr.metric == Cfg.DURATION
                    ? Fmt.dec(p.days) : Fmt.num(Math.round(Cfg.displayMetric(this, cr.val.get(p.key))));
            metric.addView(UI.tv(this, metricValue, 22, UI.PRIMARY, true));
            metric.addView(UI.tv(this, Cfg.metricUnit(this, cr.unit), 9, UI.MUTED, false));
            offer.addView(metric);
            best.addView(offer, UI.lp(this, -1, -2, 0, 10, 0, 0));
            best.addView(UI.btn(this, S.s(R.string.s_44ee8e61975b), UI.PRIMARY, 0xFF061326, v -> { tab = 1; render(); }),
                    UI.lp(this, -1, -2, 0, 12, 0, 0));
        }
        col.addView(best, UI.lp(this, -1, -2, 0, 12, 0, 0));

        col.addView(sectionTitle(S.s(R.string.s_27869643a6cb), S.s(R.string.s_a4487e1184cd)), UI.lp(this, -1, -2, 0, 16, 0, 8));
        for (final Op o : ops) {
            int count = 0; long ts = 0;
            for (Pkg p : all) if (p.op.equals(o.id)) { count++; if (p.ts > ts) ts = p.ts; }
            LinearLayout row = UI.hbox(this);
            row.setPadding(dp(13), dp(11), dp(13), dp(11));
            row.setMinimumHeight(dp(68));
            row.setBackground(UI.rr(this, UI.CARD, 18, UI.STROKE));
            row.addView(new OperatorLogo(this, o.id), UI.lp(this, 42, 34, 0, 0, 10, 0));
            LinearLayout info = UI.vbox(this);
            info.addView(UI.tv(this, o.name, 13, UI.TEXT, true));
            String status = !o.enabled ? S.s(R.string.s_acdb21890fa5) : count > 0 ? Fmt.fa(String.valueOf(count)) + S.s(R.string.s_649f868d6070) + Fmt.ago(ts) : S.s(R.string.s_c28ca07e6488);
            info.addView(UI.tv(this, status, 10, count > 0 ? UI.PRIMARY : UI.MUTED, false), UI.lp(this, -1, -2, 0, 2, 0, 0));
            row.addView(info, UI.lpw(1f));
            row.addView(UI.btn(this, o.enabled ? S.s(R.string.s_5863c48efedb) : S.s(R.string.s_592c8cbd7fc9), UI.CARD2, UI.PRIMARY, v -> launch(o)));
            col.addView(row, UI.lp(this, -1, -2, 0, 0, 0, 7));
        }
        LinearLayout privacy = UI.hbox(this);
        privacy.setPadding(dp(12), dp(10), dp(12), dp(10));
        privacy.setBackground(UI.rr(this, UI.tint(UI.ACCENT), 13, UI.STROKE));
        privacy.addView(UI.tv(this, S.s(R.string.s_33caa157388c), 10, UI.PRIMARY, true), UI.lpw(1f));
        privacy.addView(UI.tv(this, S.s(R.string.s_998863b643de), 9, UI.MUTED, false));
        col.addView(privacy, UI.lp(this, -1, -2, 0, 8, 0, 0));
    }

    /** Uses the installed operator application's real launcher identity (offline, no remote logo fetch). */
    private View bestMini(String heading, Pkg p) {
        LinearLayout c = UI.vbox(this);
        c.setPadding(dp(9), dp(10), dp(9), dp(10));
        c.setMinimumHeight(dp(88));
        c.setBackground(UI.rr(this, UI.CARD, 14, UI.STROKE));
        c.setElevation(dp(4));
        c.addView(UI.tv(this, heading, 10, UI.ACCENT, true));
        c.addView(UI.tv(this, p.label(), 11, UI.TEXT, true), UI.lp(this, -1, -2, 0, 5, 0, 0));
        c.addView(UI.tv(this, Cfg.priceLabel(this, Cfg.finalPrice(this, p)), 10, UI.MUTED, false));
        return c;
    }

    private View stat(String big, String small) {
        LinearLayout c = UI.vbox(this);
        c.setGravity(Gravity.CENTER);
        c.setPadding(dp(8), dp(12), dp(8), dp(12));
        c.setMinimumHeight(dp(96));
        c.setOrientation(LinearLayout.VERTICAL);
        c.setBackground(UI.rr(this, UI.CARD, 18, UI.STROKE));
        c.setElevation(dp(5));
        TextView number = UI.tv(this, big, 23, UI.PRIMARY, true);
        number.setGravity(Gravity.CENTER);
        number.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        number.setSingleLine(true);
        number.setEllipsize(TextUtils.TruncateAt.END);
        c.addView(number);
        TextView t = UI.tv(this, small, 10, UI.MUTED, false);
        t.setGravity(Gravity.CENTER);
        t.setSingleLine(true);
        t.setEllipsize(android.text.TextUtils.TruncateAt.END);
        c.addView(t);
        return c;
    }

    private void launch(Op o) {
        String targetPackage = null;
        Intent launchIntent = null;
        for (String p : o.pkgs) {
            Intent candidate = getPackageManager().getLaunchIntentForPackage(p);
            if (candidate != null) {
                targetPackage = p;
                launchIntent = candidate;
                break;
            }
        }
        if (launchIntent == null || targetPackage == null) {
            toast(S.s(R.string.s_99e786fe8378) + o.name + S.s(R.string.s_194b9eb57dcd));
            return;
        }

        boolean auto = ScanService.inst != null && o.enabled;
        if (auto) ScanService.startFull(o.id, targetPackage);
        try {
            startActivity(launchIntent);
            if (auto) {
                liveHandler.removeCallbacks(liveRefresh);
                liveHandler.post(liveRefresh);
                toast(S.s(R.string.s_99e786fe8378) + o.name + S.s(R.string.s_1f907ff4f8bd));
            } else if (!o.enabled) {
                toast(S.s(R.string.s_75517325ebfa));
            } else {
                toast(S.s(R.string.s_0a7d0c523599));
            }
        } catch (RuntimeException e) {
            if (auto) ScanService.stopFull(S.s(R.string.s_4f3510618568));
            toast(S.s(R.string.s_81eb7d2d09e7) + o.name + S.s(R.string.s_a8e0e8046152) + e.getClass().getSimpleName());
        }
    }

    // ---------------------------------------------------------------- compare

    private void compare(LinearLayout col) {
        LinearLayout header = UI.hbox(this);
        LinearLayout titles = UI.vbox(this);
        titles.addView(UI.tv(this, S.s(R.string.compare_title), 22, UI.TEXT, true));
        titles.addView(UI.tv(this, S.s(R.string.s_5879483d2871), 11, UI.MUTED, false), UI.lp(this, -1, -2, 0, 3, 0, 0));
        header.addView(titles, UI.lpw(1f));
        header.addView(UI.chip(this, Fmt.fa(String.valueOf(Store.all(this).size())) + S.s(R.string.s_bb4dbd348e9f), UI.tint(UI.ACCENT), UI.PRIMARY));
        col.addView(header);

        LinearLayout filter = UI.card(this);
        filter.addView(UI.tv(this, S.s(R.string.s_13f7aa821a1a), 13, UI.TEXT, true));
        chips(filter, new String[]{S.s(R.string.s_e19a1c0fd10c), S.s(R.string.s_f55747ada77e),
                S.s(R.string.s_d83169d4b855), S.s(R.string.metric_per_gb_month)}, Cfg.metric(this), i -> {
            Cfg.setInt(this, "metric", i); scroll[1] = 0; render();
        });
        filter.addView(UI.tv(this, S.s(R.string.s_782edac90d97), 11, UI.MUTED, false), UI.lp(this, -1, -2, 0, 5, 0, 0));
        chips(filter, Compare.buckets(), Cfg.bucket(this), i -> {
            Cfg.setInt(this, "bucket", i); scroll[1] = 0; render();
        });
        if (Cfg.metric(this) == Cfg.MY_USAGE) {
            stepRow(filter, S.s(R.string.s_db635c6d750c), S.s(R.string.s_8d1fe5c9b1b8), (int) Cfg.usage(this), 5, 500, 5, S.s(R.string.s_e8b255dd82c6), v -> {
                Cfg.setFloat(this, "usage", v); render();
            });
        }
        col.addView(filter, UI.lp(this, -1, -2, 0, 12, 0, 0));

        col.addView(tickCard(), UI.lp(this, -1, -2, 0, 10, 0, 6));
        Compare.Result cr = cachedCompare != null ? cachedCompare : Compare.run(this, new HashSet<String>());
        if (!cr.ambig.isEmpty()) {
            LinearLayout review = UI.card(this);
            review.addView(UI.tv(this, S.s(R.string.ambiguous_review_hint, cr.ambig.size()),
                    12, UI.TEXT, false), UI.lp(this, -1, -2, 0, 0, 0, 8));
            review.addView(UI.btn(this, S.s(R.string.review_queue_action), UI.PRIMARY,
                    0xFF061326, v -> { scroll[1] = sv == null ? 0 : sv.getScrollY(); tab = 2; render(false); }),
                    UI.lp(this, -1, -2, 0, 0, 0, 0));
            col.addView(review, UI.lp(this, -1, -2, 0, 10, 0, 8));
        }
        if (cr.ranked.isEmpty()) {
            LinearLayout empty = UI.card(this);
            empty.setGravity(Gravity.CENTER);
            empty.addView(UI.tv(this, anyCmp() ? S.s(R.string.s_f47f1330cc37) : S.s(R.string.s_452f699d58b0), 15, UI.TEXT, true));
            empty.addView(UI.tv(this, S.s(R.string.s_c1639486c1da), 11, UI.MUTED, false), UI.lp(this, -1, -2, 0, 7, 0, 0));
            col.addView(empty);
            return;
        }
        LinearLayout summary = UI.hbox(this);
        summary.setPadding(dp(12), dp(10), dp(12), dp(10));
        summary.setBackground(UI.rr(this, UI.tint(UI.ACCENT), 13, UI.STROKE));
        summary.addView(UI.tv(this, Fmt.fa(String.valueOf(cr.ranked.size())) + S.s(R.string.s_1a0b64444c6d), 11, UI.PRIMARY, true), UI.lpw(1f));
        summary.addView(UI.tv(this, cr.label, 10, UI.MUTED, false));
        col.addView(summary, UI.lp(this, -1, -2, 0, 10, 0, 8));

        compareList = new RecyclerView(this);
        compareList.setLayoutManager(new LinearLayoutManager(this));
        compareList.setNestedScrollingEnabled(false);
        compareList.setHasFixedSize(false);
        compareList.setOverScrollMode(View.OVER_SCROLL_NEVER);
        compareList.setClipToPadding(false);
        compareAdapter = new CompareAdapter(this, this::showDetail);
        compareList.setAdapter(compareAdapter);
        compareAdapter.submit(cr);
        col.addView(compareList, UI.lp(this, -1, -2, 0, 0, 0, 0));
        if (compareAdapter.hiddenCount() > 0) {
            col.addView(UI.tv(this, S.s(R.string.s_ce1abd091cc8), 10, UI.MUTED, false), UI.lp(this, -1, -2, 0, 4, 0, 0));
        }
    }

    private boolean anyCmp() {
        for (Op o : Cfg.ops(this)) if (o.cmp) return true;
        return false;
    }

    private void setAllCmp(boolean on) {
        List<Op> ops = Cfg.ops(this);
        for (Op o : ops) o.cmp = on;
        Cfg.saveOps(this, ops);
        render();
    }

    private View tickCard() {
        LinearLayout c = UI.card(this);
        List<Op> ops = Cfg.ops(this);
        LinearLayout hd = UI.hbox(this);
        hd.addView(UI.tv(this, S.s(R.string.s_791e88f7c045), 13, UI.TEXT, true), UI.lpw(1f));
        hd.addView(UI.btn(this, S.s(R.string.s_15270886eadd), UI.CARD2, UI.PRIMARY, v -> setAllCmp(true)), UI.lp(this, -2, -2, 0, 0, 5, 0));
        hd.addView(UI.btn(this, S.s(R.string.s_6cfe5535af91), UI.CARD2, UI.MUTED, v -> setAllCmp(false)));
        c.addView(hd);
        LinearLayout pills = UI.vbox(this);
        for (int i = 0; i < ops.size(); i += 2) {
            LinearLayout row = UI.hbox(this);
            for (int j = i; j < Math.min(i + 2, ops.size()); j++) {
                final Op o = ops.get(j);
                TextView pill = UI.tv(this, (o.cmp ? "✓  " : "○  ") + o.name, 11, o.cmp ? UI.contrastText(o.color) : UI.MUTED, true);
                if (o.cmp) pill.setTextColor(UI.contrastText(UI.PRIMARY));
                pill.setGravity(Gravity.CENTER);
                pill.setPadding(dp(8), dp(9), dp(8), dp(9));
                pill.setBackground(o.cmp
                        ? UI.grad(this, UI.PRIMARY, UI.BLUE, 13)
                        : UI.rr(this, UI.CARD2, 13, UI.STROKE));
                pill.setOnClickListener(v -> {
                    o.cmp = !o.cmp;
                    Cfg.saveOps(this, ops);
                    render();
                });
                LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(0, -2, 1f);
                pp.setMargins(dp(3), dp(8), dp(3), 0);
                row.addView(pill, pp);
            }
            if (ops.size() % 2 == 1 && i + 1 == ops.size() - 1) {
                row.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1f));
            }
            pills.addView(row);
        }
        c.addView(pills);
        int selected = 0;
        for (Op o : ops) if (o.cmp) selected++;
        c.addView(UI.tv(this, selected == 0 ? S.s(R.string.s_c509e7dbd820) :
                Fmt.fa(String.valueOf(selected)) + S.s(R.string.s_793ed7939fbc), 10, UI.MUTED, false), UI.lp(this, -1, -2, 0, 7, 0, 0));
        return c;
    }

    private void showDetail(final Pkg p) {
        final Op op = Cfg.opById(this, p.op);
        String operator = op == null ? p.op : op.name;
        StringBuilder sb = new StringBuilder();
        sb.append(operator).append("\n");
        sb.append(p.label()).append("\n");
        if (p.currencyKnown && !p.ambig) {
            sb.append(S.s(R.string.s_fc465313a02b)).append(Cfg.priceLabel(this, p.toman)) .append("\n");
            sb.append(S.s(R.string.s_9f0035ec1976)).append(Cfg.priceLabel(this, Cfg.finalPrice(this, p))).append("\n");
        } else {
            // Never display a candidate number as the package price when the parser could not
            // verify which amount belongs to this offer.
            sb.append(S.s(R.string.s_7ec2b264b4d7));
            sb.append(S.s(R.string.price_unknown_hint));
        }
        if (p.restricted && !p.ambig) {
            sb.append(S.s(R.string.s_11aed63041af)).append(p.why);
        }
        AlertDialog.Builder builder = new AlertDialog.Builder(this, R.style.AppDialog)
                .setTitle(S.s(R.string.dialog_package_details))
                .setMessage(sb.toString())
                .setPositiveButton(S.s(R.string.close), null);
        if (p.ambig || !p.currencyKnown) {
            builder.setNeutralButton(S.s(R.string.action_review), (d, w) -> editReview(p));
        }
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    // ---------------------------------------------------------------- settings

    private void settings(LinearLayout col) {
        LinearLayout heading = UI.hbox(this);
        LinearLayout title = UI.vbox(this);
        title.addView(UI.tv(this, S.s(R.string.settings_title), 22, UI.TEXT, true));
        title.addView(UI.tv(this, S.s(R.string.s_119425355038), 11, UI.MUTED, false), UI.lp(this, -1, -2, 0, 3, 0, 0));
        heading.addView(title, UI.lpw(1f));
        heading.addView(UI.chip(this, S.s(R.string.s_efdb1f9a0361), UI.tint(UI.ACCENT), UI.PRIMARY));
        col.addView(heading);

        LinearLayout display = section(col, S.s(R.string.s_1a75d871bc00));
        display.addView(UI.tv(this, S.s(R.string.s_632c7b73f107), 12, UI.TEXT, true));
        int activeTheme = UI.mono ? 1 : UI.light ? 2 : 0;
        chips(display, new String[]{S.s(R.string.theme_cyber), S.s(R.string.s_5cf21689ecf4), S.s(R.string.theme_light)},
                activeTheme, i -> {
                    String selected = i == 1 ? "mono" : i == 2 ? "light" : "dark";
                    Cfg.sp(this).edit().putString("appearance", selected).apply();
                    UI.applyTheme(this);
                    applySystemBars();
                    if (appBackdrop != null) appBackdrop.refreshTheme();
                    render();
                });
        display.addView(UI.tv(this,
                S.s(R.string.s_4f6e78a0f64f),
                10, UI.MUTED, false), UI.lp(this, -1, -2, 0, 0, 0, 12));
        display.addView(UI.tv(this, S.s(R.string.s_9dbdee490fed), 12, UI.TEXT, true));
        chips(display, new String[]{S.s(R.string.currency_toman), S.s(R.string.currency_rial)}, "IRR".equals(Cfg.displayCurrency(this)) ? 1 : 0, i -> {
            Cfg.setDisplayCurrency(this, i == 1 ? "IRR" : "IRT");
            if (ScanService.inst != null) ScanService.inst.hideComparisonPopup();
            render();
        });
        display.addView(UI.tv(this, S.s(R.string.s_dad554600b5e), 10, UI.MUTED, false), UI.lp(this, -1, -2, 0, 2, 0, 0));

        LinearLayout c = section(col, S.s(R.string.s_e5b443358680));
        c.addView(UI.tv(this, S.s(R.string.s_27921c677368), 10, UI.MUTED, false));
        List<Op> ops = Cfg.ops(this);
        for (final Op o : ops) {
            LinearLayout r = UI.hbox(this);
            LinearLayout t = UI.vbox(this);
            r.addView(new OperatorLogo(this, o.id), UI.lp(this, 42, 34, 0, 0, 10, 0));
            t.addView(UI.tv(this, o.name, 13, UI.TEXT, true));
            TextView pk = UI.tv(this, TextUtils.join(S.s(R.string.s_11735aabd336), o.pkgs) + " • " + (o.cur.equals("IRR") ? S.s(R.string.currency_rial) : o.cur.equals("IRT") ? S.s(R.string.currency_toman) : S.s(R.string.s_2affa76a8b46)), 9, UI.MUTED, false);
            // متن ترکیبی فارسی و نام پکیج باید پاراگراف RTL بماند تا ترتیب واژه‌ها به‌هم نریزد.
            pk.setTextDirection(View.TEXT_DIRECTION_RTL);
            t.addView(pk, UI.lp(this, -1, -2, 0, 2, 0, 0));
            r.addView(t, UI.lpw(1f));
            r.addView(UI.btn(this, S.s(R.string.s_782898711134), UI.CARD2, UI.PRIMARY, v -> editOp(o)), UI.lp(this, -2, -2, 0, 0, 6, 0));
            Switch sw = new Switch(this);
            styleSwitch(sw);
            sw.setChecked(o.enabled);
            sw.setOnCheckedChangeListener((bv, enabled) -> { o.enabled = enabled; Cfg.saveOps(this, ops); });
            r.addView(sw);
            c.addView(r, UI.lp(this, -1, -2, 0, 8, 0, 8));
            if (!o.builtin) c.addView(UI.btn(this, S.s(R.string.s_3c3a2a74d5f2) + o.name, UI.tint(UI.DANGER), UI.DANGER, v -> {
                ops.remove(o); Cfg.saveOps(this, ops); Store.clearOp(this, o.id); render();
            }), UI.lp(this, -1, -2, 0, 0, 0, 5));
        }
        int enabledCount = 0;
        for (Op o : ops) if (o.cmp) enabledCount++;
        stepRow(c, S.s(R.string.s_ab46509918a5), S.s(R.string.s_1c2cf3c9db74), Cfg.minOps(this), 1, Math.max(1, enabledCount), 1, "", v -> {
            Cfg.setInt(this, "minOps", v); render();
        });

        LinearLayout custom = section(col, S.s(R.string.s_7d33e6df160a));
        custom.addView(input(S.s(R.string.s_9db0e6e94db4), newName, s -> newName = s), UI.lp(this, -1, -2, 0, 3, 0, 6));
        EditText pkgInput = input(S.s(R.string.s_e1654c21ee35), newPkg, s -> newPkg = s);
        pkgInput.setTextDirection(View.TEXT_DIRECTION_LTR);
        custom.addView(pkgInput, UI.lp(this, -1, -2, 0, 0, 0, 6));
        chips(custom, new String[]{S.s(R.string.s_2affa76a8b46), S.s(R.string.currency_rial), S.s(R.string.currency_toman)}, newCur, i -> { newCur = i; render(); });
        custom.addView(UI.btn(this, S.s(R.string.s_bd2797c1e0c8), UI.PRIMARY, 0xFF061326, v -> addOp()), UI.lp(this, -1, -2, 0, 8, 0, 0));

        LinearLayout comparison = section(col, S.s(R.string.s_6a702aed015c));
        comparison.addView(UI.tv(this, S.s(R.string.s_13f7aa821a1a), 12, UI.TEXT, true));
        chips(comparison, new String[]{S.s(R.string.s_e19a1c0fd10c), S.s(R.string.s_f55747ada77e),
                S.s(R.string.s_d83169d4b855), S.s(R.string.metric_per_gb_month)}, Cfg.metric(this), i -> { Cfg.setInt(this, "metric", i); render(); });
        numberRow(comparison, S.s(R.string.s_97ffca1254b4), Fmt.num(Math.round(Cfg.minGb(this) * 1024)),
                s -> Cfg.setFloat(this, "minGb", Math.max(0f, Math.min(5120000f, (float) (Fmt.parse(s, 0) / 1024.0)))));
        numberRow(comparison, S.s(R.string.s_5dd19f05d553), Fmt.dec(Cfg.maxDays(this)),
                s -> Cfg.setInt(this, "maxDays", Cfg.clamp((int) Fmt.parse(s, 0), 0, 36500)));
        numberRow(comparison, S.s(R.string.s_e55f114c0739), Fmt.dec(Cfg.usage(this)),
                s -> Cfg.setFloat(this, "usage", Cfg.finiteClamp((float) Fmt.parse(s, 30), 0.1f, 5000f, 30f)));
        numberRow(comparison, S.s(R.string.s_ea8d0f428661), Fmt.num(Cfg.vat(this)), s -> Cfg.setInt(this, "vat", Math.max(0, Math.min(100, (int) Fmt.parse(s, Cfg.vat(this))))));
        swRow(comparison, S.s(R.string.s_83a98ff1527c), S.s(R.string.s_5dde7dde640c), Cfg.restricted(this), (bv, on) -> Cfg.setBool(this, "restricted", on));
        swRow(comparison, S.s(R.string.s_e5a0dee52dfb), S.s(R.string.s_96d143f71ab8), Cfg.intl(this), (bv, on) -> Cfg.setBool(this, "intl", on));

        LinearLayout popup = section(col, S.s(R.string.s_d5ec95aff74e));
        swRow(popup, S.s(R.string.s_c7480aa116f5), S.s(R.string.s_ff8143cf7774), Cfg.popup(this), (bv, on) -> Cfg.setBool(this, "popup", on));
        popup.addView(UI.tv(this, S.s(R.string.s_3a868fbe5394), 12, UI.TEXT, true), UI.lp(this, -1, -2, 0, 8, 0, 0));
        chips(popup, new String[]{S.s(R.string.s_c69d6e9d39cb), S.s(R.string.s_53850fa41d5b), S.s(R.string.s_c914b9da9c6d)}, Cfg.pmode(this), i -> { Cfg.setInt(this, "pmode", i); render(); });
        stepRow(popup, S.s(R.string.s_150d52e3b319), null, Cfg.rows(this), 3, 8, 1, "", v -> { Cfg.setInt(this, "rows", v); render(); });
        int[] hv = {0, 8, 15, 30}; int hsel = 0;
        for (int i=0;i<hv.length;i++) if (hv[i] == Cfg.hideSec(this)) hsel = i;
        chips(popup, new String[]{S.s(R.string.s_4cb49f0bcc7d), S.s(R.string.s_e1eac45cc679), S.s(R.string.s_00031efd000d), S.s(R.string.s_ce16aa1839ee)}, hsel, i -> { Cfg.setInt(this, "hide", hv[i]); render(); });
        chips(popup, new String[]{S.s(R.string.s_54d51a0d136c), S.s(R.string.s_02963ef15427)}, Cfg.bottom(this) ? 1 : 0, i -> { Cfg.setBool(this, "bottom", i == 1); render(); });
        popup.addView(UI.btn(this, S.s(R.string.s_351c88c4d377), UI.CARD2, UI.PRIMARY, v -> {
            ScanService service = ScanService.inst;
            if (service == null) toast(S.s(R.string.s_cc0a37e9ccb7)); else service.showTest();
        }), UI.lp(this, -1, -2, 0, 8, 0, 0));

        LinearLayout data = section(col, S.s(R.string.s_2e4112987a90));
        data.addView(UI.tv(this, S.s(R.string.s_b38dd5e5523d), 10, UI.MUTED, false));
        int[] fresh = {3, 7, 14, 30}; int sel = 0;
        for (int i=0;i<fresh.length;i++) if (fresh[i] == Cfg.fresh(this)) sel = i;
        chips(data, new String[]{S.s(R.string.s_a60edda1298d), S.s(R.string.s_8afac8dd9be4), S.s(R.string.s_a4516878137a), S.s(R.string.s_df4b4acff7bd)}, sel, i -> { Cfg.setInt(this, "fresh", fresh[i]); render(); });
        List<Pkg> pendingReview = Store.reviewQueue(this);
        data.addView(UI.tv(this, S.s(R.string.s_fbc6685e4b82), 10, UI.MUTED, false), UI.lp(this, -1, -2, 0, 8, 0, 0));
        data.addView(UI.btn(this, S.s(R.string.s_e9ff88e310b0) + Fmt.fa(String.valueOf(pendingReview.size())),
                UI.CARD2, UI.PRIMARY, v -> showReviewQueue()), UI.lp(this, -1, -2, 0, 7, 0, 0));
        if (HistoryLog.hasError(this)) {
            LinearLayout historyWarning = UI.card(this);
            historyWarning.addView(UI.tv(this, HistoryLog.errorSummary(this), 10, UI.DANGER, false));
            historyWarning.addView(UI.btn(this, S.s(R.string.s_811d68222b4c), UI.CARD2, UI.TEXT, v -> {
                HistoryLog.clearError(this); render();
            }), UI.lp(this, -1, -2, 0, 6, 0, 0));
            data.addView(historyWarning, UI.lp(this, -1, -2, 0, 8, 0, 0));
        }
        data.addView(UI.btn(this, S.s(R.string.s_62a4f1717ccc), UI.CARD2, UI.PRIMARY, v -> exportCsv()), UI.lp(this, -1, -2, 0, 10, 0, 0));
        data.addView(UI.btn(this, S.s(R.string.s_140c82e356c5), UI.CARD2, UI.TEXT, v -> exportDiag()), UI.lp(this, -1, -2, 0, 7, 0, 0));
        LinearLayout history = UI.card(this);
        history.addView(UI.tv(this, S.s(R.string.s_a496fda7a518), 13, UI.TEXT, true));
        List<HistoryLog.Entry> changes = HistoryLog.recent(this, 6);
        if (changes.isEmpty()) history.addView(UI.tv(this, S.s(R.string.s_762fcfffbc57), 10, UI.MUTED, false), UI.lp(this, -1, -2, 0, 6, 0, 0));
        for (HistoryLog.Entry ch : changes) {
            boolean reviewApproved = "review_approved".equals(ch.field);
            boolean reviewRejected = "review_rejected".equals(ch.field);
            if (reviewApproved || reviewRejected) {
                String label = reviewApproved ? S.s(R.string.s_3e5d7cd430e1) : S.s(R.string.s_072db689f46b);
                String detail = ch.note == null || ch.note.isEmpty() ? "" : "\n" + ch.note;
                history.addView(UI.tv(this, label + " • " + ch.title + detail + "  ·  " + Fmt.ago(ch.ts),
                        10, reviewApproved ? UI.PRIMARY : UI.DANGER, false), UI.lp(this, -1, -2, 0, 7, 0, 0));
                continue;
            }
            boolean price = "price".equals(ch.field);
            String field = price ? S.s(R.string.s_7d2c8a1926cb) : ("gb".equals(ch.field) ? S.s(R.string.s_41239044800f) : S.s(R.string.s_611e211b9254));
            String before = price ? Cfg.priceLabel(this, (long)ch.before) : Fmt.dec(ch.before) + ("gb".equals(ch.field) ? S.s(R.string.s_e8b255dd82c6) : S.s(R.string.s_69ff4a27e5a6));
            String after = price ? Cfg.priceLabel(this, (long)ch.after) : Fmt.dec(ch.after) + ("gb".equals(ch.field) ? S.s(R.string.s_e8b255dd82c6) : S.s(R.string.s_69ff4a27e5a6));
            history.addView(UI.tv(this, field + " • " + ch.title + "\n" + before + " ← " + after + "  ·  " + Fmt.ago(ch.ts), 10, price ? UI.ACCENT : UI.MUTED, false),
                    UI.lp(this, -1, -2, 0, 7, 0, 0));
        }
        data.addView(history, UI.lp(this, -1, -2, 0, 10, 0, 0));
        data.addView(UI.btn(this, S.s(R.string.s_0ed31dd62f2c), UI.tint(UI.DANGER), UI.DANGER, v -> new AlertDialog.Builder(this, R.style.AppDialog)
                .setTitle(S.s(R.string.s_a811835d38d9))
                .setMessage(S.s(R.string.clear_data_body))
                .setNegativeButton(S.s(R.string.s_fa7af603d430), null)
                .setPositiveButton(S.s(R.string.clear_confirm), (d, w) -> { Store.clearAll(this); HistoryLog.clear(this); HistoryLog.clearError(this); toast(S.s(R.string.s_ae1c7a0aa42b)); render(); })
                .show()), UI.lp(this, -1, -2, 0, 8, 0, 0));

        TextView privacy = UI.tv(this, S.s(R.string.s_fa4f6cda2a27), 10, UI.MUTED, false);
        privacy.setGravity(Gravity.CENTER);
        col.addView(privacy, UI.lp(this, -1, -2, 0, 16, 0, 0));
    }

    private void showReviewQueue() {
        List<Pkg> queue = Store.reviewQueue(this);
        if (queue.isEmpty()) {
            toast(S.s(R.string.s_6ae2c340ee23));
            return;
        }
        String[] labels = new String[queue.size()];
        for (int i = 0; i < queue.size(); i++) {
            Pkg p = queue.get(i);
            Op op = Cfg.opById(this, p.op);
            String owner = op == null ? p.op : op.name;
            labels[i] = owner + " • " + (p.title == null || p.title.isEmpty() ? S.s(R.string.s_8ddaa838238b) : p.title)
                    + "\n" + p.label() + " • " + (p.currencyKnown ? Cfg.priceLabel(this, p.toman) : S.s(R.string.s_a3179e0838db));
        }
        new AlertDialog.Builder(this, R.style.AppDialog).setTitle(S.s(R.string.review_queue))
                .setItems(labels, (dialog, which) -> editReview(queue.get(which)))
                .setNegativeButton(S.s(R.string.close), null).show();
    }

    private void editReview(Pkg source) {
        final EditText volume = input(S.s(R.string.s_888a05ecedf8), Fmt.dec(source.gb), value -> {});
        final EditText days = input(S.s(R.string.s_558799947d3a), Fmt.dec(source.days), value -> {});
        final EditText price = input(S.s(R.string.s_e1f486969ff5), String.valueOf(source.toman), value -> {});
        volume.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        days.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        price.setInputType(InputType.TYPE_CLASS_NUMBER);
        volume.setTextDirection(View.TEXT_DIRECTION_LTR);
        days.setTextDirection(View.TEXT_DIRECTION_LTR);
        price.setTextDirection(View.TEXT_DIRECTION_LTR);
        volume.setGravity(Gravity.CENTER); days.setGravity(Gravity.CENTER); price.setGravity(Gravity.CENTER);
        volume.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        days.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        price.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        final EditText note = input(S.s(R.string.s_65a45fd11fbd), "", value -> {});
        final CheckBox vat = new CheckBox(this);
        vat.setText(S.s(R.string.review_vat_included));
        vat.setContentDescription(S.s(R.string.review_vat_included));
        vat.setTextColor(UI.TEXT);
        vat.setTextSize(12);
        vat.setTextDirection(View.TEXT_DIRECTION_RTL);
        vat.setMinHeight(dp(48));
        vat.setPadding(dp(8), dp(8), dp(8), dp(8));
        vat.setChecked(source.hasCurrentManualApproval() ? source.reviewedVatIncluded : source.vatIncluded);
        LinearLayout fields = UI.vbox(this);
        fields.setPadding(dp(20), dp(8), dp(20), dp(4));
        String reviewReason = source.note == null || source.note.trim().isEmpty()
                ? (source.why == null || source.why.trim().isEmpty() ? S.s(R.string.s_51f1d7789b8f) : source.why)
                : source.note;
        fields.addView(UI.tv(this, S.s(R.string.s_983e00e1fb2c) + reviewReason, 10, UI.DANGER, false),
                UI.lp(this, -1, -2, 0, 0, 0, 8));
        fields.addView(UI.tv(this, S.s(R.string.s_c60bed445edd),
                10, UI.MUTED, false), UI.lp(this, -1, -2, 0, 0, 0, 8));
        fields.addView(volume, UI.lp(this, -1, -2, 0, 0, 0, 6));
        fields.addView(days, UI.lp(this, -1, -2, 0, 0, 0, 6));
        fields.addView(price, UI.lp(this, -1, -2, 0, 0, 0, 6));
        fields.addView(vat, UI.lp(this, -1, -2, 0, 0, 0, 0));
        fields.addView(UI.tv(this, S.s(R.string.review_vat_hint), 9, UI.MUTED, false),
                UI.lp(this, -1, -2, 0, 0, 0, 6));
        fields.addView(note, UI.lp(this, -1, -2, 0, 0, 0, 0));
        UI.applyTypefaceTree(fields);

        final AlertDialog dialog = new AlertDialog.Builder(this, R.style.AppDialog)
                .setTitle(S.s(R.string.s_cc80b89ab718) + (source.title == null ? S.s(R.string.s_eac5a12c8992) : source.title))
                .setView(fields)
                .setPositiveButton(S.s(R.string.review_approve), (d, which) -> {})
                .setNeutralButton(S.s(R.string.review_reject), (d, which) -> {})
                .setNegativeButton(S.s(R.string.cancel), null)
                .create();
        dialog.setOnShowListener(ignored -> {
            for (int which : new int[]{AlertDialog.BUTTON_POSITIVE, AlertDialog.BUTTON_NEUTRAL, AlertDialog.BUTTON_NEGATIVE}) {
                Button button = dialog.getButton(which);
                if (button != null) {
                    button.setTextColor(UI.PRIMARY);
                    button.setMinHeight(dp(48));
                }
            }
            UI.applyTypefaceTree(fields);
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                double gb = Fmt.parse(volume.getText().toString(), -1);
                double validity = Fmt.parse(days.getText().toString(), -1);
                double priceValue = Fmt.parse(price.getText().toString(), -1);
                long toman = priceValue < 0 || priceValue > 2000000000L ? -1 : Math.round(priceValue);
                boolean saved = Store.saveReview(this, source.key, true, gb, validity, toman,
                        note.getText().toString(), vat.isChecked());
                if (!saved) { toast(S.s(R.string.s_89f642a5bc99)); return; }
                dialog.dismiss(); toast(S.s(R.string.s_0374c961db3a)); render();
            });
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v -> {
                boolean saved = Store.saveReview(this, source.key, false, 0, 0, 0, note.getText().toString());
                if (!saved) { toast(S.s(R.string.s_19d060758da2)); return; }
                dialog.dismiss(); toast(S.s(R.string.s_e70dfa3af0bd)); render();
            });
        });
        dialog.show();
    }

    private View sectionTitle(String title, String subtitle) {
        LinearLayout box = UI.hbox(this);
        View accent = new View(this);
        accent.setBackground(UI.rr(this, UI.PRIMARY, 3));
        box.addView(accent, UI.lp(this, 4, 27, 0, 0, 10, 0));
        LinearLayout labels = UI.vbox(this);
        labels.addView(UI.tv(this, title, 15, UI.TEXT, true));
        if (subtitle != null && !subtitle.isEmpty()) {
            labels.addView(UI.tv(this, subtitle, 10, UI.MUTED, false), UI.lp(this, -1, -2, 0, 2, 0, 0));
        }
        box.addView(labels, UI.lpw(1f));
        return box;
    }

    private LinearLayout section(LinearLayout col, String title) {
        LinearLayout heading = UI.hbox(this);
        View accent = new View(this);
        accent.setBackground(UI.rr(this, UI.PRIMARY, 3));
        heading.addView(accent, UI.lp(this, 4, 20, 0, 0, 9, 0));
        TextView label = UI.tv(this, title, 13, UI.TEXT, true);
        heading.addView(label, UI.lpw(1f));
        col.addView(heading, UI.lp(this, -1, -2, 0, 18, 0, 8));
        LinearLayout c = UI.card(this);
        col.addView(c);
        return c;
    }

    private void styleSwitch(Switch sw) {
        int[][] states = new int[][]{{android.R.attr.state_checked}, {}};
        sw.setThumbTintList(new ColorStateList(states, new int[]{UI.PRIMARY, UI.MUTED}));
        sw.setTrackTintList(new ColorStateList(states, new int[]{
                (UI.PRIMARY & 0x00FFFFFF) | 0x88000000, (UI.STROKE & 0x00FFFFFF) | 0x66000000}));
    }

    private void swRow(LinearLayout c, String title, String sub, boolean on, CompoundButton.OnCheckedChangeListener l) {
        LinearLayout r = UI.hbox(this);
        LinearLayout t = UI.vbox(this);
        t.addView(UI.tv(this, title, 14, UI.TEXT, false));
        if (sub != null) t.addView(UI.tv(this, sub, 11, UI.MUTED, false));
        r.addView(t, UI.lpw(1f));
        Switch s = new Switch(this);
        styleSwitch(s);
        s.setChecked(on);
        s.setOnCheckedChangeListener(l);
        r.addView(s);
        c.addView(r, UI.lp(this, -1, -2, 0, 8, 0, 4));
    }

    /** Chips stay 48dp tall and scroll horizontally instead of squeezing labels off-screen. */
    private void chips(LinearLayout c, String[] labels, int sel, final IntCb cb) {
        LinearLayout row = UI.hbox(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        for (int i = 0; i < labels.length; i++) {
            final int idx = i;
            boolean on = i == sel;
            TextView t = UI.chip(this, labels[i], on ? UI.PRIMARY : UI.CARD2,
                    on ? UI.contrastText(UI.PRIMARY) : UI.TEXT);
            t.setMinWidth(dp(96));
            t.setMinHeight(dp(48));
            t.setOnClickListener(v -> {
                for (int j = 0; j < row.getChildCount(); j++) {
                    TextView sibling = (TextView) row.getChildAt(j);
                    UI.setChipSelected(this, sibling, j == idx, UI.CARD2);
                }
                cb.on(idx);
            });
            LinearLayout.LayoutParams chip = new LinearLayout.LayoutParams(-2, -2);
            chip.setMarginStart(dp(3));
            chip.setMarginEnd(dp(3));
            row.addView(t, chip);
        }
        HorizontalScrollView scroller = new HorizontalScrollView(this);
        scroller.setHorizontalScrollBarEnabled(false);
        scroller.setFillViewport(false);
        scroller.addView(row);
        c.addView(scroller, UI.lp(this, -1, -2, 0, 6, 0, 6));
    }

    private void stepRow(LinearLayout c, String title, String sub, final int val, final int min, final int max, final int step, String suffix, final IntCb cb) {
        LinearLayout r = UI.hbox(this);
        LinearLayout t = UI.vbox(this);
        t.addView(UI.tv(this, title, 13, UI.TEXT, false));
        if (sub != null) t.addView(UI.tv(this, sub, 10, UI.MUTED, false));
        r.addView(t, UI.lpw(1f));
        r.addView(UI.btn(this, "−", UI.CARD2, UI.TEXT, v -> cb.on(Math.max(min, val - step))));
        TextView n = UI.tv(this, Fmt.fa(String.valueOf(val)) + suffix, 14, UI.PRIMARY, true);
        n.setGravity(Gravity.CENTER);
        n.setMinWidth(dp(56));
        r.addView(n);
        r.addView(UI.btn(this, "+", UI.CARD2, UI.TEXT, v -> cb.on(Math.min(max, val + step))));
        c.addView(r, UI.lp(this, -1, -2, 0, 6, 0, 6));
    }

    private EditText input(String hint, String text, final StrCb cb) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setHintTextColor(UI.MUTED);
        e.setTextColor(UI.TEXT);
        e.setTextSize(13);
        e.setSingleLine();
        e.setInputType(InputType.TYPE_CLASS_TEXT);
        e.setText(text);
        e.setBackground(UI.rr(this, UI.CARD2, 12, UI.STROKE));
        e.setPadding(dp(14), dp(11), dp(14), dp(11));
        e.setMinHeight(dp(46));
        e.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
        e.setTextDirection(View.TEXT_DIRECTION_ANY_RTL);
        e.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void afterTextChanged(Editable s) { cb.on(s.toString()); }
        });
        return e;
    }

    private void numberRow(LinearLayout c, String label, String cur, StrCb cb) {
        c.addView(UI.tv(this, label, 13, UI.TEXT, false), UI.lp(this, -1, -2, 0, 10, 0, 4));
        EditText value = input("", cur, cb);
        // Numeric settings use centered LTR presentation so digits/decimal separators stay predictable.
        value.setTextDirection(View.TEXT_DIRECTION_LTR);
        value.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        value.setGravity(Gravity.CENTER);
        value.setText(Fmt.norm(cur));
        value.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        c.addView(value);
    }

    private void addOp() {
        String name = newName == null ? "" : newName.trim();
        String pkg = newPkg == null ? "" : newPkg.trim();
        if (name.isEmpty() || pkg.isEmpty() || name.length() > 40) {
            toast(S.s(R.string.s_ccd1ded3c7e7));
            return;
        }
        if (!Cfg.validPackageName(pkg)) {
            toast(S.s(R.string.s_85d39c4029cc));
            return;
        }
        List<Op> l = Cfg.ops(this);
        for (Op existing : l) if (existing.pkgs.contains(pkg)) {
            toast(S.s(R.string.s_85f305728558) + existing.name + S.s(R.string.s_7036a09d37d1));
            return;
        }
        int[] pal = {0xFF8B5CF6, 0xFFEC4899, 0xFF22C55E, 0xFFF97316, 0xFF06B6D4};
        String[] cur = {"AUTO", "IRR", "IRT"};
        l.add(new Op("c" + System.currentTimeMillis(), name, pal[l.size() % pal.length], cur[Math.max(0, Math.min(2, newCur))], false, pkg));
        Cfg.saveOps(this, l);
        newName = "";
        newPkg = "";
        render();
    }

    private void editOp(final Op o) {
        final EditText e = input("com.example.app, com.example.beta", TextUtils.join(", ", o.pkgs), s -> {});
        e.setTextDirection(View.TEXT_DIRECTION_LTR);
        LinearLayout editor = UI.vbox(this);
        editor.setPadding(dp(20), dp(8), dp(20), 0);
        editor.addView(e);
        final int[] chosenPolicy = {ProviderAdapter.normalizePolicy(o.policy)};
        editor.addView(UI.tv(this, S.s(R.string.policy_title), 12, UI.TEXT, true),
                UI.lp(this, -1, -2, 0, 12, 0, 0));
        chips(editor, new String[]{S.s(R.string.policy_auto), S.s(R.string.policy_largest),
                S.s(R.string.policy_smallest)}, chosenPolicy[0],
                i -> chosenPolicy[0] = ProviderAdapter.normalizePolicy(i));
        editor.addView(UI.tv(this, S.s(R.string.policy_hint), 10, UI.MUTED, false),
                UI.lp(this, -1, -2, 0, 4, 0, 0));
        final AlertDialog dialog = new AlertDialog.Builder(this, R.style.AppDialog)
                .setTitle(S.s(R.string.s_4cd16b460776) + o.name)
                .setMessage(S.s(R.string.s_70b71d545ea1))
                .setView(editor)
                .setPositiveButton(S.s(R.string.save), (dlg, w) -> {})
                .setNegativeButton(S.s(R.string.cancel), null)
                .create();
        dialog.setOnShowListener(v -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(button -> {
            List<String> proposed = new ArrayList<>();
            for (String raw : e.getText().toString().split("[,\\s]+")) {
                String value = raw.trim();
                if (value.isEmpty()) continue;
                if (!Cfg.validPackageName(value)) {
                    toast(S.s(R.string.s_2525630c0f0e) + value);
                    return;
                }
                if (proposed.contains(value)) {
                    toast(S.s(R.string.s_42f719e93116) + value);
                    return;
                }
                for (Op other : Cfg.ops(this)) {
                    if (!other.id.equals(o.id) && other.pkgs.contains(value)) {
                        toast(S.s(R.string.s_1ec9ab02627f) + other.name + S.s(R.string.s_2aa2964a4d3f) + value);
                        return;
                    }
                }
                proposed.add(value);
            }
            if (proposed.isEmpty()) {
                toast(S.s(R.string.s_0a4198c2c0c6));
                return;
            }
            List<Op> updated = Cfg.ops(this);
            boolean found = false;
            for (Op item : updated) {
                if (item.id.equals(o.id)) {
                    item.pkgs.clear(); item.pkgs.addAll(proposed);
                    item.policy = chosenPolicy[0];
                    found = true; break;
                }
            }
            if (!found) { toast(S.s(R.string.s_8fefa9877e3f)); return; }
            Cfg.saveOps(this, updated);
            // A changed price policy re-prices only stored packages that actually exposed
            // competing amounts; raw extraction is never invented or destroyed.
            if (chosenPolicy[0] != o.policy) Store.reprice(this, o.id, chosenPolicy[0]);
            dialog.dismiss();
            render();
        }));
        dialog.show();
    }

    // ---------------------------------------------------------------- export

    private static String csv(String value) {
        String safe = value == null ? "" : value.replace("\"", "\"\"");
        return "\"" + safe + "\"";
    }

    private void exportCsv() {
        final List<Pkg> all = Store.all(this);
        if (all.isEmpty()) {
            toast(S.s(R.string.s_8330f5bb7281));
            return;
        }
        new AlertDialog.Builder(this, R.style.AppDialog)
                .setTitle(S.s(R.string.export_privacy_title))
                .setMessage(S.s(R.string.export_privacy_message))
                .setNegativeButton(S.s(R.string.export_privacy_cancel), null)
                .setPositiveButton(S.s(R.string.export_privacy_confirm),
                        (dialog, which) -> writeCsv(all))
                .show();
    }

    private void writeCsv(List<Pkg> all) {
        String ts = new SimpleDateFormat("MMdd_HHmmss", Locale.US).format(new Date());
        try {
            String where = save("bastehyab_" + ts + ".csv", "text/csv", o -> {
                StringBuilder sb = new StringBuilder("\uFEFFoperator,title,gb,days,price_toman,"
                        + "price_with_vat_toman,vat_percent,vat_included,currency_known,ambiguous,"
                        + "per_final_gb_toman,restricted,reason,parser_note,review_status,review_note,"
                        + "reviewed_gb,reviewed_days,reviewed_toman,reviewed_vat_included,reviewed_at,captured\n");
                // one row per real package (operator + volume + duration + price), newest observation kept
                Map<String, Pkg> uniqueRows = new LinkedHashMap<>();
                for (Pkg p : all) {
                    if (p.op == null || p.op.isEmpty()) continue;
                    Pkg prev = uniqueRows.get(p.sig());
                    if (prev == null || p.ts > prev.ts) uniqueRows.put(p.sig(), p);
                }
                SimpleDateFormat stamp = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US);
                for (Pkg p : uniqueRows.values()) {
                    Op op = Cfg.opById(this, p.op);
                    long finalToman = Cfg.finalPrice(this, p);
                    sb.append(csv(op == null ? p.op : op.name)).append(',')
                            .append(csv(Privacy.scrub(p.title))).append(',')
                            .append(p.gb).append(',').append(p.days).append(',')
                            .append(p.currencyKnown ? String.valueOf(p.toman) : "").append(',')
                            .append(p.currencyKnown ? String.valueOf(finalToman) : "").append(',')
                            .append(p.vatIncluded ? 0 : Cfg.vat(this)).append(',')
                            .append(p.vatIncluded).append(',')
                            .append(p.currencyKnown).append(',')
                            .append(p.ambig).append(',')
                            .append(p.currencyKnown && !p.ambig && p.gb > 0
                                    ? String.valueOf(Math.round(finalToman / p.gb)) : "").append(',')
                            .append(p.restricted).append(',').append(csv(Privacy.scrub(p.why))).append(',')
                            .append(csv(Privacy.scrub(p.note))).append(',')
                            .append(csv(p.reviewStatus)).append(',')
                            .append(csv(Privacy.scrub(p.reviewNote))).append(',')
                            .append(p.reviewedGb).append(',')
                            .append(p.reviewedDays).append(',')
                            .append(p.reviewedToman).append(',')
                            .append(p.reviewedVatIncluded).append(',')
                            .append(p.reviewedAt > 0 ? stamp.format(new Date(p.reviewedAt)) : "").append(',')
                            .append(stamp.format(new Date(p.ts))).append('\n');
                }
                o.write(sb.toString().getBytes(StandardCharsets.UTF_8));
            });
            toast(S.s(R.string.s_4390f87cc2e7) + where);
        } catch (Exception e) {
            toast(e.toString());
        }
    }

    private void exportDiag() {
        // Flush the in-memory snapshot first; otherwise a fast tap just after a scan may
        // incorrectly report that no diagnostic exists because the debounce has not fired.
        ScanService.flushDiagnostics();
        final File f = new File(getFilesDir(), "diag.txt");
        if (!f.exists()) {
            toast(S.s(R.string.s_12371d38a1ce));
            return;
        }
        new AlertDialog.Builder(this, R.style.AppDialog)
                .setTitle(S.s(R.string.export_privacy_title))
                .setMessage(S.s(R.string.export_privacy_message))
                .setNegativeButton(S.s(R.string.export_privacy_cancel), null)
                .setPositiveButton(S.s(R.string.export_privacy_confirm),
                        (dialog, which) -> writeDiag(f))
                .show();
    }

    private void writeDiag(File f) {
        String ts = new SimpleDateFormat("MMdd_HHmmss", Locale.US).format(new Date());
        try {
            String where = save("diag_" + ts + ".txt", "text/plain", o -> {
                StringBuilder text = new StringBuilder();
                try (BufferedReader reader = new BufferedReader(
                        new InputStreamReader(new FileInputStream(f), StandardCharsets.UTF_8))) {
                    String line;
                    while ((line = reader.readLine()) != null) text.append(line).append('\n');
                }
                o.write(Privacy.scrub(text.toString()).getBytes(StandardCharsets.UTF_8));
            });
            toast(S.s(R.string.s_4390f87cc2e7) + where);
        } catch (Exception e) {
            toast(e.toString());
        }
    }

    /** Returns a human-readable location. API 29+ uses MediaStore Downloads; older Android uses the app's own Downloads folder. */
    private String save(String name, String mime, W w) throws Exception {
        if (Build.VERSION.SDK_INT < 29) {
            File dir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
            if (dir == null) throw new java.io.IOException(S.s(R.string.s_6736f12d3825));
            if (!dir.exists() && !dir.mkdirs()) throw new java.io.IOException(S.s(R.string.s_b97406653bb4));
            File out = new File(dir, name);
            try (OutputStream o = new FileOutputStream(out)) {
                w.w(o);
            } catch (Exception e) {
                out.delete();
                throw e;
            }
            return out.getAbsolutePath();
        }
        ContentValues v = new ContentValues();
        v.put(MediaStore.Downloads.DISPLAY_NAME, name);
        v.put(MediaStore.Downloads.MIME_TYPE, mime);
        Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
        if (u == null) throw new java.io.IOException(S.s(R.string.s_d73804b71428));
        try (OutputStream o = getContentResolver().openOutputStream(u)) {
            if (o == null) throw new java.io.IOException(S.s(R.string.s_6181b8080695));
            w.w(o);
        } catch (Exception e) {
            getContentResolver().delete(u, null, null);
            throw e;
        }
        return "Downloads";
    }
}
