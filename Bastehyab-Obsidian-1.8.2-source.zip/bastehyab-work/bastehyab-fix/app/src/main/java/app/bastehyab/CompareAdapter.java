package app.bastehyab;

import android.content.Context;
import android.view.ViewGroup;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

/**
 * RecyclerView adapter for the ranked package list. DiffUtil computes item moves /
 * content changes from structural package keys, so a live refresh no longer rebuilds
 * the whole list. The ViewModel is the source of truth; submit() is idempotent.
 */
final class CompareAdapter extends RecyclerView.Adapter<CompareAdapter.Row> {
    /** Keep the historic 80-row cap so a pathological dataset cannot stall the UI. */
    static final int MAX_ROWS = 80;

    interface DetailOpener { void open(Pkg p); }

    static final class Row extends RecyclerView.ViewHolder {
        final CompareRowView view;
        Row(CompareRowView v) { super(v); view = v; }
    }

    private final List<Pkg> items = new ArrayList<>();
    private final Context context;
    private final DetailOpener opener;
    private Compare.Result result;

    CompareAdapter(Context c, DetailOpener opener) {
        this.context = c;
        this.opener = opener;
    }

    private static int rankOf(Compare.Result cr, String key) {
        if (cr == null || !cr.rank.containsKey(key)) return -1;
        return cr.rank.get(key);
    }

    private static double valOf(Compare.Result cr, String key) {
        if (cr == null || !cr.val.containsKey(key)) return Double.MAX_VALUE;
        return cr.val.get(key);
    }

    /** Publish a new result; only genuinely changed rows are rebound. */
    void submit(Compare.Result cr) {
        if (cr == null) return;
        final List<Pkg> next = new ArrayList<>(cr.ranked.size() > MAX_ROWS
                ? cr.ranked.subList(0, MAX_ROWS) : cr.ranked);
        final List<Pkg> old = new ArrayList<>(items);
        final Compare.Result previous = result;
        DiffUtil.DiffResult diff = DiffUtil.calculateDiff(new DiffUtil.Callback() {
            @Override public int getOldListSize() { return old.size(); }
            @Override public int getNewListSize() { return next.size(); }
            @Override public boolean areItemsTheSame(int oldPos, int newPos) {
                return old.get(oldPos).key.equals(next.get(newPos).key);
            }
            @Override public boolean areContentsTheSame(int oldPos, int newPos) {
                Pkg a = old.get(oldPos), b = next.get(newPos);
                return a.sourceFingerprint().equals(b.sourceFingerprint())
                        && a.reviewStatus.equals(b.reviewStatus)
                        && rankOf(previous, a.key) == rankOf(cr, b.key)
                        && Double.compare(valOf(previous, a.key), valOf(cr, b.key)) == 0;
            }
        });
        items.clear();
        items.addAll(next);
        result = cr;
        diff.dispatchUpdatesTo(this);
    }

    int hiddenCount() {
        return result == null ? 0 : Math.max(0, result.ranked.size() - MAX_ROWS);
    }

    @Override public Row onCreateViewHolder(ViewGroup parent, int viewType) {
        CompareRowView row = new CompareRowView(parent.getContext());
        row.setLayoutParams(new RecyclerView.LayoutParams(
                RecyclerView.LayoutParams.MATCH_PARENT,
                RecyclerView.LayoutParams.WRAP_CONTENT));
        return new Row(row);
    }

    @Override public void onBindViewHolder(Row holder, int position) {
        final Pkg p = items.get(position);
        Op op = Cfg.opById(context, p.op);
        int rank = rankOf(result, p.key);
        holder.view.bind(p, rank < 1 ? position + 1 : rank, result, op,
                v -> opener.open(p));
    }

    @Override public int getItemCount() { return items.size(); }
}
