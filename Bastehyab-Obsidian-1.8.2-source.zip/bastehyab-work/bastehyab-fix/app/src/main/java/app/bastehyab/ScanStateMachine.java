package app.bastehyab;

/**
 * The single source of truth for an accessibility scan session. The old implementation
 * spread one logical state over six independent volatile booleans; any combination was
 * writable, so diagnostics and UI could disagree. Here only declared transitions can
 * change state, and every rejected transition is counted for diagnosis.
 *
 * This class is pure Java (no Android types), so the plain-JVM smoke suites exercise the
 * exact same transition table that the service uses.
 */
final class ScanStateMachine {
    enum State { IDLE, WAITING_CONFIRM, WAITING_PAGE, SCANNING, PAUSED, FINISHED, ERROR }
    enum Event { START, ABORT, CONFIRM, TARGET_SEEN, BEGIN_SCAN, PAUSE, RESUME, STOP, FAIL }

    private State state = State.IDLE;
    private State resumeState = State.IDLE;
    private boolean targetObserved;
    private int transitions;
    private int rejected;
    private String lastRejection = "";

    private static boolean active(State s) {
        return s == State.WAITING_CONFIRM || s == State.WAITING_PAGE
                || s == State.SCANNING || s == State.PAUSED;
    }

    /** Returns true only for a declared transition; an illegal event never mutates state. */
    synchronized boolean dispatch(Event event) {
        if (event == null) return false;
        State from = state;
        State to = null;
        switch (event) {
            case START:
                // Starting a new session always supersedes the previous one cleanly.
                targetObserved = false;
                resumeState = State.IDLE;
                to = State.WAITING_CONFIRM;
                break;
            case ABORT:
                targetObserved = false;
                resumeState = State.IDLE;
                to = State.IDLE;
                break;
            case CONFIRM:
                if (state == State.WAITING_CONFIRM) to = State.WAITING_PAGE;
                break;
            case TARGET_SEEN:
                if (state == State.WAITING_CONFIRM || state == State.WAITING_PAGE
                        || state == State.SCANNING || state == State.PAUSED) {
                    targetObserved = true;
                    to = state;
                }
                break;
            case BEGIN_SCAN:
                // The target package page must have been observed before any scrolling.
                if (state == State.WAITING_PAGE && targetObserved) to = State.SCANNING;
                break;
            case PAUSE:
                if (state == State.WAITING_PAGE || state == State.SCANNING) {
                    resumeState = state;
                    to = State.PAUSED;
                }
                break;
            case RESUME:
                if (state == State.PAUSED) {
                    to = resumeState == State.SCANNING ? State.SCANNING : State.WAITING_PAGE;
                    resumeState = State.IDLE;
                }
                break;
            case STOP:
                if (active(state)) to = State.IDLE;
                break;
            case FAIL:
                if (active(state)) to = State.ERROR;
                break;
            default:
                break;
        }
        if (to == null) {
            rejected++;
            lastRejection = from + "/" + event;
            return false;
        }
        state = to;
        transitions++;
        return true;
    }

    /** A stopped session is either conclusively finished or simply idle. */
    synchronized void stop(boolean endConfirmed) {
        state = endConfirmed ? State.FINISHED : State.IDLE;
        targetObserved = false;
        resumeState = State.IDLE;
        transitions++;
    }

    synchronized State state() { return state; }
    synchronized boolean isActive() { return active(state); }
    synchronized boolean isAwaitingConfirm() { return state == State.WAITING_CONFIRM; }
    synchronized boolean isConfirmed() {
        return state == State.WAITING_PAGE || state == State.SCANNING || state == State.PAUSED;
    }
    synchronized boolean isAwaitingPage() { return state == State.WAITING_PAGE; }
    synchronized boolean isPaused() { return state == State.PAUSED; }
    synchronized boolean isScanning() { return state == State.SCANNING; }
    synchronized boolean isTargetObserved() { return targetObserved; }
    synchronized boolean isFinished() { return state == State.FINISHED; }
    synchronized int transitions() { return transitions; }
    synchronized int rejected() { return rejected; }
    synchronized String lastRejection() { return lastRejection; }

    synchronized ScanPhase phase() {
        switch (state) {
            case WAITING_CONFIRM: return ScanPhase.WAITING_CONFIRM;
            case WAITING_PAGE: return ScanPhase.WAITING_PAGE;
            case SCANNING: return ScanPhase.SCANNING;
            case PAUSED: return ScanPhase.PAUSED;
            case FINISHED: return ScanPhase.FINISHED;
            case ERROR: return ScanPhase.ERROR;
            default: return ScanPhase.IDLE;
        }
    }

    /** Machine-readable, PII-free diagnostics line. */
    synchronized String diagnostics() {
        return "state=" + state + " targetObserved=" + targetObserved
                + " transitions=" + transitions + " rejected=" + rejected
                + " lastRejection=" + (lastRejection.isEmpty() ? "none" : lastRejection);
    }
}
