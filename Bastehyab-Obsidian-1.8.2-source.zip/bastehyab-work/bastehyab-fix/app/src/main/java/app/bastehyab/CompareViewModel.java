package app.bastehyab;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

/**
 * Comparison state survives configuration changes and is the single observable source
 * for the adapter. MainActivity publishes one Compare.run result per render; the
 * RecyclerView observes it instead of the activity rebuilding every row.
 */
public final class CompareViewModel extends ViewModel {
    private final MutableLiveData<Compare.Result> result = new MutableLiveData<>();

    LiveData<Compare.Result> result() { return result; }

    void publish(Compare.Result value) { result.setValue(value); }

    Compare.Result current() { return result.getValue(); }
}
