package app.bastehyab;

import android.content.Context;
import androidx.test.core.app.ApplicationProvider;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import org.junit.Test;
import org.junit.runner.RunWith;
import java.util.ArrayList;
import java.util.List;
import static org.junit.Assert.*;

/** Device-side smoke for the RecyclerView diff pipeline (no Activity launch required). */
@RunWith(AndroidJUnit4.class)
public final class CompareListInstrumentationTest {

    private static Compare.Result result(int count, long basePrice) {
        Compare.Result r = new Compare.Result();
        for (int i = 0; i < count; i++) {
            Pkg p = new Pkg();
            p.op = "irancell";
            p.key = "offer-" + i;
            p.title = "offer " + i;
            p.gb = 5 + i;
            p.days = 30;
            p.toman = basePrice + i;
            p.currencyKnown = true;
            p.ts = System.currentTimeMillis();
            r.ranked.add(p);
            r.val.put(p.key, p.toman / p.gb);
            r.rank.put(p.key, i + 1);
        }
        r.median = basePrice / 5.0;
        return r;
    }

    @Test public void diffReusesRowsAndTracksOnlyRealChanges() {
        Context c = ApplicationProvider.getApplicationContext();
        List<Pkg> opened = new ArrayList<>();
        CompareAdapter adapter = new CompareAdapter(c, opened::add);
        adapter.submit(result(3, 100000L));
        assertEquals(3, adapter.getItemCount());
        assertEquals(0, adapter.hiddenCount());

        // Same keys and same content: no structural change, no refresh churn.
        adapter.submit(result(3, 100000L));
        assertEquals(3, adapter.getItemCount());

        // A new offer and a changed price must be reflected by DiffUtil.
        adapter.submit(result(4, 120000L));
        assertEquals(4, adapter.getItemCount());

        Compare.Result large = result(CompareAdapter.MAX_ROWS + 5, 100000L);
        adapter.submit(large);
        assertEquals(CompareAdapter.MAX_ROWS, adapter.getItemCount());
        assertEquals(5, adapter.hiddenCount());
    }
}
