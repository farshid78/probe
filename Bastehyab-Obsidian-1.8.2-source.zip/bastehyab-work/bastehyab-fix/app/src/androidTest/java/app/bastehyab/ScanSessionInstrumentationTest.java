package app.bastehyab;

import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import org.junit.Test;
import org.junit.runner.RunWith;
import static org.junit.Assert.*;
import static app.bastehyab.ScanStateMachine.Event;

/**
 * Device-side lifecycle smoke for the accessibility scan session. Run with
 * `./gradlew :app:connectedDebugAndroidTest` on a real device or emulator.
 * CI verifies JVM/Lint only; these checks need the Android runtime.
 */
@RunWith(AndroidJUnit4.class)
public final class ScanSessionInstrumentationTest {

    @Test public void typedPhasesResolveRealLocalizedLabels() {
        S.init(InstrumentationRegistry.getInstrumentation().getTargetContext());
        ScanStateMachine machine = new ScanStateMachine();
        assertTrue(machine.dispatch(Event.START));
        assertEquals(ScanPhase.WAITING_CONFIRM, machine.phase());
        assertFalse("a typed phase must have a localized label",
                ScanPhase.WAITING_CONFIRM.label().isEmpty());
        assertTrue(machine.dispatch(Event.CONFIRM));
        assertEquals(ScanPhase.WAITING_PAGE, machine.phase());
        assertTrue(machine.dispatch(Event.TARGET_SEEN));
        assertTrue(machine.dispatch(Event.BEGIN_SCAN));
        assertEquals(ScanPhase.SCANNING, machine.phase());
        assertTrue(machine.dispatch(Event.PAUSE));
        assertEquals(ScanPhase.PAUSED, machine.phase());
    }

    @Test public void servicePhaseFollowsTheSingleSessionState() {
        S.init(InstrumentationRegistry.getInstrumentation().getTargetContext());
        ScanService.lastScanError = "";
        ScanService.session.dispatch(Event.ABORT);
        assertEquals(ScanPhase.IDLE, ScanService.phase());
        assertTrue(ScanService.session.dispatch(Event.START));
        assertEquals(ScanPhase.WAITING_CONFIRM, ScanService.phase());
        ScanService.session.stop(true);
        assertEquals(ScanPhase.FINISHED, ScanService.phase());
        assertFalse(ScanService.session.isActive());
    }
}
