# Instrumentation tests

These tests exercise the real Android runtime (resource-backed `S`/`R`, the
Accessibility scan session and the `RecyclerView`/`DiffUtil` adapter). They are **not**
run by the JVM-only `tools/run-all-checks.sh` and are **not** run by the CI `verify` job,
which has no emulator/device.

Run on a connected device or emulator (Android 7 / API 24 minimum, Android 16 / API 36
recommended):

```bash
./gradlew :app:connectedDebugAndroidTest
```

For the full five-operator acceptance pass, see `NEXT_STEPS_CHECKLIST_FA.md` items 10–11:
launch each configured operator app, enable the Accessibility service, confirm the
internet-package page, let the targeted scan complete and publish a PASS/FAIL matrix.
Real accessibility dumps must be sanitized with
`tools/fixture-sanitizer/sanitize_accessibility.py` and kept outside the repository.
