<div dir="rtl">

# بسته‌یاب | راهنمای توسعهدهندگان — نسخهٔ 1.9.0

این دایرکتوری محتوای `Bastehyab-Obsidian-1.8.2-source.zip` است. نام آرشیو تاریخی است، ولی **نسخهٔ برنامه 1.9.0** و تنها مرجع متادیتای جاری `app/build.gradle` است.

## ساختار

| مسیر | محتوا |
|---|---|
| `app/src/main/java/app/bastehyab/` | سورس Java شامل accessibility، parser، دامنه، ذخیره، UI، `provider/` و `diagnostics/` |
| `app/src/main/res/` | ۴۱۲ رشته، تمهای روشن/تاریک/تکرنگ، ابعاد، آیکونها، فونتها و پیکربندی سرویس |
| `app/src/test/` | ۳۴ رگرسیون JUnit |
| `app/src/androidTest/` | تستهای instrumentation برای lifecycle سرویس و بازیابی ردیفهای `RecyclerView` |
| `gradle/`, `gradlew`, `build.gradle`, `settings.gradle` | wrapper رسمی Gradle 8.13، AGP 8.11.1 و API 36 |
| `tools/` | ۱۰ مجموعه تست JVM، stub منابع، corpus نسخهدار، اعتبارسنجی منابع، ماتریس پذیرش دستگاهی، کنتراست و قراردادهای UI |
| `branding/` | منابع هویت بصری و تصاویر مرجع |
| `docs/history/` | بایگانی مستندات و نسخههای 1.2.2 تا 1.8.2؛ مرجع نسخهٔ جاری نیستند |
| `NEXT_STEPS_CHECKLIST_FA.md` | چکلیست فاز تکمیلی ۱۱ موردی |
| `ARCHITECTURE_FA.md` | نقشهٔ ماژولها و مرزهای وابستگی |
| `PLAY_POLICY_AUDIT_FA.md` / `RELEASE_SIGNING_FA.md` | ممیزی سیاست Play و دستورات انتشار امضاشده |
| `CHANGELOG.md` | تغییرات نسخهٔ 1.9.0 و فاز تکمیلی |
| `PROJECT_REVIEW_FA.md` / `FINAL_IMPLEMENTATION_REPORT_FA.md` | ممیزی تاریخی و گزارش نهایی |

## اجرا

```bash
bash tools/run-all-checks.sh
./gradlew :app:lintDebug :app:testDebugUnitTest :app:assembleDebug
```

دستور نخست به JDK و `javac` نیاز دارد، ولی به Android SDK وابسته نیست: کامپایل JVM، ۱۰ مجموعه تست، ۳۴ رگرسیون JUnit، ۱۰ fixture ناشناس × ۱۳۲ بررسی، گراف ۵۰ فایل منبع XML، ۴ جدول فونت sfnt، ماتریس پذیرش ۵۰ ردیفی، کنتراست و قراردادهای معماری/UI را اجرا میکند. دستور دوم به JDK 17، Android SDK Platform 36 و Build Tools 35.0.0 نیاز دارد و در CI اجرا میشود. نسخهٔ محلی `versionCode=1` است؛ انتشار محافظتشده `BH_VERSION_CODE` را از `github.run_number` میگیرد، آن را در برابر آخرین Release بررسی میکند و در صورت وجود چهار Secret، امضای اختیاری Release را اعمال میکند.

برای پذیرش دستگاهی:

```bash
python3 tools/device-acceptance/acceptance_matrix.py --template > results.csv
python3 tools/device-acceptance/acceptance_matrix.py results.csv
./gradlew :app:connectedDebugAndroidTest
```

## امنیت، حریم خصوصی و سیاست Play

- هیچ مجوز `INTERNET`، `allowBackup` یا ترافیک متنی آشکار در برنامه وجود ندارد.
- سرویس Accessibility با `packageNames` فقط به اپراتورهای پیکربندیشده محدود میشود؛ swipe تنها با پنجرهٔ فعال همان اپراتور و پس از تأیید صریح صفحه انجام میشود.
- افشای برجستهٔ جداگانه در شروع عادی برنامه نمایش داده میشود؛ دکمهٔ ادامه تنها پس از تیک `CheckBox` فعال میشود. رضایت نسخهدار در `Cfg` ذخیره میشود و `ScanService.startFull`/`confirmFull` بدون آن `ABORT` میدهند. `isAccessibilityTool` اعلام نشده است.
- متن خام صفحه ذخیره نمیشود. خروجی CSV و `diag.txt` فقط با تأیید صریح کاربر و پس از ناشناسسازی شماره/ایمیل/UUID/شناسههای بلند ساخته میشود.
- اسکن کامل فقط پس از بازکردن اپراتور و تأیید صفحهٔ بستهها آغاز میشود؛ «اسکن مجدد» هرگز بهطور خودکار تأیید نمیشود. `ScanStateMachine` تنها مرجع وضعیت است.

## ناوبری برگشت

`MainActivity` از `androidx.activity.ComponentActivity` و `OnBackPressedDispatcher` استفاده میکند. ژست پیشبینانهٔ برگشت در Android 16 ابتدا اسپلش یا تب جاری را میبندد و سپس برنامه را ترک میکند؛ متد منسوخشدهٔ `onBackPressed()` دیگر بهکار نمیرود.

## محدودیت اعتبارسنجی

تست زندهٔ پنج اپراتور، instrumentation روی دستگاه، APK امضاشده، اعلام Play Console و ویدئوی نمایش افشا در محیط توسعهٔ محلی/سندباکس انجام نشده است؛ پروتکل، ماتریس، افشا، قفل رضایت و امضای اختیاری CI آمادهاند. AAPT/Lint/APK توسط workflow روی `ubuntu-latest` اجرا میشوند و نتیجهٔ remote CI پس از push قابل مشاهده است. جزئیات در `NEXT_STEPS_CHECKLIST_FA.md` و `FINAL_IMPLEMENTATION_REPORT_FA.md`.

</div>
