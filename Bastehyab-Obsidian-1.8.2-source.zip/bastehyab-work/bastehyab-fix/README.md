<div dir="rtl">

# بسته‌یاب | راهنمای توسعهدهندگان — نسخهٔ 1.9.0

این دایرکتوری محتوای `Bastehyab-Obsidian-1.8.2-source.zip` است. نام آرشیو تاریخی است، ولی **نسخهٔ برنامه 1.9.0** و تنها مرجع متادیتای جاری `app/build.gradle` است.

## ساختار

| مسیر | محتوا |
|---|---|
| `app/src/main/java/app/bastehyab/` | سورس Java شامل accessibility، parser، دامنه، ذخیره، UI، `provider/` و `diagnostics/` |
| `app/src/main/res/` | ۴۱۲ رشته، تمهای روشن/تاریک/تکرنگ، ابعاد، آیکونها، فونتها و پیکربندی سرویس |
| `app/src/test/` | ۳۴ رگرسیون JUnit |
| `app/src/androidTest/` | تستهای instrumentation برای lifecycle سرویس و بازیابی ردیفهای `RecyclerView` |
| `gradle/`, `gradlew`, `build.gradle`, `settings.gradle` | wrapper رسمی Gradle 8.13، AGP 8.11.1 و API 36 |
| `tools/` | ۱۱ مجموعه تست JVM، stub منابع، corpus نسخهدار، اعتبارسنجی منابع، ماتریس پذیرش دستگاهی، قراردادهای انتشار امضاشده، کنتراست و قراردادهای UI |
| `branding/` | منابع هویت بصری و تصاویر مرجع |
| `docs/history/` | بایگانی مستندات و نسخههای 1.2.2 تا 1.8.2؛ مرجع نسخهٔ جاری نیستند |
| `NEXT_STEPS_CHECKLIST_FA.md` | چکلیست فاز تکمیلی ۱۱ موردی |
| `ARCHITECTURE_FA.md` | نقشهٔ ماژولها و مرزهای وابستگی |
| `PLAY_POLICY_AUDIT_FA.md` / `RELEASE_SIGNING_FA.md` | ممیزی سیاست Play و دستورات انتشار امضاشده |
| `ci-preview.p12` / `ci-preview.properties.example` | کلید **عمومی** پیشنمایش CI (SHA پینشده) برای ساخت خروجی امضاشده و قابل نصب بدون Secret؛ مناسب Play نیست |
| `CHANGELOG.md` | تغییرات نسخهٔ 1.9.0 و فاز تکمیلی |
| `PROJECT_REVIEW_FA.md` / `FINAL_IMPLEMENTATION_REPORT_FA.md` | ممیزی تاریخی و گزارش نهایی |

## اجرا

```bash
bash tools/run-all-checks.sh
./gradlew :app:lintDebug :app:testDebugUnitTest :app:assembleDebug
```

دستور نخست به JDK و `javac` نیاز دارد، ولی به Android SDK وابسته نیست: کامپایل JVM، ۱۱ مجموعه تست، ۳۴ رگرسیون JUnit، ۱۰ fixture ناشناس × ۱۳۲ بررسی، گراف ۵۰ فایل منبع XML، ۴ جدول فونت sfnt، ماتریس پذیرش ۵۰ ردیفی، کنتراست و قراردادهای معماری/UI را اجرا میکند. دستور دوم به JDK 17، Android SDK Platform 36 و Build Tools 35.0.0 نیاز دارد و در CI اجرا میشود. نسخهٔ محلی `versionCode=1` است؛ انتشار محافظتشده `BH_VERSION_CODE` را از `github.run_number` میگیرد، آن را در برابر آخرین Release بررسی میکند و **همیشه** APK را امضا و با `apksigner` تأیید مینماید: با چهار Secret کلید خصوصی تولیدی، و در غیر اینصورت کلید عمومی پیشنمایش (`ci-preview.p12`).

برای پذیرش دستگاهی:

```bash
python3 tools/device-acceptance/acceptance_matrix.py --template > results.csv
python3 tools/device-acceptance/acceptance_matrix.py results.csv
./gradlew :app:connectedDebugAndroidTest
```

## امنیت، حریم خصوصی و سیاست Play

- هیچ مجوز `INTERNET`، `allowBackup` یا ترافیک متنی آشکار در برنامه وجود ندارد.
- سرویس Accessibility با `packageNames` فقط به اپراتورهای پیکربندیشده محدود میشود؛ swipe تنها با پنجرهٔ فعال همان اپراتور و پس از تأیید صریح صفحه انجام میشود.
- افشای برجستهٔ جداگانه در شروع عادی برنامه نمایش داده میشود؛ دکمهٔ ادامه تنها پس از تیک `CheckBox` فعال میشود. رضایت نسخهدار در `Cfg` ذخیره میشود و `ScanService.startFull`/`confirmFull` بدون آن `ABORT` میدهند. `isAccessibilityTool` اعلام نشده است.
- متن خام صفحه ذخیره نمیشود. خروجی CSV و `diag.txt` فقط با تأیید صریح کاربر و پس از ناشناسسازی شماره/ایمیل/UUID/شناسههای بلند ساخته میشود.
- اسکن کامل فقط پس از بازکردن اپراتور و تأیید صفحهٔ بستهها آغاز میشود؛ «اسکن مجدد» هرگز بهطور خودکار تأیید نمیشود. `ScanStateMachine` تنها مرجع وضعیت است.

## ناوبری برگشت

`MainActivity` از `androidx.activity.ComponentActivity` و `OnBackPressedDispatcher` استفاده میکند. ژست پیشبینانهٔ برگشت در Android 16 ابتدا اسپلش یا تب جاری را میبندد و سپس برنامه را ترک میکند؛ متد منسوخشدهٔ `onBackPressed()` دیگر بهکار نمیرود.

## انتشار امضاشده و قابل نصب

`app-release-unsigned.apk` دیگر منتشر نمیشود. `app/build.gradle` در نبود `keystore.properties` ساخت `assembleRelease` را متوقف میکند و workflow محافظتشده:

1. بسته به وجود چهار Secret، `keystore.properties` را از کلید خصوصی یا از `ci-preview.properties.example` میسازد؛
2. خروجی `*unsigned*` یا بیش از یک APK را رد میکند؛
3. امضا را با `apksigner verify --verbose` تأیید مینماید؛
4. فایل را با نام `Bastehyab-1.9.0-<code>-release.apk` (تولیدی) یا `Bastehyab-1.9.0-<code>-preview-sideload.apk` (پیشنمایش عمومی) بههمراه `version-code.txt`، `apk-sha256.txt` و `signing-info.txt` منتشر میکند.

> ⚠️ `ci-preview.p12` عمداً **عمومی** است تا CI بدون هیچ رمزی خروجی قابل نصب بسازد. نسخههای `-preview-sideload.apk` فقط برای تست و نصب دستیاند و نباید در Play یا بهعنوان انتشار رسمی توزیع شوند. جزئیات و مسیر تولیدی در `RELEASE_SIGNING_FA.md`.

## محدودیت اعتبارسنجی

تست زندهٔ پنج اپراتور، instrumentation روی دستگاه، **کلید خصوصی تولیدی**، اعلام Play Console و ویدئوی نمایش افشا در محیط توسعهٔ محلی/سندباکس انجام نشده است؛ پروتکل، ماتریس، افشا، قفل رضایت، امضای همیشهفعال و تأیید `apksigner` در CI آمادهاند. AAPT/Lint/APK، ساخت APK امضاشده و تأیید `apksigner` توسط workflow روی `ubuntu-latest` و در **همین push** اجرا میشوند؛ artifact نصبپذیر `installable-release-preview-<run>` قابل دانلود است. فقط مرحلهٔ محافظتشدهٔ **انتشار** مختص `main` است. جزئیات در `NEXT_STEPS_CHECKLIST_FA.md` و `FINAL_IMPLEMENTATION_REPORT_FA.md`.

</div>
