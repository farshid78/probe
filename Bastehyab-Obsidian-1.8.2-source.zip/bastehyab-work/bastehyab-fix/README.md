<div dir="rtl">

# بسته‌یاب | راهنمای توسعهدهندگان — نسخهٔ 1.9.0

این دایرکتوری محتوای `Bastehyab-Obsidian-1.8.2-source.zip` است. نام آرشیو تاریخی است، ولی **نسخهٔ برنامه 1.9.0** و تنها مرجع متادیتای جاری `app/build.gradle` است.

## ساختار

| مسیر | محتوا |
|---|---|
| `app/src/main/java/app/bastehyab/` | سورس Java شامل سرویس دسترسی، parser، مقایسه، ذخیره و رابط نئومورفیک |
| `app/src/main/res/` | ۴۰۱ رشته، تمهای روشن/تاریک/تکرنگ، ابعاد، آیکونها، فونتها و پیکربندی سرویس |
| `app/src/test/` | رگرسیونهای JUnit |
| `gradle/`, `gradlew`, `build.gradle`, `settings.gradle` | wrapper رسمی Gradle 8.13، AGP 8.11.1 و API 36 |
| `tools/` | تستهای JVM، تولیدکنندهٔ stub منابع، بررسی کنتراست و قراردادهای UI |
| `branding/` | منابع هویت بصری و تصاویر مرجع |
| `docs/history/` | بایگانی مستندات و نسخههای 1.2.2 تا 1.8.2؛ مرجع نسخهٔ جاری نیستند |
| `CHANGELOG.md` | تغییرات نسخهٔ 1.9.0 |
| `PROJECT_REVIEW_FA.md` | ممیزی تاریخی ۸۸ یافته |
| `FINAL_IMPLEMENTATION_REPORT_FA.md` | نتیجهٔ پیادهسازی و محدودیتها |

## اجرا

```bash
bash tools/run-all-checks.sh
./gradlew :app:lintDebug :app:testDebugUnitTest :app:assembleDebug
```

دستور نخست به JDK و `javac` نیاز دارد، ولی به Android SDK وابسته نیست: کامپایل JVM، هفت مجموعه تست، ۱۷ رگرسیون JUnit، کنتراست و قراردادهای منابع/UI را اجرا میکند. دستور دوم به JDK 17، Android SDK Platform 36 و Build Tools 35.0.0 نیاز دارد و در CI اجرا میشود. نسخهٔ محلی `versionCode=1` است؛ انتشار محافظتشده تنها با `BH_VERSION_CODE` بزرگتر از آخرین Release و `keystore.properties` کامل امضا میشود.

## امنیت و حریم خصوصی

- هیچ مجوز `INTERNET`، `allowBackup` یا ترافیک متنی آشکار در برنامه وجود ندارد.
- سرویس Accessibility با `packageNames` فقط به اپراتورهای پیکربندیشده محدود میشود؛ swipe تنها با پنجرهٔ فعال همان اپراتور انجام میشود.
- متن خام صفحه ذخیره نمیشود. خروجی CSV و `diag.txt` فقط با تأیید صریح کاربر و پس از ناشناسسازی شماره/ایمیل/UUID/شناسههای بلند ساخته میشود.
- اسکن کامل فقط پس از بازکردن اپراتور و تأیید صفحهٔ بستهها آغاز میشود؛ «اسکن مجدد» هرگز بهطور خودکار تأیید نمیشود.

## ناوبری برگشت

`MainActivity` از `androidx.activity.ComponentActivity` و `OnBackPressedDispatcher` استفاده میکند. ژست پیشبینانهٔ برگشت در Android 16 ابتدا اسپلش یا تب جاری را میبندد و سپس برنامه را ترک میکند؛ متد منسوخشدهٔ `onBackPressed()` دیگر بهکار نمیرود.

## محدودیت اعتبارسنجی

تست زندهٔ پنج اپراتور، AAPT/Lint/APK و بررسی Play روی دستگاه/شبیهساز در محیط توسعهٔ محلی انجام نشده است؛ workflow ریشهٔ مخزن این مراحل را اجرا میکند. برای پذیرش نهایی، خروجی CI و fixture نسخهدار هر اپراتور نیز لازم است. جزئیات در `FINAL_IMPLEMENTATION_REPORT_FA.md`.

</div>
