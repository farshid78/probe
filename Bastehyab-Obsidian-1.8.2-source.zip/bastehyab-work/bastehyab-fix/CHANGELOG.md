# Changelog

## 1.9.0 — 2026-11-11 (remediation phase)

- Added the 11-item `NEXT_STEPS_CHECKLIST_FA.md` and completed stages 1–7: versioned operator fixture corpus, field-level evidence/confidence, price-policy UI and unified VAT/cost arithmetic, a full transition-driven `ScanStateMachine`, `RecyclerView`/`DiffUtil`/`ViewModel`/`LiveData` comparison list, instrumentation tests, explicit AAPT/font/monochrome validation, and extracted `provider`/`diagnostics` packages with `ARCHITECTURE_FA.md`.
- Added `RecyclerView`-row reuse, `CompareRowView`, `CompareAdapter`, `CompareViewModel`, `OperatorLogo`, and removed the old 80-row programmatic loop and inner logo class.
- Added `tools/resource-validation/` (50 XML resources, 4 sfnt font tables, monochrome adaptive icon, API 24–25 fallbacks) and wired it into both the JVM entry point and CI workflow.
- Added `app/src/androidTest/` instrumentation tests and `androidx.test:core:1.6.1`; documented `connectedDebugAndroidTest`.
- Added `tools/device-acceptance/` with a 50-row five-operator/two-API acceptance matrix that rejects empty, incomplete, FAIL or BLOCKED results; real-device runs remain external.
- Fetched the official Play AccessibilityService policy and added `PLAY_POLICY_AUDIT_FA.md`, a separate prominent in-app disclosure with an affirmative checkbox, versioned consent in `Cfg`, and gates in `ScanService.startFull`/`confirmFull`. `isAccessibilityTool` is intentionally not declared.
- Added optional signed-release support to the protected workflow via `KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`, with an `always` cleanup step; documented in `RELEASE_SIGNING_FA.md`. The published APK remains unsigned until those secrets are configured.
- Grew the plain-JVM suite to 10 harnesses and 34 JUnit regressions; 412 string resources now resolve, all fixture/corpus/resource/contrast/layout contracts pass, and root/in-ZIP workflow copies are identical.

## 1.9.0 — 2026-11-11

- Unified source, build, CI and runtime metadata on version 1.9.0, API 36, AGP 8.11.1 and the official Gradle 8.13 wrapper.
- Rewrote the single source archive and removed duplicate extracted source/workflows from the repository root; CI now extracts the ZIP into `bastehyab-work/bastehyab-fix`.
- Added one SHA-pinned, least-privilege workflow with JVM checks, Lint, JUnit, Debug APK and a protected monotonic release path.
- Fixed VAT double-taxation, grouped-number parsing, manual-review freshness, the fourth per-GB-month metric, CSV audit fields and 0→positive history.
- Added field-level VAT evidence, stable structural package keys, three-year validity, stale/ambiguous indicators and explicit export redaction/confirmation.
- Hardened storage with atomic staged backups, retryable recovery, bounded timestamp writes and a monotonic data revision.
- Restricted accessibility events and gestures to the configured operator; added typed scan phases, viewport-scoped scroll metrics, 64-bit fingerprints and current-viewport progress.
- Reworked the overlay: bounded/scrollable content, rotation handling, stable auto-hide deadline, accessible icons, explicit restart confirmation and foreground gesture guard.
- Replaced endless backdrop animation with a deterministic static cyber network; added WCAG-checked themes, 12sp/48dp controls, themed dialogs, scrollable metric chips, skippable splash, form-state restoration, numeric keyboards and two-stage Back via AndroidX `OnBackPressedDispatcher` (predictive-back safe on API 36).
- Fixed Android Lint `GestureBackNavigation` and `NewApi` errors: predictive back now uses `OnBackPressedDispatcher`, API 33/27 attributes are scoped with `tools:targetApi`, and the duplicate API 33 style item was removed.
- Fixed the protected release workflow: `gh api` now receives `GH_TOKEN`, and paginated release JSON is merged with `jq -s` before the monotonic version-code check.
- Migrated 401 UI strings to XML, added `S`/`R` JVM doubles, 17 JUnit regressions and seven plain-JVM test suites.

Historical reports and changelogs from 1.2.2–1.8.2 were moved to `docs/history/` and are not version metadata for the current build.
