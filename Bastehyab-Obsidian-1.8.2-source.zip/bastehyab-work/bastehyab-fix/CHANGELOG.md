# Changelog

## 1.9.0 — 2026-11-11

- Unified source, build, CI and runtime metadata on version 1.9.0, API 36, AGP 8.11.1 and the official Gradle 8.13 wrapper.
- Rewrote the single source archive and removed duplicate extracted source/workflows from the repository root; CI now extracts the ZIP into `bastehyab-work/bastehyab-fix`.
- Added one SHA-pinned, least-privilege workflow with JVM checks, Lint, JUnit, Debug APK and a protected monotonic release path.
- Fixed VAT double-taxation, grouped-number parsing, manual-review freshness, the fourth per-GB-month metric, CSV audit fields and 0→positive history.
- Added field-level VAT evidence, stable structural package keys, three-year validity, stale/ambiguous indicators and explicit export redaction/confirmation.
- Hardened storage with atomic staged backups, retryable recovery, bounded timestamp writes and a monotonic data revision.
- Restricted accessibility events and gestures to the configured operator; added typed scan phases, viewport-scoped scroll metrics, 64-bit fingerprints and current-viewport progress.
- Reworked the overlay: bounded/scrollable content, rotation handling, stable auto-hide deadline, accessible icons, explicit restart confirmation and foreground gesture guard.
- Replaced endless backdrop animation with a deterministic static cyber network; added WCAG-checked themes, 12sp/48dp controls, themed dialogs, scrollable metric chips, skippable splash, form-state restoration, numeric keyboards and two-stage Back via AndroidX `OnBackPressedDispatcher` (predictive-back safe on API 36).
- Fixed Android Lint `GestureBackNavigation` and `NewApi` errors: predictive back now uses `OnBackPressedDispatcher`, API 33/27 attributes are scoped with `tools:targetApi`, and the duplicate API 33 style item was removed.
- Fixed the protected release workflow: `gh api` now receives `GH_TOKEN`, and paginated release JSON is merged with `jq -s` before the monotonic version-code check.
- Migrated 401 UI strings to XML, added `S`/`R` JVM doubles, 17 JUnit regressions and seven plain-JVM test suites.

Historical reports and changelogs from 1.2.2–1.8.2 were moved to `docs/history/` and are not version metadata for the current build.
